[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=1&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=1&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Promotion Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=1)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=1&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=1&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=1&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=1&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=1&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=1&version=3)


# Academic Promotion Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=1&version=3#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=1&version=3#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=1&version=3#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=1&version=3#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=1&version=3#major1)
  * [Schedule and Eligibility](https://policies.rmit.edu.au/document/view.php?id=1&version=3#major2)
  * [Appeals](https://policies.rmit.edu.au/document/view.php?id=1&version=3#major3)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=1&version=3#major4)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=1&version=3#major5)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=1&version=3#section5)
  * [Section 6 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=1&version=3#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This policy provides promotion pathways for RMIT to recognise and reward the achievements of academic staff who demonstrate:
  1. sustained excellence in performance across the domains of academic activity outlined in the [Enterprise Agreements](https://policies.rmit.edu.au/download.php?id=5&version=5&associated)
  2. ongoing and positive contribution to the achievement of RMIT’s vision and strategic goals
  3. workplace behaviours that reflect the RMIT values, equity principles and ethical standards.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=1&version=3#document-top)
# Section 2 - Overview
(2)  The policy provides the framework and principles underpinning the promotion of eligible academic staff by:
  1. ensuring an effective and efficient process which is fair and equitable
  2. providing a single, promotions cycle with the flexibility of out-of-round promotions when required
  3. recognising a broad definition of academic contribution that allows for diversity in talents and achievement, and flexibility in career paths
  4. providing clear information responding to the criteria against which promotion applications are considered
  5. providing an avenue for staff to have promotion decisions reviewed
  6. fostering a culture of performance excellence.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=1&version=3#document-top)
# Section 3 - Scope
(3)  This policy applies to full-time, part-time, continuing or fixed term academic staff employed by RMIT University and RMIT Vietnam who meet the prescribed eligibility requirements for academic promotion.
(4)  This policy does not apply to casual academic staff, vocational educational or professional staff.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=1&version=3#document-top)
# Section 4 - Policy
### Principles
(5)  RMIT commits to a fair, transparent and consistent promotions framework.
(6)  The promotions framework is based on:
  1. objective determinations, with decisions based on evidence of achievement and impact at RMIT
  2. equal promotion opportunity for all staff that does not discriminate on the grounds of gender, pregnancy, ethnicity, marital status, disability, sexual preference, transgender status, political or religious beliefs, or age
  3. due recognition of the diversity of academic roles, practice and career trajectories
  4. assessment of Achievement Relative to Opportunity through consideration of fractional appointments and other work circumstances, personal circumstances, or both
  5. alignment with the RMIT strategy.


(7)  RMIT will ensure information to support applicants for academic promotion is clear, current and relevant.
### Schedule and Eligibility
(8)  Opportunity for academic promotion will be:
  1. available for applicants to level B at any time
  2. run for academic levels C, D and E and structured to enable the announcement of promotions effective as of 1 January of the following year
  3. permitted outside of the scheduled promotion round only in exceptional circumstances.


(9)  Unless an exemption has been granted under the relevant procedure, academic staff will not be eligible to apply for promotion in the year immediately following an unsuccessful application.
(10)  Promotion determinations are made to the level immediately above the applicant’s substantive classification.
(11)  In exceptional circumstances the Vice-Chancellor can approve a request for the relevant Academic Promotion Committee to consider an application for promotion to a level higher than the level immediately above the applicant’s substantive position.
### Appeals
(12)  Applicants may lodge an appeal against an application decision or a promotion outcome on the grounds specified in the [Academic Promotion Procedure - Appeals](https://policies.rmit.edu.au/document/view.php?id=5).
### Responsibilities
(13)  The Deputy Vice-Chancellor Education is responsible for:
  1. constituting the membership of all Academic Promotion Committees
  2. approving promotion recommendations put forward by the University Academic Promotion Committee.


(14)  The Chief People Officer is responsible for:
  1. approving procedures for academic promotion to levels B, C, D and E
  2. the provision of training in equal employment principles for all promotion committee members.


(15)  The University Academic Promotion Committee (UAPC) is responsible for:
  1. monitoring the promotion process with a view to ensuring fairness and compliance with the application of the policy and procedures
  2. analysing the promotion process with regard to academic quality standards and equal opportunity, including reviewing diversity of participation and achievement
  3. reviewing the promotion recommendations from the promotion committees and moderators
  4. reviewing this policy and related procedures as required and recommending any necessary changes to Academic Board.


(16)  Deputy Vice-Chancellors (or their nominated delegates) are responsible for reviewing and approving/denying requests from academic staff who wish to apply for promotion in the year immediately following an unsuccessful application.
### Review
(17)  This policy will be reviewed annually on completion of the promotion round in consultation with the Chief People Officer.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=1&version=3#document-top)
# Section 5 - Schedules
(18)  This policy includes the following schedule(s):
  1. [Schedule 1 – Academic Promotion Committees Schedule](https://policies.rmit.edu.au/download.php?id=337&version=5&associated)
  2. [Schedule 2 - University Academic Promotion Committee](https://policies.rmit.edu.au/download.php?id=3&version=4&associated)
  3. [Schedule 3 - University Academic Promotion Appeals Committee](https://policies.rmit.edu.au/download.php?id=4&version=4&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=1&version=3#document-top)
# Section 6 - Procedures and Resources
(19)  Refer to the following documents which are established in accordance with this Policy:
  1. [Academic Promotion Procedure - Level B](https://policies.rmit.edu.au/document/view.php?id=2.1.1)
  2. [Academic Promotion Procedure - Levels C, D and E](https://policies.rmit.edu.au/document/view.php?id=3)
  3. [Academic Promotion Procedure - Appeals](https://policies.rmit.edu.au/document/view.php?id=5)
  4. [Academic Promotion Procedure - Out of Round](https://policies.rmit.edu.au/document/view.php?id=4.1.1)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
