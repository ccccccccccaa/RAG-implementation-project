[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=118&version=4#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=118&version=4#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Refund of Fees Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=118)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=118&version=4)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=118&version=4)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=118&version=4)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=118&version=4)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=118&version=4)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=118&version=4)


# Refund of Fees Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=118&version=4#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=118&version=4#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=118&version=4#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=118&version=4#section4)
  * [Eligibility for a Refund](https://policies.rmit.edu.au/document/view.php?id=118&version=4#major1)
  * [Appeal of a Refund Decision](https://policies.rmit.edu.au/document/view.php?id=118&version=4#major2)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=118&version=4#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure describes the rules for students seeking a refund of a credit balance in their student account and appealing a refund assessment decision.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=118&version=4#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=118&version=4#document-top)
# Section 3 - Scope
(3)  This procedure applies to programs delivered by RMIT, and excludes programs delivered in partnership with other education providers.
(4)  For students who also hold an enrolment with a partner institution, the policy and processes of the partner institution on refund of fees and remission of debt apply.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=118&version=4#document-top)
# Section 4 - Procedure
### Eligibility for a Refund
(5)  The [Approved Schedule of Fees and Charges](https://policies.rmit.edu.au/download.php?id=128&version=1&associated) outlines all fees that may be charged by RMIT for enrolment or other engagement with RMIT.
(6)  Eligibility for a refund is determined with reference to the [Approved Schedule of Fees and Charges](https://policies.rmit.edu.au/download.php?id=128&version=1&associated).
(7)  Where a student’s request for a refund of fees is denied the response will state the reasons for the decision and advise of the right to appeal.
  1. Enrolled students considering appealing a refund decision are advised to contact the RMIT University Student Union (RUSU) Student Rights team for advice


(8)  Students who wish to apply for a refund or appeal a refund decision must follow this procedure and the processes published by the Academic Registrar.
### Appeal of a Refund Decision
(9)  The following students can appeal a decision not to refund fees and/or the refund amount for courses undertaken in the first six months of study at RMIT:
  1. a commencing international student studying in Australia on student visa
  2. a domestic student studying an ELICOS course offered by RMIT University Pathways (RMIT UP) in Australia.


(10)  Students must have received written advice of the outcome of their refund application before lodging an appeal against a refund assessment decision.
  1. International students may submit an appeal in writing, within 20 working days of the original refund outcome being sent to the student.
  2. Appeals will be considered by the following: 
    1. for RMIT Vietnam, Academic Registrar, or nominee
    2. for RMIT University, the Director, Global Student Recruitment. 
  3. Appeals are only considered if the student: 
    1. provides evidence that the institution has made an error in process that has been a significant factor in the decision; and/or
    2. provides evidence that significant circumstances have not been taken into account; and/or
    3. provides new, relevant evidence that was not available at the time of the decision, which would have been a significant factor in the decision.
  4. International students who are dissatisfied with the outcome of an appeal against a refund assessment decision may apply for external review of the decision by: 
    1. [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=2&associated) for vocational eduation students
    2. the [National Student Ombudsman](https://www.nso.gov.au/) for higher education students.
  5. Domestic students who are dissatisfied with a decision not to refund fees may seek review of the decision by the: 
    1. [National Student Ombudsman](https://www.nso.gov.au/) for higher education students
    2. [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=2&associated) for vocational education students.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=118&version=4#document-top)
# Section 5 - Resources
(11)  Refer to the following documents which are established in accordance with this procedure:
  1. Credit balance and refunds
  2. Application for a refund form
  3. Refunds for Commencing or Newly Enrolled International Students


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
