[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=252#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=252#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course External Referencing and Benchmarking Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=252)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=252)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=252)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=252)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=252)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=252)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=252)


# Program and Course External Referencing and Benchmarking Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=252#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=252#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=252#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=252#section4)
  * [General Standards](https://policies.rmit.edu.au/document/view.php?id=252#major1)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=252#section5)
  * [Section 6 - Resources](https://policies.rmit.edu.au/document/view.php?id=252#section6)
  * [Section 7 - Definitions](https://policies.rmit.edu.au/document/view.php?id=252#section7)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure outlines RMIT’s approach to benchmarking and external referencing of programs and courses.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252#document-top)
# Section 3 - Scope
(3)  This procedure applies to all accredited higher education award programs and courses offered by the RMIT Group, partners and affiliated third-parties.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252#document-top)
# Section 4 - Procedure
### General Standards
(4)  RMIT meets its legislative requirements and ensures institutional quality assurance by performing external referencing and benchmarking activities as a core component of the program and course monitoring, review, and improvement activities. The Centre for Education, Innovation and Quality (CEIQ) leads RMIT’s external referencing responsibilities and is responsible for the processes and practices supporting academic quality assurance.
(5)  External referencing is the process where a higher education provider compares an aspect of its operations with an external comparator.
(6)  External referencing and benchmarking activities for courses are managed by course coordinators under the direction of Program Managers. Program Managers reflect outside their programs to inform the design, content, and relevance of learning as part of the Comprehensive Program Reviews (CPR) and ongoing course monitoring. 
#### Comprehensive and Annual Program Reviews
(7)  The outcomes of External Referencing and Benchmarking are reported on in Comprehensive Program Reviews. Please refer to the [Program and Course Review Procedure](https://policies.rmit.edu.au/document/view.php?id=39).
(8)  RMIT’s prescribed reference points for external referencing are set out in the [RMIT Comprehensive Program Review Terms of Reference](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/ToR%20Program%20Reviews.aspx).
#### Internal and External Referencing and Benchmarking
(9)  Broad types of benchmarking that must be reported on in Comprehensive Program Reviews include:
  1. program or course internal benchmarking of program or course design and student performance
  2. external outcome benchmarking, relating to the comparison of outcomes data, especially student outcomes such as attrition, progression, and completion rates
  3. external cohort analysis of student performance data
  4. external industry engagement and consultation aligning with best practices.


(10)  Program teams may also report on:
  1. internal process benchmarking involving comparisons of processes and practices, for example, of cycle times, efficiency
  2. internal best-practice benchmarking, where RMIT selects an equivalent comparator considered to be at the forefront in the area to be benchmarked.


(11)  External referencing with peer review, moderation and validation enables alignment with the wider academic community and other higher education providers. Comparison of key program features include assessment methods and grading with competitive programs at local and international institutions.
(12)  External peer review reports must be provided as written evidence that meet the key criteria as detailed in the [External Peer Review Template](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/2022-External-Referencing-and-Benchmarking.aspx). Colleges are required to submit the report as evidence and reflection in the Comprehensive Program Review referring to external course referencing, including a copy of the written validation report. At the completion of all Comprehensive Program Reviews the reflection and outcomes of external referencing will be included in CEIQ’s subsequent report to Academic Board and its subcommittees.
(13)  Peer review and validation includes:
  1. analysis of competing programs’ curriculums
  2. approach to delivery
  3. program learning outcomes
  4. assessment methods
  5. grading guides.


(14)  Evidence from the following resources and activities can be provided with the CPR report to CEIQ, addressing the key criteria in the External Peer Review template:
  1. the use of assessment panels made up of external academic subject matter experts on final or milestone assessments (capstone or equivalent course/s)
  2. peer review portal – external academic review of final or milestone assessments (capstone or equivalent course/s)
  3. RMIT Network register provided by CEIQ – utilising the register of academic contacts from various fields of education as peer reviewers for external referencing and benchmarking
  4. Institutional partner options – utilising resources provided by CEIQ that are available on the [External Referencing and Benchmarking for Program Reviews](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/2022-External-Referencing-and-Benchmarking.aspx). Alternatively, Program Managers and college quality teams have the option to source external academic peers to review and provide reports on the capstone or equivalent course/s
  5. professional accreditation reports
  6. other methods that have addressed all key criteria in the External Peer Review Template and can be evidenced.


(15)  At the completion of all Comprehensive Program Reviews the reflection and outcomes of external referencing will be included in CEIQ’s subsequent report to Academic Board and its subcommittees.
#### Industry Advisory Committees and WIL Experiences
(16)  All RMIT programs must have an Industry Advisory Committee (IAC) to meet the RMIT threshold for external referencing and to facilitate regular communication between RMIT programs and their associated industries and communities. Industry Advisory Committees enable essential external referencing and help to maintain the programs' relevance and currency. The outcomes of IACs must be reported on in Comprehensive Program Reviews reports.
(17)  For further information on the formation and functionality of Industry Advisory Committees, refer to the [Industry Advisory Committee Guide for Program Reviews](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/IAC%20Instructional%20Guide.aspx?csf=1&web=1&e=sSX80y).
#### Industry Standards and Professional Accreditation
(18)  Program learning outcomes should be aligned to industry standards to evidence the quality and standing of the program. Programs that hold professional accreditation with peak industry bodies or organisations illustrate status, evidence and standing of professional accreditation. Professional accreditation that addresses all key criteria included in the External Peer Review Template can be used as evidence.
(19)  When reviewing a program or a course, coordinators can refer to industry and/or commission reports (i.e. Royal Commissions) on trends from industry and how these can be used to inform and validate course delivery. Aligning with the future ways of working with an industry program can offer an external evidence base as context for development and improvement which can positively impact student outcomes.
#### Student Feedback and Success
(20)  RMIT is committed to working with students to improve the quality of learning and teaching experiences. Student Staff Consultative Committees (SSCCs) are an RMIT requirement enabling students to provide feedback on their program to meet regulatory requirements. SSCCs empower students to provide real-time feedback, highlight best practice and have input into how their courses are taught and managed.
(21)  Guidance on the operational aspects of SSCCs can be found at the [Student Staff Consultative Committee resource page](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/SSCC%20Instructional%20Guide.aspx).
(22)  Program Managers and teams must demonstrate programs delivered in multiple locations and modes have mechanisms, practices, or processes in place to compare these measures across the different locations/modes. Best practice involves referencing the success of student cohorts against comparable courses of study within the program and across the discipline. This extends to the requirements of external referencing and benchmarking.
#### Program Enhancement Plans
(23)  Program Enhancement Plans (PEPs) are developed to apply improvements to programs following the submission of the Comprehensive Program Reviews. Annual Program Reviews include status updates which are completed by Program teams, led by Program Managers, and endorsed by Deans or Heads of School and College Associate Deputy Vice-Chancellors, Learning and Teaching (or equivalent). For further information on Program Enhancement Plans, refer to the [Program Enhancement Plan (PEP) for Program Reviews](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/Program-Enhancement-Plan-\(PEP\)-for-Program-Reviews.aspx).
(24)  Major actions coming out of feedback from external peer reviewer may be included as PEP goals in the Comprehensive Program Reviews. These goals are tracked and reported on in the Annual Program Reviews until resolution.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252#document-top)
# Section 5 - Schedules
(25)  The Program Review Schedule is reviewed and determined by College Quality teams and confirmed by Q1 of each cycle year. CEIQ maintains the schedule for monitoring and reporting.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252#document-top)
# Section 6 - Resources
(26)  [External Referencing and Benchmarking for Program Reviews](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/2022-External-Referencing-and-Benchmarking.aspx)
(27)  [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27)
(28)  [Program and Course Review Procedure](https://policies.rmit.edu.au/document/view.php?id=39)
(29)  [Program Reviews](https://rmiteduau.sharepoint.com/:u:/r/sites/EQ/SitePages/2022%20Program%20Reviews.aspx?csf=1&web=1&e=pANIQY)
(30)  [RMIT Comprehensive Program Review Terms of Reference](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/ToR%20Program%20Reviews.aspx)
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252#document-top)
# Section 7 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Benchmarking | The process of externally comparing aspects of educational practices within the organisation and other institutions. Benchmarking reveals skills, trends, emerging influences or changes in industry and scholarship that may validate or challenge program design or delivery.  
Capstone or Equivalent | Final year course/s that encompasses overall program learning outcomes.  
Moderation | Moderation refers to the process of ensuring that assessments are marked fairly, consistently, and equitably across different courses, programs and/or institutions. Moderation of assessment processes establish comparability of standards of student performance across, for example, different markers, locations, subjects, providers and/or courses of study.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
