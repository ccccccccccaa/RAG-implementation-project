[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=244&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=244&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Approval Procedure - Higher Education Coursework, Short Courses and Micro-credentials 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=244)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=244&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=244&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=244&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=244&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=244&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=244&version=1)


# Program and Course Approval Procedure - Higher Education Coursework, Short Courses and Micro-credentials
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=244&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=244&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=244&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=244&version=1#section4)
  * [Program Lifecycle – Higher Education Coursework Programs](https://policies.rmit.edu.au/document/view.php?id=244&version=1#major1)
  * [Program and Program Plan Discontinuation](https://policies.rmit.edu.au/document/view.php?id=244&version=1#major2)
  * [Course Lifecycle – Higher Education Coursework Programs](https://policies.rmit.edu.au/document/view.php?id=244&version=1#major3)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=244&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=244&version=1#section6)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure sets the requirements for higher education coursework program and course approval, delivery and discontinuation. It sets the approval requirements for short courses and micro-credentials that are not delivered by RMIT Training or as a vocational education and training product, that may be embedded as part of an award program or offered to learners independently of an award program.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=244&version=1#document-top)
# Section 2 - Authority
(2)  The authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=244&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all higher education coursework programs and courses offered by the RMIT Group, partners and affiliated third parties.
(4)  This procedure governs approvals for:
  1. higher education coursework programs
  2. higher education coursework courses
  3. short (non-award) courses, and
  4. micro-credentials


(5)  This procedure does not apply to non-award Foundation Studies, ELICOS and RMIT English programs which are delivered in accordance with the relevant national standards and RMIT Training.
(6)  This procedure does not apply to vocational education and training or Higher Degrees by Research programs and courses (please see [Program and Course Approval Procedure - Vocational Education and Training](https://policies.rmit.edu.au/document/view.php?id=207) and [Program and Course Approval Procedure - Higher Degree by Research](https://policies.rmit.edu.au/document/view.php?id=205)).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=244&version=1#document-top)
# Section 4 - Procedure
(7)  The program and course approval authorities are provided in the [Program and Course Schedule – Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=4&associated).
(8)  The academic and business case for new program proposals must be compliant with the requirements of the [Higher Education Standards Framework (Threshold Standards) 2021](https://policies.rmit.edu.au/directory/summary.php?legislation=44).
(9)  The academic case for all new programs must provide evidence:
  1. of how the conceptual framework underpins curriculum design and delivery
  2. of how the program design will enable graduates to meet the requirements of the professional accreditation body where programs are professionally accredited or will seek an accreditation status
  3. of how the owning college demonstrates adequate expertise and capacity for curriculum design, delivery and student support throughout the program duration
  4. that staff with responsibilities for academic oversight, teaching and assessment in the program or component of the program have: 
    1. recent scholarship and/or practice in the discipline field of delivery
    2. a qualification in a relevant discipline at least one level higher than the award level of the program or equivalent academic and/or professional experience
  5. that university learning resources and educational support are appropriate to the discipline area, and to the student cohort that will be accepted into each intake. 


(10)  The academic case for all new programs, offerings, change of titles and major amendments must provide evidence of: 
  1. external referencing and/or benchmarking of the program learning outcomes 
  2. internal referencing and/or benchmarking of the program learning outcomes
  3. outcomes of review cycles, where appropriate 
  4. student feedback and/or consultation as part of program development 
  5. industry consultation with relevance to student career pathways
  6. industry co-design with relevance to Industry Partnered Learning program elements
  7. appropriate staff consultation, particularly pertaining to cross-disciplinarity offerings. 


(11)  Where a new program or new offering proposes to establish a new program title, the academic case must provide evidence that the proposed title: 
  1. accurately conveys the type of award at the appropriate [Australian Qualifications Framework (AQF)](https://policies.rmit.edu.au/download.php?id=18&version=2&associated) level in accordance with the [Australian Qualifications Issuance Policy](https://policies.rmit.edu.au/download.php?id=407&version=1&associated)
  2. delineates a new disciplinary field in the RMIT programs suite 
  3. aligns with RMIT’s profile and strategy 
  4. accurately represents the curriculum content 
  5. is meaningful and relevant in the long term and across global locations 
  6. is consistent with national, international and professional standards. 


(12)  The academic case must define the academic and other inherent requirements, to provide assurance that: 
  1. prospective and current students can make an informed decision as to whether they can complete the program
  2. discussions with students about reasonable adjustments to accommodate disability or long-term physical or mental health conditions are based on a clear definition of the program’s inherent requirements, and
  3. all decisions governing the blend of learning, including model, timing and mode of delivery, are appropriate to the student cohort.


(13)  A new or amended program or program offering can only be advertised or commence delivery once approval has been provided in accordance with the RMIT authorities defined in the [Program and Course Schedule – Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=4&associated).
(14)  A new program or program offering:
  1. requiring Australian Commonwealth financial support under the [Higher Education Support Act 2003](https://policies.rmit.edu.au/directory/summary.php?legislation=21) can only commence delivery once it has been registered with the Commonwealth Government
  2. intended to be available to students on a student visa can only proceed with advertisement, enrolment and/or delivery to international students once it has been issued a CRICOS code
  3. required to be registered with any offshore regulator of tertiary education programs can only proceed with advertisement, enrolment and/or delivery once it has been registered.


(15)  An RMIT program must be delivered in English before it is offered in another language so learning and assessment materials can be aligned with internal and external compliance standards before they are translated.
  1. RMIT programs that are delivered and assessed in a language other than English must be approved by the Academic Board.


(16)  Administrative programs/plans are programs for non-standard enrolment scenarios that cannot be covered by any other program. They may be created at the discretion of the Academic Registrar's Group by either a college request or request from within the Academic Registrar's Group. Examples of administrative programs include, but are not limited to:
  1. foreign exchange programs
  2. single course non-award programs
  3. cross-institutional programs.


### Program Lifecycle – Higher Education Coursework Programs
#### Program Proposals
(17)  Program and program plan amendments that require establishment and approval as a new program and a new CRICOS registration include:
  1. changes to the program volume of learning
  2. changes to the primary field of study
  3. changes to the program AQF, and/or
  4. significant changes to the program learning outcomes.


(18)  Program development and amendment timelines must align with deadlines published in the Academic Registrar's Group program submissions calendar and must consider academic calendars of all program locations and modalities.
  1. ARG Academic Governance must be contacted for advice where dates do not align with published calendar dates.


(19)  All program proposal academic cases requiring Programs Committee endorsement or approval must:
  1. be written in accordance with the [Program Proposals Checklist](https://rmiteduau.sharepoint.com/sites/HEProgramApprovals/Guidance%20Material/Forms/AllItems.aspx)
  2. receive academic scrutiny and endorsement via the owning college internal governance committee, the owning college must consult with the higher education college owning the destination Bachelor award and/or same discipline area if the proposal is for a Higher Education Diploma and/or Associate Degree award
  3. be endorsed by the owning College Deputy Vice-Chancellor prior to submission to the Programs Committee
  4. be reviewed by the Program Quality Advisory Panel in accordance with the Program Quality Advisory Panel Terms of Reference.


(20)  New programs and new offerings of an existing program must complete an Academic Case Form as part of the academic case submission.
(21)  Where program elements such as courses, majors or minors are included in the program structure that is owned by a different college to the program owner, the academic case must evidence endorsement by the College Associate Deputy Vice-Chancellor Learning and Teaching (or delegate) that owns the program element/s.
(22)  For a double degree offered through more than one college, any proposal to establish, amend or discontinue a program requires endorsement from both College Deputy Vice-Chancellors, and/or the RMIT Vietnam Education Committee and the Pro Vice-Chancellor, RMIT Vietnam where a component degree is delivered at RMIT Vietnam as per the [Program and Course Schedule – Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=4&associated).
(23)  The academic case for all program amendments, new programs, new offerings and discontinuations for delivery at RMIT Vietnam must be first endorsed by the RMIT Vietnam Education Committee and the Pro Vice-Chancellor, RMIT Vietnam prior to Programs Committee submission, or prior to College Deputy Vice-Chancellor approval where the amendment is minor.
(24)  The academic case for all program amendments, new programs, new offerings and discontinuations at a global education delivery partner location must be endorsed by the Deputy Vice-Chancellor International and Engagement prior to Programs Committee submission, or prior to College Deputy Vice-Chancellor approval where the amendment is minor.
(25)  The academic case for all program amendments, new programs, new offerings and discontinuations at RMIT Online must be endorsed by the RMIT Online Board and CEO, RMIT Online prior to Programs Committee submission, or prior to College Deputy Vice-Chancellor approval where the amendment is minor.
(26)  Program proposal endorsements may be arranged to occur concurrently where appropriate.
(27)  Where a program proposal involves a service teaching agreement outside the owning college, the proposal must confirm that a service teaching agreement is in place.
(28)  Where travel is a requirement for students to complete a program, the academic case must provide a rationale. When approved, the approximate travel costs must be stated prominently in all program information provided to applicants.
#### New Programs
(29)  The owning college submits the academic case to ARG Academic Governance for Program Quality Advisory Panel review.
(30)  Following Program Quality Advisory Panel review, ARG Academic Governance arranges submission of the academic case to the Programs Committee for endorsement, and to the Academic Board for approval.
(31)  The business case must be endorsed by the General Manager, College Operations (or equivalent) and approved by the College Deputy Vice-Chancellor before the academic case can progress to the Academic Board for approval.
#### Change of Program Title
(32)  The owning college submits the academic case for a change of program title to ARG Academic Governance for Program Quality Advisory Panel review.
(33)  Following Program Quality Advisory Panel review, ARG Academic Governance arranges submission of the academic case for a change of program title to the Programs Committee for approval, and to Academic Board for noting.
#### New Offering of an Existing Award Program at a Global Partner
(34)  Where a new offering of an existing award program is offered via a new global partnership:
  1. the partnership must undergo strategic assessment by the process set out under the [Global Partner Approval Process](https://rmiteduau.sharepoint.com/sites/GlobalHub/SitePages/Global%20Partnership%20Approval%20Process.aspx) before the first program to be offered at a new global partner or campus can be submitted for approval of the Higher Education Program Approval Template Part A by the College Deputy Vice-Chancellor
  2. colleges must engage with the Director Risk Management to undertake a risk assessment prior to submission of the academic case to Programs Committee for approval. The risk assessment is to be submitted with the academic case.


(35)  The owning college arranges endorsement of the academic case by the Deputy Vice-Chancellor and Vice-President - International and Engagement and submits it to ARG Academic Governance for Program Quality Advisory Panel review.
(36)  Following Program Quality Advisory Panel review, ARG Academic Governance arranges submission of the academic case to Programs Committee for approval, and to the Academic Board for noting.
(37)  The business case must be endorsed by the General Manager, College Operations (or equivalent) and approved by the College Deputy Vice-Chancellor before the academic case can progress to the Programs Committee for approval.
#### New Offering of an Existing Award Program at a Domestic Partner Institution or Third-Party Provider
(38)  Where the offering is a new domestic or third-party provider partnership:
  1. colleges must engage with the Director, Risk Management to undertake a risk assessment prior to submission of the academic case to the Programs Committee for approval. The risk assessment is to be submitted with the academic case.
  2. and the education provider is delivering an RMIT program as an onshore third-party provider, they must be a CRICOS registered institution if the program is CRICOS registered.


(39)  The owning college submits the academic case to ARG Academic Governance for Program Quality Advisory Panel review.
(40)  Following the Program Quality Advisory Panel review, ARG Academic Governance will arrange submission of the academic case to the Programs Committee for approval, and to Academic Board for noting.
(41)  The business case must be endorsed by the General Manager College Operations (or equivalent) and approved by the College Deputy Vice-Chancellor before the academic case can progress to the Programs Committee for approval.
#### Major Amendment to an Existing Program
(42)  A program amendment is considered major and may require the creation of a new plan where the proposal involves:
  1. an amendment to the program so substantial that a new plan is required for the purpose of transitioning or teaching out students
  2. program changes that require a new CRICOS registration on advice from Education Regulation Compliance and Assurance
  3. a program that contains more than 192 credit points (over two years volume of learning): 
    1. replacement or redesign of 33% or more of the total courses by credit point weight within a program, or
    2. replacement or redesign of 25% or more of the core courses by credit point weight within a program
  4. a program that contains 192 credit points or less (for example, graduate certificates, graduate diplomas, masters, HE diplomas, and associate degrees): 
    1. replacement or redesign of 50% or more of the total courses by credit point weight within a program, or
    2. replacement or redesign of 50% or more of the core courses by credit point weight within a program
  5. an amendment made to a program or plan structure, where the course structure has been amended for the third consecutive teaching semester
  6. a program change that a school or college foresees could impact external or professional accreditation status
  7. the creation of a new first-year block.


(43)  For major amendments where students are transitioned into a new or alternate plan, a program transition plan detailing course equivalencies and other transition arrangements must be included in the program guide.
(44)  For major amendments where students will be taught out in their existing plan, the program transition plan must provide teach out timelines in the program guide.
(45)  The owning college must submit the academic case to ARG Academic Governance for Program Quality Advisory Panel review.
(46)  Following the Program Quality Advisory Panel review, ARG Academic Governance will arrange submission of the academic case to the Programs Committee for approval.
#### Creation of a New Major or Minor
(47)  To foster program offerings of disciplinarity majors and minors, colleges may submit an academic case for Programs Committee approval of a new major or minor that is not part of an existing program structure.
(48)  The owning college submits the academic case to ARG Academic Governance for Program Quality Advisory Panel review.
(49)  Following the Program Quality Advisory Panel review, ARG Academic Governance will arrange the submission of the academic case to the Programs Committee for approval.
(50)  Once the new major or minor is approved, a program may undergo an amendment to include the major or minor in its structure by the approval pathway for a minor or major amendment.
#### Change to an Existing Major or Minor
(51)  Changes to disciplinarity minors are approved by the owning College Deputy Vice-Chancellor and submitted to the Programs Committee for noting.
(52)  Changes to courses in another existing major or minor of a program are assessed as a major or minor program amendment using criteria described in this procedure.
(53)  Changes to courses in an existing major or minor may require course equivalency mapping to be included in the program guide and/or the creation of a new program plan to ensure current students in the program can complete their major/minor sequence without incurring a disadvantage. These teach out and/or transition arrangements are to be determined in consultation with the ARG.
(54)  Changes to the title of an existing major are approved by the Programs Committee as a major program amendment.
(55)  Changes to the title of an existing minor are approved by the owning College Deputy Vice-Chancellor as a minor program amendment.
#### Removal of an Existing Major or Minor
(56)  Removal of a program major is approved by the Programs Committee as a major program amendment.
(57)  Removal of a program minor is approved by the owning College Deputy Vice-Chancellor as a minor program amendment.
#### Changes to Programs Offered via Partner Institutions Outside Australia
(58)  Proposed changes must be submitted via the college’s Associate Deputy Vice-Chancellor International office to the International and Engagement Portfolio who will perform an initial assessment to advise whether it may have implications for the partner agreement or foreign jurisdiction regulatory requirements.
(59)  If the change is assessed as having a potential impact to the partner agreement or foreign jurisdiction regulatory requirements, the Deputy Vice-Chancellor and Vice-President - International and Engagement will advise whether the proposal needs to be amended prior to submission for academic and business case approval.
(60)  If the change is assessed as having no impact on the partner agreement or foreign jurisdiction regulatory requirements, the approval follows the processes for a major or minor program amendment.
#### Minor Amendment to an Existing Program
(61)  A program change is considered minor where the proposal involves changes to data and attributes that are not configured in the student administration management system, or where the configuration changes are less than those defined under major amendments as outlined above.
(62)  A program change may be classified as a minor amendment where the change has a minimal effect on students and can be considered primarily administrative in nature.
(63)  A minor amendment to an existing program must be endorsed by the owning college governance committee and approved by the College Deputy Vice-Chancellor.
  1. If the proposal is for a Higher Education Diploma or Associate Degree award, the minor amendment must be consulted with the higher education college owning the destination Bachelor award or same disciple area as per above.


(64)  For minor amendments to a program structure, a program transition plan detailing course equivalencies must be included in the program guide.
### Program and Program Plan Discontinuation
(65)  Program or program plan discontinuation may be initiated:
  1. due to program review
  2. where the Academic Board has determined not to re-accredit a program
  3. where a program or offering is determined by the owning college to no longer be viable due to declining enrolments or commencements
  4. due to changes to professional accreditation
  5. due to a strategic or viability decision of the college executive leadership
  6. when being superseded by a new program or program plan.


(66)  Proposals to discontinue an existing higher education program are approved by the relevant College Deputy Vice-Chancellor.
  1. In the instance of combined or double degrees, approval must be obtained from each College Deputy Vice-Chancellor for the discontinuation to proceed.


(67)  If the proposal is for the discontinuation of a global partner program, the Deputy Vice-Chancellor International and Engagement must be consulted before the proposal is initiated.
(68)  If the proposal is for the discontinuation of a program offered at RMIT Vietnam, the Pro Vice-Chancellor, RMIT Vietnam and RMIT Vietnam Education Committee must be consulted before the proposal is initiated.
(69)  ARG Academic Governance submit an annual update to the Programs Committee and Academic Board documenting program discontinuations that have been approved.
(70)  Discontinued programs are eligible for inactivation when the program has no active enrolled students. Inactivating a program prevents any further enrolments in the student administration management system.
(71)  Each year, the Academic Registrar’s Group circulates to colleges a list of discontinued program plans (other than program plans that are in place to enable exit awards) that have no active students, seeking advice on which of these programs should be made inactive.
#### Program Discontinuations with Active Students
(72)  If the proposal involves a discontinuation with active students requiring a teach out of the program plan and associated courses and/or student transition plans, the teach out and/or transition plans must be approved by the Programs Committee before any communications can be sent to students.
(73)  The teach out and/or transition plan approved by the Programs Committee encompasses the academic case cover sheet template, discontinuation form, program guide with an updated transition text statement, and all student letter templates intended to communicate the discontinuation.
  1. Where enrolled students will be transitioned to a new program, or offered entry to a replacement program with credit, a transition map showing credit transfer between all old and new courses is required to be submitted as part of the proposal.


(74)  Separate letter templates must be drafted using the guidance templates for domestic, international onshore, leave of absence, Vietnam and/or global partner student cohorts, and for domestic applicants who have received a letter of offer, including packaged articulation offers.
  1. International Admissions will provide communications to international students who have applied and/or received an offer to study in a domestic program plan offering.


(75)  The academic case must:
  1. convey how the program integrity will be maintained during teach out
  2. address any implications for student progression in the program
  3. include a teach out timeline indicating the core and option courses that will be offered over the period of teach out if the students will be taught out
  4. demonstrate student course mapping and credit transfer arrangements where students will be transitioned into a replacement program.


(76)  In the instance of double degrees, a transition plan must consider the proper progression of each degree component and ensure that the courses contributing to each degree component are accounted for in the transition plan. 
(77)  The owning college submits the academic case to ARG Academic Governance for Program Quality Advisory Panel review.
(78)  Following Program Quality Advisory Panel review, ARG Academic Governance will arrange the submission of the academic case to Programs Committee for approval and Academic Board for noting.
(79)  Major amendments to discontinued programs can only be made by resubmitting the teach out plan to the Programs Committee for approval.
(80)  Proposals to discontinue programs, plans or offerings with active students must include teach out and/or transition plans which are designed with the following principles:
  1. A ‘No disadvantage’ approach, which allows students to complete their current program or transition to an equivalent award without the need to complete coursework exceeding the minimum requirements for the program. The ‘no disadvantage’ approach must be reflected in the text of the student letter templates.
  2. Students studying in Australia on a student visa must be supported to complete the award title provided in their Confirmation of Enrolment (CoE). For further guidance on where students on a student visa must be transitioned to a replacement award, please contact Education Regulation Compliance Assurance.
  3. Credit transfer mapping will be provided for students who will transition into a replacement or equivalent award. 
    1. Students must not be directed to repeat a course code for a course they have already successfully completed
    2. Replacement courses that transitioning students are advised to take must include new course content, assessment, and course learning outcomes from courses they have already successfully completed
    3. Where replacement courses or course changes are required for professional accreditation, exceptions can be approved by the Deputy Vice-Chancellor Education as part of the discontinuation proposal.
  4. Teach out plans must ensure, as much as possible, that students’ travel requirements to complete coursework are not increased during teach out. 
    1. This applies to all partners, campus locations and modalities.
    2. Exemptions for students to complete their studies at a Melbourne campus location that is different to the existing Melbourne campus location can be approved as part of the Programs Committee submission for approval of a teach out plan, provided sufficient evidence of student consultation is included in the submission.


### Course Lifecycle – Higher Education Coursework Programs
(81)  A college or school may cancel a course offering with insufficient enrolments for viability, provided that the students are offered enrolment in other courses that will count towards their completion of program requirements and their completion is not delayed.
  1. Cancellation must occur prior to the commencement of the class start date.
  2. Students must receive communications prior to the class start date with sufficient time and academic advice to change their course enrolment.
  3. Relevant endorsement must be obtained by the partner or owning entity prior to cancellation for courses delivered in partnership with a third-party provider.


#### Inactivating a Course
(82)  For a course to be eligible for inactivation as part of a regular course inactivation review:
  1. there must be no active classes for the course in the current semester
  2. there must have been no active classes for the course for the last three years
  3. the course must not be prescribed in any active program’s current or future program structures.


(83)  Even if a course fulfils all the above criteria, ARG Course and Program Administration may exempt some courses from being inactivated, such as transfer credit courses and administrative courses that are rarely scheduled.
#### Short Courses and Micro-credentials
(84)  RMIT short courses and micro-credentials are non-award courses that provide students the opportunity to quickly enhance professional skills, increase general knowledge in a chosen area, augment learning in their chosen discipline of study, or may offer students an approved credit or entry pathway into an award program of learning.
(85)  Students who complete an RMIT short course will be awarded an RMIT Certificate of Completion upon finishing the course.
(86)  Students who complete a micro-credential or RMIT Online short course will be awarded an RMIT digital badge upon completion.
#### Short Courses and Micro-credentials for Credit Stacking
(87)  Short courses, micro-credentials and/or single courses may be stacked for the purposes of credit transfer toward completion of an award program.
(88)  Sets of short courses, micro-credentials and/or single courses may be approved as a non-award recognition such as a VCE Extension program that may offer students a credit and/or articulation pathway to an RMIT award program.
(89)  Where sets of short courses and/or micro-credentials are designed with the intent of being the basis for credit transfer toward courses in an award program, this should be explicitly detailed in the academic case and course guides as part of the approval submission for the credit stacking framework. 
(90)  Credit transfer awarded for stacked short course and/or micro-credential combinations should not exceed the credit limits outlined in the [](https://policies.rmit.edu.au/document/view.php?id=37)[Credit Procedure](https://policies.rmit.edu.au/document/view.php?id=37) and [](https://policies.rmit.edu.au/document/view.php?id=129&version=2)[Articulation Agreements Guideline](https://policies.rmit.edu.au/document/view.php?id=129).
(91)  Credit stacking arrangements must be considered in the regular review of programs and courses, particularly where these arrangements have been designed for a specific program (or set of related programs).
(92)  Short courses and micro-credentials approved for credit stacking frameworks cannot be used to give credit to students studying in Australia on a student visa.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=244&version=1#document-top)
# Section 5 - Schedules
(93)  [Program and Course Schedule - Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=4&associated).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=244&version=1#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Credit stacking | A process in which recognised forms of learning, such as micro-credentials or short courses that have a smaller volume of learning than a 12-credit point course are ‘stacked’ together and exchanged for specified or unspecified credit transfer as a 12-credit point course in an award program structure.  
Cross-disciplinarity | Parallel study undertaken in two or more disciplines (for example, double major from two different disciplines).  
Disciplinarity |  Learning that spans more than one discipline. Cross-disciplinarity: Parallel study undertaken in two or more disciplines (e.g. double major from two diﬀerent disciplines) Inter-disciplinarity: Integrated study undertaken in two or more disciplines (e.g. combined degree) Trans-disciplinarity: Problem-based learning that spans two or more disciplines (e.g. combined degree with combined Industry Partnered Learning).  
First-year block | Courses that provide the foundational knowledge, skills and their application as required in a discipline or industry field of study for majors/minors to build from. See the Higher Education Program Design Procedure for a complete description of requirements.  
Offering | A program or course that will be offered at a specific location or via a specific delivery mode.  
Plan | A set of courses completed by a student in relation to a program; may represent an alternative version of the program available at the same time, or a significantly different version which has been or will be available at a different time  
VCE extension | A non-award program available to eligible Victorian Certificate of Education (VCE) students that consists of two undergraduate courses taken during the final year of VCE that counts towards a student ATAR.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
