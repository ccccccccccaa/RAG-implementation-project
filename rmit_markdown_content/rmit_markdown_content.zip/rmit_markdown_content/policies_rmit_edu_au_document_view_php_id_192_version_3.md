[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=192&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=192&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Higher Doctorate Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=192)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=192&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=192&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=192&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=192&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=192&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=192&version=3)


# Higher Doctorate Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=192&version=3#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=192&version=3#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=192&version=3#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=192&version=3#section4)
  * [Eligibility](https://policies.rmit.edu.au/document/view.php?id=192&version=3#major1)
  * [Application](https://policies.rmit.edu.au/document/view.php?id=192&version=3#major2)
  * [Candidature and Submission](https://policies.rmit.edu.au/document/view.php?id=192&version=3#major3)
  * [Rules for Submission](https://policies.rmit.edu.au/document/view.php?id=192&version=3#major4)
  * [Examination](https://policies.rmit.edu.au/document/view.php?id=192&version=3#major5)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=192&version=3#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides the rules for managing and awarding Higher Doctorates at RMIT:
  1. Doctor of Letters (DLitt)
  2. Doctor of Design (DDes)
  3. Doctor of Science (DSc)
  4. Doctor of Engineering (DEng)
  5. Doctor of Business (DBus)


(2)  The purpose of the Higher Doctorate is to recognise formally the achievement of an individual, with a substantial academic connection to RMIT, in attaining international reputation of excellence and leadership in their field(s) of research/practice.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=192&version=3#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=192&version=3#document-top)
# Section 3 - Scope
(4)  This procedure applies to all staff responsible for managing Higher Doctorates and all candidates who meet the eligibility criteria in the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=192&version=3#document-top)
# Section 4 - Procedure
### Eligibility
(5)  Higher Doctorates may be awarded to individuals with a substantial academic connection to RMIT and a significant volume of high-quality research outputs for which no award has already been conferred. 
(6)  An applicant for a Higher Doctorate must:
  1. provide evidence of outstanding and internationally recognised scholarship/practice through an original, substantial and distinguished contribution to a field of knowledge/practice over and above the requirements of a standard doctoral degree, and
  2. be a graduate (minimum bachelor level) of RMIT university of at least seven (7) years standing, or
  3. be a staff member of RMIT for at least four (4) years, or
  4. have qualified, not less than 7 years previously, for a degree of another educational institution and had a close academic association with RMIT for not less than four years. 


### Application
(7)  The applicant must obtain the sponsorship of an appropriate school Dean/Head of School at RMIT University, who is willing to support the application, prior to submitting an application.
(8)  The Dean/Head of School of the sponsoring school must endorse the application.
(9)  Applicants must submit:
  1. an application fee payable to the sponsoring school, and
  2. evidence sufficient to determine whether the admission requirements are fulfilled and whether the work to be submitted is prima facie appropriate for examination.


(10)  The application is submitted to the School of Graduate Research (SGR).
(11)  If an application includes work which has been undertaken in collaboration with another person, the applicant must provide a written statement from the co-author(s) detailing the extent of the applicant’s contribution to the planning, carrying out and writing of the account of such work and indicate the portion of the applicant’s work for which originality is claimed.
(12)  The application is assessed by the appropriate College Research Committee to determine whether the admission requirements are met and whether the work to be submitted is prima facie worthy of examination and meets the requirements set out in the rules for submission listed in this procedure.
(13)  The committee reviews and endorses proposed examiners. Their recommendations are sent to the ADVC RT&D or nominee for approval. 
(14)  If the work is deemed worthy of examination, the applicant will qualify for admission and be formally offered admission to candidature. 
### Candidature and Submission
(15)  To accept admission and its conditions, the applicant pays the examination fee (payable to the sponsoring school)
(16)  The candidature begins from the date of admission.
(17)  The expected candidature period from admission to submission is one (1) week. 
(18)  By the submission date, the candidate must submit the work to be examined, following the Higher Doctorate Submission Guidelines.
### Rules for Submission
(19)  Work submitted must constitute substantial publications and/or achievement such as books, articles, full paper and refereed conference publications, live performance of creative works, recorded/rendered creative works and curated or produced substantial public exhibitions and events.
(20)  Outputs included must be HERDC or ERA eligible, i.e. peer reviewed and published prior to submission.
(21)  The submission may not include work which has been submitted previously for a degree or other award in any university. 
(22)  With the submission for examination, the applicant must include a detailed research outputs declaration outlining the extent of originality and the applicant’s part in any collaborative work. 
(23)  The submission for examination must also include an exegesis in the form of a statement identifying the contribution of the body of work and indicating the quality of work relevant to the field of research. 
### Examination
(24)  The Appointment of Examiners must comply with the [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18). For the purposes of the Higher Doctorate, the Dean/Head of School or nominee takes on the role of senior supervisor. 
(25)  Sponsors must inform potential examiners that:
  1. they will be provided with access to an electronic copy of the examinable outputs for examination, and
  2. they must complete and submit a final recommendation within eight (8) weeks of receiving notification from SGR, and
  3. they are required to attend the examination when any presentation (e.g. oral presentation, exhibition, performance or demonstration) is involved, or
  4. their identity shall remain undisclosed during the examination process but may elect to have their name revealed to the candidate at the conclusion of the examination. 


(26)  The examiners shall be principally guided in their examination of the submission by the Higher Doctorate Examiners’ Guidelines.
(27)  In the event of an examiner or any relevant party to the examination process questioning whether the work is genuinely that of the candidate, the matter will be addressed in accordance with the university’s [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28) and procedures.
(28)  The examiners shall individually and independently assess the submission and make one of the following recommendations to the ADVC RT&D or nominee:
  1. Confirmed: the candidate will be awarded the degree for which they are enrolled.
  2. Not confirmed: the candidate should not be awarded the degree for which they are enrolled and not be permitted to resubmit the suite of works and exegesis for re-examination.


(29)  An award for the degree of Higher Doctorate can only be made where both examiners confirm the candidate is suitable for conferral of the degree. 
(30)  If unsuccessful, the candidate may make a new application for admission after a lapse of two (2) years. Any new applications should include additional, published research outputs. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=192&version=3#document-top)
# Section 5 - Resources
(31)  Refer to the following documents:
  1. Higher Doctorate Application Form
  2. Higher Doctorate Submission Form
  3. Higher Doctorate Examiners’ Guidelines


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
