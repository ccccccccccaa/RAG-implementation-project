[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=204&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=204&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > COVID-19 Vaccination Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=204)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=204&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=204&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=204&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=204&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=204&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=204&version=1)


# COVID-19 Vaccination Procedure
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=204&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=204&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=204&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=204&version=1#section4)
  * [Vaccination Requirement](https://policies.rmit.edu.au/document/view.php?id=204&version=1#major1)
  * [Vaccination Status](https://policies.rmit.edu.au/document/view.php?id=204&version=1#major2)
  * [Exemptions](https://policies.rmit.edu.au/document/view.php?id=204&version=1#major3)
  * [Vaccination Information Management](https://policies.rmit.edu.au/document/view.php?id=204&version=1#major4)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=204&version=1#major5)
  * [Staff Members ](https://policies.rmit.edu.au/document/view.php?id=204&version=1#minor1)
  * [Students](https://policies.rmit.edu.au/document/view.php?id=204&version=1#minor2)
  * [Honorary Appointments](https://policies.rmit.edu.au/document/view.php?id=204&version=1#minor3)
  * [Contractors and Tenants](https://policies.rmit.edu.au/document/view.php?id=204&version=1#minor4)
  * [Volunteers](https://policies.rmit.edu.au/document/view.php?id=204&version=1#minor5)
  * [Visitors](https://policies.rmit.edu.au/document/view.php?id=204&version=1#minor6)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=204&version=1#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Purpose
(1)  The purpose of this procedure is to facilitate the protection of the health and safety of the University community by requiring all eligible people attending an RMIT University premises or activities to be fully vaccinated against COVID-19 (unless an exemption applies).
(2)  Under the Occupational Health and Safety Act 2004 (OHS Act), the University must identify whether there is a risk to the health of those attending its premises or activities from exposure to COVID-19. Where a risk is identified, the University must eliminate the risk, so far as is reasonably practicable. When elimination is not possible, the University must reduce the risk so far as reasonably practicable.
(3)  RMIT has determined that, for all those attending RMIT premises or activities, requiring the COVID-19 vaccination is the lead control measure against the risk of COVID-19 infection. It forms part of a multi-layered range of controls to reduce the risk of exposure to COVID-19.
(4)  The expected outcome from this procedure will be that:
  1. All staff, students, contractors, and visitors to RMIT premises and activities will be fully vaccinated for COVID-19 or have an approved medical exemption.
  2. RMIT will restrict access to premises or activities to anyone who is not fully vaccinated or does not have an approved medical exemption.
  3. Vaccination information is collected and stored, where required, in a manner that meets RMIT’s privacy requirements.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=204&version=1#document-top)
# Section 2 - Authority
(5)  Authority for this procedure is the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=204&version=1#document-top)
# Section 3 - Scope
(6)  This procedure will apply in Australia and will not apply at any overseas locations.
(7)  The requirements under the procedure apply in addition to any other health and safety requirements that apply (for example, general health and safety requirements that apply in a laboratory or other COVID-Safe protocols).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=204&version=1#document-top)
# Section 4 - Procedure
(8)  The University follows pandemic orders issued by the Victorian Minster for Health relating to COVID-19 vaccinations. Where any health direction issued by the Victorian Minister for Health is inconsistent with and exceeds the requirements under this procedure, the health directions will apply to the extent of any inconsistency.
### Vaccination Requirement
(9)  From 26 November 2021, it will be a requirement that:
  1. Any RMIT staff member, student, honorary appointee, contractor, tenant or volunteer attending RMIT premises or activities must be fully vaccinated against COVID-19, unless they have an exemption recognised by the University in accordance with this procedure.
  2. Any person attending RMIT premises or activities who is eligible under the Australian Government COVID-19 vaccination program to receive a COVID-19 vaccination must be fully vaccinated against COVID-19, unless they have been granted an exemption recognised by the University in accordance with this procedure.


(10)  The vaccination requirement does not apply to:
  1. any person attending RMIT premises to respond to an emergency
  2. any secondary school students attending RMIT premises as part of an authorised and planned school visit.


### Vaccination Status
(11)  The University requires all staff, students, honorary appointees, academic affiliates, contractors, tenants, and volunteers who attend RMIT premises or activities to provide evidence of their vaccination status. See Associated Information for the process for providing this evidence to the University.
(12)  For vaccinations administered in Australia, the University will accept the following documents, both of which can be obtained through a MyGov account:
  1. an Immunisation History Statement showing all required doses of the relevant vaccine have been received, or
  2. COVID-19 Digital Certificate.


(13)  If an individual has been administered a COVID-19 vaccination internationally that is approved for use in Australia by the Therapeutic Goods Administration (TGA):
  1. an application should be made by the individual to have their COVID-19 vaccination recorded on the Australian Immunisation Register (AIR) which will then be reflected in Immunisation History Statement or COVID-19 Digital Certificate from their MyGov account, and
  2. an alternative form of evidence will be required as outlined in Associated Information.


(14)  RMIT may require additional information from individuals at a later date (e.g. information about further booster doses) which may be deemed appropriate to ensure the safety of those attending RMIT premises or activities. This procedure will be updated if that occurs.
(15)  If an individual elects to not provide the University with information about their vaccination status, for the purposes of this procedure they will be considered as unvaccinated against COVID-19.
(16)  Visitors (including but not limited to those attending sporting or clinic facilities, industry partners and research study participants) will be asked to provide evidence to confirm that they are fully vaccinated against COVID-19 as part of the process to check-in to RMIT premises or activities on arrival.
### Exemptions
(17)  Any person attending RMIT premises or activities will be exempted from the requirement to be fully vaccinated if they have a recognised medical contraindication.
(18)  To gain an exemption, the person must provide the University with a COVID-19 Digital Certificate showing that the contraindication for COVID-19 vaccines has been accepted.
(19)  The University may contact the issuing medical practitioner to verify the authenticity of any such medical evidence or to determine what additional controls RMIT needs to put in place to ensure the safety of the unvaccinated person.
(20)  In order to ensure the health and safety of the University community, individuals who are granted an exemption may be subject to conditions or restrictions related to their work, study, access to RMIT premises or activities to ensure their safety and the safety of others. This may include (but is not limited to) wearing personal protective equipment (e.g. face masks and/or face shields), physical distancing, the use of rapid antigen testing, exclusion from large University activities and other measures as determined by the University. The requirement to wear personal protective equipment may also apply to others in attendance in the work or study area or at the event. A risk assessment will be conducted for each case of an exempted person to determine the appropriate additional requirements.
### Vaccination Information Management
(21)  Information submitted to the University under this procedure will be collected, stored and used only in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(22)  Any person who provides information to RMIT in accordance with this procedure must provide accurate and truthful information. Failure to provide accurate and truthful information will be considered as serious, and in the case of:
  1. a staff member, may result in disciplinary action for serious misconduct
  2. a student, may result in disciplinary action for general misconduct
  3. an honorary appointee or academic affiliate, may result in the honorary appointment being terminated and the University ceasing its affiliation with the honorary appointee
  4. a contractor, may result in the University requesting the contracting organisation to provide an alternative contractor to fulfil the duties under the contract
  5. a tenant or licensee, may result in the termination of their contractual agreement with the University
  6. a volunteer, may result in the University ceasing their volunteering arrangement, or
  7. all other visitors, they may be required to leave our premises immediately, and may be excluded from attending any RMIT premises or activity in future.


### Compliance
(23)  Compliance with this procedure is a condition of accessing any of RMIT’s Australian premises. RMIT may refuse access to RMIT premises or activities for any person who does not comply with this procedure.
#### Staff Members 
(24)  If a staff member has not been fully vaccinated against COVID-19 by 26 November 2021 and has not been granted an exemption under this procedure, the People Team will liaise with the staff member and their manager to seek to understand their reasons for choosing not to be vaccinated and to support the staff member to be vaccinated where possible.
(25)  If following these discussions the staff member continues to choose not to be vaccinated, the University will consider whether the inherent requirements of the staff member’s role require them to attend RMIT premises or activities and/or whether there are alternative measures (such as enabling the staff member to access accrued leave entitlements or providing a period of leave without pay) or reasonable adjustments that can be made.
#### Students
(26)  If a student, other than a student who enrolled to complete their studies wholly online and has no requirement to attend RMIT premises or activities, has not been fully vaccinated against COVID-19 by 26 November 2021 and has not been granted an exemption under this procedure, the Education Portfolio will provide the student with information on the vaccination requirement and support available to the student to be vaccinated where possible.
(27)  If following these discussions the student continues to choose not to be vaccinated, RMIT will consider whether there are alternative measures or reasonable adjustments, such as enabling the student to defer their studies, or adjusting their subject selection to subjects that do not require attendance at RMIT premises or activities. Students who are unvaccinated may encounter difficulties in relation to in-person assessments, including grades related to missed assessments and no opportunities for assessment resits. Assessment appeals may be declared invalid if the basis for the appeal is being unvaccinated. Complex cases will be determined on a case-by-case basis through the office of the Academic Registrar.
(28)  In circumstances where the University determines that arrangements cannot be made and the student is required to attend RMIT premises or activities to undertake their studies, the student will need to consider their enrolment and assessment options including whether they wish to withdraw from their course of study without academic and financial penalty. This recommendation should come before the class census date at the latest, but more reasonably before the class commences.
#### Honorary Appointments
(29)  If an honorary appointee or academic affiliate has not been fully vaccinated against COVID-19 by 26 November 2021 and has not been granted an exemption under this procedure, the Dean of the School will liaise with the appointee to seek to understand their reasons for choosing not to be vaccinated and to support the appointee to be vaccinated where possible.
(30)  If following these discussions the honorary appointee or academic affiliate continues to choose not to be vaccinated, the University will remove any on-campus privileges associated with the honorary appointment. In circumstances where the University determines that attendance at RMIT premises or activities is critical to the honorary appointee’s engagement with the University, RMIT may terminate the honorary appointment and cease affiliation with the honorary appointee.
#### Contractors and Tenants
(31)  If a contractor fails to provide an acknowledgment to the University of its compliance with this procedure and/or show evidence of vaccination status compliance, the University may consider appropriate action regarding the contractor’s engagement. This may include requesting for the contracting organisation to provide an alternative contractor who is fully vaccinated, or if replacement is not possible, the University may consider terminating the contract.
(32)  If a tenant or licensee fails to provide an acknowledgment to the University of its compliance with this procedure, the University may consider appropriate action regarding their lease or licence. This may include restricting them or their staff from attending RMIT premises.
#### Volunteers
(33)  If a volunteer has not been fully vaccinated against COVID-19 by 1 December 2021 and has not been granted an exemption under this procedure, the relevant University officer will liaise with the volunteer to seek to understand their reasons for choosing not to be vaccinated and to support them to be vaccinated where possible.
(34)  If following these discussions, the volunteer continues to choose not to be vaccinated and the University determines that attendance at RMIT premises or activities is critical to the volunteer’s engagement, the University may cease the volunteering arrangement.
#### Visitors
(35)  Visitors who are not fully vaccinated against COVID-19 and who do not have an approved exemption to be vaccinated will be refused access to RMIT premises or activities.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=204&version=1#document-top)
# Section 5 - Definitions
(36)  Defines any key terms and acronyms relating to the procedure where they apply.
Term  |  Definition  
---|---  
Approved vaccine |  Any COVID-19 vaccination that has been provisionally registered for use in Australia by the Therapeutic Goods Administration (TGA). In the case of people who received their vaccination at an overseas location, an Approved Vaccine means any COVID-19 vaccination that has been approved by the TGA as a recognised vaccine for the purpose of determining incoming international travellers as being appropriately vaccinated.  
Contractor |  Means a natural person, business or corporation that provides goods and/or services through a contract (written or verbal) for a specific purpose and period of time to the University. This includes contingent workers, educational and research partners, or a person who is performing work for the University (whether directly or indirectly through a third party).  
Fully vaccinated |  Means having obtained the TGA’s recommended dosage of any approved vaccine. For example, where a two-dose schedule is recommended by the TGA, a person will be considered fully vaccinated when they have received both doses of the vaccine. This may include any requirement for booster doses.  
Honorary appointee/academic affiliate |  Means a person appointed under the [Honorary and Visiting Academic Appointments Policy](https://policies.rmit.edu.au/document/view.php?id=101).  
Recognised medical contraindication |  A reaction to an approved vaccine as advised by the Australian Technical Advisory Group on Immunisation (ATAGI).  
RMIT or University premises |  Any building or outdoor space owned by the University occupied by the University, and/or under the control of the University as defined by section 11 of RMIT Statute No 1.  
University activity |  Any event or function which is organised, endorsed or arranged by RMIT, whether on RMIT premises or not, and includes but is not limited to a student attending clinical or work integrated learning placement or a staff member attending a private or third-party premises to conduct a research study.  
Staff member |  An employee of the University employed on a continuing, fixed-term or casual basis.  
Student |  A student as defined by section 4 of RMIT Statute No 1 as any person enrolled at the university.  
Tenant |  Any person who leases or licenses space at a RMIT University campus and includes venue operators.  
Visitor |  A person who is visiting someone or somewhere on a University campus or premises but is not a staff member, student, contractor, honorary appointee, tenant or volunteer.  
Volunteer |  A person providing voluntary services to the University or its students.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
