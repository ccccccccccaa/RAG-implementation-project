[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=114#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=114#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Procedure - Mobility 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=114)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=114)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=114)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=114)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=114)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=114)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=114)


# Enrolment Procedure - Mobility
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=114#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=114#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=114#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=114#section4)
  * [Cross-Institutional Study](https://policies.rmit.edu.au/document/view.php?id=114#major1)
  * [Exchange and Study Abroad](https://policies.rmit.edu.au/document/view.php?id=114#major2)
  * [Cross-Campus and Inter-Location](https://policies.rmit.edu.au/document/view.php?id=114#major3)
  * [Cross-Study Mode](https://policies.rmit.edu.au/document/view.php?id=114#major4)
  * [Processes for Global Mobility](https://policies.rmit.edu.au/document/view.php?id=114#major5)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=114#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  Mobility arrangements enable students to undertake part of their study at another institution or location, with eligible studies credited towards the program taken at their home institution.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=114#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=114#document-top)
# Section 3 - Scope
(3)  This procedure applies to all students (RMIT University, RMIT Vietnam, RMIT Online, international partners and other approved institutes within or outside of Australia) who are seeking to undertake mobility study.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=114#document-top)
# Section 4 - Procedure
### Cross-Institutional Study
(4)  A higher education student enrolled in an RMIT University program may apply to study single courses (units) at another Australian institution and have their studies credited towards their RMIT University degree, subject to the following conditions:
  1. the student must obtain written approval to undertake a non-standard enrolment
  2. the student is responsible for ensuring course entry requirements are met.


(5)  A student approved for cross-institutional study at another Australian tertiary institution must maintain continuity of enrolment at RMIT University.
(6)  If a student is undertaking all courses at the host institute for a given semester, they must apply for a leave of absence for the RMIT award program by the enrolment deadline.
(7)  Any unapproved courses (units) undertaken at the host institute will not be considered as credit toward the student’s RMIT award program.
(8)  Onshore international students on a student visa are:
  1. not eligible to study Open Universities Australia (OUA) courses as they are not CRICOS registered
  2. responsible for maintaining and meeting their visa requirements in any given semester.


(9)  A student enrolled in a degree program at another Australian university or recognised higher education provider may apply to study single courses at RMIT on a cross-institutional inbound basis.
### Exchange and Study Abroad
(10)  A student enrolled in an RMIT University program may apply for permission to study full-time at an institution in another country as either:
  1. an exchange student (where RMIT University has a formal exchange agreement with that institution)
  2. a study abroad student (where no exchange agreement exists).


(11)  RMIT University students must comply with all RMIT enrolment procedures and deadlines while overseas, including census dates.
(12)  A student enrolled in an award program at an institution in another country may apply to enrol in courses offered by RMIT University as either:
  1. an exchange student (where RMIT University had a formal exchange agreement with the other institution)
  2. a study abroad student (where no exchange agreement exists).


### Cross-Campus and Inter-Location
(13)  A student enrolled in an RMIT program offered in one country may apply to undertake one or two semesters of study at an RMIT campus or RMIT partner’s location in another country.
(14)  Students at locations outside Australia may only apply to study in the program offering in Australia if the program is CRICOS registered.
(15)  Where the mobility arrangement is approved, students will receive grades from courses they have completed in their semesters in the program at the other location, for equivalent courses in the offering of the program at their original location.
### Cross-Study Mode
(16)  Students enrolled in an RMIT award program with face-to-face delivery may apply to enrol in approved online courses offered by RMIT Online and vice-versa.
(17)  Cross-study mode enrolment is permitted on a short-term basis (one or two semesters) and not a full transfer of program.
(18)  Only approved courses undertaken in study will be credited towards an RMIT award.
(19)  Onshore international students on a student visa are not eligible to study in online study mode via RMIT Online.
### Processes for Global Mobility
(20)  RMIT publishes student information to support global mobility on the RMIT website, on the authority of the Executive Director, Students.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=114#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Mobility enrolment |  Includes the following enrolment arrangements:
  1. Cross-institutional inbound/outbound
  2. Cross-study mode
  3. Exchange inbound/outbound
  4. Study Abroad
  5. Cross-campus inbound/outbound
  6. Inter-location inbound/outbound

  
---|---  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
