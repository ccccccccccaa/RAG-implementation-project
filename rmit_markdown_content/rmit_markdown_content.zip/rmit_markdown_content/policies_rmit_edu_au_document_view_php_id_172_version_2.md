[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=172&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=172&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Conduct - Appeals Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=172)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=172&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=172&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=172&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=172&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=172&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=172&version=2)


# Student Conduct - Appeals Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=172&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=172&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=172&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=172&version=2#section4)
  * [Submission and Eligibility Requirements](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major1)
  * [Grounds of Appeal](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major2)
  * [Eligibility to Proceed to a Hearing](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major3)
  * [General](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major4)
  * [Student Conduct Appeals Committee](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major5)
  * [Conduct of a Hearing](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major6)
  * [Student Conduct Appeals Committee Determinations](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major7)
  * [Student Conduct Appeals Committee Outcome Notification](https://policies.rmit.edu.au/document/view.php?id=172&version=2#major8)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=172&version=2#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure sets out how RMIT will manage student appeals submitted against a misconduct decision made by:
  1. a Senior Officer, or
  2. the Student Conduct Board.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=172&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=172&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to students and staff of RMIT, as set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). It relates to the implementation of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and corresponding procedures regarding student conduct and the management of student misconduct.
(4)  Nothing in this procedure prevents an officer or Senior Officer from taking precautionary measures at any time to address or manage a safety concern.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=172&version=2#document-top)
# Section 4 - Procedure
### Submission and Eligibility Requirements
(5)  All appeals concerning student misconduct decisions must be submitted in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures. Only a student who has been the subject of a finding of misconduct may apply to appeal a determination.
(6)  Subject to satisfying the eligibility criteria described in this procedure, a student may apply to the Academic Registrar (or delegate) to request a hearing of the Student Conduct Appeals Committee to consider an appeal against a misconduct decision made by:
  1. a Senior Officer, or
  2. the Student Conduct Board. 


(7)  The appeal may relate to one or both of the following:
  1. the misconduct decision (findings of fact), or
  2. the consequences or penalty applied.


### Grounds of Appeal
(8)  The grounds on which a student may appeal are limited to one or more of the following:
  1. that the determination was made based on personal bias
  2. that there has been a breach of RMIT legislation, regulation, policy or procedure in the course of the determination, which has had a significant impact on the outcome of the conduct matter (which may include that a student has not received a fair opportunity to respond in all of the circumstances) 
  3. that the consequences and/or penalties applied are unreasonable, excessive, or inappropriate
  4. that there is new supporting material or evidence of a substantial nature that: 
    1. could not reasonably have been provided at the time of the original hearing or there was no reasonable opportunity to make a written submission (as appropriate), and
    2. this material or evidence would likely have had a significant impact on the determination or consequences and/or penalties applied.


(9)  The appeal application must:
  1. be in the form prescribed by the Academic Registrar (or delegate);
  2. be in writing addressing the selected ground/s of the appeal;
  3. include the evidence on which the student relies to support the ground/s of appeal, and
  4. be lodged within 20 working days from the date of the Student Conduct Board or Senior Officer’s formal outcome notification.


### Eligibility to Proceed to a Hearing
(10)  The Academic Registrar (or delegate) will assess whether an appeal application complies with the requirements of this procedure, including the grounds of appeal, in order to proceed to a hearing.
  1. In determining whether an appeal application has met the grounds of appeal requirement prescribed by clause 9, sub-clauses (b) and (c), the Academic Registrar (or delegate) will have regard to the relevance and connection of the appeal submission and any evidence to the selected appeal ground, and whether there exists a reasonable prospect of success should the appeal proceed to hearing. For the avoidance of doubt, regard will not be had to the merits of the original decision and/or outcome. 


(11)  Assessment of complete appeal submissions will commence within 10 working days of lodgement. For the avoidance of doubt, a complete submission comprises the documentation referenced at clause 9, sub-clauses (a) to (c).
(12)  Where it is determined by the Academic Registrar (or delegate) that an appeal application has not met the requirements of this procedure, including the grounds of appeal, the application will be deemed ineligible to proceed to a hearing.
(13)  Where it is determined by the Academic Registrar (or delegate) that an appeal application has met the requirements of this procedure, including the grounds of appeal, in order to proceed to a hearing:
  1. the appeal application will be referred to the original decision-maker (relevant Senior Officer or Chair, Student Conduct Board) seeking a review of the original determination and the appeal submission prior to convening a hearing of the Student Conduct Appeals Committee
  2. the appellant student will be notified of any variation to, or withdrawal of, the original determination which may remove the need for a hearing of the Student Conduct Appeals Committee and result in the discontinuation of the appeal process. 
    1. Where the appeal relates to a finding of misconduct resulting from a report made by an impacted or affected person, the Academic Registrar (or delegate) will notify the reporting person by their preferred method of contact, of any variation to, or withdrawal of the original determination. 


(14)  Where there is no change to the original determination on review, the appeal will proceed to a hearing. The Senior Officer or the Student Conduct Board Secretary (as appropriate) will provide the Academic Registrar (or delegate) with all documentation relevant to the original determination to enable distribution to the appellant student and Student Conduct Appeals Committee members when a hearing is scheduled.
(15)  The determination of the Academic Registrar (or delegate) that an appeal application meets the requirements of this procedure and will proceed to a hearing
  1. does not mean that an appeal, when heard, will be successful, and/or
  2. does not affect or determine the substantive outcome of the appeal. 


(16)  Where an application for appeal has been deemed ineligible to proceed to a hearing by the Academic Registrar (or delegate), the appellant student will be provided with reasons for the determination and advised of their right to seek external review of the Student Conduct Board or Senior Officer determination by the [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=1&associated).
### General
(17)  Where an appeal application proceeds to a Student Conduct Appeals Committee hearing, the matter will be heard within 30 working days of receiving a complete appeal submission, except where there are relevant circumstances which impact this time, or where the matter has been paused or suspended because of external requirements.
(18)  In determining a student conduct appeal matter, the Academic Registrar (or delegate) prior to hearing, and the Chair, Student Conduct Appeals Committee during proceedings:
  1. must act in accordance with this procedure, and all applicable policies
  2. must act fairly and reasonably in all the circumstances, which may include contacting the appellant to make further investigations and enquiries
  3. must ensure that all parties, including advocates and support persons are aware of the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedure requirements, including those relating to records, privacy, and confidentiality
  4. are not bound by the rules of evidence, technicalities, or legal forms, including rules which apply in any court or tribunal in Australia, such as those set out in the Evidence Act 2008 (Vic)
  5. may make such inquiries and communicate with the people they determine to be relevant and necessary to enable them to properly determine the matter
  6. may ask any student to attend a hearing, or to provide information in relation to the matter; however, may not compel or force a student to attend a hearing, or to provide information relating to a student conduct matter. 


(19)  The Chair, Student Conduct Appeals Committee (Chair) may make determinations about all matters relating to the conduct of a hearing, including but not limited to: attendance, scheduling and re-scheduling, any pausing or adjournment of the hearing, any additional material or information required, and the provision of information about the process and the determination. All such determinations are subject to this procedure, the Student Conduct Policy, and the Student Conduct Regulation.
(20)  An appellant student may respond to the documentation provided by the Senior Officer or Student Conduct Board (as appropriate) for consideration by the Student Conduct Appeals Committee by participating in a hearing in person (which may include by telephone or online video conference):
  1. with date, time, and location details (and connection information where applicable) scheduled no earlier than 10 working days from the date of the written notification and provision of the reports and related documentation, or 
  2. if the appellant student does not wish to participate in the hearing, they may provide a written submission no later than two working days before the date of the scheduled hearing of the Student Conduct Appeals Committee. 


(21)  Where the appellant student makes a written submission to the Student Conduct Appeals Committee electing not to participate in a hearing, the Student Conduct Appeals Committee will consider the matter on the basis of the potential student misconduct report and the response provided by the student.
(22)  The Secretary is responsible for managing the records of the Student Conduct Appeals Committee including outcomes. No party may make an audio or video recording of the proceedings, including if they are conducted electronically or via video link.
(23)  Any notice or written communications to students are to be provided in accordance with the requirements of the Student Conduct Procedure. 
### Student Conduct Appeals Committee
#### Membership
(24)  Where the Student Conduct Appeals Committee is convened, its membership will accord with quorum requirements set out within the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180).
(25)  Members of the Student Conduct Appeals Committee will declare any actual, potential, or perceived conflicts of interest prior to commencement of proceedings; any such declarations will be addressed by the Chair and recorded in the minutes.
(26)  Membership of the Student Conduct Appeals Committee will not include:
  1. a Senior Officer who was involved in the investigation, hearing, or referral of the reported misconduct, or
  2. where the appeal is against a misconduct decision made by the Student Conduct Board, any members having determined the original matter, or


  1. to the extent practicable, a Senior Officer who is from the school responsible for the program in which the appellant student is enrolled.


#### Matters Which are High Risk or Involve Sexual Harm
(27)  Where the appeal to be considered by the Student Conduct Appeals Committee relates to or may affect or impact the safety of any person, present any increased level of risk, or where it involves sexual harm:
  1. the Chair must consult with Safer Community on the appropriate arrangements for conducting the hearing or other matters involving the consideration of the appeal, and


  1. where relevant and practicable, the Chair and at least one of the other Senior Officer members of the Student Conduct Appeals Committee, will have undertaken relevant training in relation to sexual harm, and take a trauma-informed approach.


#### Notification of Hearing
(28)  Where an appeal application proceeds to a Student Conduct Appeals Committee hearing, the Secretary will:
  1. convene the Student Conduct Appeals Committee in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and this procedure, and
  2. notify the appellant student: 
    1. of the opportunity to respond to Senior Officer or Student Conduct Board documentation with notifications, documentation and timelines provided in accordance with clause (20)
    2. that they may be accompanied by a support person, a representative of their principal student organisation or other advocate, and their Safer Community case manager in accordance with this procedure (where applicable)
    3. details of student support services as outlined in the Student Conduct Procedure.


#### Reporting Party Notification
(29)  Where an appeal regarding misconduct involves a report made by another person, that person will be informed by their preferred method of contact about when and where the appeal hearing is to take place.
#### Representation and Support
(30)  At the Student Conduct Appeals Committee hearing, where invited to participate in person, the student may be accompanied by a support person and/or advocate. 
(31)  An advocate, and not a support person, is permitted to make submissions on the respondent’s student’s behalf.
(32)  Any person who is under the age of 18 must be accompanied to any meeting or hearing by a parent, guardian or caregiver who is responsible for their interaction with RMIT. 
(33)  A student must seek permission from the Chair if they want to be represented by a legal practitioner or to otherwise have a legal practitioner make submissions on their behalf.
(34)  The Chair has discretion not to allow a student to be represented by a legal practitioner or to have a legal practitioner make submissions on their behalf.
(35)  The Student Conduct Appeals Committee as constituted in a particular matter may be assisted by Counsel, being an external legal practitioner (Counsel Assisting). The role of the Counsel Assisting is to provide legal advice to the Student Conduct Appeals Committee on how to effectively discharge its obligations under, and comply with, the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and this and other applicable procedures. Counsel Assisting will not:
  1. undertake advocacy for the Student Conduct Appeals Committee
  2. make written or verbal submissions to or for the Student Conduct Appeals Committee, or the appellant student, or
  3. undertake examinations of any persons on behalf of the appellant student or the Student Conduct Appeals Committee.


#### Student Participation
(36)  The appellant student must confirm their attendance and the name of their support person/s and any advocate at least two working days before the hearing.
(37)  The Chair may reschedule a hearing where the appellant student:
  1. provides reasonable evidence that they are unable to attend at the scheduled time, or
  2. provides written consent to waive the requirement of 10 working days’ notice.


(38)  The Chair may request written documentation to support the appellant student’s reasonable cause for not attending, including but not limited to a health practitioner’s report and/or a statutory declaration.
(39)  If the appellant student does not make a written submission by the deadline or does not attend a hearing within 10 minutes of the scheduled commencement time, and has not provided information about a reasonable cause for their non-submission or non-attendance as the case may be, the Student Conduct Appeals Committee may proceed with consideration of the conduct matter and any determination of the Student Conduct Appeals Committee will be binding
### Conduct of a Hearing
(40)  The Chair will ensure that the Student Conduct Appeals Committee hearing:
  1. is held confidentially, and in a comfortable venue (if not conducted via telephone or online video conference), and that the safety and wellbeing of the appellant student, their support person/s, members of the Student Conduct Appeals Committee, and any other persons in attendance including RMIT staff, other students or witnesses is supported
  2. as far as possible provides the appellant student and their support person/s and/or advocate/s access to a separate private space for consultation before and after the hearing (if applicable when telephone/online video conference is used)
  3. starts at the scheduled time
  4. proceeds without interruption, and
  5. ensures all parties are treated with respect.


(41)  The Student Conduct Appeals Committee:
  1. must conduct the hearing in accordance with this procedure
  2. must act fairly in all the circumstances
  3. is not bound by the rules of evidence, technicalities, or legal forms, including rules which apply in any court or tribunal in Australia, such as those set out in the Evidence Act 2008 (Vic)
  4. may make such inquiries and communicate with the people they determine to be relevant and necessary to enable them to properly determine the matter 
  5. may require any officer to attend the hearing
  6. may ask any student to attend a hearing or interview, or to provide information in relation to the matter; however the Student Conduct Appeals Committee may not compel or force a student to attend a hearing or interview, or to provide information relating to a student conduct matter.


(42)  The Student Conduct Appeals Committee may make inquiries with any reporting persons or persons who were affected or impacted by the misconduct, considering guidance from Safer Community in relation to how this may be done in a trauma-informed and appropriately sensitive manner.
### Student Conduct Appeals Committee Determinations
(43)  Once the Student Conduct Appeals Committee has considered all relevant materials, and the appellant student’s response (where applicable), they must either:
  1. dismiss the appeal
  2. allow the appeal in whole or in part, or
  3. remit the matter to the Student Conduct Board or Senior Officer for a re-hearing.


(44)  If the Student Conduct Appeals Committee allows the whole or any part of an appeal, it must confirm, set aside, or vary any determination imposed by the Student Conduct Board or Senior Officer or substitute another determination.
(45)  Unless the matter is remitted to the Student Conduct Board or a Senior Officer under Clause (43)c, a determination of the Student Conduct Appeals Committee is final.
### Student Conduct Appeals Committee Outcome Notification
#### Notification to Appellant Student
(46)  The Secretary must provide the appellant student written notification of the Student Conduct Appeals Committee determination within 10 working days of the scheduled hearing or deadline for written response advising:
  1. of the determination made and the reasons for the decision, and
  2. of their right to seek external review of the Student Conduct Appeals Committee determination by the [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=1&associated).


#### Notification to Impacted or Affected Persons
(47)  Where an appeal relates to a finding of misconduct having resulted from a report made by an impacted or affected person, the Academic Registrar (or delegate) will notify the reporting person by their preferred method of contact that the appeal hearing has concluded and of the outcome determination.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=172&version=2#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term  | Definition   
---|---  
advocate | means a member of the principal student organisation, case manager from Safer Community or another person approved by a Senior Officer or Chair of the Student Conduct Board to accompany a student during an investigation or conduct hearing. An advocate may provide advice and is permitted to make submissions or speak on a respondent student's behalf during an investigation or conduct hearing.  
appellant student | is a student who seeking to appeal against a finding of misconduct, or the consequences or penalty applied by a Senior Officer or Student Conduct Board.  
principal student organisation | means the main body representing students at the relevant campus of RMIT.  
Secretary  | means the secretary appointed by the Academic Registrar to the Student Conduct Board or the Student Conduct Appeals Committee.  
support person | a support person is someone who may accompany a person and support their wellbeing during a student conduct investigation or conduct hearing but who may not represent or speak on behalf of the student. A support person is usually a family member, friend, fellow student or colleague.  
working day  | Means days on which the University conducts its business. Working days do not include Saturdays, Sundays and the days set out in clauses 22 and 23 of the RMIT University Enterprise Agreement 2018.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
