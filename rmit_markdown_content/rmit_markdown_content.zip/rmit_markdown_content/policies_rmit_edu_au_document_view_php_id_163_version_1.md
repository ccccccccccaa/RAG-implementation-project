[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=163&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=163&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Timetable Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=163)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=163&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=163&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=163&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=163&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=163&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=163&version=1)


# Timetable Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=163&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=163&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=163&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=163&version=1#section4)
  * [Timetable Priorities](https://policies.rmit.edu.au/document/view.php?id=163&version=1#major1)
  * [Scheduling](https://policies.rmit.edu.au/document/view.php?id=163&version=1#major2)
  * [Teaching Spaces](https://policies.rmit.edu.au/document/view.php?id=163&version=1#major3)
  * [Planning](https://policies.rmit.edu.au/document/view.php?id=163&version=1#major4)
  * [Publication and Changes](https://policies.rmit.edu.au/document/view.php?id=163&version=1#major5)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=163&version=1#major6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  Thi procedure defines rules and responsibilities for a consistent, centralised timetabling practice which enhances the student learning experience and ensures the most efficient and effective use of University resources.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=163&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Infrastructure and Asset Security Policy](https://policies.rmit.edu.au/document/view.php?id=77). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=163&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all face-to-face timetabled classes held at the City, Bundoora and Brunswick campuses of RMIT. 
(4)  It does not apply to:
  1. short or single courses, ad-hoc events and industry/partner activities delivered on Melbourne campuses
  2. timetabling for RMIT Online and RMIT Vietnam.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=163&version=1#document-top)
# Section 4 - Procedure
### Timetable Priorities
(5)  The scheduling of learning and teaching activities must:
  1. achieve learning outcomes
  2. maximise the use of the University’s facilities and teaching resources
  3. maximise efficiencies for academic and teaching staff
  4. provide outcomes that enhance the student experience
  5. support student completion of a standard program structure in minimum time


(6)  The following considerations must be taken in account when scheduling timetables:
  1. larger classes will be timetabled prior to smaller classes
  2. first-year classes will have precedence over later year classes
  3. classes that occupy large blocks of time will be timetabled prior to those which occupy small block of time
  4. precedence will be given to classes requiring specialised facilities in multi-use space
  5. access for students and or staff with disabilities will take precedence, matching resources with accessibility.


### Scheduling
(7)  Schools must complete class scheduling in accordance with the RMIT accredited program and course approval calendar.
(8)  Class scheduling must align with actual delivery dates and timetable development timeline.
(9)  All scheduled synchronous on-campus and online classes offered by the University must be timetabled on the university’s timetable system.
### Teaching Spaces
(10)  All lecture theatres and generic classrooms must be centrally managed.
(11)  All teaching spaces must be booked via the prescribed timetabling system.
(12)  Timetabling Services is responsible for assigning and coordinating specialist teaching spaces in conjunction with the managing college and/or school to identify any standard setup/set down time allowances to be built into the location resource.
(13)  All teaching spaces must be prioritised to standard teaching activities from ‘0’ week of respective calendars prior to being made available for exams, enrolments, orientation, balloting, exhibitions or ad-hoc activities.
### Planning
#### Time Considerations
(14)  Classes must be timetabled within the spread of University’s teaching hours.
(15)  Standard delivery periods are defined as follows:
  1. standard DAY delivery period is 8:30am to 6:30pm Monday to Friday
  2. standard EVENING delivery period is 6:30pm to 9:30pm Monday to Friday.


(16)  To improve room availability, multi-hour classes commencing from 8.30am must be scheduled to maximise utilisation.
(17)  City, Brunswick and Bundoora West teaching periods must commence on the half hour.
(18)  Bundoora East campus teaching periods must commence on the half hour to facilitate student and staff movement between Bundoora East and West campuses.
(19)  Classes will end ten (10) minutes prior to published end time to enable room changeover and allow students to move to the next class.
#### Breaks
(20)  Breaks in the timetable must be scheduled between the hours of 11.30am and 2.30pm for staff and students.
(21)  Any teaching booking of duration of 4 hours or more must have a break period incorporated into the delivery block.
(22)  Bundoora and Brunswick common lunch hour must remain class-free unless otherwise approved by the campus director.
#### Other Considerations
(23)  Wherever possible, classes scheduled on evenings, weekends and public holidays must consolidate rooms into energy efficient spaces and buildings rather than spread across teaching facilities on a relevant campus, to support the University’s greenhouse gas emissions reduction target.
(24)  Speciality teaching spaces defined as needing lab support must be timetabled within the scope of hours determined by the controlling college.
(25)  Classes must be allocated to resources as per the academic requirements provided, i.e. room size, equipment, space type.
(26)  Programs or courses with periods of professional experience must only be timetabled for those weeks when campus resources are required, to enable rooms to be timetabled for other purposes when students are undertaking off-campus activities.
(27)  Intensives and other non-standard booking patterns must minimise the number of timeslots that are unavailable for standard semester classes.
(28)  A staff member’s timetable will operate in accordance with their employment terms and conditions.
### Publication and Changes
(29)  Full-year timetables will be published prior to the close of re-enrolment for the following year to permit students to make informed choices about course selection.
(30)  Changes to the timetable post-publication will be minimised; valid reasons for changes include:
  1. unexpected academic or teaching staff changes
  2. unexpected surge/decline in enrolled student numbers
  3. health or safety hazard
  4. adjustments required to accommodate staff or students with special needs
  5. late changes to Vocational Education Training Packages
  6. changes to student placement arrangements.


(31)  Changes to the published timetable relating to a change of day/time and/or delivery will require the approval of the college Dean or delegate as determined by the Deputy Vice-Chancellor for the respective college.
(32)  Approved changes will be updated on the published timetable with appropriate notification provided to staff and students as necessary.
### Responsibilities
(33)  Timetabling Services has a responsibility to:
  1. ensure the University’s timetabling process is conducted in a coordinated, efficient and effective manner
  2. minimise the need for students and staff to travel between campuses on the same day
  3. clump student classes within their student timetables, to minimise the spread of classes and avoid large gaps of time for students across the day
  4. assist with the resolution of timetable clashes and escalate matters to the Senior Manager, Timetable Services as required.


(34)  Program Managers or equivalent are responsible for providing program-specific information to ensure the timetable meets all requirements.
(35)  Academic and Teaching staff are responsible for submitting course teaching requirements and their hours of work unavailability through the prescribed channels.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
