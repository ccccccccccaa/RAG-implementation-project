[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=157#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=157#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Work Adjustment Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=157)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=157)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=157)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=157)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=157)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=157)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=157)


# Work Adjustment Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=157#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=157#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=157#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=157#section4)
  * [Work Adjustment Requests](https://policies.rmit.edu.au/document/view.php?id=157#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=157#major2)
  * [Review of Work Adjustments](https://policies.rmit.edu.au/document/view.php?id=157#major3)
  * [Privacy](https://policies.rmit.edu.au/document/view.php?id=157#major4)
  * [Concerns](https://policies.rmit.edu.au/document/view.php?id=157#major5)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=157#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  RMIT recognises the importance of work adjustments including flexible working arrangements in maintaining a diverse and adaptable workforce and particularly considers staff requests for work adjustment related to illness, injury, disability and balancing work/life/family needs. 
(2)  The University will undertake work adjustments where such adjustments are reasonable and appropriate in the circumstances and are consistent with work output requirements, work standards or provided the adjustments do not otherwise place the University in a position of 'unjustifiable hardship' in relation to the management of its finances or the pursuit of its legitimate objectives. The University will make workplace adjustments wherever it is required to do so by law. 
(3)  In recent decades the move has been away from a medical understanding towards a social understanding of disability. Disability arises from the interaction between people and their environment. The University adopts this way of thinking from the [United Nations Convention on the Rights of Persons with Disabilities](https://policies.rmit.edu.au/download.php?id=326&version=1&associated) which reflects the emphasis on removing environmental barriers which prevent inclusion, full participation and advancement. Disability is the impact of impairment; it is not the impairment itself.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=157#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Flexible Work Policy](https://policies.rmit.edu.au/document/view.php?id=125).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=157#document-top)
# Section 3 - Scope
(5)  This procedure applies to all employees of RMIT University, RMIT Online and RMIT University Pathways (RMIT UP).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=157#document-top)
# Section 4 - Procedure
### Work Adjustment Requests
(6)  A work adjustment may have one of these outcomes or a combination of the following:
  1. Workplace access: changes to work area design and means of access to the workplace and all facilities, modifications to technology and equipment
  2. Hiring practices: changes to the procedures used for testing, selection, learning and development training, promotion and termination
  3. Work procedure: modifications to the specific requirements of a role, restructuring of duties, modifications to working hours, adoption of flexible work practices, flexible hours and leave options
  4. Provision of specific services, facilities, aids or equipment, including, but not limited to, the provision of interpreters, equipment, or assistance with particular aspects of a job
  5. Reassignment of an individual employee: a change of position or the reassignment of specific tasks to another position.


(7)  Adjustments can apply at each stage of employment and through various work practices, including:
  1. recruitment, selection and appointment
  2. training and career development
  3. probation, progression and promotion
  4. performance management
  5. any other employment benefit.


(8)  Adjustments may be permanent or temporary depending on the nature of the request and the requirements of the individual. Adjustments can include:
  1. flexible working arrangements
  2. accessible premises
  3. assistive technology
  4. supervision/additional support
  5. ergonomic equipment
  6. Auslan interpretation and/or captioning
  7. job design or work arrangements
  8. training or retraining
  9. provision of information in suitable formats
  10. adjustment to communication styles


(9)  Stakeholders involved in the work adjustment can include any or all of the following:
  1. staff member
  2. people manager
  3. service areas such as People, Property Services and ITS
  4. external contractors and consultants.


#### Illness, Injury or Disability
(10)  The University will provide work adjustment or develop a return to work program based on the needs of the individual when staff experience illness, injury or disability.
(11)  In order to assess reasonable accommodation, or to ensure a safe and timely return to work, the University will work with the individual to understand impacts, may reach out to [Job Access](https://policies.rmit.edu.au/download.php?id=327&version=1&associated) in collaboration with the individual for a workplace assessment, may request a fitness for work certificate or further information from a medical practitioner to support the University in determining an appropriate adjustment.
#### Rehabilitation Return to Work
(12)  For staff with illness, injury or disability compensated as part of an accepted and current workers’ compensation claim, refer to the [Injury Management (WorkCover) Process](https://policies.rmit.edu.au/download.php?id=202&version=1&associated).
### Responsibilities
(13)  RMIT collects information on new staff and their workplace adjustment requirements at the onboarding stage of the employee lifecycle. This information is:
  1. to enable the best advice and solution to work adjustment request in optimal timeframes
  2. completely confidential and only shared with stakeholders that need to assess a solution.


(14)  The Work Adjustment team of specialist advisors, in consultation with staff member and their manager, is responsible for providing staff with the right combination of workplace adjustment, that is ready for their first day at work.
(15)  People managers are responsible for enabling the work adjustment and will support the Work Adjustment team.
#### Job Applicants
(16)  Job applicants will be asked if they require a work adjustment through the standard RMIT application form. 
(17)  If a job applicant is offered an interview and requires a work adjustment to participate in the interview process, they must self-identify through the application process to the People Recruitment Team. 
(18)  Requests for adjustments will not impact on the selection panel’s final decision, although the panel is able to assess the applicant's ability to perform the inherent requirements of the position. 
#### New Staff
(19)  New staff should provide workplace adjustment requirements through the recruitment and onboarding form.
#### Existing Staff
(20)  The following support services are available to existing staff:
  1. People Connect (who will log the request and forward it to the appropriate team)
  2. Health Safety and Wellbeing for return to work from illness/injury
  3. Work Adjustment team for all other work adjustment queries.


### Review of Work Adjustments
(21)  After the implementation of a work adjustment, staff will be able to provide comments on the process and outcome and there will be a systematic review of the adjustment.
(22)  A term of review of the adjustment needs to be decided between manager and staff member, depending on the need or any changes required during the course of employment.
  1. The review term normally won’t exceed 12 months.
  2. If further changes are required to assist the staff member, then updated documentation may be requested.
  3. Work adjustments may need to be reviewed specifically if the position changes or the staff member’s circumstances change. 


(23)  If a work adjustment is an ongoing requirement, staff are encouraged to record all requirements on their personnel file, which can serve as a passport for work adjustment for future adjustments especially if a change of position, manager, promotion or location requires review/continuation of work adjustment requirements.
#### Communicating Work Adjustment Needs
(24)  Staff are encouraged to communicate workplace requirements in relation to any impairment, health condition or disability in the normal course of employment. These work requirements may be temporary or ongoing and could include a range of support from awareness of immediate manager to tangible supports and work adjustments.
(25)  Staff requesting a work adjustment are encouraged to discuss the underlying issue, but the focus should primarily be on the work adjustment required. RMIT encourages a culture that supports and meets the needs of staff and students. 
### Privacy
(26)  Information provided by staff relating to personal circumstances, disability and/or health conditions must be treated sensitively, and identifying information must only be shared with the staff member's consent.
(27)  De-identified statistics will be maintained and used for planning and reporting purposes within the People team to ensure RMIT is informed of staff requirements in relation to work adjustment and responds adequately.
(28)  Managers may discuss matters with service providers in general terms and on a no-name basis to obtain advice on managing any particular situation.
(29)  Personal and health information provided to the University will be treated in accordance with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and applicable legislation.
### Concerns
(30)  If a staff member/applicant or manager has concerns about any actions they may raise their concerns directly with People Connect who will triage the issue and seek expert advice or refer on as appropriate.
#### Discrimination and Harassment Grievances
(31)  Any grievances arising from discrimination or harassment on the ground of disability, illness, injury or personal circumstances should be reported in the first instance to either:
  1. a manager
  2. member of the People team, or
  3. escalated via the [Complaints Portal](https://policies.rmit.edu.au/download.php?id=121&version=1&associated) in accordance with the [Staff Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=156).


(32)  A staff member or applicant who requests a work adjustment is protected from being disadvantaged because they made such a request. Individuals who feel that they have experienced unfavourable treatment due to their disability or work adjustment request may contact People Connect for advice or raise their concerns via the [Complaints Portal](https://policies.rmit.edu.au/download.php?id=121&version=1&associated).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=157#document-top)
# Section 5 - Schedules
(33)  This policy includes the following schedule(s):
  1. [Schedule 1 – Service Catalogue for Workplace Adjustment](https://policies.rmit.edu.au/download.php?id=204&version=2&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
