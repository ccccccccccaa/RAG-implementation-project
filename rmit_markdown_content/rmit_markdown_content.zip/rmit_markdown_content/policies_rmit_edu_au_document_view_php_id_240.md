[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=240#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=240#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Qualifying for an Award and Grade Point Average Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=240)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=240)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=240)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=240)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=240)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=240)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=240)


# Program and Course Qualifying for an Award and Grade Point Average Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=240#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=240#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=240#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=240#section4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides the rules for qualifying for awards, and the parameters for degree classes.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=240#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=240#document-top)
# Section 3 - Scope
(3)  This procedure applies to coursework and higher degree by research award courses.
(4)  This procedure only applies to Associate Degrees, Bachelor honours degrees and Masters by Research degrees commenced after 1 January 2016.
(5)  For students who commenced study in a bachelor honours degree program prior to 1 January 2016 the award level is determined based on the whole-program Grade Point Average (GPA), refer to[ Appendix 1 – Award Level Classification prior to 1 January 2016](https://policies.rmit.edu.au/download.php?id=467&version=2&associated).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=240#document-top)
# Section 4 - Procedure
(6)  The Dean, Head of School or Cluster Director is accountable for approval of the list of students who have qualified for a coursework award and the level of the award.
(7)  The Associate Deputy Vice-Chancellor Research Training and Development is accountable for approval of the list of students who have qualified for a research award and the level of the award.
(8)  The following types of awards are awarded unclassified (pass only):
  1. an award for a nationally recognised training package qualification, accredited vocational education and training course or skill set
  2. Doctor of Philosophy.


(9)  The following types of awards are awarded as a pass with distinction where the student has achieved a cumulative grade point average (GPA) of 3.0 or above for all courses in the program, or as a pass where the student has achieved a cumulative GPA of less than 3.0:
  1. Undergraduate Certificate
  2. Associate Degree
  3. Bachelor degree
  4. Graduate Certificate
  5. Graduate Diploma
  6. Masters by Coursework.


(10)  When students complete double degree programs, the award level for each component single degree is determined separately. 
(11)  RMIT does not provide manual or exceptional adjustments to GPA calculations.
(12)  Bachelor honours degrees are awarded with the following levels of honours, or as a pass only, where the weighted average mark (WAM) of candidates’ courses is within the ranges stated. In four-year Bachelor honours degrees, the WAM calculation includes only the courses identified as to be used in the calculation. For further detail see the [Program and Course Weighted Average Mark Procedure](https://policies.rmit.edu.au/document/view.php?id=241).
  1. WAM of 80 or more, Honours First Class (H1)
  2. WAM of 70 – 79, Honours Class 2A (H2A)
  3. WAM of 60 - 69, Honours Class 2B (H2B)
  4. WAM of 50 – 59, pass.


(13)  Masters by Research degrees are awarded with the following award levels where candidates’ mark in the research project is within the ranges stated below.
  1. 80% to 100%, High Distinction (HD)
  2. 70% to 79%, Distinction (D)
  3. 60% to 69%, Credit (C)
  4. 50% to 59%, pass (P).


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
