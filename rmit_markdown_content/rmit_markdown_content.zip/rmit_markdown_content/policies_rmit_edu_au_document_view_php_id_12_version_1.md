[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=12&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=12&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Higher Degrees by Research Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=12)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=12&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=12&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=12&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=12&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=12&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=12&version=1)


# Higher Degrees by Research Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=12&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=12&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=12&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=12&version=1#section4)
  * [HDR Candidature](https://policies.rmit.edu.au/document/view.php?id=12&version=1#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=12&version=1#major2)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=12&version=1#major3)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=12&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=12&version=1#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This policy provides a framework for the effective delivery and management of higher degrees by research (HDR) at RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=1#document-top)
# Section 2 - Overview
(2)  The objectives of this policy are to:
  1. support compliance with national regulation and quality standards;
  2. promote high-quality research training experiences and outcomes; and
  3. identify and define the roles and responsibilities of all parties involved in research training.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=1#document-top)
# Section 3 - Scope
(3)  The policy applies to all staff responsible for HDR management and supervision and all HDR candidates of the University and its controlled entities (known as the RMIT Group).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=1#document-top)
# Section 4 - Policy
(4)  Candidates admitted for enrolment in a higher degree by research at RMIT undertake a research project under academic supervision with the objectives of:
  1. producing research for examination;
  2. developing demonstrable researcher and professional capabilities; and
  3. disseminating the findings of their research in high-quality research outputs.


(5)  Research training is delivered in identified fields of established or emerging capability.
(6)  High-quality supervision, support and resources will be available to and accessible by candidates.
(7)  Candidates are provided with opportunities to undertake professional and researcher development activity to support successful and timely completion.
(8)  Candidates are expected to prepare and present their research as unified and coherent in content and address a single, significant research question/theme in the field or area of professional practice.
(9)  Fair complaints and appeals processes are available to address concerns or grievances that may arise during candidature.
(10)  Research degrees are developed, delivered, examined and awarded in accordance with the Australian Qualifications Framework and the Australian Code for Responsible Conduct of Research.
### HDR Candidature
#### Admission and Scholarship
(11)  Admission for enrolment in a higher degree by research at RMIT is in accordance with the [Admission and Credit Policy](https://policies.rmit.edu.au/document/view.php?id=6), the HDR Admissions and Scholarships Procedure and the [HDR Sanctions Assessment Process](https://policies.rmit.edu.au/document/view.php?id=21).
(12)  By instructing an offer of admission to be made to an applicant, the RMIT enrolling School confirms that it has:
  1. the appropriate discipline expertise to house the research;
  2. the necessary space, facilities, equipment, technical and resource staff and funding for the applicant, for the duration of the program; and
  3. the capacity to provide dedicated supervision for the duration of the program.


(13)  The Commonwealth Government of Australia provides funding to support research training at RMIT via its Research Training Program (RTP) block grant. Information on the application and management of RTP scholarship funding is provided in the RMIT RTP Scholarship Policy References.
#### Supervision
(14)  RMIT allocates all candidates a minimum of two suitably qualified and registered supervisors, with relevant expertise, comprising at least: one senior supervisor and one other supervisor. Further information about managing supervisor arrangements, responsibilities and registration is provided in the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14).
#### Workspace Allocation
(15)  All candidates attending RMIT campuses have access to non-laboratory work space. Work space allocation is aligned with the [Infrastructure and Asset Security Policy](https://policies.rmit.edu.au/document/view.php?id=77) and governed by the [HDR Space Management Policy](https://policies.rmit.edu.au/document/view.php?id=26) (divisional policy).
#### Candidature Duration and Enrolment
(16)  Candidature duration is calculated from the research commencement date as stated in the candidate’s offer of admission. The permitted candidature duration is:
  1. PhD – minimum 3.0 Equivalent Full Time Student Load (EFTSL) and maximum 4.0 EFTSL
  2. Masters by research – minimum 1.0 EFTSL and maximum 2.0 EFTSL.


(17)  Full-time commitment will average at least four days per week over the course of the year. Part-time commitment will average at least two days per week over the course of the year.
(18)  Any work, paid or otherwise, undertaken by the candidate outside of their research project may not affect their ability to maintain this commitment.
(19)  Enrolment conditions and variations are set out in the [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16).
#### Progress Management
(20)  Candidate progress is managed through:
  1. regular supervision meetings;
  2. provision of research methods coursework and appropriate skills development training;
  3. formative assessment of progress and researcher capability through three candidature milestones; and
  4. provision of other relevant services and support available to enrolled students. 


(21)  Candidates are required to maintain satisfactory progress as evidenced through:
  1. regular supervisor-candidate meeting records;
  2. public dissemination of research outputs;
  3. successful, timely achievement of three candidature milestones; and
  4. successful completion of research coursework.


(22)  Where candidates’ academic progress is impeded for any reason, they are offered a period of focused action and support to facilitate a return to satisfactory progress. 
(23)  Where a candidate has been unable to return to satisfactory progress and there is evidence that the School has provided adequate guidance, direction and support for the candidate’s progress, the relevant Research Candidate Progress Committee (RCPC) will consider the viability of the candidature and make a recommendation to the ADVC RT&D regarding candidature continuation.
(24)  HDR progress is supported, monitored, assessed and reviewed in accordance with the provisions set out in the [HDR Progress Management Procedure](https://policies.rmit.edu.au/document/view.php?id=15) and the [HDR Action and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=13).
#### Submission and Examination
(25)  The following provisions will apply to candidates submitting for examination from 1 January 2020. Submission and examination for candidates submitting prior to this date will follow the provisions in the 2015-2019 HDR Policy.
(26)  Enrolled candidates are permitted to submit their completed research for external examination subject to:
  1. completion of the minimum enrolment period for the program;
  2. satisfactory progress as evidenced by successful achievement of candidate milestones;
  3. completion of any coursework required by the program; and
  4. completion of research to the standard and specification of the program in accordance with the Australian Qualifications Framework. 


(27)  Research for examination must:
  1. be unified and coherent in content and address a single, significant research question/theme in a field or area of professional practice; and
  2. include a digital record of candidates’ published research outputs, artefacts or experiential presentations which embody candidates’ research undertaken during the course of candidature.


(28)  HDR examinations must be conducted by two experts of international standing in the discipline/field who are external to RMIT, independent of the conduct of the research and without any real or perceived conflict of interest in accordance with the Australian Council of Graduate Research Conflict of Interest Guidelines.
(29)  Examination outcomes are as follows:
  1. In order to pass, an HDR submission must receive two externally-provided pass recommendations on the same version of the submitted work.
  2. Where examiner recommendations diverge on whether the research submitted merits a pass, the University will review the examination in accordance with the relevant procedure. 
  3. Where no clear pass is determined a candidate may be permitted one opportunity of up to twelve months’ duration to revise and resubmit their research for re-examination. 
  4. Candidates receiving a fail classification will not be awarded the degree for which they were enrolled and will not be permitted to revise and resubmit for re-examination for the same level of degree. However, a doctoral candidate whose research has been classified as Failed may be invited to resubmit their HDR submission and have it examined for the award of the related masters by research program within two months of classification.


(30)  RMIT will consider posthumous submission and examination.
(31)  Rules, classifications and processes for examination are prescribed in the [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18), [HDR Posthumous Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=17) and must comply with the Disseminating Research Outputs Process.
#### Complaints and Appeals
(32)  Complaints and grievances relating to HDR are managed in accordance with the Student and Student-Related Complaints Policy.
(33)  Candidates with a current enrolment (including those on an approved period of leave of absence) are entitled to appeal a decision to terminate their candidature or the outcome of an examination in accordance with the Assessment, Academic Progress and Appeals Regulations.
#### Completion
(34)  To be awarded the degree candidates must have:
  1. lodged an approved final archival version of the HDR submission (the archive); and
  2. met all requirements of the [Conferral and Graduation Policy](https://policies.rmit.edu.au/document/view.php?id=8) and associated procedures.


#### Open Access and Embargo
(35)  RMIT will provide open access to all HDR submission archives that have been classified as passed except in cases where an application for an embargo is successful.
(36)  Candidates are entitled to apply for an embargo on publication of their research in the RMIT Research Repository, if they can meet the grounds for embargo as outlined in the [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18).
### Responsibilities
(37)  Academic Board is responsible for overseeing the quality enhancement and review of research training.
(38)  Research Committee is responsible for identifying the areas of established and emerging research strength within the University appropriate to support research training, and overseeing HDR performance against University key performance indicators
(39)  Graduate Research Committee is responsible for:
  1. Providing academic leadership pursuant to quality enhancement, and the avoidance of conflict of interest and institutional and academic risk in the delivery of research training; and
  2. through its Executive group: 
    1. reviewing and ratifying final examination classifications in the case of one or two Fail recommendations being made by examiners on re-examination of an HDR submission;
    2. reviewing exceptional applications for embargo; and
    3. approving requests for posthumous submission and examination.


(40)  The ADVC RT&D or delegate, with the support of the School of Graduate Research, is responsible for:
  1. managing the HDR policy framework and developing and approving all associated procedures and supporting documents to this policy;
  2. approving variations to candidature, milestone outcomes, and panels of examiners; and
  3. determining examination classifications.


(41)  College DPVCs R&I are responsible for:
  1. providing strategic leadership to ensure that HDR profile, and areas of research in which supervision and scholarship are supported are aligned to University strategy;
  2. convening Research Candidate Progress Committees; and
  3. ensuring resourcing and support for quality assurance is available.


(42)  Deans/Heads of School are responsible for:
  1. appointing an HDR Delegated Authority (HDR DA) to act on their behalf;
  2. delivering research training and ensuring supervision and resources required to complete a higher degree by research are available to and accessible by HDR candidates; 
  3. ensuring that all HDR candidates attending RMIT campuses have access to non-laboratory/studio work space;
  4. allocation of supervisors to candidates and oversight of supervision performance;
  5. providing School specific orientation and induction to newly enrolled candidates;
  6. ensuring that academic and professional development activity undertaken within candidature duration supports candidates’ successful and timely completion;
  7. monitoring the general progress and welfare of HDR candidates; and
  8. monitoring compliance with this policy.


(43)  Supervisors are responsible for:
  1. adhering to the HDR [Supervision Code of Practice](https://policies.rmit.edu.au/document/view.php?id=20) and registering and maintaining ongoing eligibility for registration on the RMIT Supervisor Register;
  2. providing timely guidance and feedback to candidates to enable them to maintain satisfactory academic progress and complete their research to a globally recognised standard;
  3. reviewing variations to candidature and submissions for examination; and
  4. providing support and guidance to candidates in the production of high-quality research outputs based on their research and in accessing opportunities for professional development and end-user engagement.


(44)  Candidates are responsible for:
  1. maintaining good academic progress; and
  2. complying with the University’s policy and procedures.


### Review
(45)  The ADVC RT&D is responsible for review of this policy and supporting documents.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=1#document-top)
# Section 5 - Procedures and Resources
(46)  Refer to the following documents which are established in accordance with this Policy:
  1. [HDR Action and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=13)
  2. HDR Admissions and Scholarships Procedure [in development]
  3. [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16)
  4. [HDR Posthumous Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=17)
  5. [HDR Progress Management Procedure](https://policies.rmit.edu.au/document/view.php?id=15)
  6. [HDR Sanctions Assessment Process](https://policies.rmit.edu.au/document/view.php?id=21)
  7. [HDR Space Management Policy](https://policies.rmit.edu.au/document/view.php?id=26)
  8. [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14)
  9. [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18)
  10. [Masters by Research Grading Procedure](https://policies.rmit.edu.au/document/view.php?id=19)
  11. [Research Training Program Scholarships](https://policies.rmit.edu.au/document/view.php?id=22)
  12. [Supervision Code of Practice](https://policies.rmit.edu.au/document/view.php?id=20)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=1#document-top)
# Section 6 - Definitions
Adjudicator | An academic, external to RMIT, appointed to adjudicate on examiners' recommendations.  
---|---  
AHEGS | Australian Higher Education Graduation Statement. All graduates from Australian higher education providers receive an AHEGS.  
ARG | Academic Registrar's Group. ARG's role in relation to higher degrees by research is to support the administrative configuration of programs, to review compliance with academic policy, manage complaints and appeals processes, and to handle the conferral of degrees on behalf of the University.  
Artefact | A component of a candidate’s research submitted for examination that is not the written component.   
Associate supervisor | A member of the supervisory team who contributes in particular areas of disciplinary or methodological expertise. See also HDR supervisor; senior supervisor.  
Candidate | Student enrolled in an HDR degree from the research commencement date until the completion date.  
CASP | Candidate Action and Support Plan. A plan for focused support and monitoring with the goal of returning a candidate to satisfactory academic progress.  
CHEAC | College Higher Degrees by Research Examinations Advisory Committee recommends whether an interim classification may be applied following examination.  
College CASP review | Review by College Graduate Research Committee representative or nominee, to review the action and support provided to a candidate.  
Completion date | The date the candidate submits the final archival version of their HDR submission.  
Confirmation of candidature | The first milestone review which assesses candidate academic progress specifically to determine whether the candidature may transition from probationary candidature to confirmed status. See also milestone review.  
Consumed load | Amount of EFTSL that has been consumed since the research commencement date of a higher degree by research candidate.  
Development activity | Activity, training, internship or work placement which supports the development of HDR candidates as professionals and/or researchers.  
Dissertation | Written component of an HDR submission where other components exist, such as experiential presentation or artefact of the research.  
EFTSL | Equivalent Full Time Student Load (1 EFTSL = 1 full-time year).  
Examination classification | The final assessment made of an HDR submission.  
Experiential presentation | An element of the examination which may include: oral presentation; exhibition; demonstration; performance or similar. The requirement to prepare for such a presentation will be identified in the research project design in accordance with School advice. A digital record of this element must be made available for archival.  
Extension beyond maximum duration of candidature | Time granted to a candidate after their maximum duration of candidature has been reached to allow for HDR submission.   
Final archival | The process by which a candidate lodges the final version of their HDR submission, following successful examination and any required amendments.   
First enrolment date | A candidate’s first enrolment date is the date they first enrol in a program. This should be on or before the research commencement date on the candidate’s offer letter. Enrolment prior to commencement may be helpful to establish ‘student’ status for administrative and regulatory purposes. See also research commencement date.  
GRC | Graduate Research Committee. Committee which oversees the development and implementation of HDR policy, quality assurance of HDR programs, and which makes recommendations to Research Committee on matters of quality and strategy relating to graduate research.  
GRC Executive | The Executive group of the Graduate Research Committee, comprising College GRC representatives, and the Associate Deputy Vice-Chancellor Research Training and Development.  
Graduate research internship | A short-term, (3-6 month) research contract undertaken by an HDR candidate with a partner organisation external to the University, under the academic supervision of the candidate’s RMIT supervisory team and an industry supervisor.  
HDR administrator | A staff member in a school or college who supports the administration of HDR candidates.  
Higher degrees by research | Masters by research or doctoral degrees which conform to the specifications of Levels 9 and 10 of the Australian Qualifications Framework (AQF).  
HDR Delegated Authority (HDR DA) | Member of academic staff described in Clause 7.6a). who has the delegated authority of the Dean/Head of School to provide academic leadership and support for higher degrees by research programs. Schools allocate different titles for HDR DAs, such as Associate Deans/Heads Higher Degrees by Research, HDR Directors, HDR Coordinators.  
HDR Sanctions and Defence Trade Controls assessment | Process used to identify whether the proposed research of an applicant for HDR admission, or the current research of a candidate, is subject to sanctions arising from the [Autonomous Sanctions Act 2011](https://policies.rmit.edu.au/directory/summary.php?legislation=29) or the [Charter of the United Nations Act 1945](https://policies.rmit.edu.au/directory/summary.php?legislation=31) or controls under the [Defence Trade Controls Act 2012](https://policies.rmit.edu.au/directory/summary.php?legislation=23).  
HDR submission | The candidate’s submission for examination which comprises a thesis or dissertation and may also include published research outputs, artefacts or experiential presentations of the research conducted during candidature.  
HDR supervisor | An appropriately experienced and qualified individual responsible for advising and guiding a candidate on the conduct of their research. See also associate supervisor; senior supervisor; joint senior supervisor.  
International candidate | A person enrolled in a higher degree by research who is not a citizen or permanent resident of Australia or a citizen of New Zealand.   
Joint senior supervisor | Senior supervisor appointed to a candidate, alongside another senior supervisor.   
Local candidate | A person enrolled in a higher degree by research who is a citizen or permanent resident of Australia or a citizen of New Zealand.  
Milestone review | A formal event to review the academic progress of an HDR candidate; see also confirmation of candidature.  
Moderator | An RMIT academic staff member (HDR DA or nominee) who is appointed to review examination reports and recommended grades for a Masters by research when the examiners’ grades differ by more than 15 percentage points.  
Normal location of study | The place where an enrolled candidate will undertake the bulk of their study and research towards their degree.  
Offshore candidate | A candidate who is located outside of Australia for the majority of their candidature whether local or international.  
RCPC | Research Candidate Progress Committee. The committee which reviews unsatisfactory academic progress of a candidate and determines whether a candidature should be terminated.   
Research commencement date | The date appearing on the candidate’s offer letter, from which duration of HDR candidature is calculated. See also first enrolment date.  
Research output | Public dissemination of research outcomes in the form of a book, book chapter, commissioned report, conference paper, creative work, journal article, patent, or performance, or other form appropriate to the discipline or field.  
Research project | In relation to HDR candidates, the work planned to fulfil the requirements of the degree.  
Research Training Program (RTP) | The Australian Federal Government block grant provided to Australian higher education providers (universities) to support the research training of local and international HDR candidates.  
Scholarship | A financial allowance or benefit (to help with living expenses and/or a tuition fee) provided to a student to support their study. See also Stipend.  
Senior supervisor | A member of the supervisory team who, provides overall academic leadership to the candidate on their research project. See also Associate supervisor.  
SGR | School of Graduate Research. The unit within the Research & Innovation Portfolio which provides support for strategic development in research training and manages the policy, procedures, and business processes associated with research training at RMIT.  
Stipend | A financial allowance paid directly to the candidate to support living costs while enrolled in their program of study. See also Scholarship.  
Study away | A period of time when an enrolled candidate is undertaking research and study away from their normal location of study, for example, conference attendance or fieldwork.   
Study load | Study load denotes the time fraction allocated to a candidate’s study and is either 'full-time' or 'part-time'.  
Submitted status | The enrolment status of a candidate who has submitted their research for examination.  
Supervisor register | The list of personnel eligible to undertake HDR supervision at RMIT.  
Termination of candidature | Cancellation of the enrolment of a candidate in their HDR program; a result of unacceptable lack of academic progress.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
