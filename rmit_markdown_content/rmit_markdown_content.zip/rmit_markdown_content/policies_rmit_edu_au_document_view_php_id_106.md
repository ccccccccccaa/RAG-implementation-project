[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=106#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=106#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Conduct Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=106)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=106)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=106)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=106)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=106)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=106)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=106)


# Student Conduct Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=106#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=106#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=106#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=106#section4)
  * [Reports of Potential Student Misconduct](https://policies.rmit.edu.au/document/view.php?id=106#major1)
  * [Student Care](https://policies.rmit.edu.au/document/view.php?id=106#major2)
  * [Students Who Are Also Staff of RMIT](https://policies.rmit.edu.au/document/view.php?id=106#major3)
  * [Address for Notice and Communication](https://policies.rmit.edu.au/document/view.php?id=106#major4)
  * [Records, Privacy, and Confidentiality](https://policies.rmit.edu.au/document/view.php?id=106#major5)
  * [Section 5 - Definitions ](https://policies.rmit.edu.au/document/view.php?id=106#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure addresses: 
  1. how RMIT will respond to and refer potential student misconduct
  2. student care
  3. processes applicable to respondent students who are also members of staff
  4. address for notice and communication, and
  5. records, privacy, and confidentiality.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=106#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=106#document-top)
# Section 3 - Scope
(3)  This procedure applies to students and staff of RMIT, as set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). It relates to the implementation of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and corresponding procedures regarding student conduct and the management of student misconduct.
(4)  Nothing in this procedure prevents an officer or Senior Officer from taking precautionary measures at any time to address or manage a safety concern.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=106#document-top)
# Section 4 - Procedure
### Reports of Potential Student Misconduct
(5)  An officer must comply with this procedure when they receive a report or any information resulting in a reasonable belief that a student may have engaged in any form of misconduct under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
(6)  For matters relating to potential academic student misconduct, the officer must investigate the conduct in accordance with the [Academic Integrity Policy](https://policies.rmit.edu.au/document/view.php?id=168) and report it to the relevant course coordinator (or equivalent):
  1. The course coordinator (or equivalent) must evaluate the conduct and determine whether: 
    1. it is an assessment matter that can be addressed as part of the assessment of the student’s work in accordance with clause (10) of the [Academic Integrity Procedure](https://policies.rmit.edu.au/document/view.php?id=179), or
    2. it is potential academic misconduct which will be referred to a Senior Officer via the [Academic Integrity and Student Conduct Reporting Form](https://www.rmit.edu.au/staff/teaching/student-administration/managing-academic-integrity-and-student-conduct).


(7)  For matters relating to potential general misconduct, the officer must:
  1. make initial enquiries and collate relevant information and materials regarding the conduct, and
  2. refer the matter along with the relevant material to a Senior Officer via the [Academic Integrity and Student Conduct Reporting Form](https://www.rmit.edu.au/staff/teaching/student-administration/managing-academic-integrity-and-student-conduct).


(8)  For matters relating to potential high risk misconduct, the officer must refer the conduct to the Student Conduct Board. 
### Student Care
(9)  Applying the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures may have adverse personal or academic consequences for students; therefore, any students to which these procedures apply will be provided with resources and information to support their welfare and wellbeing.
(10)  Staff will assist students, where appropriate, by providing:
  1. information on relevant support services including referral to external services, as required by the nature of the reported conduct
  2. clear and open communication, and
  3. procedural fairness.


(11)  RMIT Group support services include: 
  1. Safer Community
  2. mental health wellbeing and counselling
  3. peer support and advocacy (principal student organisation and Student Council)
  4. assessment adjustments
  5. student complaint processes 
  6. health, security, or accommodation providers
  7. Ngarara Willim Centre (for Aboriginal and Torres Strait Islander students and staff).


(12)  Where there is an emergency or an immediate risk of harm, staff should seek urgent assistance via:
  1. emergency services and RMIT Security, for RMIT Australia. RMIT Security will assist in coordinating personal safety of staff and students, property damage or theft, or referral to a Critical Incident Management Team
  2. the relevant local authority, for offshore campuses and partners.


(13)  Where staff have concerns about how to support a distressed student or staff member, they should immediately contact the RMIT Staff Line for students and People Connect for staff support, for:
  1. advice on managing distress
  2. strategies to address the behaviour causing distress
  3. reasonable and appropriate precautionary measures to protect the safety of any person
  4. referral of the student and staff to other specialist support
  5. disclosure of information.


(14)  Where a student conduct process has commenced, a student may choose to disclose details of concerning, threatening or inappropriate behaviour.
  1. Disclosures may include, but are not limited to, the provision of information about physical or verbal assault, sexual harm or sexual assault, stalking, self-harm, bullying, harassment, unlawful discrimination and/or victimisation.
  2. A person who makes a disclosure or a report of these kinds of behaviours or harm will be informed by staff about their options, including if they would like to report their experience to the police, as well as their ability to engage with the special consideration process or any other academic or wellbeing support mechanisms.
  3. A person may make a disclosure of sexual harm; however, they may choose not to have that disclosure treated as an instance of potential student misconduct to which this procedure applies.


(15)  Staff must notify Safer Community (while maintaining student privacy to the extent possible, and subject to the requirements of this procedure) if any conduct or incident involves:
  1. a person under the age of 18 years
  2. sexual harm, a vulnerable party, or where responding to the matter may require a trauma-informed approach, or
  3. any behaviour which is threatening, concerning or inappropriate.


(16)  Staff must contact the Ngarara Willim Centre if any conduct or incident involves an Aboriginal or Torres Strait Islander student.
  1. The Ngarara Willim Centre may provide care and support to the student during the misconduct process.
  2. Any notice of written communication sent to an Aboriginal or Torres Strait Islander student under clause (21) must also be sent to Ngarara Willim. Notifications received by Ngarara Willim will not be considered receipt of the correspondence by the student.


### Students Who Are Also Staff of RMIT
(17)  Where a student who is the subject of a potential misconduct report is also a staff member, action may also be taken under the relevant staff policy where their position as a staff member was relevant to the circumstances of the reported conduct.
(18)  Factors which may affect the relevance of a person’s status as a staff member may include (but are not limited to):
  1. whether the person was acting in their capacity as a staff member at the time the reported conduct is said to have occurred
  2. whether the person’s status as a student and staff member was known or apparent to any other persons involved
  3. whether the person’s status as a staff member was still current at the time of the reported conduct
  4. whether the person’s status as a staff member enabled the person to have additional access to RMIT facilities or equipment which relates to the reported conduct
  5. whether the person’s status as a staff member provided them actual or perceived: 
    1. authority, power, or trust
    2. ability to influence student or staff matters
    3. obligations to discharge a duty of care in relation to a student
    4. discretion in relation to a student or staff matter
  6. the nature and seriousness of the potential student misconduct and its consequences
  7. any other facts or circumstances which relate to the persons involved in the reported conduct which are relevant to a person’s status as a staff member.


(19)  In circumstances where both the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and the relevant staff policy and procedures apply, RMIT’s human resources team will work with the Academic Registrar (or delegate) to determine the most appropriate way or ways to proceed, which may include pausing one set of proceedings or investigation while the other continues, or having both proceedings being conducted at the same time.
(20)  Where the reported conduct is investigated, the investigation should be undertaken so as to reduce an overlap or repeated questioning or evidence gathering, and evidence or other relevant material gathered in the course of one proceeding may be used in relation to the other.
### Address for Notice and Communication
(21)  Any notice or written communication to a student for the purposes of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), policy and corresponding procedures, including in relation to the application of an executive suspension, notification of the opportunity to make a response to conduct matter or an outcome determination, is sufficient if it is in writing and:
  1. emailed to the student’s allocated RMIT email account, or if there is no RMIT email account, or if access to the RMIT email account has been suspended, such other personal email account held in RMIT’s student records system; or
  2. posted by registered mail to the address listed in the student’s contact information within RMIT’s student records system.


(22)  A notice is deemed to have been received:
  1. if sent by email, either at the time designated by an email delivery receipt, or 24 hours after the time it was sent by RMIT, whichever occurs first, or


  1. after 72 hours if posted by registered mail.


### Records, Privacy, and Confidentiality
(23)  All parties to Student Conduct matters initiated under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures must maintain confidentiality whilst the process is underway in order to ensure the integrity of the proceedings and outcomes. This requirement does not limit the exercise of student academic freedoms associated with university operations upon the formal conclusion of student conduct proceedings.
(24)  Advocates and support persons are bound by the same confidentiality requirements as all other persons involved in conduct proceedings.
(25)  RMIT recognises the importance of maintaining confidentiality to ensure safety and will seek to balance this with procedural fairness. This may mean that the identities of persons who are witnesses are not disclosed to a respondent student where it might give rise to a risk to safety or wellbeing. Different approaches to confidentiality may also apply where a matter involves persons who are under 18 years of age.
(26)  Records and information regarding student conduct matters will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and the information management policies and procedures.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=106#document-top)
# Section 5 - Definitions 
Term  | Definition  
---|---  
advocate | means a member of the principal student organisation, case manager from Safer Community or another person approved by a Senior Officer or Chair of the Student Conduct Board to accompany a student during an investigation or conduct hearing. An advocate may provide advice and is permitted to make submissions or speak on a respondent student's behalf during an investigation or conduct hearing.  
course coordinator | means the academic or teaching staff member who is responsible for the management, conduct, teaching and assessment of a course.  
respondent student  | is a student who is reported to have engaged in conduct which might, if proven, constitute misconduct, or who has been found to have engaged in misconduct.  
Senior Officer | means the role of Senior Officer as established under the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180) and referenced within the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).  
sexual assault | occurs when someone does not consent to a sexual act, such as where a person is forced, coerced, or tricked into sexual acts against their will or without their consent, including when they have withdrawn their consent. Sexual assault includes a range of behaviours, all of which are unacceptable and constitute a crime. Examples of conduct which may constitute sexual assault or sexual harassment are also set out in the [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).  
sexual harm | is the term RMIT uses to describe any kind of impact on a person (including trauma) which could result from non-consensual sexual behaviour, including sexual harassment or sexual assault.  
support person | a support person is someone who may accompany a person and support their wellbeing during a student conduct investigation or conduct hearing but who may not represent or speak on behalf of the student. A support person is usually a family member, friend, fellow student or colleague.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
