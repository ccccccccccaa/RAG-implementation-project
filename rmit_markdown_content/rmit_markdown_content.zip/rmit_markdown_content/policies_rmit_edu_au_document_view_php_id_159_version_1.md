[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=159&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=159&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Cultural Collection Asset Guideline: RMIT Design Archives 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=159)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=159&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=159&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=159&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=159&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=159&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=159&version=1)


# Cultural Collection Asset Guideline: RMIT Design Archives
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=159&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=159&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=159&version=1#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=159&version=1#section4)
  * [Collection Scope](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major1)
  * [Acquisitions](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major2)
  * [Acquisition Process](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major3)
  * [Collection Storage and Conservation](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major4)
  * [Deaccessioning](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major5)
  * [Access](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major6)
  * [Loans](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major7)
  * [Born Digital and Digital Collections](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major8)
  * [Oral Histories](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major9)
  * [Legal/Ethical Obligations](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major10)
  * [Copyright](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major11)
  * [Privacy](https://policies.rmit.edu.au/document/view.php?id=159&version=1#major12)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This guideline ensures the RMIT Design Archives (RDA), an RMIT cultural asset, is cared for and managed in accordance with the [Cultural Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=74) and the [ICOM Code of Ethics for Museums](https://policies.rmit.edu.au/download.php?id=216&version=1&associated).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=159&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Cultural Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=74).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=159&version=1#document-top)
# Section 3 - Scope
(3)  These guidelines apply to all RMIT University employees and other individuals acting on behalf of the University working within the RMIT Design Archives.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=159&version=1#document-top)
# Section 4 - Guideline
### Collection Scope
#### Collection Themes
(4)  The RDA collects material related to design in Melbourne and Victoria from World War II to the present, focusing on the following disciplines:
  1. architecture
  2. landscape architecture
  3. interior design
  4. textile design
  5. fashion design
  6. industrial/product design
  7. automotive design
  8. furniture design
  9. gold and silversmithing
  10. graphic/communication design


#### Historic Period / Time Period
(5)  The RDA collection scope covers from World War II to the present day.
#### Geographic Area / Region
(6)  The geographic focus of the collection is Melbourne and Victoria.
#### Physical Items to be Collected
(7)  The RDA collects physical and digital forms of a range of material types across all stages of the design process, including but not limited to: 
  1. awards
  2. audio-visual recordings
  3. documents and correspondence
  4. garments and textiles
  5. drawings
  6. artwork
  7. ephemera
  8. job files
  9. models and prototypes
  10. research notes
  11. scrapbooks
  12. sketchbooks
  13. sample books
  14. posters
  15. photographs
  16. press clippings
  17. product brochures
  18. promotional materials
  19. books and magazines
  20. oral histories


#### Collection Development
(8)  Priorities for collection development will be identified annually by RDA staff in collaboration with the RMIT Design Archives Collection Advisory Panel.
(9)  Collection priorities will be shared with the RMIT Cultural Collections Acquisition Committee (CCAC) at the first CCAC meeting each year.
### Acquisitions
#### Method of Acquisition
(10)  RDA will acquire items by donation, bequest, purchase or transfer of title.
(11)  RDA will not accept:
  1. accept conditional donations, or
  2. permanent loans. Extended loans for established periods of time will be negotiated as required (see Loans).


(12)  Items offered to RMIT for RDA under the Cultural Gifts Program will be assessed in accordance with the Cultural Gifts Program guidelines.
(13)  RDA will conduct acquisition processes in accordance with the [ICOM Code of Ethics for Museums](https://policies.rmit.edu.au/download.php?id=216&version=1&associated).
(14)  All acquisition proposals will be reviewed considered by the Cultural Collections Acquisition Committee (CCAC), with final approval resting with the Deputy Vice-Chancellor Design and Social Context (or their approved delegate).
#### Acquisition Criteria
(15)  Proposed acquisitions must meet the following criteria:
  1. Legal Requirements: The RDA will only accept items where the donor/vendor has clear legal title to the item.
  2. Provenance and Documentation: The history of the item must be known and associated documentation and support material can be provided.
  3. Storage: Acceptance of large items (or collections) will be conditional on storage space being available as well as resources required to house them appropriately.


(16)  Proposals will be further assessed according to the following criteria:
  1. Significance: Items that are significant for their historic, aesthetic, scientific/research or social/spiritual value.
  2. Relevance: Items that relate to their collection purpose and collection scope.
  3. Condition, Intactness, Integrity: Items should be in good condition, suitable for research or display and not requiring extensive conservation work or treatment.
  4. Interpretive and Teaching Potential: Items that enhance the interpretation of collection themes or align with the University’s teaching and learning objectives.
  5. Rarity: Rare examples of a particular kind of item.
  6. Representativeness: Excellent representative examples of a particular kind of item.
  7. Duplications: Items that duplicate items already within the collection or elsewhere within RMIT will not be accepted unless they are of superior condition and/or historic value.


### Acquisition Process
#### General
(17)  Any travel costs in excess of $100, associated with assessment or acquiring a potential collection item, must be pre-approved by the Collections and Archives Manager.
(18)  No material should be brought onsite without prior approval from the CCAC. In exceptional circumstances, approval may be given by the Collections and Archives Manager (or their representative) for early receipt of material.
(19)  In general, material will be considered unavailable for research, teaching and learning purposes until fully processed.
#### Offers of Donation/Transfer
(20)  In general, the first point of contact is the RMIT Design Archives Collections Coordinator. Potential Donors should be referred to the Collections Coordinator.
(21)  Any site visits to a donor or potential donor should be attended by a representative of both the curatorial and collections teams.
(22)  The potential donor, in liaison with Collections Coordinator, will be requested to complete an Offer of Donation Form to record the context, history, significance and associations of the material, and to provide any supporting documentation demonstrating provenance.
(23)  The Collections Coordinator will transcribe the Offer of Donation Form information into the Acquisition Proposal Form before passing on the proposal document to the RMIT Design Archives Curatorial Officer.
(24)  The Curatorial Officer will appraise the material against the Collecting Areas and Acquisition Criteria, and if found suitable for the collection, include this in the Acquisition Proposal Form.
(25)  The Collections Coordinator will ensure the Acquisition Proposal Form is complete and sent to the Collections and Archives Manager at least two weeks prior to the next CCAC meeting.
(26)  The Collections and Archives Manager will send proposed acquisitions documentation and meeting agenda to the CCAC at least one week prior to meetings.
(27)  The CCAC will recommend the offer of donation be approved or declined.
(28)  Final approval for acquisitions rests with Deputy Vice-Chancellor Design and Social Context, or their approved delegate.
(29)  On approval of the proposed donation, the donor will be informed of the outcome and required to sign a Deed of Gift assigning legal ownership for the material to the RDA.
(30)  The material will be transferred onsite for inventory, registering (or cataloguing), physical numbering, photographing (or digitisation) and rehousing.
(31)  If any material is brought on site before it has been assessed and rejected by the CCAC, the material will be returned to the donor with an explanatory letter within 30 days.
(32)  If the material for whatever reason is not claimed by the donor or it is not able to be returned, RMIT may treat any such material as uncollected goods according to the [Australian Consumer Law and Fair Trading Act 2012 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=37).
#### Purchases
(33)  Any member of the RMIT Design Archives Collection Advisory Panel may make recommendations for acquisitions by purchase via the Acquisition Proposal Form.
(34)  The Curatorial Officer will ensure acquisition proposals are appraised against the Collection Scope and Acquisition Criteria.
(35)  The Collections Coordinator will ensure the Acquisition Proposal Form is complete and sent to the Collections and Archives Manager at least two weeks prior to the next Cultural Collections Acquisition Committee meeting.
(36)  The Collections and Archives Manager will send proposed acquisitions documentation and meeting agenda to the CCAC at least one week prior to meetings.
(37)  Items acquired for the RDA permanent collection by purchase, must obtain financial approval from the appropriate delegate.
  1. Should the total price for a purchased collection item exceed the capitalisation threshold of $5000 (including costs incurred in getting the asset to a position of use (e.g. import duties, delivery fees)), the RDA will inform the Financial Services Group in accordance with the [Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=128).


### Collection Storage and Conservation
(38)  The RDA aims to achieve high standards of collection care and storage.
  1. Collection storage areas will be secure, tidy and sealed against the weather.
  2. Access to storage areas will be controlled and monitored by RDA collections staff.
  3. Ultra-violet light will be excluded from storage areas.
  4. When storage areas are not in use lights must be turned off.
  5. Preference will be given to conservation quality storage materials. No material will enter collection stores without first being quarantined.
  6. Storage areas will be regularly cleaned and checked for pests and other problems in accordance with the RMIT Cultural Collections Integrated Pest Management Plan.
  7. Collection items will be allocated a permanent storage location and, when not in immediate use, will be stored there at all times.
  8. Any change of location (including temporary) will be recorded immediately in the collection management system by trained personnel.
  9. Items should not be stored on the floor.
  10. Untrained personnel may not handle, clean, treat or restore collection items without supervision of collection staff.
  11. Researchers will be given guidance on how to appropriately handle specific materials prior to handling collections items and where required PPE will be provided to them.
  12. All professional staff and volunteers handling collection materials will be required to participate in annual refresher training, to be led by collections staff.


### Deaccessioning
#### Criteria for Deaccessioning
(39)  An item may be considered for deaccessioning if:
  1. the physical condition of the item is so poor that restoration is not practicable or would compromise its integrity 
    1. items that are damaged beyond reasonable repair and are of no use for study or teaching purposes may be destroyed
  2. the item poses threats to health and safety to the staff and the public.
  3. the item breaches Aboriginal, Torres Strait Islander or other community group cultural guidelines
  4. the RDA is unable to care adequately for the item because of its particular requirements for storage or conservation. 
  5. the item is a duplicate that has no added value as part of a series.
  6. the item is of poor quality and lacks aesthetic, historical and/or scientific value for exhibition or study purposes and no longer meets the Acquisition Criteria
  7. the authenticity or attribution of the item is determined to be false or fraudulent, and the fraudulent item lacks sufficient aesthetic, historical and/or research value to warrant retention. 
    1. In disposing of a presumed forgery, the RDA shall consider all related legal, curatorial and ethical consequences, and should avoid releasing the item to public auction. 
  8. The item is more suited to another collecting organisation and its collecting scope.
  9. The RDA's possession of the item is inconsistent with applicable law or ethical principles, e.g., the item was, or may have been, stolen or illegally exported or imported, or the item may be subject to other legal claims for return or restitution. 
  10. The item is no longer consistent with the RDA's mission or collecting goals.
  11. A substantiated request for the return of the item to its original owner/donor is received.


#### Deaccessioning Process
(40)  Collections staff will identify and propose material to the CCAC for consideration, with close reference to the criteria stated above.
(41)  Deaccessioning proposals will be presented via the Acquisition Proposal Form and contain:
  1. a brief description of the item and provenance (if known)
  2. acquisition details and legal status
  3. reasons for recommending deaccessioning.


(42)  Where possible and appropriate donors, or their legal representative, will be contacted and notified of intent to deaccession. 
(43)  The item identified for deaccession must be held for a twelve-month ‘cooling-off’ period before it is finally disposed, unless it poses an unacceptable hazard to personnel or to other collections, in which case it may be disposed earlier in consultation with RMIT Workplace Health & Safety.
(44)  When deaccessioned, the details provided at clause (41) will be recorded on the item’s file and will be available for inspection if required. Accession numbers will not be reallocated to other items.
(45)  Staff, volunteers, committee members and their families are prohibited from purchasing, or otherwise obtaining, any de-accessioned item.
(46)  Any funds realised from the deaccessioning and disposal of an item will be used solely for the benefit of the collection in accordance with the [Guidelines on Deaccessioning of the International Council of Museums](https://policies.rmit.edu.au/download.php?id=217&version=1&associated).
(47)  Where the RDA has decided to dispose by exchange, the agreement for exchange may include provision for payment or receipt of money in addition to the deaccessioned object, in recognition of the difference in value between the objects exchanged.
(48)  Where possible and relevant, the name of the donor or the fund from which a deaccessioned item was originally acquired is to be credited to a new acquisition.
#### Disposal Methods
(49)  Approved methods of disposal in priority order are:
  1. return to original donor (unless the item was acquired under the Australian Government’s Cultural Gifts Program)
  2. transfer to a like-minded, relevant, public collecting institution
  3. redistribution within RMIT as an educative/interpretive tool
  4. sale by public auction (unless the item was acquired under the Australian Government’s Cultural Gifts Program)
  5. destruction.


### Access
(50)  Access to the RDA is facilitated in the following ways:
  1. collection holdings will be made accessible via the RMIT website
  2. physical collection items are made available for research purposes by appointment under strict staff supervision
  3. where possible, collections engagement will be enhanced through open storage, displays and public programs
  4. the RDA will lend items to other organisations for exhibition. It will not lend to private collectors, students or individuals.


### Loans
#### General
(51)  The RDA may lend and borrow material to help meet its purpose, including lending items to other collecting organisations. It will not lend to private collectors, students or individuals.
(52)  The RDA does not accept permanent, long-term, or conditional loans.
(53)  Loan forms must specify the agreed insurance coverage to be met by the Borrower. Loans documentation will be managed by RDA staff.
#### Inward Loans Process
(54)  Inward loans shall only be accepted for specific exhibitions or research and for fixed periods of time.
  1. A representative of both the RDA and the lender will be required to sign an agreed inward loan form.
  2. Each party will hold a copy of this agreement.
  3. This form will record conditions of the loan and the period of the loan.
  4. Loans shall remain in the possession of the RDA for the time specified on the form.


(55)  The RDA agrees to exercise the same care with respect to loans as it does for its own collection.
(56)  The RDA may request to renew loans if required.
  1. Documentation recording renewal must be signed by the RDA and the lender.


(57)  The RDA will recognise the asset at current market value at insurance value set by the Lender and agreed to by Central Risk Management.
(58)  The RDA will inform Financial Control of receipt of any loaned item in accordance with the [Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=128).
#### Outward Loans Process
(59)  RDA may lend items to other collecting organisations. It will not lend to private collectors, students or individuals.
  1. A formal loan agreement will be signed by both parties, outlining any conditions and the period of the loan.
  2. The Borrower will be required to provide a Certificate of Currency and insurance, environmental and facility reports as requested.
  3. The maximum loan period is 12 months. Applications for extension of this period must be made prior to the loan expiry date.


(60)  Loans will remain in the possession of the borrower until returned to RDA.
(61)  For any item listed on the asset register loaned to an outside institution, RDA will notify Financial Control of the change of location, in accordance with the [Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=128).
### Born Digital and Digital Collections
(62)  RDA acknowledges that digital collections are as important as physical and analogue collections. 
(63)  Decisions on born digital material will be subject to the same acquisition criteria and processes as non-digital items.
(64)  Digital Preservation Process will include the following steps:
  1. Quarantine: Records are checked for viruses and completeness.
  2. Preservation: Records are preserved (normalised, or converted, into open formats)
  3. Storage: Records are deposited for long-term storage in a digital archive.
  4. Back-up: Digital records are regularly backed-up (daily by ITS; monthly to external hard-drive by collections staff).


(65)  Digitisation projects will be guided by the [National Library of Australia image capture standards](https://policies.rmit.edu.au/download.php?id=207&version=1&associated) and the [National Archives of Australia technical specifications for digitising audiovisual records](https://policies.rmit.edu.au/download.php?id=208&version=1&associated). 
### Oral Histories
(66)  The RDA will observe their legal, ethical and moral obligations in the recording, transcribing and subsequent use of oral history interviews in accordance with the [Oral History Association Guidelines for Ethical Practice](https://policies.rmit.edu.au/download.php?id=209&version=1&associated) as well as the RMIT [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28).
(67)  An Oral History Agreement must be signed by the person interviewed, which clearly states the purpose and intended uses of the interviews and what copyright provisions apply.
(68)  The RDA aims to have full copyright over any material it collects with regards to oral histories.
(69)  Associated material collected as a result of any interview (e.g. diaries, photographs, etc.) will be subject to the same collection acquisition criteria as outlined in Acquisitions.
### Legal/Ethical Obligations
#### Aboriginal Items
(70)  The RDA endorses Article 31 of the [United Nations Declaration on the Rights of Indigenous Peoples](https://policies.rmit.edu.au/download.php?id=211&version=1&associated) which states that Indigenous peoples have the right to maintain, control, protect and develop their cultural heritage, traditional knowledge and traditional cultural expressions.
(71)  The RDA recognises First Nations Peoples' ownership of their Indigenous Cultural and Intellectual Property that may be held in our collections and works proactively with Aboriginal and Torres Strait Islander staff members and communities to provide access to collections. This includes any cultural heritage and knowledge recorded in published works.
(72)  The management and display of collection items and/or documentation pertaining to any Aboriginal and Torres Strait Islander material will comply with the:
  1. [Australian Museums and Galleries Association First Peoples: Connecting Custodians (2020) (draft)](https://policies.rmit.edu.au/download.php?id=212&version=1&associated)
  2. [Aboriginal and Torres Strait Islander Protocols for Libraries, Archives and Information Services (2012)](https://policies.rmit.edu.au/download.php?id=214&version=1&associated),
  3. [Dhumbah Goorowa Reconciliation Plan 2019-2020](https://policies.rmit.edu.au/download.php?id=213&version=1&associated).


(73)  In doing so, RDA will promote standards of excellence in practice, in accordance with National and State Libraries Australasia National position statement for Aboriginal and Torres Strait Islander library services and collections, with a focus on the following:
  1. The right of Aboriginal and Torres Strait Islander peoples to: 
    1. be informed about collections items that exist relating to them, their culture, language and heritage.
    2. determine any use and access provisions for collection items that relate to them, their culture, language, history and perspectives.
    3. request the removal of or limiting of access to content that should not be accessed due to cultural restrictions
  2. The development of strategies to return usable copies of collection material to cultural owners to support cultural and language maintenance or revitalisation
  3. Aboriginal and Torres Strait Islander people will be: 
    1. consulted in relation to the catalogue description and classification of collection materials, and opportunities will be made for them to annotate and describe material that relates to themselves and their communities
    2. consulted and involved with all aspects of any interpretation of any collection items that exist relating to them, their culture, language and heritage, whether for exhibition, publication or educational purposes
  4. Aboriginal and Torres Strait Islander communities will be consulted about and before any digital content that might be made available online, including websites and social media.
  5. Where materials are accessible, whether online or physically, access will be preceded by a notice advising Aboriginal and Torres Strait Islander people of potentially sensitive or distressing content such as images, sounds and names of deceased persons; images of people who have not yet been identified; and historical images containing nudity.


(74)  These principles will form the basis of an ongoing dialogue between stakeholders and RDA and will be periodically reviewed and revised in order to better facilitate understanding, collaboration and organisational goals.
### Copyright
(75)  To the extent permitted by law and to the extent necessary to enable RMIT to exercise its rights, RDA will uphold all:
  1. intellectual rights (as defined in Article 2 of the [Convention Establishing the World Intellectual Property Organisation (WIPO Convention) (1967)](https://policies.rmit.edu.au/download.php?id=218&version=1&associated)
  2. principles of RMIT’s [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23)
  3. moral rights, rights of integrity and rights of attribution inherent in an acquisition.


### Privacy
(76)  The RDA will adhere to the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and affirms RMIT’s commitment to privacy and its approach to the responsible handling of personal and sensitive information in all its forms, consistent with relevant legislation.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
