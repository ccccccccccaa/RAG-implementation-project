[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=241&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=241&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Weighted Average Mark Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=241)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=241&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=241&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=241&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=241&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=241&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=241&version=1)


# Program and Course Weighted Average Mark Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=241&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=241&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=241&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=241&version=1#section4)
  * [Composition of WAM courses in honours programs](https://policies.rmit.edu.au/document/view.php?id=241&version=1#major1)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This schedule provides the rules for calculating Weighted Average Mark. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=241&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=241&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to Bachelor honours (embedded honours and one-year honours) programs approved after 1 January 2016. 
(4)  This procedure only applies to Associate Degrees, Bachelor honours degrees and Masters by Research degrees commenced after 1 January 2016.
(5)  For students who commenced study in a bachelor honours degree program prior to 1 January 2016 the award level is determined based on the whole-program Grade Point Average (GPA), refer to [Appendix 1 – Award Level Classification prior to 1 January 2016](https://policies.rmit.edu.au/download.php?id=467&version=2&associated).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=241&version=1#document-top)
# Section 4 - Procedure
(6)  In Bachelor honours degrees, a weighted average mark (WAM) is the average of a student’s numerical marks in the nominated set of courses, weighted by the value of the course credit points.
(7)  Refer to the [Weighted Average Mark (WAM)](https://www.rmit.edu.au/students/my-course/assessment-results/results-grades/wam) webpage for the formula for calculating WAM and further information.
(8)  A course counts towards a student's WAM if it has been designated as a WAM course, and a student takes the course while enrolled in an honours program or a program that is GPA-linked to an honours program.
(9)  In double degree programs, a WAM-marked course will count towards the WAM calculation for all programs it is taken as part of.
(10)  New courses must be designated as WAM when created and before students enrol in the course.
(11)  If a new WAM course is to be included in existing honours programs, the programs’ design team must be notified that the new course is WAM designated.
(12)  Once a course is designated a WAM course, it must remain a WAM course.
(13)  Designating a WAM course is a declaration that the course contributes to the most advanced program learning outcomes of an honours program. Typically, these courses are structured in year three or later.
(14)  A new WAM designated course must be created if a school/industry cluster or college determines that an existing course is no longer suitable as a WAM course as it no longer represents part of the most advanced program learning outcomes.
(15)  If an existing course is not designated as a WAM course, it cannot be declared as a WAM course in the future.
(16)  RMIT does not provide for manual or exceptional adjustments to WAM calculations.
### Composition of WAM courses in honours programs
(17)  Single-degree embedded honours programs must have at least 96 credit points of designated WAM courses. Core and program option courses count toward this limit.
(18)  Double-degree embedded honours programs, where both degree components are honours degrees, must have at least 96 credit points of designated WAM courses per degree component, except where a course contributes to the honours-level program learning outcomes for each component degree.
  1. The component degrees’ WAM and other courses must be stated in the program guide in accordance with the [Program and Course Guides Instruction](https://policies.rmit.edu.au/document/view.php?id=203).


(19)  All courses count towards a student’s WAM in a one-year Bachelor honours program whether they are a designated WAM course or not.
(20)  Students must be informed that a course they are enrolling in is a designated WAM course in Enrolment Online if they are enrolled in an embedded Bachelor honours program.
(21)  WAM is used to calculate the honours level awarded in an honours program.
(22)  A student in an honours program cannot opt out of receiving the WAM calculation unless they started the program before 2016 and were incorrectly advised about their inclusion in a category affected by the WAM.
(23)  Occasional exceptions in some program transfers before and after 2016 may justify a student’s honours level to be determined by the pre-2016 system of GPA.
(24)  If a student started in a Bachelor program (pass or honours) before 2016 and the program was converted to a different Bachelor honours program in 2016 or later, only their 2016 and later results in that honours program count toward their WAM.
(25)  If a student started in a Bachelor program (pass or honours) after 2016 and the program was converted to a different Bachelor honours program in 2016 or later, and the old and new programs are GPA-linked, results in both GPA-linked programs count toward their WAM.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
