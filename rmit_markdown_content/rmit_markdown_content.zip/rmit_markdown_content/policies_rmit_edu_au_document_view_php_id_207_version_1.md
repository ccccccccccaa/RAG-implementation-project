[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=207&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=207&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Approval Procedure - Vocational Education and Training 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=207)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=207&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=207&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=207&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=207&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=207&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=207&version=1)


# Program and Course Approval Procedure - Vocational Education and Training
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=207&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=207&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=207&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=207&version=1#section4)
  * [Training Package Lifecycle – Vocational Education](https://policies.rmit.edu.au/document/view.php?id=207&version=1#major1)
  * [Variation to an Existing Program](https://policies.rmit.edu.au/document/view.php?id=207&version=1#minor1)
  * [Course Transitions and Deletion](https://policies.rmit.edu.au/document/view.php?id=207&version=1#minor2)
  * [Training Product Discontinuation, Transition and Teach-out](https://policies.rmit.edu.au/document/view.php?id=207&version=1#minor3)
  * [Programs to be Removed from RMITs Scope of Registration](https://policies.rmit.edu.au/document/view.php?id=207&version=1#minor4)
  * [Registration of the Decision to Discontinue a Vocational Education Program outside Australia](https://policies.rmit.edu.au/document/view.php?id=207&version=1#minor5)
  * [Consultation with Stakeholders](https://policies.rmit.edu.au/document/view.php?id=207&version=1#minor6)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=207&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets the requirements for vocational education and training program and course approval, amendment and discontinuation.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=207&version=1#document-top)
# Section 2 - Authority
(2)  The authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=207&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all vocational education and training programs and courses offered by the RMIT Group, partners and affiliated third parties.
(4)  This procedure does not apply to non-award Foundation Studies and English Language Intensive Courses for Overseas Students (ELICOS) programs which are delivered in accordance with the relevant national standards and RMIT University Pathways (RMIT UP) procedures.
(5)  This procedure does not apply to higher education programs, RMIT short (non-award) courses, micro-credentials or Higher Degrees by Research programs and courses (please see [Program and Course Approval Procedure – Higher Education Coursework, Short Courses and Micro-Credentials](https://policies.rmit.edu.au/document/view.php?id=297) and [Program and Course Approval Procedure - Higher Degrees by Research](https://policies.rmit.edu.au/document/view.php?id=205)). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=207&version=1#document-top)
# Section 4 - Procedure
(6)  All training products on RMIT’s Scope of Registration comply with the requirements of the training products and/or VET accredited courses.
(7)  Award programs comply with the volume of learning in the relevant [Australian Qualifications Framework (AQF)](https://policies.rmit.edu.au/download.php?id=18&version=2&associated) specification. 
  1. Programs may have a reduced volume of learning. Justification for the reduction is provided in writing in the Training and Assessment Strategy and is based on factors such as: 
    1. characteristics of the cohort
    2. design of the program.
  2. The rationale must clearly describe how the specific student cohort: 
    1. has the characteristics to achieve the required rigour and depth of training
    2. can meet all the competencies in a shorter timeframe.


(8)  A new training product can only be advertised or commence delivery once:
  1. the authorities defined in the [Program and Course Schedule - Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=10&associated) have provided approval
  2. it has been added to RMIT’s Scope of Registration
  3. the permanent delivery location and delivery state/territory is added to RMIT’s Scope of Registration.


(9)  A new training product:
  1. requiring the availability of VET student loan (VSL) support can only be advertised with VSL eligibility once it has been registered with the Commonwealth Government
  2. intended to be available to students on a student visa in Australia can only be advertised or commence delivery once it has been issued a CRICOS code.


(10)  An RMIT training product must be delivered in English before it is offered in another language, so that learning and assessment materials can be aligned with internal and external compliance standards before they are translated.
  1. RMIT programs that are delivered and assessed in a language other than English must be approved by the Academic Board.


### Training Package Lifecycle – Vocational Education
(11)  The approval authorities for new programs, changes to existing programs and changes to RMIT’s Scope of Registration are defined in the [Program and Course Schedule - Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=10&associated). 
(12)  A training and assessment strategy is required for each delivery for RMIT vocational education and training programs and plans. This requirement includes Nationally Recognised Training Package Qualifications, Accredited Courses, Skill Sets and standalone Units of Competency.
(13)  Scope audit update reports are provided to the College of Vocational Education by the Academic Registrar's Group at least twice per year to support reporting and compliance activities. 
(14)  RMIT has delegated authority to add or remove programs from its Scope of Registration without applying to ASQA.
  1. The College Deputy Vice-Chancellor College of Vocational Education and CEO of the Registered Training Organisation is the nominated Delegate under the Agreement. 
    1. All training products listed in Schedule 1 of the Delegation Agreement must still apply directly to ASQA for addition to scope. Refer to the ASQA Delegation Agreement for further information.
  2. RMIT can only add or remove programs from its CRICOS registration with prior approval from ASQA.
  3. ASQA must be notified of any changes to a permanent delivery location and/or changes to interstate delivery.


(15)  All proposed changes to RMIT's Scope of Registration, including proposed replacements of superseded training products (both equivalent and non-equivalent) and associated cessations of delivery must have:
  1. a concept submission recommended by the Program Working Group, for endorsement by the College Executive before proceeding with a business and academic case, or business case waiver
  2. a Notice of Intent, submitted to ARG Course and Program Administration.


(16)  The business and academic case undergoes a pre-executive review by the Associate Deputy Vice-Chancellor Learning and Teaching, Associate Deputy Vice-Chancellor Programs and Delivery, and General Manager, College Operations (or equivalent), prior to approval by the College Executive.
(17)  The addition of a training product, other than the replacement of a superseded product with an equivalent product, must be endorsed by an ASQA Delegation Panel prior to being approved for addition to RMIT’s Scope of Registration by the College Deputy Vice-Chancellor Vocational Education and CEO of the Registered Training Organisation.
  1. Refer to the [ASQA Delegated Functions Processes and Guide](https://rmiteduau.sharepoint.com/sites/VEprogramapproval/Guidance%20Materials/Forms/AllItems.aspx?id=%2Fsites%2FVEprogramapproval%2FGuidance%20Materials%2FPanel%20Management&viewid=47f1b4f3%2D7678%2D4ad3%2Dbfbf%2D7b5ea75d34af) for further information, maintained by the Academic Registrar's Group on the [Vocational Education Program Approval](https://rmiteduau.sharepoint.com/sites/VEprogramapproval/SitePages/VE%20Program%20Approvals.aspx) SharePoint Site
  2. Education Regulation Compliance Assurance quality reviews the ASQA Delegations process annually and reports to the Education Committee for noting.
  3. ARG Academic Governance reports the outcomes of the ASQA Delegation panel submissions to the Education Committee for noting.


(18)  Academic case and business case proposals (or business case waiver) are required for:
  1. new offerings of training products in a discipline or industry area not currently delivered by RMIT
  2. new offerings of equivalent programs automatically added to RMIT’s Scope of Registration
  3. new offerings that have strategic or resource implications
  4. new offerings of training products at an approved RMIT partner institution or enterprise, and
  5. the creation of a new plan.


(19)  All changes made to RMIT’s Scope of Registration on the National Register by delegated approval are reconciled annually.
  1. ARG Academic Governance will reconcile changes to the Scope of Registration approved by the Delegate Representative with the National Register and provide a report using the template provided by ASQA.
  2. The Annual Reconciliation Report must be approved by the Delegate as an accurate record.
  3. ARG Academic Governance will submit the Annual Reconciliation Report to the Education Committee for noting.


(20)  The Education Regulation Compliance Assurance team will submit the Annual Reconciliation Report and the Annual Quality Assurance Review report to ASQA as per the requirements of the Delegation Agreement.
#### Variation to an Existing Program
(21)  A program structure amendment, creation of a new plan, or new domestic delivery location may be made or added for the following reasons:
  1. to cater for an industry-specific cohort
  2. specialisation in the training package with testamur requirements
  3. introduction of trainees and apprentices
  4. consultation with relevant industry groups including the Industry Advisory Committee
  5. external updates to units or courses (superseded or deleted units of competency)
  6. community, industry or government demand.


(22)  The creation of a new plan must be recommended by the Program Working Group prior to approval by the Associate Deputy Vice-Chancellor Learning and Teaching.
(23)  Program amendments are approved by the Associate Deputy Vice-Chancellor Learning and Teaching.
(24)  If the location is in a state or territory that is not listed on RMIT’s Scope of Registration for that training product, that change must be notified to ASQA and added to RMIT’s Scope of Registration by the Academic Registrar's Group.
#### Course Transitions and Deletion
(25)  Where a training package requires the delivery of a superseded or deleted unit, programs should continue to follow the training package rule.
  1. Where electives are imported and superseded, all learners' training and assessment is completed and relevant AQF certification document is issued, or learners transferred into its replacement, within one year from the date the replacement training product was released on the national register.
  2. When a unit has been removed or deleted from the national register, no new students can be enroled into the unit. Existing students in the unit have one year to complete the unit.


#### Training Product Discontinuation, Transition and Teach-out
(26)  Decisions by RMIT to cease delivery of a training product may emerge from periodic reviews or planning processes, including internal or external auditing or review processes. Training products on the National Register may also be superseded, deleted or removed, requiring RMIT to discontinue delivery. At times, RMIT may also be directed by a regulator or funding body to cease delivery of a particular training product.
(27)  Training package qualifications do not have pre-set expiry date.
  1. When a training package qualification is superseded, new students may still commence training during the one-year transition period, except for students on a student visa. 
  2. All training and assessment of students in the superseded program must be completed and AQF certification documentation issued, or transferred to the replacement program, within the expiration period which is typically 12 months.


(28)  When a training package qualification is removed or deleted, with no superseding qualification, all training must finish within the teach out period specified by ASQA. No new students may be admitted into a removed or deleted qualification.
(29)  Accredited courses have a set currency period which can be viewed on the National Register.
  1. This information is collated as part of the scope audit reporting process managed by the Academic Registrar's Group and monitored by the College of Vocational Education.
  2. A new learner must not commence training in a non-current accredited course.
  3. All learner's training and assessment must be completed, and relevant AQF certification documentation issued, or learners must be transferred into its replacement within a period of two years from the date the currency period ends unless a formal extension is granted.


(30)  Where a training product is to be superseded, removed or deleted, the Program Manager must develop a transition plan for current and deferred students that ensures they have all completed their studies within the transition period or successfully transitioned to another training product.
(31)  The College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent) must approve a proposal to discontinue a program where the program has no active students.
(32)  Where a program has active students who must transition into a replacement program, the transition plan must be approved by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent).
(33)  Discontinuation documentation for approval must include the completed discontinuation form/s, and the transition plan where the program has active students.
  1. Where the program discontinuation is triggered by a replacement program, discontinuation planning should be initiated by the Program Manager as soon as the replacement program appears on the National Register.
  2. Where the program to be discontinued will not be replaced, discontinuation planning should be initiated at least 12 months, or as early as possible, before the planned discontinuation of intakes.


(34)  Where there are applicants and/or active students in the program, transition letters must be drafted to students in accordance with the relevant ASQA Standards and approved by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent).
(35)  If the program has students enrolled/studying in Australia on a student visa and is to be replaced with a new program, the students on a student visa can be informed that the replacement program is the reason for the discontinuation. However, the new program cannot be marketed or promoted until it has received CRICOS registration. Where a CRICOS-registered course is discontinued Education Regulation Compliance and Assurance and Global Student Recruitment should be consulted to mitigate risk of provider default.
(36)  If the discontinuation includes an offering at an RMIT partner institution outside Australia, the Associate Director, College of Vocational Education Quality and Compliance consults the Associate Director Global Operations to ensure that the partner is aware of the discontinuation and informed about the transition plan for active students.
(37)  If RMIT is directed by a regulator or accrediting or funding body to cease delivery of a vocational education program, the transition plan will include individual counselling to students on their options to continue their study at other providers. The college will approach other providers to facilitate this transfer on the students’ behalf.
(38)  If the discontinuation includes an offering at an RMIT partner, the College of Vocational Education will submit the discontinuation form to the RMIT manager of the partner contract for endorsement prior to submission to the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent) for approval.
#### Programs to be Removed from RMITs Scope of Registration
(39)  All students must have exited a training product before its expiry on the National Register.
(40)  The College of Vocational Education must liaise with Academic Registrar's Group Enrolment and Student Records to ensure all students have exited the training product before the program expiry, and before removal from scope can be requested. For an equivalent replacement training package qualification, ASQA will remove the superseded version of the qualification from RMIT’s Scope of Registration once the transition period has ended.
(41)  Where possible, discontinuations must be planned, coordinated with International Admissions and registered well in advance so that marketing materials can be updated, international applicants can be issued with alternative offers and adequate time for consultation with students affected by the discontinuation.
(42)  Where ASQA identifies that a provider has one or more training package qualification listed on CRICOS that have recently been superseded by a new equivalent qualification:
  1. ASQA will update RMIT’s registration on PRISMS
  2. the qualification will receive a new CRICOS code when the training package is updated
  3. a new CRICOS form is required to be submitted to Education Regulation Compliance Assurance to ensure any changes to the program are accurately reflected on CRICOS
  4. the College of Vocational Education must continue to apply to add accredited courses to CRICOS.


(43)  Removal of superseded training products that have been replaced with non-equivalent training products must be approved by the College of Vocational Education Deputy Vice-Chancellor and CEO of Registered Training Organisation for removal from RMIT’s Scope of Registration.
  1. The College of Vocational Education must notify the Academic Registrar's Group when all students have exited the training product that is to be removed from RMITs Scope of Registration.
  2. The Academic Registrar's Group will notify Education Regulation Compliance Assurance when CRICOS cancellation is required.
  3. Education Regulation Compliance Assurance must confirm there are no existing Confirmation of Enrolments active in PRISMS before proceeding with CRICOS cancellation.
  4. CRICOS cancellation must occur before the training product can be removed from RMIT’s Scope of Registration.
  5. ASQA may cancel CRICOS registration where there are no active Confirmation of Enrolments.


#### Registration of the Decision to Discontinue a Vocational Education Program outside Australia
(44)  To discontinue an offering with an approved partner institution outside Australia, first follow the Third-Party Educational Delivery Policy.
  1. A decision to discontinue a vocational education partner program may need to be reported to ASQA. Consult Education Regulation Compliance Assurance for advice.


(45)  Once the decision to discontinue has been endorsed by the Deputy Vice-Chancellor and Vice-President - International and Engagement, continue with planning the discontinuation process. 
(46)  If the discontinued program has an offering at an RMIT partner institutions outside Australia, the College of Vocational Education must seek input from Global Operations in drafting letters to students.
#### Consultation with Stakeholders
(47)  Where a discontinuation is the result of an RMIT internal decision (rather than the superseding of the qualification or its deletion from the training package) consult with the following groups as soon as the decision to discontinue is made:
  1. relevant industry groups
  2. relevant licensing or professional accreditation agencies
  3. relevant regulatory agencies, as required
  4. students with current enrolments including those on leave of absence
  5. Program Coordinator, Program Manager or Director
  6. Global Student Recruitment (if CRICOS registered)
  7. Education, Regulation, Compliance and Assurance (if CRICOS registered).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=207&version=1#document-top)
# Section 5 - Schedules
(48)  [Program and Course Schedule - Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=10&associated).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
