[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=187&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=187&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Board Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=187)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=187&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=187&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=187&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=187&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=187&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=187&version=3)


# Academic Board Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=187&version=3#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor2)
  * [3. Definitions](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor3)
  * [Part B - THE ACADEMIC BOARD](https://policies.rmit.edu.au/document/view.php?id=187&version=3#part2)
  * [4. Purpose and Functions of the Academic Board](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor4)
  * [5. Membership of the Academic Board](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor5)
  * [6. Term of Office and Vacancies](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor6)
  * [7. Office Bearers](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor7)
  * [8. Meetings of the Academic Board](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor8)
  * [Part C - REVOCATION OF REGULATIONS](https://policies.rmit.edu.au/document/view.php?id=187&version=3#part3)
  * [9. Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=187&version=3#minor9)


This is not a current document. To view current or future versions, click the link in the document's navigation bar.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to:
  1. define the purpose and functions of the Academic Board
  2. make provision for the membership of the Academic Board
  3. make provision for the appointment of the Chair and Deputy Chair of Academic Board; and
  4. provide for meetings of the Academic Board.


#### 2. Authorising Provision
(2)  The Academic Board is required to be established by Council pursuant to section 20 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
(3)  The functions of the Academic Board are established under Part 4 of the RMIT Statute No. 1 (Amendment No. 2).
(4)  These Regulations are made pursuant to sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20) and Part 4 of the [RMIT Statute No. 1 (Amendment No. 2)](https://policies.rmit.edu.au/document/view.php?id=177).
#### 3. Definitions
(5)  In these Regulations, unless the contrary intention appears:
  1. academic staff means those higher education employees of the University within the meaning of the collective agreement or award that applies to Higher Education employees, appointed to an established position and being not less than 0.5 of a full time position.
  2. professional staff means those professional, administrative, clerical, computing and technical employees of the University within the meaning of the applicable collective agreement or award appointed to an established position and being not less than 0.5 of a full time position.
  3. senior academic staff means academic classification levels C, D and E within the meaning of the applicable collective agreement or award appointed to an established position and being not less than 0.5 of a full time position
  4. senior teaching staff means classification level Senior Educator Level 1, Senior Educator Level 2 and Senior Educator Level 3 within the meaning of the applicable collective agreement or award appointed to an established position and being not less than 0.5 of a full time position
  5. teaching staff means those VE employees of the University within the meaning of the collective agreement or award that applies to VE employees appointed to an established position and being not less than 0.5 of a full time position.


## Part B - THE ACADEMIC BOARD
#### 4. Purpose and Functions of the Academic Board
(6)  The Academic Board is the principal academic governing body responsible for oversight of RMIT's academic affairs across the RMIT Group.
(7)  The responsibilities of the Academic Board are derived from:
  1. its functions established in the RMIT Statute No. 1 (Amendment No. 2).
  2. the academic governance requirements of the Higher Education Standards Framework (Threshold Standards) 2021, namely that the Academic Board is the body that oversees Academic Governance across the RMIT Group.
  3. the Standards for Registered Training Organisations (RTOs) 2015, Part 4, RTO governance and administration


(8)  Consistent to the purpose and functions noted above, Academic Board is responsible for governance of all aspects of the University’s academic mission inclusive of learning and teaching, scholarship, research and research training.
(9)  The Academic Board fulfills its responsibilities by monitoring and providing oversight of the following:
  1. academic quality, standards and outcomes;
  2. academic and research integrity;
  3. academic innovation and risk; and
  4. academic freedom.


#### 5. Membership of the Academic Board
(10)  Membership of the Academic Board comprises:
  1. ex officio members: 
    1. Chancellor (or nominee)
    2. Vice-Chancellor and President
    3. Deputy Vice-Chancellor Education and Vice-President
    4. Deputy Vice-Chancellor Research and Innovation and Vice-President
    5. Deputy Vice-Chancellor International and Engagement and Vice-President
    6. Deputy Vice-Chancellor College of Business and Law and Vice-President
    7. Deputy Vice-Chancellor College of Design and Social Context and Vice-President
    8. Deputy Vice-Chancellor STEM College and Vice-President
    9. Deputy Vice-Chancellor College of Vocational Education and Vice-President
    10. Executive Director, Library Services
    11. Associate Deputy Vice-Chancellor Education, Learning, Teaching and Quality
    12. Associate Deputy Vice-Chancellor Research Training and Development
    13. Associate Deputy Vice-Chancellor, Research and Innovation Capability
    14. Academic Registrar
    15. Pro Vice-Chancellor Vietnam and General Director, RMIT Vietnam or nominee
    16. President, [RMIT University Student Union](https://policies.rmit.edu.au/download.php?id=125&version=1&associated)
    17. President, RMIT Vietnam Student Council
    18. one (1) Aboriginal and/or Torres Strait Islander academic nominated by the Chair of Academic Board
    19. University Secretary
    20. Pro Vice-Chancellor, Indigenous Education, Research and Engagement
    21. Aboriginal and/or Torres Strait Islander Elder in Residence
    22. Chief Executive Officer, RMIT Online
    23. Chief Executive Officer, RMIT University Pathways (RMIT UP)
    24. Chair, Professorial Academy, or nominee drawn from the Professorial Academy
  2. one (1) Head of School, Dean or Executive Dean from each higher education college, elected by the academic staff of each college
  3. two (2) senior academics/teaching staff in a non-executive role from each college elected by the academic and teaching staff of each college
  4. two (2) academic staff from each college, elected by and from the academic staff of each college
  5. one (1) member elected by and from the postgraduate students of the University
  6. one (1) member elected by and from the higher degree by research students of the University
  7. two (2) members elected by and from the undergraduate students of the University
  8. two (2) members elected by and from the students enrolled in VE or associate degree programs of the University
  9. two (2) members elected by and from the professional staff
  10. five (5) members elected by and from the academic staff
  11. five (5) members elected by and from the teaching staff
  12. four (4) members elected by and from the professors of the University occupying a Level E appointment, not including honorary or adjunct professors.


(11)  Clauses (10)d., i., j. and k. include employees of the University at Executive Level 1, Heads of School, Deans and Directors.
(12)  The University Secretary, or nominee is the secretary of the Academic Board.
#### 6. Term of Office and Vacancies
(13)  An elected member:
  1. holds office for a period of two (2) years except that student members will hold office for a term of one (1) year, and
  2. assumes office on the first day of January following the member’s election unless the member is replacing a vacancy under section 5(2), in which case the elected member may assume office at the next meeting.


(14)  Where a member of the Academic Board:
  1. elected by staff ceases to be a member of staff, or
  2. elected by enrolled students, ceases to be an enrolled student,


that member ceases to be a member of the Academic Board and the vacancy thereby created is a casual vacancy.
(15)  Any vacancy created in the membership of the Academic Board is dealt with in accordance with the provisions of the [Elections Regulations](https://policies.rmit.edu.au/document/view.php?id=194).
(16)  Where an elected member of the Academic Board is to be absent from the University for a period exceeding six (6) months a person may be appointed by the Chair of the Academic Board for the duration of the absence of the elected member.
(17)  All elections to the Academic Board must be conducted in accordance with the [Statute](https://policies.rmit.edu.au/document/view.php?id=177) and Elections Regulations, unless otherwise specified.
#### 7. Office Bearers
(18)  The Board shall in every second calendar year elect from amongst its members a Chair and Deputy Chair who will hold office for a period of two (2) years.
(19)  The Chair and Deputy Chair must be a senior academic or senior educator in accordance with the definitions provided under regulation 3(1).
(20)  A person may not serve as Chair or Deputy Chair while they are:
  1. an ex-officio member of the Academic Board, or
  2. a Head of School, Dean or Executive Dean of a University school.


(21)  A call for nominations to members of the Academic Board for the position of Chair and Deputy Chair is made by the Board secretary not less than ten (10) working days prior to the first day of the ballot period.
(22)  Nominations for the position of Chair and Deputy Chair may be submitted by a date set by the Board secretary no later than one (1) working day prior to the first day of the ballot period.
(23)  If more than one nomination is received for each position, the Board secretary will conduct an election for that position.
(24)  The Board secretary, not later than five (5) working days prior to the last day of the ballot period, notifies members of the Academic Board of:
  1. the nominations received, and
  2. the process for voting (by secret ballot)


(25)  Where the Chair of the Academic Board is absent from the University the Deputy Chair will preside and assume all functions and duties of the Chair.
(26)  If the Deputy Chair is required to act as Chair but is unavailable or unable to do so, the Council may by resolution appoint an interim Acting Chair for a specified period.
(27)  The Chair or Deputy Chair positions will become vacant if the occupant:
  1. resigns from their office bearer position;
  2. ceases to be a member of the Board.


(28)  If the office of Chair becomes vacant on or after the last six months of the Chair’s term, the vacancy must be filled by the Deputy Chair. 
(29)  If the Deputy Chair is required to act as Chair but is unavailable or unable to do so, the Council may by resolution appoint a Chair for the remainder of the term.
(30)  If the office of Chair becomes vacant before the last six months of the Chair’s term, a new Chair must be elected as soon as possible in accordance with the office bearer election provisions of these regulations.
#### 8. Meetings of the Academic Board
(31)  Meetings of the Academic Board are conducted in accordance with the [Standing Orders of Academic Board](https://policies.rmit.edu.au/download.php?id=268&version=1&associated).
## Part C - REVOCATION OF REGULATIONS
#### 9. Revocation of Regulations
(32)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 2.8.1 The Academic Board – Membership.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
