[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=250&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=250&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Policy Governance Procedure Schedule 1 - Policy Proposal and Approval 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=250)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=250&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=250&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=250&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=250&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=250&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=250&version=2)


# Policy Governance Procedure Schedule 1 - Policy Proposal and Approval
Hide Navigation
  * [ ](https://policies.rmit.edu.au/document/view.php?id=250&version=2#major1)


This is not a current document. To view the current version, click the link in the document's navigation bar.
### Policy Governance Procedure Schedule 1 - Policy Proposal and Approval 
Table 1 – Policy Development and Review Check Points:
Category | Endorsement to Commence Policy Development | Endorsement to Commence Procedure Development | Mid-way check with approval authority for new policies and policy reviews  
---|---|---|---  
Governance  | University Policy Manager | Policy owner | Vice-Chancellor's Executive  
Academic | Chair, Academic Board and University Policy Manager | Policy owner | Academic Board and Vice-Chancellor's Executive  
Talent and Culture | University Policy Manager | Policy owner | Vice-Chancellor's Executive  
Operational Effectiveness | University Policy Manager | Policy owner | Vice-Chancellor's Executive  
Table 2 – Approval authority for new and post-review policy documents:
Category | Group policy | Divisional policy | Procedures | Resources | Conditions/limitations  
---|---|---|---|---|---  
Governance | Council | N/A | Policy owner | Policy owner | Scope is RMIT Group-wide  
Academic | Academic Board | Chair, Academic Board and Deputy Vice-Chancellor Education or Deputy Vice-Chancellor Research and Innovation | Policy owner | Policy owner | [Delegations of authority](https://policies.rmit.edu.au/document/view.php?id=51)  
Talent and Culture | Academic Board or VCE(1) | Vice-Chancellor and relevant VCE member | Policy owner | Policy owner | [Delegations of authority](https://policies.rmit.edu.au/document/view.php?id=51)  
Operational Effectiveness | Vice-Chancellor's Executive | Chief Financial Officer and Chief Operating Officer | Policy owner | Policy owner | [Delegations of authority](https://policies.rmit.edu.au/document/view.php?id=51)  
Table 3 – Approval authority for minor amendments and administrative changes to policy documents (policies, procedures and resources):
| Definition | Authority to amend  
---|---|---  
Minor amendments | A change that does not change the intent of the policy document or significantly affect the content or application of the policy, e.g. to clarify existing details, align with legislative changes, or include additional processes for a new system, a new campus or controlled entity. | Policy owner  
Administrative changes | A correction to a policy document to update a title, name, formatting, web link, spelling, grammar, and references to law or other policy documents, or for clarity of language. | Central Policy  
This Schedule was updated in 2022 to:
  1. update the approval authorities
  2. add a mid-way check with approval authorities to table 1
  3. add table 3.


(1) Depending on subject matter (e.g. matters that related to academic status). Endorsement is required from the non-approving body prior to submission for approval. Consult the University Policy Manager.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
