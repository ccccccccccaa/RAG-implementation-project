[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=115&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=115&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Procedure - Leave of Absence 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=115)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=115&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=115&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=115&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=115&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=115&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=115&version=2)


# Enrolment Procedure - Leave of Absence
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=115&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=115&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=115&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=115&version=2#section4)
  * [Eligibility](https://policies.rmit.edu.au/document/view.php?id=115&version=2#major1)
  * [Duration of Leave](https://policies.rmit.edu.au/document/view.php?id=115&version=2#major2)
  * [Approving Authority and Reporting](https://policies.rmit.edu.au/document/view.php?id=115&version=2#major3)
  * [Fee Implications](https://policies.rmit.edu.au/document/view.php?id=115&version=2#major4)
  * [Authority of the Academic Registrar](https://policies.rmit.edu.au/document/view.php?id=115&version=2#major5)
  * [Review of Determinations](https://policies.rmit.edu.au/document/view.php?id=115&version=2#major6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  RMIT students may apply for a leave of absence (LOA) while enrolled in their award program by submitting an application to the relevant area for approval. This procedure outlines LOA rules for RMIT students.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=115&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=115&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all student cohorts enrolled in an RMIT award program and Foundation Studies.
(4)  LOA is not available to students in Victorian Certificate of Education or Victorian Certificate of Applied Learning programs.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=115&version=2#document-top)
# Section 4 - Procedure
### Eligibility
(5)  Students may apply for LOA from RMIT for a defined period, in accordance with the processes prescribed by the Academic Registrar.
(6)  In considering an application for LOA, it is the student’s responsibility to:
  1. seek appropriate advice before suspending their studies
  2. be aware of the potential impact of the absence on their ability to successfully complete the program
  3. be aware of the consequences that suspending their studies may have on their status as a student.


(7)  LOA for international students studying in Australia on a student visa can only be granted on compassionate or compelling grounds. Examples of such grounds are published on the RMIT website.
  1. Students studying in Australia on a student visa are advised to always seek advice including from the [Department of Home Affairs](https://policies.rmit.edu.au/download.php?id=129&version=1&associated) prior to applying for LOA.


(8)  LOA is not normally available to students in the first semester (or study period) of their program unless they can demonstrate exceptional circumstances.
(9)  LOA is not available for prospective students who have been offered a place at RMIT and have not yet enrolled but wish to defer their studies for one or more semesters or study periods. In these instances, applicants may defer their enrolment in the offered place in accordance with admissions processes.
(10)  LOA may not be available to students in programs delivered with industry partners.
(11)  A student may be denied LOA at the discretion of the teaching school/industry cluster/college or RMIT Online where the program is in teach-out and the requested period of leave would mean the student is unable to complete the program requirements on time.
(12)  LOA processes for higher degree by research (HDR) students are managed in accordance with the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16), and the [Research Scholarship Terms and Condition](https://policies.rmit.edu.au/download.php?id=112&version=1&associated) as necessary.
(13)  A student may be denied LOA if they exceeded the maximum total of periods of leave in their program, as defined below.
### Duration of Leave
(14)  LOA must have a definitive start date and must be for a specified amount of time, not exceeding one year.
(15)  LOA can apply to:
  1. a standard study period for higher education coursework students
  2. the relevant study period for Vocational Education and Foundation Studies students
  3. any approved period for HDR students.


(16)  The total maximum period of leave for a student in a coursework program is 50% of total duration of the program, unless exceptional circumstances apply, and relevant approval is obtained.
(17)  Program structure and course availability may affect the period of LOA granted.
### Approving Authority and Reporting
(18)  The teaching school/industry cluster/college or RMIT Online may grant LOA to a student; in exceptional circumstances the Academic Registrar may do this.
(19)  For coursework students the Dean/Head of School/Cluster Director or nominee is authorised to approve applications for LOA of up to 50% of total duration of the program, or LOA that will bring the student’s total leave in the program to two years.
(20)  In all instances, the Academic Registrar must be satisfied that LOA applications for international students studying in Australia on a student visa, including those exceeding the maximum period, demonstrate compassionate or compelling grounds prior to be granted.
(21)  LOA for a cumulative total of more than two years or more than 50% of the duration of the program may be approved in exceptional circumstances, by either the:
  1. relevant College Deputy Vice-Chancellor, for coursework students
  2. Associate Deputy Vice-Chancellor Research Training and Development, for HDR students in accordance with the provisions of the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16).


(22)  If an application for LOA is rejected or varied, the school/Industry Cluster or Academic Registrar's Group (for students studying in Australia on a student visa) must inform the student of the reasons for the decision and details of available review processes.
(23)  For international students studying in Australia on a student visa, the University will report the LOA to the [Department of Home Affairs](https://policies.rmit.edu.au/download.php?id=129&version=1&associated).
  1. Reporting the LOA may affect the student’s visa and the student may be required by the [Department of Home Affairs](https://policies.rmit.edu.au/download.php?id=129&version=1&associated) to leave Australia while they are not enrolled.
  2. In all instances, students studying in Australia on a student visa are advised to seek advice, including from the [Department of Home Affairs](https://policies.rmit.edu.au/download.php?id=129&version=1&associated), on their visa status and conditions.


### Fee Implications
(24)  Where LOA is applied to standard semester, students must withdraw from courses in the flexible term during their period of leave to avoid remaining liable for those tuition fees.
(25)  Students who take an approved LOA before the relevant census date will have the relevant paid fees re-credited to their student account, excluding any applicable penalties. This credit will be applied to future fee liabilities or the student may apply for a refund.
(26)  Students will remain liable for fees and may incur an academic penalty if they submit a request for LOA after the relevant census date. In special circumstances, students may apply for a remission of debt.
(27)  Where the school/industry cluster/college or RMIT Online recommends LOA for a student whose enrolment has been discontinued as part of the late enrolment process, a late enrolment fee may be applied.
(28)  A student granted LOA remains an RMIT student and is:
  1. eligible to appeal a University decision to suspend, expel or exclude them, or a student conduct decision
  2. entitled to retain but not use their RMIT student card
  3. entitled to have and use a student email account
  4. entitled to apply for credit
  5. entitled to use academic and student support services
  6. responsible for checking their RMIT student email account
  7. responsible for maintaining up-to-date contact details on their student record
  8. responsible for re-enrolling by the relevant dates.


### Authority of the Academic Registrar
(29)  The Academic Registrar may grant an LOA on administrative grounds in exceptional circumstances.
(30)  The Academic Registrar or Registrar of the institution may, in exceptional circumstances, authorise an LOA to be backdated to before the relevant course census date, which will determine fee entitlements. Such decisions are final.
### Review of Determinations
(31)  The student may seek a review of a decision to deny their application for LOA or approval of LOA for a different period than requested.
(32)  The student must request such a review within 20 working days of the date of the email notifying them of the decision, by email to (as relevant):
  1. (for international students studying on a student visa in Australia who have had their LOA rejected, including HDR students) the Associate Director, Enrolment and Student Records. The Enrolment and Student Records team may consult with Education Regulation Compliance Assurance on ESOS matters as required
  2. (for other students, excluding HDR students, who have had their LOA rejected by their Dean/Head of School/Cluster Director) the College Associate Deputy Vice-Chancellor Learning and Teaching
  3. (for HDR students seeking review of an LOA decision by a Dean/Head of School/Industry Cluster) the Associate Deputy Vice-Chancellor Research, Training and Development
  4. (for HDR students seeking review of a decision by the Associate Deputy Vice-Chancellor Research, Training and Development on a request for LOA longer than one year, or LOA while the student is on an extension beyond the maximum period of candidature) the Deputy Vice-Chancellor Research and Innovation.


(33)  Students studying on a student visa who are not satisfied with the outcome of a review of the decision to deny their application for LOA or approval of LOA for a different period, may apply to the [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=2&associated) for a review of the decision.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
