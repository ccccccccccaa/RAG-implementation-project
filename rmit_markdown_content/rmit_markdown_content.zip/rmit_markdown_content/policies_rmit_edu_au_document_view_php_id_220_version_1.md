[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=220&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=220&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Sexual Harm Explanations and Examples 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=220)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=220&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=220&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=220&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=220&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=220&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=220&version=1)


# Sexual Harm Explanations and Examples
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=220&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=220&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=220&version=1#section3)
  * [Section 4 - Resource](https://policies.rmit.edu.au/document/view.php?id=220&version=1#section4)
  * [What students does the Sexual Harm Prevention and Response Policy apply to? ](https://policies.rmit.edu.au/document/view.php?id=220&version=1#major1)
  * [What is Consent?](https://policies.rmit.edu.au/document/view.php?id=220&version=1#major2)
  * [What is Sexual Harm?](https://policies.rmit.edu.au/document/view.php?id=220&version=1#major3)
  * [What is Sexual Harassment?](https://policies.rmit.edu.au/document/view.php?id=220&version=1#major4)
  * [What is Sexual Assault?](https://policies.rmit.edu.au/document/view.php?id=220&version=1#major5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This resource supports the understanding and operationalisation of the [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218) and the [Gender-Based Violence Response Procedure - Australia](https://policies.rmit.edu.au/document/view.php?id=219).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=220&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=220&version=1#document-top)
# Section 3 - Scope
(3)  This resource applies to:
  1. all students within the RMIT Group, with the same scope as the RMIT [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)
  2. all staff and associates of the RMIT Group, with the same scope as the [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=220&version=1#document-top)
# Section 4 - Resource
### What students does the Sexual Harm Prevention and Response Policy apply to? 
(4)  The [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218) applies to all students within the RMIT Group, with the same scope as the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), including:
  1. Students on approved leave of absence and students who have allowed their enrolment to lapse
  2. Students studying through [Open Universities Australia (OUA)](https://www.open.edu.au/) or other third-party providers of RMIT courses and programs
  3. Students studying RMIT programs at global partner institutions
  4. Higher degree by research students, including those who have submitted work for examination
  5. Graduands or past students
  6. Students in single courses or short courses.


### What is Consent?
(5)  Consent means free agreement, given voluntarily and on an informed basis. Circumstances in which a person does not consent to an act include, but are not limited to, the following:
  1. the person submits to the act because of force or the fear of force, whether to that person or someone else
  2. the person submits to the act because of the fear of harm of any type, whether to that person or someone else or an animal
  3. the person submits to the act because the person is unlawfully detained
  4. the person is asleep or unconscious
  5. the person is so affected by alcohol or another drug as to be incapable of consenting to the act. This circumstance may apply where a person gave consent when not so affected by alcohol or another drug as to be incapable of consenting.
  6. the person is incapable of understanding the sexual nature of the act
  7. the person is mistaken about the sexual nature of the act
  8. the person is mistaken about the identity of any other person involved in the act
  9. the person mistakenly believes that the act is for medical or hygienic purposes
  10. if the act involves an animal, the person mistakenly believes that the act is for veterinary or agricultural purposes or scientific research purposes
  11. the person does not say or do anything to indicate consent to the act
  12. having initially given consent to the act, the person later withdraws consent to the act taking place or continuing.


(6)  Clear and unambiguous agreement must be expressed outwardly through mutually understandable words or actions. Consent must be voluntarily given.
(7)  Consent to engage in one sexual activity or past agreement to engage in a particular sexual activity cannot be presumed to constitute consent to engage in a different sexual activity or to repeat a sexual activity. Just because person (B) has done something previously with person (A), or even with another person, it does not mean that person (B) is always regarded as having consented to that activity.
(8)  It is not enough to presume consent if a person didn’t protest or physically resist. It is not enough to presume consent if the person did not sustain physical injury.
(9)  It is important to understand that:
  1. a person can consent to an act only if the person is capable of consenting and free to choose whether or not to engage in or allow the act
  2. where a person has given consent to an act, the person may withdraw that consent either before the act takes place or at any time while the act is taking place.


### What is Sexual Harm?
(10)  Sexual harm is non-consensual behaviour of a sexual nature that causes a person to feel uncomfortable, frightened, distressed, intimidated, or harmed either physically or psychologically. Sexual harm includes behaviour that also constitutes sexual harassment and sexual assault.
(11)  Sexual harm occurs when there is no freely given agreement, or when someone is being coerced or manipulated into any unwanted sexual activity, or when someone does not have the capacity to give or withdraw consent.
(12)  Sexual harm can impact anyone regardless of their sex, gender identity or sexual orientation. Sexual harm does not have to be repeated or continuous; it can be a one-off incident.
(13)  Examples of behaviours which constitute sexual harm include (but are not limited to):
  1. sexual assault or threatening sexual assault
  2. strong pressuring or demands for sex or sexual acts
  3. obscene gestures of a sexual nature such as simulating masturbation
  4. being forced to watch pornography
  5. indecent exposure including someone showing or “flashing” their genitals
  6. taking intimate (semi-nude, nude, whether or not participating in sexual activity) image, photo or video without consent
  7. sharing, showing or distributing an intimate (semi-nude, nude, while participating in sexual activity) image, photo or video without consent.


(14)  Sexual harm is not consensual sexual interaction, flirtation, attraction or friendship which is invited, mutual, or reciprocated, but it can occur if a person continues with the relevant behaviour after being put on notice that the behaviour is no longer agreed to or welcome.
### What is Sexual Harassment?
(15)  Sexual harassment is when a person:
  1. makes an unwelcome sexual advance, or an unwelcome request for sexual favours, or
  2. engages in other unwelcome conduct of a sexual nature in relation to a person, in circumstances in which a reasonable person, having regard to all the circumstances, would have anticipated the possibility that the person harassed would be offended, humiliated or intimidated.


(16)  The circumstances to be considered include, but are not limited to, the following:
  1. the sex, age, sexual orientation, gender identity, intersex status, marital or relationship status
  2. religious belief, race, colour, or national or ethnic origin, of the person harassed
  3. the relationship between the person harassed and the person who made the advance or request or who engaged in the conduct
  4. any disability of the person harassed
  5. any other relevant circumstance.


(17)  ‘Conduct of a sexual nature’ includes making a statement or a physical gesture, of a sexual nature to a person, or in the presence of a person. It can be physical, verbal or written.
(18)  Sexual harassment can take various forms. It can be subtle and implicit, rather than explicit. Sexual harassment can include:
  1. unwelcome touching, hugging, fondling or kissing
  2. sexually suggestive behaviour such as staring or leering
  3. sexually suggestive comments or ‘jokes’
  4. displaying or showing sexually explicit or offensive objects or images (such as screen savers or desktop backgrounds)
  5. unwanted invitations to go out on dates or requests for sex
  6. intrusive questions or comments about a person's private life or the way they look
  7. unnecessary familiarity, such as deliberately brushing up against a person
  8. insults or taunts based on sex
  9. sexually explicit physical contact
  10. sexually explicit emails or text messages
  11. accessing sexually explicit internet sites
  12. inappropriate advances on social networking sites or other messaging platforms
  13. stalking
  14. sexual assault.


(19)  Sexual harassment does not need to be repeated, or continuous; it can be a one-off incident.
(20)  A person might say they “were only joking” but jokes can still be insulting, threatening, humiliating or unwelcome, and can still be sexual harassment.
(21)  RMIT acknowledges the significant harm or distress that can occur when threats to distribute intimate images are made, and where such images are actually distributed (e.g. sexting, or revenge porn in the context of relationship breakdown). As such, RMIT’s definition of sexual harassment includes the situation where:
  1. person (A) intentionally distributes an intimate image of another person (B) to a person other than (B) (including via social media), and
  2. the distribution of the image is contrary to community standards of acceptable conduct
  3. except where (B) is an adult and has expressly consented or implied consent to the distribution of the intimate image and how it was distributed.
  4. An intimate image is one that depicts: a person engaged in sexual activity, a person in a manner or context that is sexual, or the genital or anal region of a person, or breasts for a female, or a person who identifies as female. Sexual harassment also occurs where person (A) threatens to send an intimate image of person (B). 


### What is Sexual Assault?
(22)  For the purposes of RMIT’s [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218), RMIT defines Sexual assault as:
  1. person (A) intentionally touching another person (B) and the touching is sexual
  2. person (B) who was touched did not agree or consent to the touching, and
  3. person (A) did not reasonably believe that person (B) consented.
  4. If person (A) knew that (B) was not consenting, this will be sexual assault; and if person (A) did not believe on reasonable grounds that (B) was consenting, this will also be sexual assault.


(23)  For the purposes of this policy, RMIT also includes those acts which would constitute the following within the definition of sexual assault:
  1. rape, rape by compelling sexual penetration, and sexual assault by compelling sexual touching
  2. assault (being the non-consensual application of force) with intent to commit a sexual act, and
  3. threat to commit a sexual assault or rape
  4. under the [Crimes Act 1958 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/crimes-act-1958/); even though, for succinctness the specific elements of each are not set out separately in the definitions contained in the [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).


(24)  Sexual assault occurs when a person is forced, compelled, coerced or tricked into sexual acts against their will or without their consent, including when they have withdrawn consent. This includes rape, sexual penetration and/or sexual touching.
(25)  Touching could be with any part of the body or with anything else, and may be sexual due to:
  1. the area of the body that is touched or used in the touching, including (but not limited to) the genital or anal region, the buttocks or, in the case of a female or a person who identifies as a female, the breasts, or
  2. the fact that the person doing the touching seeks or gets sexual arousal or sexual gratification from the touching, or
  3. any other aspect of the touching, including the circumstances in which it is done.


(26)  The following are examples of sexual assault:
  1. Two people in a relationship start engaging in sexual activity, but person A changes their mind and says they want to stop. Person B refuses to stop and forces the sexual activity.
  2. A student taking advantage of another intoxicated student at a party by encouraging them back to their room and engaging in sexual activity when the student is unable to give consent due to being affected by alcohol.
  3. A research supervisor manipulates a student to engage in sexual acts in exchange for better marks.
  4. A staff member who has been continually making advances towards another staff member proceeds to force themselves onto that staff person while they are alone in a meeting room, attempting to kiss and touch them under their clothing.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
