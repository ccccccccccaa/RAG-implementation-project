[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=22&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=22&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Research Training Program Scholarships 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=22)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=22&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=22&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=22&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=22&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=22&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=22&version=1)


# Research Training Program Scholarships
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=22&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=22&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=22&version=1#section3)
  * [Section 4 - Policy References](https://policies.rmit.edu.au/document/view.php?id=22&version=1#section4)
  * [Student Eligibility, Type of Support, and Rates](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major1)
  * [Period of Support](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major2)
  * [Application, Selection and Offers Processes for Awarding RTP Scholarships](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major3)
  * [Transition Arrangements for Continuing Students](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major4)
  * [Admission – Facilities and Supervision](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major5)
  * [Supervision](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major6)
  * [Employment and Study Load](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major7)
  * [Changes to Enrolment](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major8)
  * [Termination of an RTP Fees Offset](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major9)
  * [Termination of an RTP Stipend](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major10)
  * [Grievances, Reviews and Appeals](https://policies.rmit.edu.au/document/view.php?id=22&version=1#major11)
  * [Section 5 - More Information](https://policies.rmit.edu.au/document/view.php?id=22&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  The Research Training Program (RTP) block grant is allocated to the University by the Australian Government to support domestic and overseas students enrolled in a PhD or masters by research program. RTP Scholarships are awarded to eligible candidates in accordance with the Commonwealth Scholarship Guidelines (Research) 2017.
(2)  This document details the conditions of RTP scholarships at RMIT. It supports the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated) (T&Cs).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=1#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=1#document-top)
# Section 3 - Scope
(4)  This document applies to higher degree by research (HDR) applicants, current HDR candidates and staff who administer the RTP Scholarships block grant for the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=1#document-top)
# Section 4 - Policy References
### Student Eligibility, Type of Support, and Rates
(5)  The RTP program supports the following scholarship types:
  1. RTP Fees Offset: A contribution to the costs incurred by the University in the provision of higher degrees by research. All Australian and New Zealand citizens (domestic candidates) are eligible for this support unless they are already receiving an equivalent award or scholarship from the Commonwealth designed to offset HDR fees. International candidates in receipt of a Tuition Fee Scholarship at RMIT will receive this support. The RTP fee offset rate is specified in the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
  2. RTP Stipend Scholarship (RSS): Funding to assist candidates with living costs while undertaking a higher degree. To be eligible for an RTP stipend a student must not be receiving income from another source to support that student’s general living costs while undertaking their course of study if that income is greater than 75 per cent of that student’s RTP stipend rate. Income unrelated to the student’s course of study or income received for the student’s course of study but not for the purposes of supporting general living costs is not to be taken into account. The RMIT RTP stipend rate is specified in Research Stipend Scholarships.
  3. RTP Allowances: funding to assist candidates with ancillary costs of a higher degree, such as health cover and relocation costs for overseas candidates, thesis printing and academic publication costs. RTP allowances are available to candidates in receipt of an RTP stipend, in accordance with the eligibility criteria outlined in the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).


#### Policy source:
[Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated)
### Period of Support
(6)  The duration of RTP support is as follows:
  1. For domestic candidates the RTP Fees Offset may be provided up to the maximum duration of candidature.
  2. For all RTP support provided to international candidates, and for domestic RTP stipend recipients, RTP support is for the full time equivalent (FTE) of up to three years for doctoral study (six-month extension may be applied for); and for masters by research study, a maximum of two years (FTE).


(7)  The candidate’s period of support will be adjusted to account for any periods of leave approved by RMIT.
(8)  Extensions to candidature duration are subject to approval by the Associate Deputy Vice-Chancellor Research Training and Development in accordance with the [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16) and any other applicable [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
(9)  Current RMIT RTP stipend rates are available via research scholarships.
(10)  Further information about eligibility, selection, entitlements, paid leave for stipend recipients and other terms and conditions for Scholarships in accordance with the Commonwealth Scholarships Guidelines are set out in the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
#### Policy source: 
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clause (19) [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated) section 8. [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16)
### Application, Selection and Offers Processes for Awarding RTP Scholarships
(11)  The entry requirements for a place in a PhD program or Masters by research program at RMIT are available via research programs.
(12)  In order to be eligible to apply for an RTP stipend, applicants must have completed a bachelor degree with first class honours, or be regarded by RMIT as having an equivalent level of attainment in accordance with section 3 of the RMIT [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
(13)  The application process for a place in a research program is available at how to apply.
(14)  Information is available on the Admission and Credit Policy and the Scholarships, Prizes and Grants Policy. Information about RTP stipends is available in the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
#### Policy source: 
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clause (19) [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated) section 3. HDR Admissions and Scholarships Procedure [under development]
### Transition Arrangements for Continuing Students
(15)  All candidates may access information about the new RTP Scholarships and the transition arrangements applying to their previous RTS places and Australian Postgraduate Awards (APA) or International Postgraduate Research Scholarship (IPRS) via information for candidates.
(16)  Further information is also available from the Department of Education and Training's RTP FAQs for Students.
### Admission – Facilities and Supervision
(17)  Admission for enrolment in a higher degree by research at RMIT is in accordance with RMIT’s Admission and credit policy. By instructing an offer of admission to be made to an applicant, the enrolling school confirms that:
  1. it has the appropriate discipline expertise to house the research;
  2. it has the necessary space, facilities, equipment, technical and resource staff and funding for the applicant, for the duration of the program; and
  3. it has the capacity to provide dedicated supervision for the duration of the program.


(18)  The enrolling school must abide by its commitment to provide the above for the duration of candidature.
(19)  All HDR candidates attending RMIT campuses have access to non-laboratory workspace.
(20)  HDR workspace allocation will be aligned with (and should not exceed) the published policy governing workspace allocation for staff of the University.
(21)  The principles governing HDR space management and specific management requirements are set out in the HDR Space Management Policy.
#### Policy source:
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clauses (12) and (15) [HDR Space Management Policy](https://policies.rmit.edu.au/document/view.php?id=26)
### Supervision
(22)  RMIT will provide all HDR candidates with a suitably qualified senior supervisor and at least one other supervisor who have expertise in the discipline area of the candidate’s research project.
(23)  Supervisors are responsible for providing guidance regarding the candidate’s research project, assisting in resolving research-related issues and providing timely feedback.
(24)  Supervision must be undertaken in accordance with the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14) and the [Supervision Code of Practice](https://policies.rmit.edu.au/document/view.php?id=20).
(25)  The Dean/Head of School/Centre (or delegate) is accountable for the allocation of supervisors to candidates throughout the period of candidature and the oversight of supervision performance.
(26)  The senior supervisor or at least one of the joint senior supervisors must be an RMIT staff member.
(27)  Candidates or HDR Delegated Authorities (HDR DAs) may request a change to supervisory arrangements at any time as detailed in the HDR Supervision Arrangements Procedure.
(28)  All supervisors are required to be accredited and listed on the RMIT supervisor register before they can be allocated to candidates.
(29)  Categories of supervisor registration are determined by a combination of supervisory experience and research activity.
(30)  To maintain their level of registration supervisors must:
  1. meet ongoing eligibility requirements, and
  2. demonstrate they are effectively supporting candidates to achieve their expected milestones and research outcomes.


(31)  The requirements for supervisor registration are detailed in the HDR Supervision Arrangements Procedure.
#### Policy source:
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clause (14) [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14) HDR [Supervision Code of Practice](https://policies.rmit.edu.au/document/view.php?id=20)
### Employment and Study Load
(32)  Full-time commitment will average at least 4 days per week over the course of the year. Part-time commitment will average at least 2 days per week over the course of the year. Any work, paid or otherwise, undertaken by the candidate outside of their research project may not affect their ability to maintain this commitment.
(33)  Any changes between full- and part-time study load must be applied for in accordance with the eligibility requirements and processes set out in the HDR Candidature Duration and Enrolment Variation Procedure.
(34)  Where a candidate engages in a graduate research internship, work placement or other professional development activity during candidature:
  1. RSS conditions apply if the candidate receives an income associated with the activity (see requirements in section 1.2)
  2. there will be no impact on the duration or level or support provided through an RTP fees offset scholarship.


(35)  Additional provisions relate to employment while in receipt of a RSS or other type of stipend, further details are available in the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
#### Policy source:
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clauses (17) and (18) [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16) [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated)
### Changes to Enrolment
(36)  Any changes between full- and part-time study load must be applied for in accordance with the eligibility requirements and processes set out in the [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16).
(37)  By approving any program transfer to - or within - RMIT by an RTP Scholarship recipient, RMIT commits to providing the equivalent RTP Scholarship at the standard RMIT rates for the remaining duration of candidature in the new program (less any scholarship already received in-candidature). Request for any exceptions may be considered for approval by the Associate Deputy Vice-Chancellor Research Training and Development.
(38)  Where an RMIT-enrolled RTP Scholarship recipient transfers to another university, RTP scholarship support provided through RMIT will cease on cancellation of enrolment at RMIT. RMIT will supply details of the RTP support already provided to the candidate to the new university, with the candidate’s consent. The rates and support provided by the new university may vary within parameters permitted in section 1.6 of the Commonwealth Scholarship Guidelines 2017.
(39)  Further information about program transfers (within or external to RMIT), study load changes and other enrolment changes can be found in the HDR Candidature Duration and Enrolment Variation Procedure.
#### Policy source:
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) (HDR Candidature) [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16) [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated)
### Termination of an RTP Fees Offset
(40)  RMIT can terminate an RTP fees offset based on a candidate having established unsatisfactory academic progress, in accordance with the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) sections 5.13 and 5.14 and associated procedures. 
(41)  Any RTP fees offset will be terminated at the same time as candidature termination.
#### Policy source:
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clauses (21) to (24) [HDR Action and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=13) [HDR Progress Management Procedure](https://policies.rmit.edu.au/document/view.php?id=15)
### Termination of an RTP Stipend
(42)  RMIT can terminate an RTP Stipend in accordance with the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
(43)  If a research stipend is terminated, it cannot be re-activated unless the termination occurred in error.
#### Policy source:
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clauses (21) to (24) [HDR Action and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=13) [HDR Progress Management Procedure](https://policies.rmit.edu.au/document/view.php?id=15)
### Grievances, Reviews and Appeals
(44)  For the resolution of concerns or grievances in candidature or a review of a decision, candidates should follow the provisions of RMIT's Complaints Governance Policy.
(45)  Candidates seeking to appeal against their examination outcome, or termination of candidature may do so in accordance with the Assessment, Academic Progress and Appeals Regulations.
#### Policy source:
[Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) clauses (32) to (33) Complaints Governance Policy Assessment, Academic Progress and Appeals Regulations
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=1#document-top)
# Section 5 - More Information
(46)  Refer to the:
  1. Commonwealth Scholarships Guidelines (Research) 2017
  2. Current stipend rates and information on fees offset scholarships
  3. Department of Education and Training RTP FAQs for Students
  4. Department of Education and Training RTP FAQs for Administrators
  5. [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
