[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=196&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=196&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Intellectual Property Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=196)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=196&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=196&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=196&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=196&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=196&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=196&version=1)


# Intellectual Property Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=196&version=1#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=196&version=1#minor1)
  * [Part B - INTELLECTUAL PROPERTY COMMITTEE](https://policies.rmit.edu.au/document/view.php?id=196&version=1#part2)
  * [2. Intellectual Property Committee](https://policies.rmit.edu.au/document/view.php?id=196&version=1#minor2)
  * [Part C - REVOCATION OF REGULATIONS](https://policies.rmit.edu.au/document/view.php?id=196&version=1#part3)
  * [3. Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=196&version=1#minor3)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to make further provision in relation to intellectual property and to establish the intellectual property committee.
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
## Part B - INTELLECTUAL PROPERTY COMMITTEE
#### 2. Intellectual Property Committee
(3)  There is an Intellectual Property Committee (the committee).
(4)  The committee is an advisory committee to the Vice-Chancellor.
(5)  Membership and conduct of meetings of the committee is as determined by the committee’s terms of reference, as approved by the Vice-Chancellor.
(6)  The committee is responsible for all aspects of University intellectual property and without limiting the generality of the same:
  1. a) makes policy recommendations on intellectual property ownership rights between the University, its academic and research groups, members of staff and students, its commercial companies and parties external to the University including the division of any income derived from the commercialisation of intellectual property
  2. recommends the extent to which the University will support the development of any intellectual property
  3. advises and makes recommendation to the Vice-Chancellor on progress towards intellectual property goals within the context of the University’s Strategic Plan
  4. informs the Vice-Chancellor on the activities of the committee
  5. provides recommendation on the dissemination of material to inform the wider University community of any matters of intellectual property law, including for research, teaching materials, courseware and student assessment and monitors the effectiveness of such dissemination
  6. informs the University community about intellectual property matters, and
  7. recommends to the Vice-Chancellor the establishment of a sub-committee to resolve any dispute submitted to it by a member of staff or student concerning: 
    1. the ownership of intellectual property
    2. the division of any income arising from the commercialisation of intellectual property.


(7)  Where the sub-committee is unable to resolve any dispute submitted to it under clause (6)g., the staff member or student may appeal to the Vice-Chancellor.
## Part C - REVOCATION OF REGULATIONS
#### 3. Revocation of Regulations
(8)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 7.1.1 The Intellectual Property Committee.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
