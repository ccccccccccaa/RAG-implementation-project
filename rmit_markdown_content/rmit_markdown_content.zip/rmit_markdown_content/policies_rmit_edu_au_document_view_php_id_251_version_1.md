[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=251&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=251&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Academic Management Procedure - Higher Education Coursework 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=251)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=251&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=251&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=251&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=251&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=251&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=251&version=1)


# Program and Course Academic Management Procedure - Higher Education Coursework
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=251&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=251&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=251&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=251&version=1#section4)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=251&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure defines academic leadership responsibilities for the oversight and quality assurance of new or existing higher education coursework programs and course offerings in compliance with legislative requirements. It prescribes the managerial framework for program and course design, delivery, quality review cycles and professional and internal accreditation. The procedure is intended for all staff involved in program design, review and delivery.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=251&version=1#document-top)
# Section 2 - Authority
(2)  The authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=251&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all higher education coursework programs and courses offered by the RMIT Group, including programs delivered by controlled entities and offshore partners, and short non-award courses (i.e. micro-credentials and Future Skills) which are embedded in award programs and/or courses.
(4)  This procedure does not apply to Higher Degree by Research programs, vocational education and training programs, RMIT University Pathways (RMIT UP) programs and courses, and short non-award courses.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=251&version=1#document-top)
# Section 4 - Procedure
#### Higher Education Coursework Program and Course Academic Management
(5)  Each college has an Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent) who is responsible for leading academic management and for oversight of quality assurance for all coursework programs and courses owned by the college.
(6)  Each school or discipline has a Dean/Head of School/Cluster Director (or equivalent) who is responsible for the management of quality assurance for all coursework programs and courses owned by the school/discipline or industry cluster, including program and course reviews, professional accreditation, continuous improvement initiatives in response to student experience metrics, and staff capability development.
(7)  Each college has a Senior Manager Quality Enhancement (or equivalent) who is responsible for coordinating quality assurance for all coursework programs and courses owned by the college.
(8)  Each program has a Program Manager (or equivalent). A college may choose to appoint a Major/Minor Coordinator instead of, or in addition to, a Program Manager to oversee a specified discipline area.
(9)  A Program Manager and/or Major/Minor Coordinator is appointed by the Dean/Head of School/Cluster Director (or equivalent or delegate) of the owning school/industry cluster as the leading academic member for all locations and modalities that the program or discipline is offered. Program Managers and/or Major/Minor Coordinators are responsible for ensuring that the requirements of the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27) and associated instruments and professional accreditation requirements are met.
  1. For large or multiple location/partner programs with multiple appointed Program Managers/Major/Minor Coordinators, the Dean/Head of School/Cluster Director (or equivalent) may appoint the Associate Dean (or equivalent) of the owning school/industry cluster as the leading academic member to coordinate academic oversight.
  2. Where a program and/or discipline area is owned by the college, the Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent) appoints a Program Manager and/or Major/Minor Coordinator.


(10)  Program or discipline teams are appointed by the decision of the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent), or Dean/Head of School/Cluster Director of the owning school/industry cluster to coordinate program design, ongoing development and review.
  1. The program/discipline team should comprise at least four academic staff members actively involved in the program/discipline delivery and teaching.
  2. The team includes representatives from each partner and/or location at which the program/discipline is offered, and at least one active researcher.
  3. The program or discipline team should meet a minimum of twice per year, or as directed by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent) or Dean/Head of School/Cluster Director of the owning school/industry cluster.
  4. A smaller program or discipline team may be appropriate for programs with a small student cohort and/or volume of learning less than two years full-time equivalent, such as a graduate certificate. For these programs, the size and composition of the program/discipline team must be sufficient to address the educational, academic support, and administrative needs of student cohorts undertaking the program.
  5. Where a delivery partner is not able to join meetings of the program team, meeting minutes and actions will be made available to the delivery partner.


(11)  Each coursework course has a Course Coordinator (or equivalent).
(12)  A Course Coordinator (or equivalent) is assigned by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent), or Dean/Head of School/Cluster Director of the owning school/industry cluster (or delegate) as the leading academic member for all locations and modalities during each teaching period that the course is delivered. Course Coordinators (or equivalent) are responsible for coordinating the curriculum, teaching and assessment across all course offerings during the agreed teaching period/s.
  1. An Offering Coordinator may be appointed at a delivery partner or RMIT Vietnam to work with a Course Coordinator to ensure the coordination of teaching, curriculum and assessment for a course offering.


(13)  Program Managers, Major/Minor Coordinators, Course Coordinators, and other staff with responsibilities for academic oversight, teaching and assessment in a course or component of a course will have:
  1. appropriate qualifications or equivalent relevant academic or professional or practice-based experience and expertise as per the guidance for [Higher Education Staff Qualifications, Scholarship and Equivalency](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/HE-Staff-Qualifications.aspx?csf=1&web=1&e=HlM7hn&CID=90737ec3-3e23-4f34-b20b-b3ab9c45be56),
  2. continuing scholarship or research or advances in practice that maintains currency of knowledge in the discipline area of teaching, and
  3. skills in contemporary teaching, learning and assessment relevant to their role, the discipline, modes of delivery and the needs of the eligible student cohorts in accordance with the [RMIT Educator and Researcher Capability framework](https://www.rmit.edu.au/staff/service-connect/careers-management/career-development/learn/capability-development-frameworks/educator-and-researcher).


(14)  The Dean/Head of School/Cluster Director (or equivalent) of the school/industry cluster is responsible for ensuring any casual academic staff or external specialists appointed to contribute to the design and/or delivery of programs, courses or units receive appropriate guidance and supervision by a permanent senior academic staff member.
#### Course Management Teams
(15)  A course management team (CMT) is formed for all courses offered in multiple locations, modalities and where more than one person is responsible for teaching and/or assessment in the course.
  1. The CMT should meet a minimum of twice per teaching period for the course offering, or as directed by the College Associate Deputy Vice-Chancellor, Learning and Teaching (or equivalent) or Dean/Head of School/Cluster Director of the owning school/industry cluster.
  2. Refer to the [CMT template](https://www.rmit.edu.au/staff/teaching/program-and-course-admin/program-and-course-forms) and [Equivalence and Comparability of Academic Standards](https://rmiteduau.sharepoint.com/sites/EQ/SitePages/2022%20Program%20Reviews.aspx) for further information.


(16)  The responsibilities of the CMT are:
  1. to assist the Course Coordinator (or equivalent) in delivering the course
  2. to evidence that the learning outcomes of the course are met in all locations and modalities
  3. to foster collaboration in course design and assessment, collegiality, team building and inclusion
  4. to ensure the standards of the learning outcomes are equivalent and comparable for every offering.


(17)  The members of the CMT should include:
  1. the Course Coordinator (or equivalent)
  2. the Offering Coordinator/s and/or those responsible for leading the delivery of the course in other locations and modalities
  3. other academic and teaching staff responsible for teaching and/or assessment of the course at the invitation of the Course Coordinator.


(18)  All or part of the reporting template should be used by the Course Coordinator to request information from the course teams in each location.
(19)  The CMT discussion should include consideration of:
  1. course content
  2. contextualisation
  3. learning resources
  4. course delivery
  5. assessment
  6. results
  7. student feedback.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=251&version=1#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Accreditation |  A type of quality assurance process under which programs, services and operations of educational institutions are evaluated by an external body or institutional governing body to determine if relevant standards are met. If standards are met, accredited status is granted by the appropriate agency. For RMIT, the relevant external regulatory bodies are the Tertiary Education Quality Standards Authority (TEQSA) for higher education and Foundation Studies, the Australian Skills Quality Authority (ASQA) for vocational education and training products, the National ELICOS Accreditation Scheme (NEAS) for English language intensive programs. The relevant institutional bodies are the Academic Board and the ASQA Delegation Panel.  
Professional accreditation | Granted to programs of study that have been assessed by and meet the knowledge and skills competencies required by the granting professional body. Professional accreditation status of a program of study may be required for a graduate to be eligible to practice within that profession, also known as statutory accreditation.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
