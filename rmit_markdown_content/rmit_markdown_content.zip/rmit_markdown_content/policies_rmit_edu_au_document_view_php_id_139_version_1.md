[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=139&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=139&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Taxation Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=139)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=139&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=139&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=139&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=139&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=139&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=139&version=1)


# Taxation Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=139&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=139&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=139&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=139&version=1#section4)
  * [Goods and Services Tax (GST)](https://policies.rmit.edu.au/document/view.php?id=139&version=1#major1)
  * [Fringe Benefits Tax (FBT)](https://policies.rmit.edu.au/document/view.php?id=139&version=1#major2)
  * [Taxes in Other Jurisdictions](https://policies.rmit.edu.au/document/view.php?id=139&version=1#major3)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=139&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides business rules to ensure the University complies with: 
  1. all relevant taxation laws, regulations, rulings, policies and procedures in the countries in which it operates. 
  2. reporting obligations for relevant taxation laws in the countries in which it operates.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=139&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Financial Management Policy](https://policies.rmit.edu.au/document/view.php?id=70).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=139&version=1#document-top)
# Section 3 - Scope
(3)  This procedure relates to taxation managed by the Finance and applies to all staff making purchases on behalf of the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=139&version=1#document-top)
# Section 4 - Procedure
### Goods and Services Tax (GST)
(4)  The University must be provided with a valid tax invoice for every purchase over Australian Taxation Office (ATO) approved limits to claim a GST refund from the ATO. 
(5)  A valid tax invoice must be always be requested before payment is made to a supplier, and a receipt obtained. 
(6)  Invoices in electronic form can be tax invoices if they provide all the information required and are legible and accessible for audit purposes. 
(7)  A pro-forma invoice is not a tax invoice and payment should not be made until a tax invoice is received. 
(8)  For credit card expenditure or expense reimbursements where the payment has already been made and the supplier has refused to provide a tax invoice: 
  1. tax invoice requirements may be met if that information is contained in other documentation related to the purchase and combined as a whole; and 
  2. all documentation must be attached in the University’s expense management system. 


(9)  The requirement to produce a tax invoice can be waived where the vendor is using an electronic purchasing system. The information must be provided in electronic format and be available for audit by the ATO as required, to satisfy legislative requirements. 
### Fringe Benefits Tax (FBT)
(10)  All transactions entered into by the University must be analysed to determine the correct FBT treatment and will comply with all FBT laws, rulings, guidelines and reporting obligations.
(11)  When the taxable value of all benefits received by an employee reaches $2,000.00 or more, the grossed-up amount of this benefit will appear on the employee's payment summary. 
(12)  An employee must keep a travel diary as required by the [Travel Policy](https://policies.rmit.edu.au/document/view.php?id=80) to ensure the University's FBT liability is reduced to the maximum extent possible. Rules related to private travel are also included in the [Travel Policy](https://policies.rmit.edu.au/document/view.php?id=80). 
(13)  In the event of an ATO audit discovering non-compliance with the rules in any of the previous five FBT years, any FBT and subsequent penalty (up to 200% of the tax payable) will be charged directly to the department concerned and reported on the employee payment summary where required. 
### Taxes in Other Jurisdictions
(14)  Due to the complexity of international tax, guidance must be sought from Central Finance Operations prior to entering into commercial contracts or creating new subsidiaries. 
(15)  Any business case involving establishing operations or activities in a new jurisdiction must include and assess the tax compliance obligations and compliance costs as part of its assessment. 
#### General considerations
(16)  RMIT’s exemption from income tax in Australia should not be assumed to apply in other jurisdictions; conditions for income tax exemption can differ between jurisdictions, and additional compliance obligations may result from other tax imposts. 
(17)  Central Finance Operations should be engaged early to support best practice; where necessary, engagement with external consultants in Australia and overseas may also be required. The costs of compliance (both setup and annual) can be significant. 
(18)  RMIT may be required to meet annual or more regular tax obligations and will likely be liable to value-added tax (VAT), GST and/or sales tax and the associated compliance obligations. 
(19)  RMIT may also be liable for employment tax obligations in respect of activities to be conducted in a foreign country by its employees, employers and contractors. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=139&version=1#document-top)
# Section 5 - Resources
(20)  Refer to the following documents which are established in accordance with this procedure:
  1. FBT Guideline
  2. GST Guideline


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
