[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=203#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=203#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Guide Instruction 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=203)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=203)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=203)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=203)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=203)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=203)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=203)


# Program and Course Guide Instruction
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=203#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=203#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=203#section3)
  * [Section 4 - Instructions](https://policies.rmit.edu.au/document/view.php?id=203#section4)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=203#major1)
  * [Section A: Program Guides](https://policies.rmit.edu.au/document/view.php?id=203#major2)
  * [Section B: Course Guides](https://policies.rmit.edu.au/document/view.php?id=203#major3)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=203#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This instruction provides the rules for the development and content of program and course guides.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=203#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=203#document-top)
# Section 3 - Scope
(3)  This instruction applies to all vocational education, higher education and Higher Degree by Research programs, skill sets and courses offered by the RMIT Group. 
(4)  This instruction does not apply to non-award programs including Foundation Studies, English Language Intensive Courses for Overseas Students (ELICOS) and English preparation programs.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=203#document-top)
# Section 4 - Instructions
(5)  Program and course guides are the approved statement of program and course requirements and form part of the enrolment agreement with the student. 
(6)  Program and course guides for offerings, plans and delivery modes are:
  1. accurate and up to date
  2. published as part of the RMIT Handbook
  3. accessible to current and prospective students before any related marketing material can be published
  4. compliant with RMIT policies and relevant legislative instruments, and
  5. written with the student audience in mind. 


### Responsibilities
(7)  The College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent), with support from the General Manager, College Operations (or equivalent), are accountable for the accuracy and alignment of program information published to RMIT websites for their respective colleges, including program guides, marketing program summaries and course guides. 
  1. The CEO, RMIT Online is accountable for this requirement for RMIT Online offerings. 
  2. The Deputy Vice-Chancellor and Vice-President - International and Engagement is accountable for this requirement for RMIT offerings with global partners. 
  3. The Chief Experience Officer is accountable for this requirement for RMIT Vietnam offerings. 
  4. The Admissions Governance Steering Committee provides oversight for this function. 


(8)  The Program Manager (or equivalent) and/or the college teams responsible for program quality, governance and admissions are responsible for ensuring: 
  1. that the information in published program guides is correct and up to date 
  2. that published program guide material is monitored and updated as part of the program quality and admissions review cycles. 
    1. For higher education programs, please see the Higher Education new program and program amendments schedule on the [Program and Course forms webpage](https://www.rmit.edu.au/staff/teaching/program-and-course-admin/program-and-course-forms) for program and course amendment dates. 


### Section A: Program Guides
(9)  The program guide sets out the program requirements a student must fulfil to be eligible for the award. 
(10)  A separate program guide is created for each partner and/or campus offering. 
  1. Exceptions may apply to administrative programs, exchange programs, non-award programs, programs delivered by third-parties, or in consultation with Academic Governance. 


(11)  Once a program guide in ‘submitted’ or ‘endorsed’ status has been approved, it is published as soon as practicable upon confirmation of approval. 
  1. To comply with records management of program approvals, the approved program guide is published before any further changes can be made. 
  2. The publication timeline of an approved program guide may take into account professional accreditation and/or offshore regulatory requirements. 


(12)  A program guide is created for each intermediate award, even where these are only available as exit awards. 
(13)  A program guide is written in second person, for example: using language such as ‘you will’. 
(14)  Where the program offering is registered for delivery to students studying on a student visa in Australia, the program guide complies with the [National Code of Practice for Providers of Education and Training to Overseas Students 2018](https://policies.rmit.edu.au/directory/summary.php?code=3) (National Code 2018), including: 
  1. the provision of accurate and accessible information to assist students in making informed decisions about the program 
  2. the provision of RMIT’s CRICOS registered name and registered number 
  3. the provision of information about any non-tuition fees anticipated for students to complete the program 
  4. ensuring overseas students have sufficient English language proficiency, educational qualifications and/or work experience to enrol in the program. 


(15)  For a program to be described as professionally accredited in the program guide, it must hold an active professional accreditation status by the relevant body. 
  1. A program may be described as having conditional and/or provisional accreditation status in the program guide where these classifications are appropriate to the relevant body. 
  2. Where a professionally accredited program is offered at a new campus or partner location, the owning college is responsible for confirming the accreditation status of the new offering and amending the program guide information accordingly. 
  3. A program holding professional accreditation with an Australian professional body must seek the same professional accreditation for any offshore offering of the same program, in addition to any appropriate offshore accreditation that may be required. 


#### Program Guide Fields
(16)  A higher education coursework program guide must align with the requirements of the Academic Registrar's Group [Program Proposal Checklist](https://rmiteduau.sharepoint.com/sites/HEProgramApprovals/Guidance%20Material/Forms/AllItems.aspx). 
#### External Accreditation and Industry Links
(17)  The External Accreditation and Industry Links section of the program guide: 
  1. provides accurate information about current professional accreditation and/or eligibility for industry memberships 
  2. uses specific language about whether a program is professionally accredited, provisionally accredited, conditionally accredited, seeking accreditation, or not accredited 
  3. does not describe a program offering or plan as having professional accreditation until that accreditation is confirmed 
  4. accurately reflects the professional accreditation status and wording documented on the professional accrediting body website and in official communications from the professional accreditation body 
  5. conveys to students: 
    1. the benefits of any professional accreditation or memberships upon graduation 
    2. if professional accreditation is a requirement to practice in the profession met by the program of study upon graduation 
  6. describes any industry connections, registrations, affiliations and Industry Advisory Committee associated with the program. 


(18)  Where the professional accreditation status is described as seeking, students should be clearly informed prior to their program enrolment of the impact on their qualification if professional accreditation is not successfully obtained. 
(19)  Where professional accreditation status is described as conditional, students should be clearly informed prior to their program enrolment if there is a risk that the program might not obtain full accreditation and the impact to their qualification if professional accreditation is not successfully obtained. 
(20)  If the status of professional accreditation changes, the college must fully inform affected students of the potential impact on their studies and future employment outcomes. 
(21)  Where core courses differ between locations and all program offerings lead to professional accreditation, the program guide External Accreditation and Industry Links section identifies which course titles and codes are required for professional accreditation for each additional plan offering. 
  1. For example, if a partner institution outside Australia requires a specific course to meet accreditation requirements for that location, the program guide accreditation statement for that location plan advises students of courses required to fulfil accreditation requirements. 


#### Purpose of the Program
(22)  The Purpose of the Program section provides: 
  1. a description of the program curriculum and objectives 
  2. a description of the range of career and further study pathways upon completion 
  3. a statement describing why a student would choose the program 
  4. a summary of selection choices if there is a choice of major/minor or program options
  5. a description of any capstone courses (for example, course title, code and brief description) 
  6. a statement explaining the program delivery mode with; the requirements for in-person attendance; the mix of in-person attendance and online (blended), or if it must be undertaken entirely online 
  7. a description of any research course title/s and code/s where a program is a Masters by Coursework or Honours. 


#### Statement on Competency-based Training (Vocational Education only)
(23)  The Statement on Competency-based Training uses the standard text statement provided for vocational education program guides and provides a hyperlink to information about how to apply for Recognition of Prior Learning. Changes to the standard text statement may be approved by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent). 
#### Program Learning Outcomes Statement (Higher Education only)
(24)  The Program Learning Outcomes Statement for higher education provides a list of the program learning outcomes students can expect to graduate with, using complete phrases and words without acronyms. 
  1. For guidance on the design of appropriate program learning outcomes, please refer to the [Program and Course Design Procedure - Higher Education Coursework](https://policies.rmit.edu.au/document/view.php?id=298) and the [Educator Resource Hub](https://policies.rmit.edu.au/download.php?id=405&version=2&associated). 


#### Program Learning Outcomes Matrix (Higher Education Coursework only)
(25)  The Program Learning Outcomes Matrix for higher education coursework demonstrates how courses taken in the current program structure meet the program learning outcomes, the approved set of RMIT Capabilities and map to the specified AQF level learning outcome descriptors for the appropriate award level. 
  1. First year study blocks are included in the program learning outcomes mapping. 
  2. Program majors and compulsory minors are included in the program learning outcomes mapping in a separate row/column for first-year block courses. 
  3. Other courses that are deemed core to the program, such as a research course or choice of core options are included in the program learning outcomes mapping in a separate row/column. 
  4. Program options, electives and non-compulsory minors do not need to be included in the program learning outcomes mapping. 
  5. Where a course in the program plan is offered at two locations for the plan, both course codes should be listed in the program learning outcomes matrix. 


#### Employability Skills (Vocational Education only)
(26)  The Employability Skills section of the program guide for vocational education aligns with the skill clusters described in the [Core Skills for Work Developmental Framework](https://www.dewr.gov.au/skills-information-training-providers/core-skills-work-developmental-framework). Foundation skills are usually outlined by the training package handbook. 
#### Program Structure
(27)  The Program Structure section in a published program guide: 
  1. provides any relevant guidance for students to select course combinations, such as a major or minor 
  2. provides clear guidance to students on required core and optional program elements and combinations of learning blocks required to achieve particular graduate outcomes 
  3. reflects the approved program structure 
  4. accurately reflects the planned sequence of study to align with the scheduling of classes
  5. provides active hyperlinks to the correct and up to date course guides, or is republished when the course guide hyperlinks become activated 
  6. complies with the [Program and Course Design Procedure - Higher Education Coursework](https://policies.rmit.edu.au/document/view.php?id=298) and the [Program and Course Configuration Instruction](https://policies.rmit.edu.au/document/view.php?id=41). 


#### Work Integrated Learning (WIL)
(28)  The Work Integrated Learning (WIL) section of the program guide state: 
  1. the designated WIL course/s in the program, identified by the course title/s and course code/s
  2. the activities that will be offered in the program as WIL, placements, industry engaged projects, blended activities, simulated workplace environments, and other suitable descriptor 
  3. that WIL activities in courses may vary in different locations and with different cohorts 
  4. the registered work-based training hours (where applicable) for CRICOS registered programs 
  5. both academic prerequisites and non-academic eligibility requirements (which may include but are not limited to immunisation or vaccination requirements, visas, Working with Children Checks, Police Checks, National Disability Insurance Scheme Worker Screening Check and responsibilities for associated costs), including those aligned to the requirements of professional registration and accrediting bodies where applicable 
  6. other information that may be pertinent to the completion of WIL in the program 
  7. a description of other Industry Partnered Learning (IPL) that students may expect to encounter in the program, including Career Development Learning (CDL) and Industry Embedded Activities (IEA) 
  8. in addition, a vocational education program guide must include the national course code/s of designated WIL courses. 


For further information please refer to the [Program and Course Work Integrated Learning Procedure](https://policies.rmit.edu.au/document/view.php?id=119). 
#### Approach to Learning and Assessment
(29)  The Approach to Learning and Assessment section of the program guide provides: 
  1. a summary of the curriculum delivery plan and any mandatory work placements 
  2. an overarching statement outlining how learning activities and assessment methods will prepare students for career and graduate outcomes 
  3. the method of blended delivery, where applicable (for example, where lectures will be delivered online and/or intensive on-campus teaching activities) and the rationale or intent behind this design 
  4. a hyperlink to the [Assessment and Assessment Flexibility Policy ](https://policies.rmit.edu.au/document/view.php?id=7)
  5. any inherent requirements of the program 
  6. hyperlinks to location-specific student support services 
  7. information about support available via the Equitable Learning Service 
  8. information that aligns with the relevant Training and Assessment Strategy for vocational education programs. 


#### Articulation and Pathways
(30)  The Articulation and Pathways section of the program guide provides: 
  1. any shorter recency requirements, or waiver of recency requirements, for credit or advanced standing, otherwise a standard recency requirement of ten years for credit transfer will apply in accordance with the [](https://policies.rmit.edu.au/document/view.php?id=126)[Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126)
  2. any specified credit pathway or competency agreement for program entry, with the remaining credit points for higher education or volume of learning for vocational education that are required to complete the program 
  3. specific pathway recommendations for further studies at RMIT
  4. a statement about the availability of credit transfer and recognition of prior learning and a hyperlink to student-facing information for the application process 
  5. courses which articulating students will receive credit for in destination programs within an articulation agreement 
  6. a statement outlining whether a student can exit a program prior to completion and obtain a lower award, including what criteria needs to be met. 


#### Entrance Requirements
(31)  The Entrance Requirements section of the program guide provides: 
  1. program minimum entry requirements in terms of the qualifications and scores most relevant to applicants who are citizens in the location where the plan is being offered 
  2. any required prerequisite study, where applicable 
  3. alternate entry pathways that may be available, with work experience stated as the number of full-time equivalent years 
  4. International English language requirements as the International English Language Testing System band or a hyperlink to the English language requirements web page for equivalences and further information. 
  5. any further selection tasks that may be required for successful entry into the program 
  6. any further requirements, such as an interview or personal statement that is not classified as a selection task 
  7. a hyperlink to the web page for entry requirements by country for equivalence information to the stated academic requirement 
  8. any essential requirements to successfully complete the program, such as a Working with Children Check, any immunisation or vaccination requirements or Police Check 
  9. where the plan has been discontinued, a statement advising students that the plan has been discontinued and the teaching period for the final intake. The final teaching intake period should take into account any articulation agreements, and needs to state when the last cohort from any other RMIT lower award can be admitted into the program. 


(32)  English language entry requirements stated in the program guide are in accordance with the [](https://policies.rmit.edu.au/document/view.php?id=131)[English Language Proficiency Procedure](https://policies.rmit.edu.au/document/view.php?id=131). 
(33)  Minimum academic entry requirements stated in the program guide are in accordance with the [](https://policies.rmit.edu.au/document/view.php?id=6)[Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6) and corresponding procedures. 
(34)  Inherent requirements are not included in the program entrance requirements and do not form a basis of assessing applicant suitability for entry into a program. 
#### Library, IT and Specialist Resources
(35)  The Library, IT and Specialist Resources section of the program guide provides: 
  1. contextualised resource information to the offering location and delivery mode 
  2. hyperlinks to the discipline-specific library subject guide 
  3. information on general IT services for students and any IT resources specific to the program 
  4. links to RMIT learning support services and Student Connect. 


#### Student Expenses and Charges in Addition to Fees
(36)  Any additional expenses that a student will incur to successfully complete the program of study that is not already approved and published in the material fees schedule must be stated in the Student Expenses and Charges in Addition to Fees section of the program guide. 
#### Program Transition Plan
(37)  Where the program plan is to be discontinued, the Program Transition Plan section of the program states: 
  1. a clear explanation of what is planned and how students will be supported in the transition and/or teach out. This statement must be consistent with the discontinuation letters provided to students 
  2. the teaching period of the final intake and the teaching period the program/plan is intended to be fully taught out by, or students transitioned out from
  3. an RMIT program for transitioning into, if available 
    1. for CRICOS-registered programs, the replacement program must be CRICOS registered before it can be published as part of a Program Transition Plan for international students studying in Australia 
  4. where applicable, how the transition arrangement will work for academic progress, explaining: 
    1. maximum time to complete the program 
    2. maximum leave of absence 
    3. course grades will be transferred and/or contribute to students’ grade point average (if the transition case involves being moved to a different program) 
  5. a table showing mapping of equivalent courses and/or credit transfer if program transitioning occurs.


(38)  Where there is a major program amendment approved and students will be required to transition to the new program structure and/or plan code, the Program Transition Plan section of the program guide provides: 
  1. a description of the teaching period in which the amendment will be implemented 
  2. a table showing the mapping of equivalent courses and/or credit transfer 
  3. course title changes, and 
  4. changes to core and option course lists. 


#### Nominal Program Duration and Volume of Learning
(39)  The nominal program duration stated in a program guide should be the AQF volume of learning appropriate to the AQF qualification type, expressed in terms of a full-time enrolment in the two Melbourne standard semesters per year. That is, one AQF year equals two Melbourne standard higher education semesters with a full-time enrolment of 48 credit points per semester, or two Melbourne vocational education semesters with a full-time enrolment of 720 scheduled contact hours in total for both semesters. Refer to the [](https://policies.rmit.edu.au/document/view.php?id=113)[Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=113) for further information. 
  1. The full load in Vocational Education will be dependent on the nominal hours for the program or skillset. 


(40)  If a program can be offered both on full-time and part-time basis, the full-time basis is quoted first in the program guide, and then the part-time basis afterwards in this exact format: (for example, ‘three years full-time, six years part-time’ or ‘six months full-time, 12 months part-time’). 
(41)  Programs with CRICOS registration state the program duration separately for domestic and students studying on visas. For example, ‘Domestic students three years full-time, six years part-time; International students three years full-time’. 
(42)  The defined program credit points for higher education or nominal hours for vocational education needed to complete a program comply with the AQF volume of learning appropriate to the AQF qualification type. 
(43)  Higher Degree by Research program duration and volume of learning are specified in the [](https://policies.rmit.edu.au/document/view.php?id=164)[HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16). 
(44)  Scheduled contact hours for vocational education programs cannot exceed the maximum funded hours available for the qualification that is stated in the purchasing guide. 
  1. No changes may be made to the scheduled contact hours of a program or plan during a calendar year without approval from Data and Analytics, and Financial Services. 
  2. For specific rules on changing the duration of a program or plan, or the relevant reportable hours of a vocational education program, please refer to the [Program and Course Configuration Instruction](https://policies.rmit.edu.au/document/view.php?id=41). 


### Section B: Course Guides
(45)  The Course Guide is the approved statement of the course requirements, attributes, learning outcomes and assessment. As such, it forms part of the enrolment agreement with the student. 
(46)  The Course Guide is comprised of a Course Guide Part A and a Course Guide Part B. 
  1. The Course Guide Part A is published as public facing information and provides a course synopsis with key attributes such as credit points and course learning outcomes that are applicable to all offerings and student cohorts. 
  2. The Course Guide Part B contains more detailed internally facing information, such as the teacher/s, campus or modality, instruction mode/s, teaching schedule, assessment tasks and resources. 
    1. This information may be provided to members of the public, such as industry partners, upon request. 
    2. A separate Course Guide Part B is provided for each delivery of a course specific to a location or modality and teaching period, or class, in the case of flexible terms. 
    3. Student delivery and/or curriculum and assessment information that is not provided in the Course Guide Part B must be accessible in the learning management system.


(47)  Accurate and current information in each field of the Course Guide Part A must be completed for endorsement and publication before the Course Guide/s Part B can be published. 
(48)  The information provided in the Course Guide Part B matches the information in the Course Guide Part A and the learning management system shell. 
  1. Any change to content that affects the accuracy of information in both Parts A and B must be made first in Part A and approved by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent). 


(49)  A Course Guide is written in the second person, for example, ‘you will’. 
#### Changes to Course Guides
(50)  Any changes made to course learning outcomes, assessment and/or curriculum in Course Guides needs to be evaluated to determine whether the changes require the creation of a new course. This decision must be made according to the following principles: 
  1. students who have successfully passed the course must not be made to repeat the superseded course within 10 years as part of their transition or completion requirements. Refer to the [](https://policies.rmit.edu.au/document/view.php?id=130)[Currency of Learning Guideline](https://policies.rmit.edu.au/document/view.php?id=130) for further information 
  2. whether the superseded course needs to continue being delivered as part of a teach-out arrangement 
  3. whether the existing course is included in credit mapping as part of an articulation agreement 
  4. whether the creation of a new course may reduce any adverse impacts on the student experience 
  5. whether the course is included in Vietnam and/or partner offerings and ensuring consultation has occurred to inform the decision
  6. whether a change of ASCED code will be required. 


(51)  Changes to the Course Guide Part A should be made at least two weeks prior to the commencement of the teaching period the changes are intended to start in, and in or after the final week of semester where the course is delivered over consecutive semesters. For example, changes to take effect for semester 2, 2023 should be made during the final week of semester 1, 2023. 
  1. All changes to Course Guide Part As are approved by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent or delegate). 
  2. Any changes to a Course Guide Part A made during a teaching period also affects the Course Guide Part B for every subsequent teaching period. 
  3. Where the course is offered in multiple locations with overlapping teaching periods, changes to Course Guide Part As should be made in consultation with the Academic Governance team, who can advise date windows to update Course Guide Part As concurrently for all locations. 


(52)  Changes to Course Guide Part Bs are approved by the Program Manager (or equivalent or delegate) and can be made up until the first day of classes for each relevant teaching period that is covered by the guide. Colleges may institute their own approval level higher than the Program Manager. 
(53)  For changes to assessment in course guides, please refer to the relevant section of the [](https://policies.rmit.edu.au/document/view.php?id=7)[Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7). 
#### Course Guide Part A
(54)  The Course Guide Part A is published for all currently active courses. 
  1. Exceptions that do not require a published Course Guide Part A are PhD or Masters by Research thesis/project courses, or purely administrative courses. For example, Study Abroad courses or courses created solely for the purposes of credit transfer or Recognition of Prior Learning (RPL). 
  2. Other exceptions are approved by the Academic Registrar. 


(55)  For courses in coursework programs, the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent or delegate) and Dean/Head of School/Cluster Director (or equivalent) are responsible for the review and publication of up-to-date Course Guide Part A information prior to the start of each teaching semester. 
(56)  For courses in Higher Degree by Research programs, the relevant delegated authority and Deputy Dean Research and Innovation or Head of School (or equivalent) are responsible for the review and publication of accurate Course Guide Part A information prior to the start of each teaching semester. 
(57)  The Course Guide Part A provides: 
  1. the number of credit points for higher education 
  2. the nominal course hours for vocational education 
  3. for vocational education: advice as to whether the course could be included as part of a cluster of units for some cohorts of students with a reference to all unit titles and codes included in the cluster 
  4. current Course Coordinator (or equivalent) information 
  5. the prerequisite courses, assumed knowledge and capabilities, noting that: 
    1. only a system enforced requisite can be described as a ‘requisite’, ‘pre-requisite’ or ‘co-requisite’
    2. a non-system enforced requirement should be described as ‘recommended knowledge or prior study’ or ‘assumed knowledge or prior study’ and should refer students to their Course Coordinator or equivalent for further information
    3. vocational education courses must only include requisite units that are prescribed in the training packages or accredited courses
    4. if there are no prerequisites or assumed knowledge, write ‘none’ 
  6. a course description that includes: 
    1. a brief description of the purpose of the course and its subject matter 
    2. a statement describing the relationship of the course to a discipline, major, research project, placement and/or the program learning outcomes 
    3. a statement to describe any course attributes, such as WIL, weighted average mark (WAM), Capstone, whether the course has travel requirements, or whether the course includes other Industry Partnered Learning (IPL) experiences 
    4. a designated WAM course includes a statement to students that it will contribute to their overall honours mark 
  7. for higher education coursework: the course objectives, learning outcomes, and capability development, which: 
    1. show mapping to the relevant program learning outcomes developed by the course, unless it is a shared course that prevents publication of program-level mapping or if the course is a University Elective 
    2. describe any skills or capabilities embedded to meet professional accreditation requirements
  8. for vocational education: 
    1. the course learning outcomes 
    2. the elements linked to the National Element Code/s and Title/s 
    3. the skills and knowledge required to demonstrate competency in the listed elements 
  9. an overview of learning activities for higher education coursework, including: 
    1. how the learning delivery will be structured, including the blended delivery model applied 
    2. the type of engagement the learning activities will require 
  10. an overview of learning resources including: 
    1. a description of resources provided via the learning management system and a hyperlink for access 
    2. a description of other essential or helpful learning resources, such as the Liaison Librarian information
  11. an overview of assessment for higher education coursework: 
    1. lists each assessment task, the type, weighting and course learning outcomes that link to each task 
    2. is relevant for a course offered across all locations and delivery modes or provides an overview for each modality or location if the assessment tasks will be differentiated 
    3. contextual rationale between locations or modalities when assessment types or weightings are different 
  12. an overview of assessment for vocational education: 
    1. lists the assessable items 
    2. provides a description of competency-based assessment results 
    3. may provide an assessment mapping matrix (optional).


#### Designated WIL Courses 
(58)  Course guides for all WIL courses include in the Course Guide Part A: 
  1. both academic prerequisites and non-academic eligibility requirements (which may include but are not limited to immunisations or vaccination requirements, visas, Working with Children Checks, Police Checks, National Disability Insurance Scheme Worker Screening Check and responsibilities for associated costs), including those aligned to the requirements of professional registration and professional accrediting bodies where applicable 
  2. a description of WIL activities that will be offered as either, or in the combination of, placements, industry engaged projects, blended WIL activities (both online and face-to-face), simulated workplace environments, or other approved WIL activities described in the [Program and Course Work Integrated Learning Procedure](https://policies.rmit.edu.au/document/view.php?id=119).
  3. where applicable, details that stipulate the minimum and maximum range of duration of a WIL Placement as either hours or days 
  4. a WIL-specific statement addressing inclusivity, health, safety and wellbeing, cultural safety, accessibility, equity and adjustments 
  5. advice on the expectation of student preparation prior to the WIL activity, supervision and monitoring during the activity, and reflective practice and debriefing during and following the activity 
  6. a statement confirming who will be assessing the student during the WIL activity (i.e. RMIT staff/qualified workplace supervisor/both) 
  7. a statement which advises if the student, school or a nominated area is responsible for sourcing the WIL placement or activity 
  8. advice on student registration with Global Experiences if WIL activity is overseas 
  9. a statement that WIL agreements, schedules and relevant insurance documentation must be fully approved, and the WIL Preparation module for students and/or WIL Ready Cred for students must be successfully completed by Higher Education students before the WIL activity commences. Vocational education students are not required to complete the WIL preparation module or WIL Ready Cred. 


#### Course Guides Part B
(59)  A Course Guide Part B is published for all higher education coursework course offerings where the Course Guide Part A is required to be published.
  1. This requirement includes all global and onshore partners and third parties, except where prior approval has been sought from the Academic Registrar. 


(60)  A Course Guide Part B is not required for courses in Higher Degree by Research programs. 
(61)  A vocational education program may be exempted from publishing Course Guide Part B by the College Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent or nominee). 
(62)  The Course Coordinator (or equivalent) is responsible for ensuring that the information in the Course Guide Part B is correct and published prior to the commencement of classes. 
(63)  Colleges and campuses may institute their own publication deadlines to fall before the first day of the relevant teaching period. 
(64)  Where a course is offered in flexible terms, the Course Coordinator (or equivalent) can publish a Course Guide Part B at their discretion, as follows: 
  1. one Course Guide Part B that applies to all classes in each flexible term, or 
  2. one Course Guide Part B for each class scheduled in the flexible term. 


(65)  The information provided in the Course Guide Part B must match the information that is provided in the corresponding learning management system shell. 
(66)  The Course Guide Part B provides: 
  1. current hyperlinks to the relevant resources for the cohort on academic integrity, academic progress, appeals, assessment adjustments, award levels, grades, student feedback, and the RMIT students page 
    1. for students studying in Australia, a single hyperlink can be provided to the Student Essentials landing page with a list of relevant topics
  2. accurate course attributes extracted from the student administration system, such as career, campus and learning mode 
    1. these fields are updated in the student administration system if the information extracted from the Course Guides is incorrect. Contact Course and Program Administration (cpa@rmit.edu.au) for further assistance
  3. a description of the primary learning mode, including whether each class type (lecture, tutorial, etc.) will be delivered as face-to-face, online or in a hybrid blend
  4. a description of the anticipated teacher guided and learner directed hours 
  5. principal teacher’s contact information, including name, email, phone and availability 
    1. additional staff contact details must be provided where appropriate 
  6. the weekly teaching schedule and subject matter topics 
  7. any prescribed texts and references 
  8. a detailed description of each assessable item and its due date 
  9. a description of assignment submission procedures 
  10. an RMIT-approved definition of plagiarism, possible consequences, appropriate use of citations and a current link to Library resources 
  11. an RMIT-approved description of the grading system used in the course offering 
  12. information about feedback timelines for assessment tasks 
  13. information about special considerations, extensions, reviews and appeals 
  14. information about academic integrity and misconduct. 


#### Assessment in Course Guides
Note: this section refers to the treatment of assessment items in course guides. For information about assessment policy and process, refer to the [](https://policies.rmit.edu.au/document/view.php?id=7)[Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7) and [Assessment Processes](https://policies.rmit.edu.au/document/view.php?id=38)
(67)  The assessment section of Course Guide Part A states: 
  1. a succinct title and description of the assessment type for each assessment task in the course
  2. the weighting allocated to each assessment task (except in competency-based courses, where assessment tasks are not weighted) 
  3. any other requirements for satisfactory completion of the course or module, including any hurdle requirements 
  4. how the assessment is related to the course learning outcomes. 


(68)  In courses for higher education coursework programs, no assessment task can be weighted at more than 50% of the total mark for the course unless: 
  1. the course is a research component of the program 
  2. the assessment is linked to WIL activities 
  3. the higher weighting is approved as an exception by Programs Committee. Grounds for such exceptions may include pedagogical reasons or external accreditation requirements. 


(69)  Changes to assessment tasks in the course guide after the commencement of the teaching period are approved by the Dean/Head of School/Cluster Director (or equivalent). 
  1. Any such changes are updated in the Course Guides Part A and B. 
  2. Changes are communicated to students as soon as practicable. 
  3. Changes to the assessment type must not introduce any accessibility barriers for students.
  4. Changes to the assessment due date are updated at least five working days prior to the new due date. 


For detailed requirements in relation to arranging an extension of time, the design of assessment, submission of assessment and feedback on assessment see the [](https://policies.rmit.edu.au/document/view.php?id=38)[Assessment Processes](https://policies.rmit.edu.au/document/view.php?id=38).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=203#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this instruction).
Term |  Definition  
---|---  
Placements |  These activities are generally on-site placements in a workplace or community setting, can be onshore, offshore or online, and may be paid or unpaid.  Common terminology for WIL placement activities includes practical placement, practicum, cooperative education, clinical placements, fieldwork, and internship.  
Projects  |  WIL projects are co-designed with industry and/or community partners. Industry engaged projects commonly require teams or individual students to undertake a real project that is based on real problems or addresses the needs of the industry or community. It may include capstone projects, collaborative research projects, multi-disciplinary projects or work-based projects. Industry partners are engaged in the project and provide feedback to students. Industry engaged WIL projects may be paid or unpaid. They may take place on campus, off campus, offshore or online.  
Simulated workplace environments |  WIL activities in simulated workplace environments may be necessary for ethical, safety or professional reasons or when other forms of industry engaged WIL are unavailable. These environments are designed to simulate real workplaces in their function, equipment and mode of operation so that students can experience a variety of scenarios and inter-related activities similar to real work experience in the industry or profession to which the program leads.  This type of WIL can occur face-to-face or online, on campus or off campus, and is usually unpaid.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
