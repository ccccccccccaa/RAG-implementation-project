[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=101&version=4#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=101&version=4#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Honorary Appointments Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=101)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=101&version=4)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=101&version=4)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=101&version=4)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=101&version=4)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=101&version=4)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=101&version=4)


# Honorary Appointments Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=101&version=4#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=101&version=4#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=101&version=4#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=101&version=4#section4)
  * [Employment Relationship](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major1)
  * [Eligibility and Requirements of Appointment](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major2)
  * [Reimbursement of Travel and Living Expenses](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major3)
  * [Specific Employment Assignment for Honorary Appointees](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major4)
  * [Visa Requirements for International Visiting Academics](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major5)
  * [Use of Title](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major6)
  * [Contribution and Duties](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major7)
  * [Obligations](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major8)
  * [Access to University Facilities and Systems](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major9)
  * [Induction](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major10)
  * [Insurance](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major11)
  * [Intellectual Property](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major12)
  * [Conflict of Interest](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major13)
  * [Termination of Appointment](https://policies.rmit.edu.au/document/view.php?id=101&version=4#major14)
  * [Section 5 - Transitional Provisions](https://policies.rmit.edu.au/document/view.php?id=101&version=4#section5)
  * [Section 6 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=101&version=4#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  The purpose of this policy is to detail the principles informing and criteria applying to honorary appointments established under the [Titles Regulations](https://policies.rmit.edu.au/document/view.php?id=197).
(2)  Under the [Titles Regulations](https://policies.rmit.edu.au/document/view.php?id=197), the University may confer titles on persons who are associated with the University in a substantial way, including persons who are not employed or appointed to established or recurrent positions, subject to the relevant policies and procedures.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=4#document-top)
# Section 2 - Overview
(3)  The objectives of this policy are to enable RMIT University to:
  1. ensure the appointment process is fair and equitable throughout the University
  2. provide a targeted response to the strategic directions of the University
  3. broaden the research and teaching base of the University
  4. maximise the academic and industry expertise in the broader community to advance the University’s research, teaching and learning experience
  5. foster honorary appointments that represent the diversity of our students, workforce and community
  6. build and establish its international, interstate and intra-state networks in teaching, research and scholarship
  7. to engage industry practitioners that support practical education and training that is aligned to modern professional and industry needs and connects students and other staff to international industry and professional experience.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=4#document-top)
# Section 3 - Scope
(4)  This policy applies to the honorary appointment process at RMIT.
(5)  This policy does not cover:
  1. current employees on a fixed term or continuing contract
  2. academic staff visiting from other national or international institutions who receive payment for their service and will be sponsored on a Temporary Skill Shortage (482) visa or its subsequent replacement
  3. recipients of Honorary Awards conferred by RMIT University Council including Honorary Degrees, with the exception of University Medals.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=4#document-top)
# Section 4 - Policy
### Employment Relationship
(6)  An honorary appointment does not in itself constitute an employer/employee or independent contractor relationship between the individual and the University.
### Eligibility and Requirements of Appointment
(7)  An individual must meet eligibility requirements as outlined in [Schedule 1](https://policies.rmit.edu.au/download.php?id=358&version=2&associated) before being considered for an honorary appointment and title.
(8)  [Schedule 1](https://policies.rmit.edu.au/download.php?id=358&version=2&associated) of this policy establishes the definition, equivalent academic level and criteria for each honorary title, and the term of appointment and authority for approval.
### Reimbursement of Travel and Living Expenses
(9)  An honorary appointee may receive reimbursement for reasonable travel and living expenses while performing relevant activities for the University by prior agreement with the relevant manager. Reimbursement arrangements must be stipulated in the proposal recommending appointment and, if relevant, be consistent with any immigration requirements.
### Specific Employment Assignment for Honorary Appointees
(10)  Appointment and conferral of an honorary title does not preclude an individual being appointed to a paid position within the University. Any paid work that is outside the scope of the honorary appointment will be subject to a separate agreement.
(11)  Where an honorary appointee becomes employed by the University, the type and level of job title will be based on the criteria applicable to the role.
(12)  Where an honorary appointee becomes employed:
  1. on a fixed-term or continuing basis, the honorary appointment will be suspended for the period of the employment and an extension form will be submitted at the conclusion of the individual’s period of employment to reinstate the original honorary appointment, or
  2. on a casual basis, the honorary appointment may remain in effect.


### Visa Requirements for International Visiting Academics
(13)  International visiting academics that do not have Australian residence rights must obtain an appropriate visa before they enter Australia. 
### Use of Title
(14)  The level of title conferred will be determined on the basis of the contribution expected of the recipient, the criteria applicable to the level of appointment of staff by the University and the nominee’s level of experience and expertise.
(15)  Emeritus is used throughout the policy and on conferring of the award. Emeritus is utilised as a singular, inclusive, non-gendered title. 
(16)  A visiting academic title will normally be awarded for the period of the association or visit. 
(17)  An honorary appointee will use the relevant honorary prefix before the appropriate title in any correspondence or documents during the term of the appointment (e.g Visiting Associate Professor of RMIT University).
(18)  The use of any title covered by this policy is not to be used for private gain or for private purposes not associated with or for the benefit of the University.
### Contribution and Duties
(19)  An honorary appointee may make contributions across colleges or portfolios.
(20)  More than one honorary appointment position may be attached to a school, college or portfolio.
(21)  The precise duties of each honorary appointment will be the subject of negotiation between the individual and the relevant manager or supervisor, who will be responsible for managing the performance of duties of the honorary appointee.
(22)  These duties should be clearly outlined in the proposal recommending appointment, and would normally involve contribution to one or more of the following areas:
  1. learning and teaching
  2. research and scholarship
  3. leadership and engagement.


(23)  Honorary appointees may be asked to do duties which include, but are not limited to:
  1. The identification and/or participation in research collaboration and/or innovative industrial opportunities through joint research programs, grant applications, tenders and/or research projects.
  2. The contribution of ERA-eligible research outputs with a by-line to the University that align with the University’s strategic objectives.
  3. Subject to normal approval processes, external advice or joint supervisory positions for research postgraduate students and/or assessment of senior undergraduate or postgraduate students. 
  4. Contribution to activities associated with developing the University’s external relationships with industry and community.
  5. Representation of the University in professional forums, conferences and public seminars.
  6. Contribution to the profile and reputation of the University through public dissemination of knowledge and intellectual engagement.
  7. Staff and/or student engagement, development or mentoring.


(24)  An honorary appointee will not be a member of any University body, except for co-option.
(25)  For all purposes of courtesy and on ceremonial occasions (including participation in academic processions) all honorary appointees with Professor in their title shall have the rank of professor.
### Obligations
(26)  An honorary appointee is expected to uphold the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), promote the goals and values of RMIT and act with integrity and dhumbali (commitment) to uphold the reputation of RMIT and the RMIT community.
(27)  An honorary appointee is bound to abide by University legislation, policies and procedures whilst undertaking activities relating to their appointment. These include but are not limited to RMIT’s [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91), [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53), [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23) and [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213), including the requirement to have a working with children check 
(28)  Any breach or suspected breach of policy or any conduct which, in the opinion of the University, is likely to bring the University or any of its related entities into disrepute may result in withdrawal of the title and/or relationship.
### Access to University Facilities and Systems
(29)  It is the responsibility of the relevant manager to provide appropriate physical accommodation, equipment and resources, where relevant.
(30)  An honorary appointee is eligible to access an RMIT email address and full academic staff privileges at RMIT University Libraries.
### Induction
(31)  It is the responsibility of the relevant manager to ensure all honorary appointees have completed the RMIT University induction modules and, where relevant, compliance modules as relevant to the duties of the appointment. All honorary appointees with an RMIT email account must complete the [Information governance, privacy and cybersecurity compliance module](https://www.rmit.edu.au/staff/service-connect/careers-management/career-development/learn/compliance-education).
### Insurance
(32)  As this type of appointment does not constitute an employment arrangement, honorary appointees are not covered by the University's workers' compensation insurance by virtue of their honorary appointment .
(33)  An honorary appointee is covered by RMIT’s personal accident, public liability and professional indemnity insurance policies whilst engaged in RMIT approved activities. Any accident or incident involving an honorary appointee should be reported to the relevant manager or supervisor and reported as an incident in the University’s incident and hazard reporting system. 
### Intellectual Property
(34)  Any intellectual property rights in materials created by the honorary appointee whilst working on any University project during the term of appointment will be owned by the University or in accordance with the University’s agreement with an external funding body.
### Conflict of Interest
(35)  An honorary appointee must disclose any actual, perceived or potential conflict of interest to the University, which may arise at any point during the appointment period in accordance with the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91) and related procedure.
### Termination of Appointment
(36)  An honorary appointee may have their appointment terminated by the relevant approving authority, if it is considered that continuation is not in the best interests of the University.
(37)  Termination of honorary appointment prior to their formal end date will be assessed on a case-by-case basis and will be in accordance with the conditions outlined in the letter of appointment. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=4#document-top)
# Section 5 - Transitional Provisions
(38)  From the approval date of this policy all fixed-term honorary appointments will become transitional until their nominated expiration date.
(39)  Vice-Chancellor's Innovation Professor title holders at September 2022 may have their appointment extended under the terms and conditions of the policy and procedure in place at the time of the approval of their original appointment. Appointment extension is available by application only, for one additional term (maximum duration of 6 years).
(40)  Where an honorary appointee’s transitional appointment is due to expire and either (a) the honorary appointee is no longer eligible for the title due to changes to the definition and/or criteria; or (b) the honorary title no longer exists under the policy, a new nomination should be submitted for the most appropriate honorary title. If the nomination process for the new honorary title requires references, these may be waived if there is a break between appointments of less than three (3) months. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=4#document-top)
# Section 6 - Procedures and Resources
(41)  Refer to the following documents which are established in accordance with this policy:
  1. [Honorary Appointments Procedure](https://policies.rmit.edu.au/document/view.php?id=102)
  2. [Schedule 1 – Honorary Appointments](https://policies.rmit.edu.au/download.php?id=358&version=2&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
