[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=135#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=135#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Selection Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=135)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=135)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=135)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=135)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=135)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=135)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=135)


# Selection Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=135#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=135#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=135#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=135#section4)
  * [Selection Accountability](https://policies.rmit.edu.au/document/view.php?id=135#major1)
  * [Impartiality of Selection Decisions](https://policies.rmit.edu.au/document/view.php?id=135#major2)
  * [Selection Methodology](https://policies.rmit.edu.au/document/view.php?id=135#major3)
  * [Equity and Other Admission Schemes](https://policies.rmit.edu.au/document/view.php?id=135#major4)
  * [Ranking and Selection for Competitive Programs](https://policies.rmit.edu.au/document/view.php?id=135#major5)
  * [Internal Applicants](https://policies.rmit.edu.au/document/view.php?id=135#major6)
  * [Selection Tasks](https://policies.rmit.edu.au/document/view.php?id=135#major7)
  * [Offers of Admission](https://policies.rmit.edu.au/document/view.php?id=135#major8)
  * [Errors in Selection](https://policies.rmit.edu.au/document/view.php?id=135#major9)
  * [Review of Selection Decisions](https://policies.rmit.edu.au/document/view.php?id=135#major10)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides the rules for fair and transparent selection methodology that is applied impartially and is designed to support inclusivity and identify applicants that are capable of success at RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=135#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=135#document-top)
# Section 3 - Scope
(3)  This policy applies to all programs and courses offered by the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=135#document-top)
# Section 4 - Procedure
### Selection Accountability
(4)  The following officers are accountable for the selection of applicants:
  1. for coursework programs, the Dean/Head of School/Cluster Director (or equivalent) or nominee
  2. for higher degree by research (HDR) programs, the Associate Deputy Vice-Chancellor Research Training and Development or nominee.


(5)  Applicants must not be pooled (held for competitive selection at a later time where places are limited) unless this has been approved by:
  1. the General Manager – College Operations (or equivalent) for coursework programs
  2. the Associate Deputy Vice-Chancellor Research Training and Development for HDR programs.


### Impartiality of Selection Decisions
(6)  Applicants are selected fairly and in accordance with the formally approved admission standard for the program.
(7)  Staff involved in selection decisions must comply with the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91).
(8)  Staff who suspect there has been or will be a conflict of interest during the selection process must immediately notify the relevant Dean/Head of School/Cluster Director or Director (or equivalent).
  1. If the Dean/Head of School/Cluster Director or Director (or equivalent) is unavailable, or are themselves suspected, the staff member must notify the relevant Deputy Vice-Chancellor.
  2. The recipient of the report must follow the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91).


(9)  Selection requirements only seek relevant information required for assessment. They do not unfairly disadvantage some applicants.
### Selection Methodology
(10)  Colleges/schools/industry clusters must document rigorous and properly approved selection methodology for assessment of applicants’ capacity for success in the program. This may include elements such as:
  1. minimum academic requirements
  2. where relevant, selection tasks and their purpose
  3. details of how equity and other admission schemes are applied
  4. selection methodology for each location and fund source, and
  5. ranking methodology for competitive entry.


(11)  A summary of the program selection methodology must be published to applicants.
(12)  Program entry requirements and selection methodology must be applied consistently to all applicants for a program at each location and for each funding source.
  1. Program entry requirements and selection methodology must not change during an intake.
  2. An adjustment to the entry requirements may be amended where it is advantageous and equitable to all applicants and cohorts within an intake period. 


(13)  In determining whether the applicant satisfies published requirements, the applicant’s entire application, including any equity or access provisions or entrance schemes must be considered.
  1. Only information that is formally required of applicants will be considered.


(14)  Greater weight may be given to an applicant’s most recent and/or relevant previous qualification, study, or experience where provided for in the selection methodology.
(15)  If an applicant does not meet minimum entry requirements but demonstrates they are capable of success in the program, a case for equivalence may be submitted in accordance with the [Admission Procedure](https://policies.rmit.edu.au/document/view.php?id=36).
(16)  The School of Graduate Research (SGR) assesses applications for research programs with input from schools/industry clusters (where relevant) on whether applicants satisfy the relevant program entry requirements. For further information on HDR selection, please refer to the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16). 
### Equity and Other Admission Schemes
(17)  Where applicable to a student’s application, equity and other admissions schemes must be taken into consideration as part of selection, in accordance with the Equity and other Admission Schemes Procedure.
(18)  If an applicant raises issues relating to access and equity that are not resolved by referring to the selection methodology, staff with responsibility for selection may seek advice from Domestic Admissions.
### Selection Process for Indigenous Australians
(19)  Applications from Indigenous Australians are overseen by the Ngarara Willim Centre. Applicants may be assessed through the Indigenous Access Program using a non-competitive and pathways focused approach.
### Ranking and Selection for Competitive Programs
(20)  Where profile is limited for a program, staff may seek approval from their General Manager – College Operations (or equivalent) to pool and rank applications.
(21)  If a program intends to pool international applicants for competitive selection, the impact on selection of those applicants must be considered including delays to visa processing and shorter periods for ELICOS enrolments.
(22)  Selection methodology must include ranking methodology when selection of applicants for a program is competitive.
(23)  If programs select competitively, applicants who are eligible for admission are ranked in order according to the program ranking methodology and offers are made in order from highest to lowest rank until all places are filled.
(24)  Final selection rank must take into consideration all aspects of an application including equity and access provisions, selection tasks and academic results.
(25)  Feedback on an applicant’s performance in ranking for competitive selection must be provided on request and should provide the applicant with sufficient detail to improve their chances of selection in the future.
### Internal Applicants
(26)  Internal applicants must satisfy the same entry requirements as external applicants for the program.
(27)  Internal applicants may be given preference in selection when this is provided for in the selection methodology.
(28)  RMIT students are guaranteed entry into their subsequent program if they achieve the entry requirements as published at the time of their packaged offer.
### Selection Tasks
(29)  Selection tasks are designed to assess an applicant’s capacity to succeed in the program and reflect RMIT’s commitment to equity and inclusion.
(30)  Selection tasks and the selection task assessment methodology are documented and approved by the relevant Dean/Head of School/Cluster Director (equivalent) and the approval documentation is retained in the relevant school/industry cluster/selection area.
(31)  Applicants are given detailed instructions regarding the requirements of the selection task and assessment criteria and how the selection task will be used as part of program selection methodology. Submission dates and timelines for selection tasks are published on relevant webpages and publications.
(32)  The requirement for a selection task is published in program guides and detailed in program summaries and (where applicable) the Victorian Tertiary Admissions Centre (VTAC) website.
(33)  Details of selection tasks are published in program guides and summaries and (where applicable) the VTAC website.
(34)  Assessment of an applicant’s performance in a selection task must be recorded.
(35)  Feedback on an applicant’s performance in a selection task must be provided on request and provide the applicant with sufficient detail to improve their performance in the task in future.
### Offers of Admission
(36)  Selection outcomes may only be decided by:
  1. an employee or contractor of RMIT
  2. an RMIT partner who is expressly authorised to do so by the Academic Registrar, or
  3. VTAC acting on behalf of RMIT.


(37)  Offers can be made on the condition that the applicant provides additional evidence that they meet entry requirements or to satisfy other conditions detailed in the offer.
(38)  RMIT may place a time limit on an offer or conditional offer of admission, after which the offer will lapse.
(39)  Once a student has been offered a place, it will be honoured if the entry requirements change between the offer and the date that the student commences in the program.
(40)  Offers of admission specify the following details of the offered enrolment:
  1. program
  2. attendance mode
  3. the teaching period in which the enrolment will start
  4. whether full time or part time
  5. duration of study (for international applicants)
  6. campus, and
  7. financial or funding related details and where appropriate any deposits to be paid by the applicant.


(41)  All offers of admission are made in writing.
### Errors in Selection
(42)  Where a selection officer learns that an offer has been made in error, the following process is followed and completed within five (5) working days of the error being identified:
  1. The selection officer must immediately inform the college admissions office (for coursework applicants) or the SGR admissions team (for research applicants) that an offer has been made in error.
  2. The college admissions office or SGR admissions team must advise the manager of Domestic Admissions or International Admissions (as relevant) and the Academic Registrar of the circumstances.
  3. The Academic Registrar (or delegate) is authorised to decline to approve withdrawal of the offer if the applicant has enrolled and/or commenced classes or if they are not persuaded that there are grounds to withdraw the offer.


(43)  If the Academic Registrar (or delegate) approves the withdrawal of offer, the applicant will be notified in writing with the reason.
### Review of Selection Decisions
(44)  An unsuccessful applicant seeking a review must submit a request for feedback within 10 working days of the day on which formal notification of the selection decision was sent.
(45)  International applicants who have been denied under the Simplified Student Visa Framework (SSVF) cannot seek a review of this decision. Applicants may make a new application if they meet SSVF requirements.
(46)  The selection officer must provide the applicant with reasons for the decision within five (5) working days of being contacted by the applicant, including information relevant to the application and any selection task that will help the applicant improve a future application.
#### Formal Review
(47)  Where an applicant has sought feedback on their application but remains dissatisfied with the outcome, they may seek a formal review of a selection decision where they can provide evidence that all of the following grounds exist:
  1. the applicant satisfied all relevant entry requirements
  2. the application was lodged on time, in the correct manner, and they provided all the relevant, valid documentation to the university
  3. the applicant has evidence that the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6) was improperly applied, and
  4. the applicant has sought feedback from the selection officer.


(48)  A review application must be submitted within 20 working days from the date the selection decision was sent.
(49)  On receiving a request for review, the relevant college Associate Deputy Vice-Chancellor Learning and Teaching, or delegate, (for coursework applicants) or the Associate Deputy Vice-Chancellor Research Training and Development (for research applicants) will:
  1. arrange an investigation within two working days, and
  2. advise the applicant in writing of the outcome of the review within a further 20 working days.


(50)  A formal review decision is final and cannot be appealed within the University.
(51)  An application for review may be dismissed as without substance, with notification of reasoning provided to the applicant, where they:
  1. did not meet the published admission requirements of the program to which admission was sought, or
  2. fail to produce evidence substantiating the grounds of review detailed in clause (47).


(52)  Where a review against a selection decision is upheld the reviewer must send notice of the outcome to the applicant within 10 working days.
  1. The notice will contain the full decision of the review and state any actions being taken by the University in relation to it.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
