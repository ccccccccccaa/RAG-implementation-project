[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=156&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=156&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Staff Complaints Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=156)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=156&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=156&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=156&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=156&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=156&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=156&version=2)


# Staff Complaints Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=156&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=156&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=156&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=156&version=2#section4)
  * [Application](https://policies.rmit.edu.au/document/view.php?id=156&version=2#major1)
  * [Complaint Resolution Approach](https://policies.rmit.edu.au/document/view.php?id=156&version=2#major2)
  * [Making a Complaint](https://policies.rmit.edu.au/document/view.php?id=156&version=2#major3)
  * [Complaint Assessment](https://policies.rmit.edu.au/document/view.php?id=156&version=2#major4)
  * [Complaint Resolution Outcomes](https://policies.rmit.edu.au/document/view.php?id=156&version=2#major5)
  * [Privacy and Confidentiality](https://policies.rmit.edu.au/document/view.php?id=156&version=2#major6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure details how the RMIT Group will manage staff and staff-related concerns or complaints and how staff can seek resolution of complaints relating to aspects of their engagement with RMIT, consistent with the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=156&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=156&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all staff, including employees (current, former and prospective), and researchers of the RMIT Group. It also applies to volunteers and honorary or visiting affiliates.
(4)  This procedure does not apply to:
  1. staff employed by an RMIT partner
  2. contractors, including agency staff engaged as contingent labour, who must follow the [Third-Party Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=111).


(5)  This procedure cannot be used to appeal or request review of decisions made:
  1. under an enterprise agreement, policy or associated procedure that provides its own appeal, review or complaint mechanism.
  2. by RMIT University Council or Academic Board
  3. by an external organisation.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=156&version=2#document-top)
# Section 4 - Procedure
### Application
(6)  This procedure can be used to address staff complaints where a response or resolution is explicitly or implicitly expected, in relation to:
  1. policies, procedures, decisions and decision-making processes
  2. omissions, systems or quality of service
  3. staff, student or third party behaviour.


(7)  Where another appropriate RMIT procedure or process exists, that policy document may be followed as an alternative. This includes an RMIT policy document used to:
  1. address staff conduct, staff underperformance and breaches of specific RMIT policy and conditions of employment
  2. make whistleblower complaints and public interest disclosures.


(8)  Where matters are being addressed under more than one policy document, RMIT must organise a fair and sensible order for events to proceed. Other policy documents which might overlap with this procedure include, but are not limited to:
  1. a complaint or report being managed by an RMIT student, or third party conduct/complaint procedure
  2. a complaint or report being managed by an external agency.


### Complaint Resolution Approach
(9)  Complaint management will be aligned to the principles of the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110).
(10)  Expectations include but are not limited to, providing complainants and respondents with:
  1. updates on progress and reasons for any lengthy delays
  2. relevant details and time to respond to any questions
  3. a written resolution if requested by a complainant or respondent, including: 
    1. an explanation of and reasons for the resolution
    2. details of any policy/information/evidence relied upon
  4. information about the appropriate appeal or review process at the conclusion of the matter
  5. advice that under certain circumstances RMIT may continue to pursue the matter even if the complaint is withdrawn.


(11)  Where a complainant displays unreasonable conduct (as defined in the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110)), the Chief People Officer or delegate may restrict access to complaint management services. This may include a decision by People to close the complaint and decline any further response.
### Making a Complaint
(12)  The Chief People Officer or delegate provides resources on how to make a complaint and to advise parties to a complaint of their rights and expectations in the management of the complaint.
(13)  Avenues for raising a concern or complaint include but are not limited to the RMIT [Complaints Portal](https://policies.rmit.edu.au/download.php?id=121&version=1&associated).
(14)  Anonymous complaints can be made however they may limit the ability for the People team to effectively manage the complaint. Where possible, this will be clearly communicated to the complainant.
### Complaint Assessment
(15)  On receipt, submissions will be referred to and assessed by People to determine the most appropriate resolution process or procedure to be applied. Some complaints will be addressed by People and others will be referred to the relevant organisational area for consideration and response.
(16)  When considering how to manage the complaint, the assigned case manager may be required to:
  1. seek clarification or request further information to assess the nature of the complaint
  2. identify parties involved in a complaint and seek further information
  3. liaise and discuss with the Manager, Central Complaints and Investigations.


(17)  The case manager will resolve the complaint following a procedurally fair process.
(18)  Where a decision is taken to deal with the complaint using an alternative RMIT procedure or process in accordance with clause (7) the complainant will be informed and referred to the relevant person who will assist them.
  1. It is recommended that complaints regarding conduct that are described or perceived as misconduct are managed under alternative policy document(s).


### Complaint Resolution Outcomes
(19)  Resolutions imposed or introduced as an outcome of this procedure include a wide variety on non-disciplinary actions including but not limited to explanation, apology, correction, training, counselling, coaching, and a review of practice.
(20)  People will not reopen a matter that is closed unless new information is presented that the Chief People Officer or delegate considers to be material to the outcome.
(21)  People may report on any systemic issues or organisation failures to inform reporting and improvement activities. In these circumstances, information will be de-identified to protect the privacy of parties to a complaint.
### Privacy and Confidentiality
(22)  The outcome of a complaint can be shared by RMIT with all parties to a complaint and with others who may need to be informed as part of their role, but any disclosure must be balanced against preserving the privacy of others consistent with the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110) and [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(23)  All parties involved in a complaint managed under this procedure must treat the details, their involvement, the names of other associated parties and all reports, findings, recommendations and actions as confidential unless informed otherwise by People.
(24)  Limitations apply to privacy and confidentiality:
  1. where risks to health and safety are present, 
  2. in matters involving persons under 18 years of age, or
  3. in circumstances where information is otherwise permitted or required to be shared by law.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
