[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=186&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=186&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Controlled Entity Guideline 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=186)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=186&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=186&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=186&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=186&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=186&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=186&version=2)


# Controlled Entity Guideline
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=186&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=186&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=186&version=2#section3)
  * [Section 4 - Guideline ](https://policies.rmit.edu.au/document/view.php?id=186&version=2#section4)
  * [Administration](https://policies.rmit.edu.au/document/view.php?id=186&version=2#major1)
  * [Roles and Responsibilities](https://policies.rmit.edu.au/document/view.php?id=186&version=2#major2)
  * [Record Keeping Requirements](https://policies.rmit.edu.au/document/view.php?id=186&version=2#major3)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  These Guidelines outline the roles and responsibilities of certain roles at the University for the administration of Controlled Entities and should be read in conjunction with the [Controlled and Non-Controlled Entities Policy](https://policies.rmit.edu.au/document/view.php?id=184) and [Controlled and Non-Controlled Entities Procedures](https://policies.rmit.edu.au/document/view.php?id=185).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=186&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Controlled and Non-Controlled Entity Procedure](https://policies.rmit.edu.au/document/view.php?id=185).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=186&version=2#document-top)
# Section 3 - Scope
(3)  These Guidelines are for those involved in the management, conduct or administration of an RMIT Controlled Entity.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=186&version=2#document-top)
# Section 4 - Guideline 
### Administration
(4)  Each Controlled Entity has a Board of Directors (Board) who have been approved by the RMIT University Council (Council). Subject to any requirement under local laws for Controlled Entities registered outside Australia, a Board of a Controlled Entity must have at least three and no more than seven directors, with a Chair approved by the VC.
(5)  Each Controlled Entity has a Chair nominated by the Vice-Chancellor (VC).
(6)  The VC may nominate a Management Committee.
(7)  The Executive Director, Governance, Legal and Strategic Operations is the nominated Company Secretary for each Controlled Entity, subject to any requirement under local laws for Controlled Entities registered outside Australia.
### Roles and Responsibilities
(8)  The Board is responsible for:
  1. discharging their duties as directors
  2. ensuring policies and procedures are in place to govern disclosures of interests and management of conflicts of interest
  3. creating the annual business plan and annual budget
  4. ensuring all adequate controls, accountability and reporting structures are in place and that University policies and procedures, regulatory and legal requirements are complied with by Management and the Controlled Entity
  5. reporting to Council, the VC and/or VCE as required, including providing: 
    1. annual attestation
    2. annual reports on business performance
    3. audit and risk reports
    4. annual statement of governance principles
    5. notification (immediate) of any regulatory notification or representation from a government or statutory authority or threatened or instigated legal action against the Controlled Entity.


(9)  The University Secretariat, or Executive Officer nominated by the Controlled Entity, administers corporate secretarial documents for Controlled Entities. This includes:
  1. providing training and induction for new directors
  2. circulating agendas for meetings of the Board, including any annual general meetings
  3. taking minutes at Board Meetings
  4. drafting Board resolutions
  5. maintaining company registers
  6. lodging annual statements and all other required documents with ASIC
  7. retaining all company records
  8. providing templates and document administration for documents submitted to Council.


(10)  The Deputy CFO Central Finance Operations administers financial compliance for Controlled Entities. This includes:
  1. being the contact person for the Victorian Auditor General’s Office (VAGO)
  2. preparing the annual financial statements for sign off by Council
  3. provide guidance on the applicability of the relevant accounting standards and departmental requirements


(11)  The Director, Risk Management administers risk assessments and internal audit activities in relation to Controlled Entities. This includes:
  1. conducting all internal audit activities as required by Council from time to time;
  2. seeking assurance on risk matters on behalf of the VC or Council;
  3. overseeing the conduct of risk assessments in relation to the activities of Controlled Entities.


(12)  The Chief Executive Officer (or equivalent) is responsible for the administration of the Management Committee of a Controlled Entity. This includes:
  1. providing all required reports to the VC when required
  2. preparing management accounts and reports for consideration by the VC and the Board as required
  3. ensuring the Management Committee operates the business of the Controlled Entity in compliance with all laws and regulations and policies of the University.


### Record Keeping Requirements
(13)  The Chief Executive Officer of the Controlled Entity will ensure that records are maintained in accordance with University policy.
(14)  The University Secretariat will maintain all company secretarial documents, Council records relating to the Controlled Entity, minutes and company registers of the Controlled Entity.
(15)  The Chief Financial Officer will maintain all financial information of the Controlled Entity in accordance with University policies.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
