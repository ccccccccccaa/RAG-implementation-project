[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=129&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=129&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Credit Agreements and Credit Arrangements Guideline 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=129)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=129&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=129&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=129&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=129&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=129&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=129&version=1)


# Credit Agreements and Credit Arrangements Guideline
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=129&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=129&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=129&version=1#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=129&version=1#section4)
  * [Credit Agreements and Credit Arrangements](https://policies.rmit.edu.au/document/view.php?id=129&version=1#major1)
  * [Maximum Advanced Standing for Previous RMIT Study ](https://policies.rmit.edu.au/document/view.php?id=129&version=1#major2)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This schedule provides guidance on the amount of advanced standing that can be granted into RMIT programs when negotiating credit agreements or assessing possible credit arrangements. 
(2)  A credit agreement is a formal agreement between organisational components of the RMIT Group or between RMIT and another tertiary institution or industry partner by which eligible students are granted defined amounts of advanced standing towards an RMIT program.
(3)  A credit arrangement is an approved assessment of an RMIT program or another tertiary institution's program by which graduates of the program are granted defined amounts of advanced standing towards an RMIT program. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=129&version=1#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=129&version=1#document-top)
# Section 3 - Scope
(5)  This document applies to all staff involved in the management and assessment of credit. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=129&version=1#document-top)
# Section 4 - Guideline
### Credit Agreements and Credit Arrangements
(6)  The following officers or committees may approve credit agreements made within the RMIT Group, between RMIT University and another Australian or international tertiary institution: 
  1. for credit agreements for coursework programs, the relevant Deputy Vice-Chancellor(s) or nominee(s) 
  2. for credit agreements for higher degree by research programs, the Research Committee
  3. for credit agreements between RMIT University and a tertiary institution outside Australia, the Deputy Vice-Chancellor Global Development. 


(7)  When negotiating credit agreements with other institutions or assessing possible credit arrangements the University will seek to maximise the credit available to students. 
(8)  When negotiating credit agreements towards higher level AQF qualifications with other institutions, or assessing possible credit arrangements, the University will use the following AQF recommendations as a guide for credit towards qualifications in the same or a related discipline: 
  1. 50% (144 credit points) credit towards a three-year bachelor degree for an advanced diploma or associate degree
  2. 37.5% (144 credit points) credit towards a four-year bachelor degree for an advanced diploma or associate degree
  3. 33% (96 credit points) credit towards a three-year bachelor degree for a diploma
  4. 25% (96 credit points) credit towards a four-year bachelor degree for a diploma. 


### Maximum Advanced Standing for Previous RMIT Study 
(9)  Clauses (10) to (12) of this document detail the maximum amounts of advanced standing for previous RMIT study that can be granted under a credit agreement or credit arrangement. 
(10)  The maximum amount of advanced standing that will be granted to RMIT vocational education graduates who are admitted to an RMIT higher education program in the same area of study is as follows: 
  1. 75% credit (144 credit points) for an advanced diploma towards a two-year associate degree
  2. 50% credit (144 credit points) for an advanced diploma towards a three-year bachelor degree
  3. 37.5% credit (144 credit points) for an advanced diploma towards a four-year bachelor degree or four-year bachelor honours degree 
  4. 50% credit (96 credit points) for a diploma towards a two-year associate degree
  5. 33% credit (96 credit points) for a diploma towards a three-year bachelor degree
  6. 25% credit (96 credit points) for a diploma towards a four-year bachelor degree. 


(11)  The maximum amounts of advanced standing detailed in clause (10) will be granted regardless of the duration (volume of learning) of the lower program. 
(12)  The maximum amount of advanced standing will be granted to students who complete a two-year RMIT associate degree or a two-year RMIT advanced diploma and are then admitted to a bachelor degree in the same area of study. The credit arrangements are as follows: 
  1. 66% credit (192 credit points) for an associate degree towards a three-year bachelor degree 
  2. 50% credit (192 credit points) for an associate degree towards a four-year bachelor degree or four-year bachelor honours degree
  3. 66% credit (192 credit points) for a two-year advanced diploma towards a three-year bachelor degree
  4. 50% credit (192 credit points) for a two-year advanced diploma towards a four-year bachelor degree or four-year bachelor honours degree. 


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
