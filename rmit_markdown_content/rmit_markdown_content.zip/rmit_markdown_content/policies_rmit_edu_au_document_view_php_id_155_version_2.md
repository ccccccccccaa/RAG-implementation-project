[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=155&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=155&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Employee Probation Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=155)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=155&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=155&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=155&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=155&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=155&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=155&version=2)


# Employee Probation Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=155&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=155&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=155&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=155&version=2#section4)
  * [Probation](https://policies.rmit.edu.au/document/view.php?id=155&version=2#major1)
  * [Commencing Probation](https://policies.rmit.edu.au/document/view.php?id=155&version=2#major2)
  * [Extension of Probation](https://policies.rmit.edu.au/document/view.php?id=155&version=2#major3)
  * [Performance Concerns During Probation](https://policies.rmit.edu.au/document/view.php?id=155&version=2#major4)
  * [Probation Review and Outcome](https://policies.rmit.edu.au/document/view.php?id=155&version=2#major5)
  * [Confirmation of Appointment](https://policies.rmit.edu.au/document/view.php?id=155&version=2#major6)
  * [Non-Confirmation of Appointment](https://policies.rmit.edu.au/document/view.php?id=155&version=2#major7)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=155&version=2#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  The probation period is a formal period of review for an employee when they are first engaged at RMIT.
(2)  The probation period gives RMIT an opportunity to review an employee’s suitability and effectiveness in their position. It also provides the employee time to consider if RMIT and the position meets their expectations.
(3)  This procedure sets rules and outlines information and support available to managers and employees regarding the probationary process.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=155&version=2#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Employee Lifecycle Policy](https://policies.rmit.edu.au/document/view.php?id=123).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=155&version=2#document-top)
# Section 3 - Scope
(5)  This procedure applies to all RMIT University employees.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=155&version=2#document-top)
# Section 4 - Procedure
### Probation
(6)  All new employees at RMIT University are subject to a probationary period in accordance with their relevant enterprise agreement or employment contract terms and conditions.
(7)  A probationary period is designed to establish whether there is an appropriate match between the individual, the position, and the work environment. This period provides the opportunity to address any issues, including role clarity or performance concerns early.
(8)  Where the people manager is satisfied that the employee is able to apply the skills, competencies, experience and behaviours required for the position and environment and the employee is satisfied with the arrangement, the employee successfully completes probation.
(9)  Probation can only be waived in exceptional circumstances and must be approved in accordance with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).
(10)  Existing continuing employees entering into a secondment or new contract of employment are not required to serve an additional probation period.
(11)  People managers are expected to provide guidance to employees as part of the induction process.
### Commencing Probation
(12)  Commencing probation periods are determined by appointment type in accordance with Table 1: Commencing Probation Durations, unless the relevant enterprise agreement requires otherwise.
#### Table 1: Commencing Probation Durations
Appointment type |  Commencing Probation period  
---|---  
Continuing • VE teaching employees • Professional employees • Children’s Services employees • Senior, Specialist and Executive Employees (SSEE), and • Senior Executive employees. |  6 months  
Continuing • Academic employees |  A minimum of 12 months and a maximum of 3 years  
Fixed term • VE teaching employees • Professional staff • Children’s Services employees • Senior, Specialist and Executive Employees (SSEE), and • Senior Executive employees |  50% of the duration of the contract with a minimum of 3 months and a maximum of 6 months  
Fixed term • Academic employees |  50% of the duration of the contract with a minimum of 6 months and a maximum of 3 years.  
### Extension of Probation
(13)  During probation, the probation period may be extended for any employee to a maximum of 12 months. Employees who have commencing probation periods longer than 12 months cannot have their probation periods extended.
(14)  A decision to extend probation can only be made once the people manager has consulted with the People team (People) and has the support of their manager.
### Performance Concerns During Probation
(15)  People managers are expected to bring incidents of unsatisfactory performance/conduct to the attention of the employee immediately and address any concerns with the employee in a professional and confidential manner.
(16)  Employees must be given an opportunity to improve/correct behaviour in a reasonable timeframe and with support.
(17)  People managers must ensure they keep file notes from meetings when discussing performance or conduct issues.
(18)  When discussing performance or conduct issues with employees, people managers are required to make clear:
  1. the behaviour and standards which are required
  2. how the employee is failing to meet those expectations
  3. timelines in which to improve and dates of follow up meetings
  4. any steps or actions intended to address the issue
  5. what support is required for the employee to meet the expectations of the role
  6. summary of any factors the employee wishes to take into consideration
  7. that the issue might lead to non-confirmation of employment if reasonable improvement is not achieved within the timelines (where relevant).


(19)  In serious cases, immediate non-confirmation of employment may be required.
### Probation Review and Outcome
(20)  People managers will be notified of upcoming probation end dates.
(21)  At the end of the probationary period the manager must decide if:
  1. the employee’s appointment is confirmed, or
  2. the employee’s employment is not confirmed.


### Confirmation of Appointment
(22)  Once the probation date has passed, the employee’s employment is automatically confirmed.
(23)  It is possible for the probation period to be completed prior to the period identified in the employee’s contract if the employee demonstrates competency in their position prior to the end of probation.
(24)  For employment to be confirmed the employee must demonstrate:
  1. behaviour consistent with the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52)
  2. adherence to the relevant enterprise agreement, policies and procedures
  3. willingness and capacity to achieve requirements within the position
  4. performance to the satisfaction of the people manager.


### Non-Confirmation of Appointment
(25)  At any time during probation, either party may bring employment to an end in accordance with their contract and the relevant enterprise agreement.
(26)  If a people manager is considering non-confirmation, they must have the support of their manager and as well as People to determine how to progress this most effectively.
(27)  A decision to not confirm employment will not be supported unless there is reasonable documentary evidence of the manager having had discussions with the employee regarding deficiencies in performance/behaviours and an opportunity for the employee to take corrective action.
(28)  If the people manager recommends a non-confirmation of appointment before the end of the employee’s probation period, the manager must notify People of this as soon as possible. People will liaise with the manager to ensure that all requirements of the relevant enterprise agreement and/or contract terms and conditions are met.
(29)  In line with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51), the employee’s employment may be terminated during or at the end of their probation period. The manager will notify the employee of non-confirmation of employment, with support from People.
(30)  Nothing in this procedure precludes an employee from being dismissed or summarily dismissed for misconduct or serious misconduct.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=155&version=2#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
People manager | The person who is responsible for managing the performance of an employee. This will be the immediate line manager, unless the University nominates an alternative manager. Where an employee has two or more managers, one should be nominated as the performance manager.  
---|---  
Performance and Career Plan | An online Performance and Career Plan tool supports employees to manage the performance development cycle in a timely and consistent way. It is the ongoing process of setting goals, reviewing performance, providing feedback together with coaching. Plans are established by both the manager and employee as part of the annual performance review process which records annual work goals, career aspirations and development goals for the employee’s year ahead; and the specific targets and progress towards achieving those goals. The Performance and Career Plan forms the basis for performance conversations at any stage of the annual performance development cycle including formal ongoing discussions and end-of-year reviews.  
Relevant Senior Officer | The Vice-Chancellor, or member of the Vice-Chancellor's Executive, or their delegate.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
