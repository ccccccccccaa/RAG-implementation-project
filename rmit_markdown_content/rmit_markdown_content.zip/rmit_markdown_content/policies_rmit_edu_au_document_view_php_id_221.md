[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=221#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=221#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Procurement and Expenditure Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=221)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=221)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=221)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=221)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=221)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=221)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=221)


# Procurement and Expenditure Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=221#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=221#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=221#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=221#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=221#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=221#major2)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=221#major3)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=221#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=221#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The purpose of this policy is to:
  1. set out the principles which govern RMIT’s third-party expenditure and commitments in relation to acquiring goods or services
  2. support policies and procedures on [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51) and asset management
  3. ensure RMIT’s expenditure and commitments deliver best value for money outcomes with acceptable risk profiles
  4. ensure all procurement and expenditure activities support RMIT’s strategic objectives, comply with legislative and regulatory requirements, and include consideration of quality, service, environmental and social impacts.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=221#document-top)
# Section 2 - Overview
(2)  This policy outlines the legislation, regulations and policies that RMIT must comply with in its procurement and expenditure activities, the principles RMIT commits to and the responsibilities of the Procurement team and other staff when purchasing goods or services for RMIT. It also covers how non-compliance with the policy is managed.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=221#document-top)
# Section 3 - Scope
(3)  This policy applies to the RMIT Group, which includes RMIT University and its controlled entities.
(4)  This policy applies to all third party expenditure and commitments by RMIT Group entities to acquire goods or services, and to the disposal of RMIT assets by RMIT Group employees, contractors and consultants.
(5)  The following activities are excluded from the scope of this policy:
  1. RMIT University Student Union expenditure
  2. RMIT financial investments
  3. the engagement of barristers by the Legal Services Group
  4. the acquisition, disposal or management of works of art
  5. purchasing, leasing, disposal, sale and any other dealing in relation to RMIT real estate.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=221#document-top)
# Section 4 - Policy
### Principles
(6)  RMIT’s expenditure on third party goods or services is subject to:
  1. Australian Commonwealth laws, including the [Modern Slavery Act 2018](https://policies.rmit.edu.au/directory/summary.php?legislation=40) (Cth)
  2. Victorian State laws, including the [Financial Management Act 1994](https://policies.rmit.edu.au/directory/summary.php?legislation=7) (Vic)
  3. Other legal requirements, as applicable to the nature of the goods or services, or the relevant country or jurisdiction of supply or delivery.


(7)  RMIT Group procurement and expenditure activities:
  1. support RMIT’s strategic objectives and organisational needs
  2. are conducted to ensure probity in its procurement and expenditure activities reflect: 
    1. honesty, equity and fairness in the treatment of suppliers
    2. integrity, and consistency, making objective, justifiable and auditable decisions demonstrating impartiality and the consideration of all relevant criteria
    3. transparency, and confidentiality for proprietary or confidential information (where appropriate), and respect for intellectual property rights
  3. be conducted with an appropriate market approach that promotes open and fair competition in all dealings
  4. seek to achieve value for money outcomes in expenditure activities which support RMIT’s commercial objectives.


(8)  RMIT is committed to the triple bottom line approach regarding environmental, social and financial sustainability. All procurement decisions will take account of RMIT’s responsibilities and obligations regarding:
  1. diversity, inclusion and accessibility
  2. labour and human rights principles, including the risk of modern slavery in supply chains
  3. social and environmental sustainability
  4. supporting the business and entrepreneurial endeavours of Aboriginal and Torres Strait Islanders
  5. data privacy and data security
  6. corporate governance and ethical business practices
  7. document and records retention
  8. wellbeing, health and safety of all RMIT employees, contractors, consultants and students.


(9)  Any actual, perceived or potential conflict of interest in procurement activities must be disclosed and managed in accordance with the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91) and RMIT Supplier Code of Conduct.
(10)  Approvals for procurement activities must be sought and provided in accordance with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).
(11)  Where an RMIT staff member receives gifts, hospitality or any other benefits from third parties, including current or prospective suppliers, the University’s [Gifts, Benefits and Hospitality Policy](https://policies.rmit.edu.au/document/view.php?id=96) applies, which may require the gifts or benefits to be declined or otherwise declared.
(12)  For the purposes of complying with the thresholds established through the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51) and this policy, the disposal of an RMIT asset is to be assessed as if it were an expenditure of money. 
### Responsibilities
(13)  The RMIT Procurement team is responsible for:
  1. ensuring suppliers are registered in accordance with RMIT’s Corporate Social Responsibility requirements
  2. providing governance and process oversight of expenditure, including reporting non-compliance with policy and process for the RMIT Group
  3. providing easy to use clear and compliant processes that enable expenditure activities in accordance with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51)
  4. leading the sourcing activities for high-value and high-risk expenditure to ensure process governance, risk-appropriate commercial decision making, and the best value for money outcomes
  5. RMIT’s category and vendor management, through developing and implementing strategies that deliver significant value, including the management of key supplier relationships.


(14)  All RMIT staff are responsible for:
  1. complying with the requirements for quotations, payment methods and engagement of the Procurement team, as set out in Procurement Schedule 1 – Purchasing Threshold (Australia and Vietnam)
  2. using preferred suppliers and panels, in accordance with the panel rules, as established by the RMIT Procurement team
  3. proactively assessing the need for a proposed expenditure, and its likely value and risk profile
  4. referring high-value or high-risk expenditure to the RMIT Procurement team in a timely manner, to enable RMIT to achieve appropriate value for money outcomes
  5. where an expenditure activity does not require the engagement of the Procurement team, obtaining the required number of quotations, and seeking a value for money outcome
  6. creating an approved purchase order in Workday prior to committing to the expenditure with the supplier.


### Compliance
(15)  An RMIT staff member may obtain approval, in accordance with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51), to:
  1. use a supplier which is not an approved or preferred supplier or a panel of approved suppliers for a particular activity or supply
  2. obtain a lower number of quotations than as required under [Procurement Schedule 1 – Purchasing Threshold (Australia and Vietnam)](https://policies.rmit.edu.au/document/view.php?id=223)
  3. use a sole supplier
  4. extend or vary an existing agreement with a current supplier without conducting a separate quotation or tender process where one or more of the following criteria applies: 
    1. the approved supplier or panel of approved suppliers cannot supply the goods or services required;
    2. demonstrated unique technical requirements with only one sole supplier in the market (e.g. a unique service or product which is not-substitutable)
    3. time-critical events that have been caused by unforeseen circumstances
    4. other exceptional circumstances based on business necessity as determined by the Chief Officer Procurement or the Chief Operating Officer.


(16)  This policy applies to procurement and expenditure activities that use research funding to purchase goods or services. Stakeholders who purchase goods or services on behalf of RMIT using research funding must be aware that:
  1. approval of a funding submission by an RMIT staff member is not a sufficient approval or waiver for the purposes of this policy, and
  2. obtaining quotes for a research funding application may not be sufficient to meet the requirements of this policy or its corresponding procedures if the funding application is successful.


(17)  Where the RMIT Procurement team is leading a Strategic Sourcing event, a Procurement Control Group (PCG) will be established to provide oversight of procurement reporting, performance and policy compliance. It is the responsibility of the PCG to endorse and approve sourcing recommendations and decisions in accordance with the Procurement Plan.
(18)  RMIT treats any breach of policies or procedures seriously. Instances of non-compliance with this policy must be reported in accordance with the Compliance Management Policy and may lead to disciplinary action.
(19)  RMIT does not tolerate fraud or corruption. The [Anti-Corruption and Fraud Prevention Policy](https://policies.rmit.edu.au/document/view.php?id=47) sets out RMIT’s approach to preventing and dealing with fraud and corruption. Any potential breach of this policy must be reported to the relevant body or role, as detailed in the Escalation guide: Regulatory, Legal, Conduct, Safety and Security Matters. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=221#document-top)
# Section 5 - Procedures and Resources
(20)  Refer to the following documents which are established in accordance with this policy for RMIT Australia:
  1. [Procurement Schedule 1 - Purchasing Threshold (Australia and Vietnam)](https://policies.rmit.edu.au/document/view.php?id=223)
  2. [Procurement Strategic Sourcing Procedure (Australia)](https://policies.rmit.edu.au/document/view.php?id=224)
  3. [Procurement Quotation Procedure (Australia)](https://policies.rmit.edu.au/document/view.php?id=222)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=221#document-top)
# Section 6 - Definitions
High-risk expenditure | Where the business impact of the acquisition is identified as high or critical risk when assessed using the RMIT Risk Exposure Tool  
---|---  
Preferred supplier | A supplier contracted or identified by Procurement to provide defined goods or services to RMIT.  
Probity | Evidence that processes have adhered to standards of integrity, transparency and honesty.  
Strategic sourcing | The process through which RMIT Procurement engages the supply market to source goods or services for RMIT.  
Third-party expenditure | Any expenditure for acquiring goods or services from a third party (i.e. not from within RMIT).  
Value for money outcome | The optimal outcome considering the acquisition cost, operating cost, disposal cost, quality of goods or services, quality of associated services, and RMIT’s objectives over the useful life of the goods or service.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
