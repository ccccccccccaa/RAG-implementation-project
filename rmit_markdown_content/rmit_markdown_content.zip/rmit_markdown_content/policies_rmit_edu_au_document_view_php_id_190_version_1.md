[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=190&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=190&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Assessment, Academic Progress and Appeals Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=190)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=190&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=190&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=190&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=190&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=190&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=190&version=1)


# Assessment, Academic Progress and Appeals Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=190&version=1#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor2)
  * [Part B - ASSESSMENT AND ACADEMIC PROGRESS](https://policies.rmit.edu.au/document/view.php?id=190&version=1#part2)
  * [3. Coursework](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor3)
  * [4. Research](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor4)
  * [5. Schedule of Grades](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor5)
  * [Part C - COLLEGE APPEALS COMMITTEE](https://policies.rmit.edu.au/document/view.php?id=190&version=1#part3)
  * [6. College Appeals Committee](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor6)
  * [7. Membership](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor7)
  * [8. Eligibility and Appealable Decisions](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor8)
  * [9. Hearing of the College Appeals Committee](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor9)
  * [10. After the Hearing](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor10)
  * [Part D - UNIVERSITY APPEALS COMMITTEE](https://policies.rmit.edu.au/document/view.php?id=190&version=1#part4)
  * [11. University Appeals Committee](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor11)
  * [12. Membership](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor12)
  * [13. Eligibility and appealable decisions](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor13)
  * [14. Hearing of the Committee](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor14)
  * [15. After the Hearing](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor15)
  * [Part E - MISCELLANEOUS](https://policies.rmit.edu.au/document/view.php?id=190&version=1#part5)
  * [Division 1 – Address for Notice](https://policies.rmit.edu.au/document/view.php?id=190&version=1#major1)
  * [16. Address for Notice](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor16)
  * [17. Regulation of Proceedings](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor17)
  * [Division 2 – Transitional Provisions](https://policies.rmit.edu.au/document/view.php?id=190&version=1#major2)
  * [18. Regulation of Proceedings](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor18)
  * [Division 3 – Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=190&version=1#major3)
  * [19. Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=190&version=1#minor19)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to :
  1. make provision for assessment and appeals relating to academic and student affairs
  2. provide for monitoring and management of students’ academic progress
  3. establish College Appeals Committees, and
  4. establish the University Appeals Committee.


#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
## Part B - ASSESSMENT AND ACADEMIC PROGRESS
#### 3. Coursework
(3)  Every course includes assessment.
(4)  The assessment is in such written, oral, electronic or practical form or forms as the relevant college or the School of Graduate Research prescribes.
(5)  For each course the college or the School of Graduate Research makes available to students, course guides that provide information on assessment as prescribed in the relevant policies and procedures.
(6)  Where a student provides evidence that:
  1. they were, or will be, prevented from attending or completing any form of assessment by the prescribed time, or
  2. their performance in any form of assessment has been severely affected by illness or other cause,


the student may apply through the relevant application process to the Academic Registrar for an assessment adjustment in accordance with the relevant policies and procedures.
(7)  Each school establishes:
  1. course assessment committees, which are responsible for monitoring and managing the assessment and results outcomes for individual courses managed by the school, and
  2. program assessment boards, which are responsible for monitoring and managing coursework student academic performance at the program level, including making recommendations to the dean/head of school for the exclusion of students who have had sustained unsatisfactory academic progress.


(8)  A student may appeal against a decision made:
  1. under clause (7)a. to the relevant College Appeals Committee in accordance with Part C of these Regulations, and
  2. under clause (6) or (7)b. to the University Appeals Committee in accordance with Part D of these Regulations.


#### 4. Research
(9)  The research component of higher degree by research programs is assessed via external, independent examination.
(10)  The research component is in such written, oral or practical form or forms as the School of Graduate Research prescribes.
(11)  Where, due to compassionate or compelling circumstances, a student provides evidence that they will be prevented from attending or completing any presentation relating to their research examination, the student may apply in writing to the Higher Degree by Research Coordinator in their school for a postponement of the presentation.
(12)  Each school establishes research candidature milestone review panels which are responsible for monitoring and managing the research thesis/project progress of the student towards their timely completion of the degree.
(13)  The progress of research students is also formally monitored and documented at the regular meetings students have with their supervisors.
(14)  Each college establishes research candidate progress committees that will be responsible for monitoring and managing student performance in the program, including deciding whether a student’s candidature should be terminated where the student is classified as having established unacceptable academic progress.
(15)  A student may appeal against a decision made:
  1. under clause (12) to the RMIT Research Committee in accordance with the relevant policies and procedures, and
  2. under clause (14) to the University Appeals Committee in accordance with Part D of these Regulations.


#### 5. Schedule of Grades
(16)  The Academic Board determines a schedule of grades.
## Part C - COLLEGE APPEALS COMMITTEE
#### 6. College Appeals Committee
(17)  In each college there is a College Appeals Committee.
#### 7. Membership
(18)  Membership of the College Appeals Committee comprises:
  1. the Deputy Vice-Chancellor and Vice-President (or nominee) of the college
  2. one member appointed by the College Board from the academic staff, and
  3. one member who is an enrolled student nominated by the relevant recognised RMIT student organisation.


(19)  The chair of the College Appeals Committee is the Deputy Vice-Chancellor (or nominee) of the college.
(20)  The secretary is the College senior administrative/academic officer (or nominee) and is non-voting.
(21)  Wherever possible membership of the College Appeals Committee will represent gender equality.
(22)  A person will not be appointed a member of the College Appeals Committee or be permitted to carry out the responsibilities of clause (25):
  1. who has had any involvement in the matter forming the subject of the appeal, or
  2. where, for any other reason it would be inappropriate for the person to be a member to hear the appeal.


(23)  A quorum of the College Appeals Committee is the chair and one (1) voting member.
#### 8. Eligibility and Appealable Decisions
(24)  Subject to satisfying any eligibility criteria described in the relevant policies or procedures, a student may appeal to the relevant Deputy Vice-Chancellor to request a hearing of the College Appeals Committee against:
  1. the student’s final result in any course delivered by the college, and/or
  2. the outcome of an application for credit.


(25)  The Deputy Vice-Chancellor (or nominee) will decide whether the application satisfies the grounds of appeal as defined in the relevant policies or procedures to determine whether the appeal can proceed to a hearing.
(26)  Where eligibility criteria are deemed:
  1. to have been met, the Deputy Vice-Chancellor (or nominee) will approve the request and arrange for a hearing of the College Appeals Committee,
  2. not to have been met, the Deputy Vice-Chancellor (or nominee) will deny the request and advise the student accordingly, including the reasons for the determination. This communication must be sent within twenty (20) working days from the date the appeal submission was deemed by the college to be complete and will also advise the student of their right to seek a further internal or external review of the decision, as appropriate.


(27)  Any appeal under clause (24) will be made by lodging a notice of appeal in the prescribed form with the relevant Deputy Vice-Chancellor not later than the timeframe set within the relevant policies or procedures.
#### 9. Hearing of the College Appeals Committee
(28)  Where a hearing of the College Appeals Committee has been granted, the College Appeals Committee will, other than in exceptional circumstances, hear the appeal within twenty (20) working days from the date the appeal submission was deemed by the college to be complete.
(29)  The student will be given notice in writing not less than five (5) working days before the date of the hearing, stating:
  1. the date, time and place of the hearing
  2. that the student has the right to: 
    1. be heard
    2. make a written submission
    3. be accompanied by any other person
    4. be represented by another person
    5. be present throughout the hearing
    6. call any persons as witnesses
    7. engage an interpreter, provided that if the student intends to be represented by another person or to call other persons as witnesses the student will notify the secretary of the College Appeals Committee in writing of the names of such persons no less than one (1) working day before the date of the hearing,
  3. no party will be permitted to have legal representation at the appeals hearing, and
  4. the student will not be present when the College Appeals Committee is considering its decision.


(30)  The relevant dean/head of school (or nominee) will be given notice in writing not less than five (5) working days before the date of the hearing, stating:
  1. the date, time and place of the hearing
  2. the substance of the student’s appeal and the grounds for the appeal
  3. that they have the right to: 
    1. be heard
    2. make a written submission
    3. be present throughout the hearing
    4. call any persons as witnesses, and
  4. that they will not be present when the College Appeals Committee is considering its decision.


(31)  Notwithstanding clauses (29)b.i. and (30)c.i. where the student does not appear at the hearing and has not submitted any reasonable cause for their absence or the relevant dean/head of school is not represented at the hearing, the hearing may proceed and the decision of the College Appeals Committee will not thereby be invalidated.
(32)  The College Appeals Committee will hear the appeal and after giving the student and such other persons as it considers appropriate an opportunity to be heard will:
  1. uphold the appeal
  2. dismiss the appeal, or
  3. make such other decision as it considers appropriate.


#### 10. After the Hearing
(33)  Within five (5) working days of the hearing of appeal the secretary of the College Appeals Committee will:
  1. in writing, notify the student, the relevant dean/head of school and other areas as considered appropriate, of the decision of the College Appeals Committee, including the reason for the decision, and
  2. where the decision has been other than to uphold the appeal, inform the student of their right to seek a further internal, or external review of the decision, as appropriate.


## Part D - UNIVERSITY APPEALS COMMITTEE
#### 11. University Appeals Committee
(34)  There is a University Appeals Committee.
#### 12. Membership
(35)  Membership of the University Appeals Committee comprises:
  1. the chair of the Academic Board (or nominee)
  2. one (1) member appointed by the Academic Board from the academic staff, and
  3. one (1) member who is an enrolled student nominated by the relevant recognised RMIT student organisation.


(36)  The chair of the University Appeals Committee is the chair of the Academic Board (or nominee).
(37)  The secretary will be the Academic Registrar (or nominee) and is non-voting.
(38)  Wherever possible membership of the University Appeals Committee will represent gender equality.
(39)  A person will not be appointed a member of the University Appeals Committee or be permitted to carry out the responsibilities of clause (43):
  1. who has had any involvement in the matter forming the subject of the appeal, or
  2. where for any other reason it would be inappropriate for the person to be a member to hear the appeal.


(40)  All members as identified under clause (35) must be formally invited to the appeal hearing.
(41)  A quorum of the University Appeals Committee is the chair and one (1) voting member.
#### 13. Eligibility and appealable decisions
(42)  Subject to satisfying any eligibility criteria described in the relevant policies or procedures, a student may appeal to the Academic Registrar (or nominee) to request a hearing of the University Appeals Committee regarding:
  1. an outcome of a College Appeals Committee application where it can be established that a breach of University legislation, policy or procedure by the college has occurred that has had a significant impact on the outcome of the application
  2. a decision to exclude the student or terminate their higher degree by research candidature for unsatisfactory academic progress
  3. the outcome of an application for special consideration
  4. the outcome of an application for a future assessment adjustment
  5. the outcome of an application for an equitable assessment arrangement, or
  6. the outcome of a thesis/project examination for a student in a research program where there is evidence of a breach of University legislation, policy or procedure that has had a significant impact on the outcome of the examination.


(43)  The Academic Registrar (or nominee) will decide whether the application satisfies the grounds for appeal defined in the relevant policies or procedures to determine whether the appeal can proceed to hearing.
(44)  Where eligibility criteria are deemed:
  1. to have been met, the Academic Registrar (or nominee) will approve the request and arrange for a hearing of the University Appeals Committees
  2. not to have been met, the Academic Registrar (or nominee) will deny the request and advise the student accordingly, including the reasons for the determination. This communication must be sent within twenty (20) working days from the date the appeal submission was deemed by the Academic Registrar (or nominee) to be complete and will also advise the student of their right to seek a further internal or external review of the decision, as appropriate.


(45)  Any appeal under clause (42) will be made by lodging a notice of appeal in the prescribed form with the Academic Registrar (or nominee) not later than the timeframe set within the relevant policies or procedures.
#### 14. Hearing of the Committee
(46)  Where a hearing of the University Appeals Committee has been granted, the University Appeals Committee will, other than in exceptional circumstances, hear the appeal within twenty (20) working days from the date the appeal submission was deemed by the Academic Registrar (or nominee) to be complete.
(47)  The student will be given notice in writing not less than five (5) working days before the date of the hearing, stating:
  1. the date, time and place of the hearing
  2. that the student has the right to: 
    1. be heard
    2. make a written submission
    3. be accompanied by any other person
    4. be represented by another person
    5. be present throughout the hearing
    6. call any persons as witnesses
    7. engage an interpreter, provided that if the student intends to be represented by another person or to call other persons as witnesses the student will notify the Academic Registrar (or nominee) in writing of the names of such persons no less than one (1) working day before the date of the hearing,
  3. no party will be permitted to have legal representation at the appeal hearing, and
  4. the student will not be present when the University Appeals Committee is considering its decision.


(48)  The original determination authority will be given notice in writing not less than five (5) working days before the date of the hearing, stating:
  1. the date, time and place of the hearing
  2. the substance of the student’s appeal and the grounds for the appeal
  3. that they have the right to: 
    1. be heard
    2. make a written submission
    3. be present throughout the hearing
    4. call any persons as witnesses, and
  4. that they will not be present when the University Appeals Committee is considering its decision.


(49)  Notwithstanding clauses (47)b.i. and (48)c.i. where the student does not appear at the hearing and has not submitted any reasonable cause for their absence or the relevant original determination authority is not represented at the hearing, the hearing may proceed and the decision of the University Appeals Committee will not thereby be invalidated.
(50)  The University Appeals Committee will hear the appeal and after giving the student and such other persons as it considers appropriate an opportunity to be heard will:
  1. uphold the appeal
  2. dismiss the appeal, or
  3. make such other decision as it considers appropriate.


#### 15. After the Hearing
(51)  Within five (5) working days of hearing the appeal the Academic Registrar (or nominee) will:
  1. in writing, notify the student, the original determination authority and other areas as considered appropriate, of the decision of the University Appeals Committee, including the reason for the decision, and
  2. where the decision has been other than to uphold the appeal, inform the student of their right to seek a further internal or external review of the decision, as appropriate.


## Part E - MISCELLANEOUS
### Division 1 – Address for Notice
#### 16. Address for Notice
(52)  Any written notice required to be given by the University under these Regulations may be sent via email. In the case of the student, it will be to the student email address as recorded on the official University student database.
#### 17. Regulation of Proceedings
(53)  Subject to University legislation, a panel, board or committee constituted under these Regulations regulates its own proceedings and in hearing any case is not bound by the rules or practices as to evidence or procedure, but may inform itself in relation to any matter as it considers appropriate.
### Division 2 – Transitional Provisions
#### 18. Regulation of Proceedings
(54)  In this Division:
  1. commencement date means the day on which these Regulations come into operation
  2. old regulations means the Regulations 5.4.1, 5.4.2 and 5.4.4 in force up until the commencement date of these Regulations.


(55)  Any appeal process commenced, on and from the commencement date, is to be dealt with under these Regulations.
(56)  Any appeal process commenced, prior to the commencement date, is to be dealt with under the old regulations.
### Division 3 – Revocation of Regulations
#### 19. Revocation of Regulations
(57)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 5.4.1 Assessment and Academic Progress
  2. Regulation 5.4.2 The College Appeals Committee
  3. Regulation 5.4.4 The University Appeals Committee.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
