[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=259&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=259&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Domestic and Family Violence Procedure (Australia) 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=259)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=259&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=259&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=259&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=259&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=259&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=259&version=1)


# Domestic and Family Violence Procedure (Australia)
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=259&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=259&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=259&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=259&version=1#section4)
  * [Disclosures](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major1)
  * [Reports or notifications to Police](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major2)
  * [Precautionary Measures – Safety Planning](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major3)
  * [Leave and Reasonable Work Adjustment - Staff](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major4)
  * [Academic Adjustments - Students](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major5)
  * [Staff and students who use violence](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major6)
  * [Privacy, Confidentiality and Record keeping](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major7)
  * [Internal reporting and continuous improvement](https://policies.rmit.edu.au/document/view.php?id=259&version=1#major8)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure documents how RMIT will respond to matters involving, domestic and family violence, including how to support affected staff and students.
(2)  RMIT recognises that staff or students affected by domestic and family violence may experience significant physical or emotional trauma, loss of work and educational opportunities, and disruption to their lives. RMIT recognises the impact of domestic and family violence on student and staff wellbeing and is committed to promoting the health and safety of its staff and students on campus, in our workplaces and learning environments.
(3)  RMIT is committed to working toward the prevention of violence and will work collaboratively to address the practices, attitudes, norms and behaviours that underpin and give rise to domestic or family violence.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259&version=1#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259&version=1#document-top)
# Section 3 - Scope
(5)  This procedure applies to all staff, students researchers, contractors, visitors and volunteers of the RMIT’s campuses and controlled entities in Australia. A separate procedure applies to RMIT Vietnam.
(6)  The specific definitions for family violence and family members are contained in [Domestic and Family Violence – Schedule 1 – Definitions](https://policies.rmit.edu.au/document/view.php?id=261).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259&version=1#document-top)
# Section 4 - Procedure
### Disclosures
(7)  A disclosure of domestic and family violence is when a person makes known that:
  1. they are experiencing domestic and family violence or
  2. their family member is experiencing domestic and family violence.


(8)  RMIT recognises and respects that staff and students may choose if, when and to whom to make a disclosure of domestic and family violence.
(9)  RMIT staff and students who have experienced domestic and family violence can contact Safer Community for support and advice regardless of where or when the harm occurred. Safer Community intranet site also provides staff and students with lists of external specialist support and advice services.
(10)  Where a staff member receives a disclosure of domestic and family violence, they must act promptly, confidentially and with sensitivity, in accordance with this procedure.
(11)  Where a staff member receives a disclosure they must:
  1. advise the discloser about this procedure, and inform them that they can seek support from Safer Community, and
  2. advise the discloser that any information or details they disclose about the domestic and family violence will be kept confidential and used solely for the purpose of assessing the discloser’s needs and providing them with appropriate support.


(12)  Staff members who receive disclosures of domestic and family violence must treat all information disclosed to them as confidential and ensure they maintain that confidentiality unless:
  1. the affected person gives consent for their details to be communicated to another person for the purpose of seeking appropriate support, in which case, disclosure is only on a need-to-know basis, or
  2. disclosure is required by law, including to the police or a regulatory body, for example Child Protection Services.


(13)  Students and staff members must not victimise or otherwise subject another person to detrimental action as a consequence of that person disclosing, providing information about, or otherwise being involved in the support for an individual experiencing domestic and family violence.
(14)  Safer Community provides support for persons who make a disclosure of domestic and family violence to them.
  1. For staff: With consent of the discloser, Safer Community can provide advisory support to the relevant People Business Partner to support work adjustments, leave and safety planning.
  2. For students: With consent of the discloser, Safer Community can provide advisory support, including safety planning, to the student’s area of study (College or School) and work with the Special Consideration Team for support on considerations of academic accommodation (including assessment flexibility options).


(15)  RMIT staff members affected by domestic and family violence (within Australia and internationally) can also contact People Connect or the Employee Assistance Program for support and advice.
(16)  RMIT students affected by domestic and family violence (within Australia and internationally) can refer to [Student Connect](https://policies.rmit.edu.au/download.php?id=130&version=2&associated) and the specialist agencies detailed on the Safer Community webpage. 
### Reports or notifications to Police
(17)  Safer Community can provide appropriate support to a person who has experienced domestic and family violence who wishes to make a police report. However Safer Community cannot make a police report on that person’s behalf.
(18)  In certain circumstances, RMIT may have a duty to notify the police about an incident of domestic and family violence. This includes:
  1. where it involves an unacceptable risk to students or staff
  2. where the person who is the subject of the disclosure presents a risk to themselves, or
  3. if there is a risk to the children of staff or students under the age of 18.


(19)  Except in emergency circumstances, a notification to the police by RMIT must go through the appropriate approval channels. For students, approval must be given by the Academic Registrar's Group. For staff approval can be sought from Safer Community; the Security Manager and/or the Chief People Officer.
(20)  The decision to notify the police (about a staff member or a student) must take into account:
  1. evidence of an unacceptable risk to RMIT’s community or the public
  2. multiple disclosures, reports or complaints about the same person
  3. advice from Safer Community
  4. the wishes of the person who has experienced the domestic and family violence or who made the disclosure initially.


(21)  Safer Community will advise the person who has disclosed the domestic and family violence about RMIT’s decision to notify the police and (to the extent possible) will keep the person informed of any actions that result from that notification.
(22)  Safer Community must report any concerns or disclosures or reports of child abuse or maltreatment, including if a reasonable belief is formed that a child may be at risk from domestic and family violence. as outlined in the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) and procedures.
### Precautionary Measures – Safety Planning
(23)  When a disclosure concerning domestic and family violence is made, Safer Community can offer advisory support in safety planning, which may include putting in place temporary or permanent precautionary measures to ensure the safety and wellbeing of staff and students experiencing domestic and family violence.
(24)  Safer Community may need to complete a domestic and family violence risk assessment (the MARAM tool) in consultation with the affected person.
(25)  Any safety planning and precautionary measures adopted should be agreed to by the staff member or student concerned.
(26)  For students, Safer Community, with the consent of the affected person, will reach out to their Program Manager or Senior Officer where required. Safer Community will work with the Program Manager or Senior Officer to provide appropriate precautionary measures to support and ensure the safety of a student experiencing domestic and family violence. The decision to implement any precautionary measures will ultimately rest with the Program Manager or Senior Officer. Precautionary measures could include:
  1. changing the student’s attendance schedule or timetable
  2. changes to email contacts
  3. providing assistance from RMIT security while on campus
  4. downloading the SafeZone app (free for all staff and students) on the affected student’s mobile device, and
  5. any other reasonable measures determined on a case-by-case basis.


(27)  For staff, Safer Community, with the consent of the affected person, will reach out to the People Business Partner to discuss possible precautionary measures required to support and ensure the safety of a staff member experiencing domestic and family violence. Safer Community and the People Business Partner will work in collaboration with the affected person to plan safety measures. The decision to implement any precautionary measures will ultimately rest with the People Business Partner and People Connect. Precautionary measures may include but are not limited to:
  1. temporary or permanent relocation of the staff member to a more secure work area, and/or support in hybrid working conditions
  2. setting up procedures for alerting security and/or the police (if appropriate)
  3. organising security to be present at start and end of day
  4. escorting entry to and exit from the building i.e., to car park or public transport
  5. regular walk-bys or enhanced visibility of security
  6. managing telephone, fax, email or mail harassment
  7. changing the staff member's contact details and/or removing them from public directories
  8. changing the staff member’s preferred first or last name on public University systems
  9. where a Family Violence Intervention Order exists, asking the staff member to consider including the relevant University campus on the order and making provisions (with consent) for security to be aware of such orders
  10. downloading the SafeZone app (free for all staff and students) on the affected staff member’s mobile device. 


(28)  If a person contravenes a court order by coming into the workplace or learning environment, or if a person becomes violent in the workplace or learning environment, on being notified, the relevant manager must:
  1. contact RMIT Security
  2. with the consent of the staff or student who is the subject of the incident, ensure that Safer Community has been promptly notified of the incident
  3. refer the staff member who is the subject of the incident and any staff members involved in or witnessing the incident to the University's Employee Assistance Program
  4. in the case of a student, refer the student who is the subject of the incident and any students involved in, or who have witnessed the incident to the University’s Counselling Service
  5. document the incident as a health and safety incident as soon as possible and, within 24 hours, via RMIT’s incident and hazard reporting system, PRIME.


(29)  In high-risk cases Safer Community, with consent, will make warm referrals to specialist family violence agencies. 
### Leave and Reasonable Work Adjustment - Staff
(30)  All staff experiencing or affected by domestic and family violence have access to a range of leave and reasonable work adjustments as outlined in the Enterprise Agreement and under the [Fair Work Act 2009](https://policies.rmit.edu.au/directory/summary.php?legislation=6). These adjustments may include but are not limited to:
  1. paid or further unpaid leave
  2. changes to the employee span of hours or pattern of hours and/or shift patterns
  3. job redesign or changes to duties
  4. relocation to suitable employment within RMIT
  5. a change of telephone number or email address as appropriate
  6. any other appropriate measure including those available under existing family-friendly and flexible work arrangements.


(31)  Staff members seeking to access leave or reasonable work adjustments may be required to provide evidence or documentary proof of their domestic and family violence situation. This may be in the form of an agreed document issued by Safer Community or by the Police, a Court, a doctor, a District Nurse, a Maternal and Health Care Nurse, a Family Violence Support Service or lawyer. This information will be treated confidentially.
(32)  RMIT acknowledges that staff affected by domestic and family violence may not be in a position to provide evidence or supporting documentation. A staff member’s access to leave and other support options should not be denied in the absence of evidence or supporting documentation.
### Academic Adjustments - Students
(33)  All students experiencing or affected by domestic and family violence may apply for flexible assessment arrangements or other adjustments as outlined in the [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7), the [Admission Procedure](https://policies.rmit.edu.au/document/view.php?id=36), and the [Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=113). These adjustments can include, but are not limited to, academic changes to facilitate ongoing student engagement, applications for special consideration, deferred assessment, extensions of time, leave of absence, deferrals and/or withdrawal.
(34)  Students applying for flexible assessment arrangements or other adjustments will be required to provide evidence or documentary proof of their domestic and family violence situation. This may be in the form of an agreed document issued by Safer Community or by the Police, a Court, a doctor, a District Nurse, a Maternal and Health Care Nurse, a Family Violence Support Service or lawyer, social worker, counsellor and psychologist. This information will be treated confidentially.
### Staff and students who use violence
(35)  RMIT is aware that in addition to there being staff and students who are victim-survivors or affected by domestic and family violence, there are also likely to be staff and students who use violence or engage in domestic and family violence. RMIT recognises the need to respond to this appropriately and sensitively.
(36)  It is never acceptable for a person to engage in domestic and family violence in, or from, the workplace or learning environment. Staff and students must not use RMIT resources, including IT infrastructure, to engage in behaviour that threatens, harasses, victimises, or abuses another person.
(37)  Where a student or staff member makes a disclosure to their Academic Head, Head of School, People team, supervisor or Safer Community about any current or pending court proceedings involving domestic violence orders in which they are the respondent, reasonable adjustments to study or work may be implemented as appropriate, as well as access to counselling or the employee assistance program (EAP).
(38)  Where the person who has used violence and the person affected by the domestic and family violence are both members of the RMIT community, RMIT will seek to ensure the safety of all parties.
(39)  Staff should consult with the Safer Community team for advice on how to address a staff member or student who has engaged in harassment, assault or domestic and family violence. Managers or colleagues should encourage people who are using violence to seek immediate help from a range of external providers, including the EAP, if it is safe to do so.
(40)  Where an incident of domestic and family violence has occurred in connection with a staff member’s employment or workplace, or a student’s learning environment or campus, or any RMIT premises or event, RMIT may treat it as a breach of the applicable staff or student behaviour policy or code of conduct.
### Privacy, Confidentiality and Record keeping
(41)  RMIT recognises the sensitivity of domestic and family violence situations and confidentiality is maintained when supporting staff and students affected by domestic and family violence in accordance with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59). RMIT recognises that confidentiality may be critical to the safety of the affected person or their family.
(42)  Safer Community maintains a confidential register of disclosures and reports about domestic and family violence. All information is collected, stored, and accessed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(43)  RMIT will use de-identified data about disclosures relating to domestic and family violence to inform preventative strategies, identify trends and develop targeted responses to domestic and family violence in the RMIT community.
(44)  There are some limited circumstances in which RMIT may be required to disclose identifying information about a person, for the safety and wellbeing of members of the RMIT community, including the person identified (such as where RMIT is required by law to report an incident to the police or a regulator) and in child safe matters.
### Internal reporting and continuous improvement
(45)  De-identified data is reported by RMIT’s Health, Safety and Wellbeing team every six months, or as required, to the Vice-Chancellor’s Prevention of Gender-based Violence Advisory Group, RMIT Council and other areas of RMIT. This data assists in identifying trends, systemic issues and opportunities for improvements and preventative actions. It also contributes to the evaluation of prevention programs. Access to this information will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(46)  RMIT will make available and promote family violence awareness raising programs as detailed within the Vice-Chancellor's Prevention of Gender-based Violence Advisory Group Workplan. RMIT will ensure that information on support options is made available to staff and students.
(47)  RMIT provides de-identified data to external agencies or bodies, where required, to ensure compliance with legislated reporting requirements including, but not limited to, those detailed under the [Gender Equality Act 2020 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/gender-equality-act-2020/) and the [Workplace Gender Equality Act 2012 (Cth)](https://www.legislation.gov.au/Details/C2012C00899). Access to this information is managed in accordance with the RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
