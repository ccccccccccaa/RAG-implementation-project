[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=250#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=250#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Policy Governance Procedure Schedule 1 - Policy Proposal and Approval 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=250)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=250)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=250)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=250)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=250)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=250)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=250)


# Policy Governance Procedure Schedule 1 - Policy Proposal and Approval
Hide Navigation
  * [Policy categories](https://policies.rmit.edu.au/document/view.php?id=250#major1)
  * [Approval authorities](https://policies.rmit.edu.au/document/view.php?id=250#major2)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
### Policy Governance Procedure Schedule 1 - Policy Proposal and Approval 
### Policy categories
(1)  Policy documents are categorised as either governance, operational or academic, depending on their content. Where there is ambiguity about the category for a particular policy, the University Policy Manager determines the appropriate category.
(2)  In exceptional circumstances, a policy may need to change its category in response to a significant change in scope and content. The policy owner must seek approval for the change from the approval authority of the new category, after obtaining endorsement from the existing approval authority.
### Approval authorities
(3)  The following tables outline the appropriate approval authority for:
  1. commencing the development of new policies or procedures (table 1)
  2. checking on the direction of new and revised policy suites midway through the process (table 1)
  3. approving new or fully revised policy documents(table 2)
  4. approving minor or administrative amendments to policy documents (table 3).


(4)  There is only one approval authority for each policy category. However:
  1. operational policies that have an impact on academic staff or on the delivery of research and education, need to be endorsed by Academic Board prior to being submitted to the Vice-Chancellor's Executive Meeting for approval
  2. academic policies that have an operational impact must be endorsed by the Vice-Chancellor's Executive Meeting prior to being submitted to Academic Board for approval
  3. academic policies must be sent to all Academic Board sub-committees for either endorsement or noting, depending on the content (refer to Policy Hub for guidance).


(5)  Policy owners must notify the University Policy Manager when they exercise their delegated authority to approve new procedures, standards, instructions or guidelines. The University Policy Manager reports such approvals in the biannual policy reports to Academic Board and the Audit and Risk Management Committee .
Table 1: Endorsement checkpoints for commencing new policy development and for progressing to approval
Category | Endorsement to develop new policy | Endorsement to develop new procedure  | Mid-way check with approval authority for new policies and policy reviews  
---|---|---|---  
Governance  | University Policy Manager | Policy owner | Vice-Chancellor's Executive Meeting  
Academic | Chair, Academic Board and University Policy Manager | Policy owner | Academic Board (and Vice-Chancellor's Executive Meeting where there is an operational impact)  
Operational  | University Policy Manager | Policy owner | Vice-Chancellor's Executive Meeting (and Academic Board where there is an academic impact)  
Table 2: Approval authority for new or revised policy documents
Category | Policy or Policy Suite |  RMIT Group Procedures, Standards, Instructions or Guidelines | Controlled Entity Instructions or Guidelines  
---|---|---|---  
Governance | Council, via Vice-Chancellor's Executive Meeting to note, Audit and Risk Management Committee to endorse | Policy owner | CEO equivalent, or delegate  
Academic |  Academic Board, via Academic Board Sub-Committees to endorse or note, depending on content (Vice-Chancellor's Executive Meeting to endorse first where there is an operational impact) | Policy owner | CEO equivalent, or delegate  
Operational |  Vice-Chancellor's Executive Meeting  (Academic Board to endorse first where there is an academic impact) | Policy owner | CEO equivalent, or delegate  
Table 3: Approval authority for minor amendments and administrative changes to policy documents (policies, procedures, standards, instructions and guidelines)
| Definition | Authority to amend  
---|---|---  
Minor amendments | A change that does not alter the intent of the policy document or significantly affect the content or application of the policy, e.g. to clarify existing details, align with legislative changes, or include additional processes for a new system, a new campus or controlled entity. |  Policy owner for RMIT Group documents CEO equivalent or delegate for controlled entity documents  
Administrative changes | A correction to a policy document to update a title, name, formatting, web link, spelling, grammar, and references to law or other policy documents, or for clarity of language. |  Central Policy for RMIT Group documents Local policy site administrator for controlled entity documents  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
