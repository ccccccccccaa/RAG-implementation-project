[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=259#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=259#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Domestic and Family Violence Procedure - Australia 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=259)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=259)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=259)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=259)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=259)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=259)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=259)


# Domestic and Family Violence Procedure - Australia
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=259#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=259#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=259#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=259#section4)
  * [Disclosures](https://policies.rmit.edu.au/document/view.php?id=259#major1)
  * [Ways to make a disclosure](https://policies.rmit.edu.au/document/view.php?id=259#major2)
  * [Ways to make a formal report](https://policies.rmit.edu.au/document/view.php?id=259#major3)
  * [Precautionary Measures – Safety Planning](https://policies.rmit.edu.au/document/view.php?id=259#major4)
  * [Leave and reasonable work adjustment - Staff](https://policies.rmit.edu.au/document/view.php?id=259#major5)
  * [Academic Adjustments – Students](https://policies.rmit.edu.au/document/view.php?id=259#major6)
  * [Staff and students who use violence](https://policies.rmit.edu.au/document/view.php?id=259#major7)
  * [Privacy, confidentiality and record-keeping](https://policies.rmit.edu.au/document/view.php?id=259#major8)
  * [Internal reporting and continuous improvement](https://policies.rmit.edu.au/document/view.php?id=259#major9)
  * [External reporting](https://policies.rmit.edu.au/document/view.php?id=259#major10)
  * [Section 5 - Compliance](https://policies.rmit.edu.au/document/view.php?id=259#section5)
  * [Section 6 - Schedule](https://policies.rmit.edu.au/document/view.php?id=259#section6)
  * [Section 7 - Definitions](https://policies.rmit.edu.au/document/view.php?id=259#section7)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This procedure documents how RMIT will respond to matters involving, domestic and family violence, including how to support affected staff and students. The specific definitions for family violence and family members are contained in Domestic and Family Violence Schedule 1 – Explanations and Examples.
(2)  RMIT recognises that staff and students affected by domestic and family violence may experience significant physical or emotional trauma, loss of work and educational opportunities, and disruption to their lives. In recognition of the impact of domestic and family violence on student and staff wellbeing, RMIT has services to assist affected persons to take precautionary safety measures and to make adjustments to their work or study commitments while they manage their personal situation.
(3)  This procedure should be read in conjunction with the RMIT policies regarding behavioural standards and conduct which are listed on the Associated Information tab for this procedure on the [Policy Register](https://policies.rmit.edu.au/download.php?id=470&version=1&associated). Policies and procedures of relevant third parties may also apply in some circumstances (for example, the policies of industry partners hosting RMIT students on placement).
(4)  RMIT acknowledges that intersectionality can compound the impact of discrimination and that certain groups of people will be more vulnerable to the effects of discrimination and harassment than other groups.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259#document-top)
# Section 2 - Authority
(5)  Authority for this document is established by the [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259#document-top)
# Section 3 - Scope
(6)  This procedure applies to all members of the RMIT community, including staff, students and associates (e.g. RMIT University Council members, representatives, volunteers) of the RMIT Group. RMIT Group means RMIT University and its controlled entities including RMIT Europe, RMIT Online, and RMIT University Pathways).
(7)  A separate procedure applies to RMIT Vietnam.
(8)  Third parties are in the scope of this policy where there is a connection with RMIT, such as contractors, licensees or lessees, service providers, visitors, international education agents and delivery partners, and partner organisations in Australia or overseas acting for or on behalf of RMIT in relation to our students and staff.
(9)  The policy covers all RMIT activities on-campus, at affiliated venues, and off-campus events where staff, students or third parties are representing RMIT, and includes virtual and online environments.
(10)  If domestic and family violence is reported outside of the scope of this policy, RMIT will provide referrals to appropriate support services.
(11)  All partner organisations must adhere to RMIT policies when delivering RMIT programs and providing services to RMIT students, regardless of international and local regulatory contexts, the independence of partner organisations and commercial considerations. These contextual factors are governed by Gender Based Violence Policy and managed through contract and partner management processes to ensure compliance.
(12)  This procedure applies at all times when persons are working for, studying, representing or travelling with or for the RMIT Group, including, but not limited to, attending and engaging in RMIT events, functions and activities both on- and off-campus, nationally and internationally.
  1. On campus refers to: 
    1. all RMIT campuses, locations, premises, and facilities where RMIT business or activities take place
    2. RMIT owned, operated, affiliated or endorsed venues including accommodation.
  2. Off-campus includes activities and events at non-RMIT venues where staff, students or third parties are representing RMIT (e.g., sporting events, social events, cultural events, competitions, placements, conferences, unwanted social contact by electronic outside working hours).


(13)  This procedure also applies to virtual spaces and online work and study environments including but not limited to RMIT systems, IT infrastructure or assets.
(14)  The [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) take precedence over this one to the extent of any inconsistency regarding harm relating to children.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259#document-top)
# Section 4 - Procedure
### Disclosures
(15)  A disclosure refers to the sharing of information about an experience of domestic and family violence where a person makes known that:
  1. they are experiencing domestic and family violence or
  2. their family member is experiencing domestic and family violence.


(16)  Anyone connected to RMIT, including third parties, are supported to make a disclosure without fear of sanction or inaction. However, the steps which RMIT can take and its timely response and resolution may depend on whether the person who is the victim-survivor wishes to participate or to utilise RMIT’s processes. RMIT recognises and respects that staff and students may choose if, when and to whom to make a disclosure of domestic and family violence.
(17)  All RMIT staff receiving a disclosure must inform the discloser about support from [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community). Staff must notify [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) of the disclosure to support RMIT’s whole-of-organisation prevention and support strategies. Staff must inform the discloser of the obligation to notify [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) and seek consent on what information can be shared, including anonymity preferences.
(18)  If domestic and family violence is disclosed or reported as occurring outside the scope of this procedure, RMIT will provide referrals to specialist domestic and family violence support services as appropriate.
### Ways to make a disclosure
(19)  In an emergency or in circumstances of immediate danger, the Victoria police (Triple Zero - 000).
(20)  All persons including staff members, students, representatives and volunteers who have experienced domestic and family violence can contact [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) for specialist trauma-informed, safety first, and inclusive and intersectional support and advice regardless of where or when the harm or violence occurred, whether they want only to make a disclosure of harm, or to make a formal report about it.
(21)  RMIT encourages individuals wanting to make an informal or formal report to contact [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) for guidance. Safer Community offers information on reporting procedures, which may vary depending on the individual's status (student, staff, or third party) and the status of the respondent.
(22)  All disclosures and reports made through [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) will receive a response within one business day. This response will acknowledge receipt of the disclosure or report.
### Ways to make a formal report
(23)  Individuals who disclose domestic and family violence may choose to make a formal report, but it is not mandatory. A formal report involves providing a statement about the incident and seeking a formal timely resolution and response from RMIT.
(24)  If a person who has experienced domestic and family violence wants to make a report to the police, [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) can support a person to make a police report. However, [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) cannot make a police report on that person’s behalf.
(25)  If a person who has experienced domestic and family violence wishes to report to police, no further investigation will be made within RMIT while the police investigation is underway, but support from [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) will be ongoing.
(26)  In certain circumstances, RMIT may have a duty to notify the police in its own name, even if the individual does not wish to. This may occur where there is a serious or imminent risk to the safety of another person or persons, or to meet RMIT’s legal obligations. This includes where the incident involves an imminent and/or serious risk to students or staff, or where the person who is the subject of the disclosure or report presents a risk to themselves.
  1. A notification to the police by RMIT in its own name must be approved by the Chief Operating Officer (if the respondent is a staff member and/or a third party) or the Academic Registrar (if the respondent is a student), taking into account: 
    1. evidence of an unacceptable risk to RMIT’s community, or the public.
    2. multiple disclosures, reports, or complaints about the same person.
    3. advice from the Critical Incident Management Team in accordance with the [Business Resilience Policy](https://policies.rmit.edu.au/document/view.php?id=67), and other relevant groups including [Health, Safety and Wellbeing](https://www.rmit.edu.au/students/support-services/health-safety-wellbeing), [Risk Management](https://www.rmit.edu.au/students/student-life/rights-responsibilities/risk-management), [Compliance](https://www.rmit.edu.au/about/governance-management/compliance), the [Academic Registrar’s Group](https://www.rmit.edu.au/staff/rmit-structure/education/groups/academic-registrars-group), and [Legal Services](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services).
    4. advice from [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community).
    5. the wishes of the person who has experienced the domestic and family violence or who made the disclosure or report initially.


(27)  [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) will advise the person who has disclosed or reported the domestic and family violence about RMIT’s decision to notify the police and, to the extent possible, will keep the person informed of any actions that result from that notification.
(28)  Persons who make a report, as well as persons who are the subject of a report, will be provided with information about the steps involved for any formal or informal resolution process, and they will be kept appropriately informed about the progress and outcome of those steps in accordance with the relevant policy and procedure.
### Precautionary Measures – Safety Planning
(29)  When a disclosure concerning domestic and family violence is made, [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) can offer advisory support in safety planning, which may include putting in place temporary or permanent precautionary measures to ensure the safety and wellbeing of staff and students experiencing domestic and family violence.
(30)  [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) need to complete a domestic and family violence risk assessment, using the Multi Agency Risk and Assessment and Management (MARAM) Framework, in consultation with the affected person.
(31)  Any safety planning and precautionary measures adopted should be led and agreed to by the staff member or student concerned.
(32)  For students, [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community), with the consent of the affected person, will reach out to their Program Manager or Senior Officer where required. [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) will work with the Program Manager or Senior Officer to provide appropriate precautionary measures to support and ensure the safety of a student experiencing domestic and family violence. The decision to implement any precautionary measures will ultimately rest with the Program Manager or Senior Officer. Precautionary measures could include:
  1. changing the student’s attendance schedule or timetable
  2. changes to email contacts
  3. providing assistance from RMIT security while on campus
  4. downloading the SafeZone app (free for all staff and students) on the affected student’s mobile device, and
  5. any other reasonable measures determined on a case-by-case basis.


(33)  For staff, [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community), with the consent of the affected person, will reach out to the People Business Partner to discuss possible precautionary measures required to support and ensure the safety of a staff member experiencing domestic and family violence. [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) and the People Business Partner will work in collaboration with the affected person to plan safety measures. The decision to implement any precautionary measures will ultimately rest with the People Business Partner and People Connect. Precautionary measures may include but are not limited to:
  1. temporary or permanent relocation of the staff member to a more secure work area, and/or support in hybrid working conditions
  2. setting up procedures for alerting security or the police (if appropriate)
  3. organising security to be present at start and end of day
  4. escorting entry to and exit from the building i.e., to car park or public transport
  5. regular walk-bys or enhanced visibility of security
  6. managing telephone, fax, email or mail harassment
  7. changing the staff member's contact details and/or removing them from public directories
  8. changing the staff member’s preferred first or last name on public University systems
  9. where a Family Violence Intervention Order exists (the terminology used for this order may vary depending on the jurisdiction), asking the staff member to consider including the relevant University campus on the order and making provisions (with consent) for security to be aware of such orders
  10. downloading the SafeZone app (free for all staff and students) on the affected staff member’s mobile device.


(34)  If a person contravenes a court order by coming into the workplace or learning environment including virtual or remote locations or residences, or if a person becomes violent in the workplace or learning environment, on being notified, the relevant manager must:
  1. contact [RMIT Campus Security](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/campus-security)
  2. with the consent of the staff or student who is the subject of the incident, ensure that Safer Community has been promptly notified of the incident
  3. refer the staff member who is the subject of the incident and any staff members involved in or witnessing the incident to the Employee Assistance Program (EAP)
  4. in the case of a student, refer the student who is the subject of the incident and any students involved in, or who have witnessed the incident to the University’s Counselling Service
  5. document the incident as a health and safety incident as soon as possible and, within 24 hours, via RMIT’s incident and hazard reporting system, Safety Now.


(35)  In high-risk cases [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community), with consent, will make referrals to specialist family violence agencies.
### Leave and reasonable work adjustment - Staff
(36)  All staff experiencing or affected by domestic and family violence have access to a range of leave and reasonable work adjustments as outlined in the [Enterprise Agreement](https://policies.rmit.edu.au/download.php?id=5&version=5&associated) and under the [Fair Work Act 2009](https://policies.rmit.edu.au/directory/summary.php?legislation=6). These adjustments may include but are not limited to:
  1. 20 days of paid leave or further unpaid leave
  2. changes to the employee span of hours or pattern of hours and/or shift patterns
  3. job redesign or changes to duties
  4. relocation to suitable employment within RMIT
  5. a change of telephone number or email address as appropriate
  6. any other appropriate measure including those available under existing family-friendly and flexible work arrangements.


(37)  Staff members seeking to access leave or reasonable work adjustments may be required to provide evidence or documentary proof of their domestic and family violence situation. This may be in the form of an agreed document issued by [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) or by the Police, a Court, a doctor, a District Nurse, a Maternal and Health Care Nurse, a Family Violence Support Service or lawyer. This information will be treated confidentially.
(38)  RMIT acknowledges that staff affected by domestic and family violence may not be in a position to provide evidence or supporting documentation. A staff member’s access to leave and other support options should not be denied in the absence of evidence or supporting documentation.
### Academic Adjustments – Students
(39)  All students experiencing or affected by domestic and family violence may apply for flexible assessment arrangements or other adjustments as outlined in the [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7), the [Admission Procedure](https://policies.rmit.edu.au/document/view.php?id=36), and the [Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=113). These adjustments can include, but are not limited to, academic changes to facilitate ongoing student engagement, applications for special consideration, deferred assessment, extensions of time, leave of absence, deferrals and/or withdrawal.
(40)  Students applying for flexible assessment arrangements or other adjustments will be required to provide evidence or documentary proof of their domestic and family violence situation. This may be in the form of an agreed document issued by [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) or by the Police, a Court, a doctor, a District Nurse, a Maternal and Health Care Nurse, a Family Violence Support Service or lawyer, social worker, counsellor and psychologist. This information will be treated confidentially.
### Staff and students who use violence
(41)  RMIT is aware that in addition to there being staff and students who are victim-survivors or affected by domestic and family violence, there are also likely to be staff and students who use violence or engage in domestic and family violence. RMIT recognises the need to respond to this appropriately and sensitively.
(42)  It is never acceptable for a person to engage in domestic and family violence in, or from, the workplace or learning environment. Staff and students must not use RMIT resources, including IT infrastructure, to engage in behaviour that threatens, harasses, victimises, or abuses another person.
(43)  Where a student or staff member makes a disclosure to their Academic Head, Head of School, People team, supervisor or [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) about any current or pending court proceedings involving domestic violence orders in which they are the respondent, reasonable adjustments to study or work may be implemented as appropriate, as well as access to counselling or the employee assistance program (EAP).
(44)  Where the person who has used violence and the person affected by the domestic and family violence are both members of the RMIT community, RMIT will seek to ensure the safety of all parties.
(45)  Staff should consult with the [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) team for advice on how to address a staff member or student who has engaged in harassment, assault or domestic and family violence. Managers or colleagues should encourage people who are using violence to seek immediate help from a range of external providers, including the EAP, if it is safe to do so.
(46)  Where an incident of domestic and family violence has occurred in connection with a staff member’s employment or workplace, or a student’s learning environment or campus, or any RMIT premises or event, RMIT may treat it as a breach of the applicable staff or student behaviour policy or code of conduct.
### Privacy, confidentiality and record-keeping
(47)  Disclosures and formal reports of domestic and family violence will be handled confidentially in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59). Information may be shared on a need-to-know basis with appropriate RMIT officers or external authorities as part of RMIT’s duty of care or legal obligations.
(48)  [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) maintains a confidential register of disclosures and formal reports. All information will be collected, stored, and accessed per RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and applicable laws.
(49)  There are some limited circumstances in which RMIT may be required to share identifying information about a person who has made a disclosure or report of domestic and family violence or about whom the disclosure or report has been made, for the safety and wellbeing of the members of the RMIT community, including for the safety of the person identified, such as where RMIT is required by law to report an incident to the police or a regulator.
### Internal reporting and continuous improvement
(50)  RMIT will use de-identified data from disclosures and reports to inform preventive interim safety measures, if necessary, to focus on the level and nature of the risk as part of assessment and proactive ongoing monitoring. It also collects, analyses, and reports de-identified data to identify trends, underlying issues, and emerging risks. This data- driven approach informs and enhances RMIT’s strategies for effective prevention and response.
(51)  De-identified data will be reported by Health, Safety and Wellbeing every six months, or as required, to the [Vice-](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safe-respectful-community) [Chancellor’s Advisory Group on Gendered Violence Prevention](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safe-respectful-community), RMIT University Council (Council), and other areas of RMIT as required to identify trends and systemic issues, contribute to evaluation of prevention programs, and aid RMIT to identify opportunities for improvements and preventative actions. Access to this information will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(52)  RMIT may provide information to a third party for investigation purposes in accordance with the Student Conduct Policy and Staff [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52). Where a requirement to make a report to a third party and/or the Commission for Children and Young People exists and this information is not able to be provided in a de-identified format, the individual will be consulted prior to the report being made and every effort taken to respect privacy and minimise trauma.
### External reporting
(53)  RMIT will also use de-identified data and formal reports to provide high-level, public-facing reporting on known incidents domestic and family violence. It will also provide de-identified data to external agencies or bodies, where required, to ensure compliance with legislated reporting requirements including but not limited to those detailed under the [Gender Equality Act 2020](https://policies.rmit.edu.au/directory/summary.php?legislation=48) (Vic) and the [Workplace Gender Equality Act 2012 (Cth)](https://www.legislation.gov.au/C2004A03332/latest/text). Access to this information will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(54)  If disclosed or reported incidents indicate material breaches in safety or preventative controls, including recurring incidents of domestic and family violence, [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) will notify the Director, Education Regulation, who will determine if it is appropriate to notify the [Tertiary Education and Quality Standards Agency (TEQSA)](https://www.teqsa.gov.au/). If deemed appropriate, a recommendation will be made to the Deputy Vice-Chancellor Education that TEQSA be notified in accordance with TEQSA Standards and [TEQSA Good Practice Note: Preventing and responding to sexual assault and](https://www.teqsa.gov.au/guides-resources/resources/good-practice-notes/good-practice-note-preventing-and-responding-sexual-assault-and-sexual-harassment-australian-higher-education-sector) [sexual harassment in the Australian higher education sector (2020)](https://www.teqsa.gov.au/guides-resources/resources/good-practice-notes/good-practice-note-preventing-and-responding-sexual-assault-and-sexual-harassment-australian-higher-education-sector).
(55)  If disclosed or reported incidents occurred in relation to an activity funded in whole or in part by the Department of Foreign Affairs and Trade (DFAT), [Safer Community](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safer-community) will notify the Director, Health, Safety and Wellbeing, who will determine if it is appropriate to notify DFAT. If deemed appropriate, a recommendation will be made to the Chief People Officer that DFAT be notified in accordance with the [Department of Foreign Affairs and Trade (DFAT) Preventing](https://policies.rmit.edu.au/document/view.php?id=259#_bookmark0) [Sexual Exploitation, Abuse and Harassment Policy (2019)](https://policies.rmit.edu.au/document/view.php?id=259#_bookmark0). This notification must be made within two (2) working days of RMIT becoming aware of an alleged incident.
(56)  The Vice-Chancellor is responsible for overseeing the handling of any historical allegation, including confirming that it has been referred to the relevant authority, i.e. Police, Reportable Conduct Scheme.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259#document-top)
# Section 5 - Compliance
(57)  RMIT will support members of the RMIT community who believe they have experienced gender-based violence/harm and/or sexual harm or unlawful discrimination.
  1. Students may make a complaint under the [Student and Student-Related Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=34) or under the [Gender Violence Response Procedure](https://policies.rmit.edu.au/document/view.php?id=219).
  2. Staff may make a complaint under the [Staff Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=156) or under the [Gender Violence Response Procedure](https://policies.rmit.edu.au/document/view.php?id=219).
  3. Third parties may make a complaint under the [Third Party Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=111) or under the [Gender Violence Response Procedure](https://policies.rmit.edu.au/document/view.php?id=219).


(58)  A breach of this procedure may result in disciplinary action. Depending on the nature and impact of the breach, other actions may also be instigated, including legal action.
(59)  In cases where non-compliance issues arise, the RMIT will utilise various investigative tools to actively monitor and address these issues. This may include:
  1. conducting proactive audits
  2. undertaking investigations when non-compliance is suspected.


(60)  This procedure supports RMIT’s compliance obligations regarding:
  1. [Charter of Human Rights and Responsibilities Act 2006 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=46)
  2. [Child Wellbeing and Safety Act 2005 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=47)
  3. [Gender Equality Act 2020 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=48)
  4. [Protected Disclosure Act 2012 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=24)
  5. [Respect@Work – Changes to the Sex Discrimination Act 1984 and the Australian Human Rights Commission Act](https://policies.rmit.edu.au/download.php?id=501&version=2&associated) [1986](https://policies.rmit.edu.au/download.php?id=501&version=2&associated)
  6. [Department of Foreign Affairs and Trade (DFAT) Preventing Sexual Exploitation, Abuse and Harassment Policy](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.dfat.gov.au%2Finternational-relations%2Fthemes%2Fpreventing-sexual-exploitation-abuse-and-harassment&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326788109%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=Fsi4lqRTZHkPS6j9TfydiFJbSQzsmqEqL%2Bnwpg8Nshw%3D&reserved=0) [(2019)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.dfat.gov.au%2Finternational-relations%2Fthemes%2Fpreventing-sexual-exploitation-abuse-and-harassment&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326788109%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=Fsi4lqRTZHkPS6j9TfydiFJbSQzsmqEqL%2Bnwpg8Nshw%3D&reserved=0)
  7. [Higher Education Standards Framework 2021](https://policies.rmit.edu.au/directory/summary.php?legislation=44)
  8. [Education Services for Overseas Students (ESOS) Framework](https://www.education.gov.au/esos-framework)
  9. [Occupational Health and Safety Act 2004](https://policies.rmit.edu.au/directory/summary.php?legislation=15)
  10. [Fair Work Act 2009](https://policies.rmit.edu.au/directory/summary.php?legislation=6)
  11. [Equal Opportunity Act 2010 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/equal-opportunity-act-2010/030)


(61)  The procedure support RMIT’s commitment to adhering to sector best practices:
  1. [Australia Human Rights Commission – Guidelines for Complying with the Positive Duty under the Sex](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fhumanrights.gov.au%2Fsites%2Fdefault%2Ffiles%2F2023-08%2FGuidelines%2520for%2520Complying%2520with%2520the%2520Positive%2520Duty%2520%25282023%2529.pdf&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326737813%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=J4%2Fz6iNWVUINphHq8BLui88zRYIZm3N6cOBkSTm21fg%3D&reserved=0) [Discrimination Act 1984 (Cth) (AHRC)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fhumanrights.gov.au%2Fsites%2Fdefault%2Ffiles%2F2023-08%2FGuidelines%2520for%2520Complying%2520with%2520the%2520Positive%2520Duty%2520%25282023%2529.pdf&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326737813%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=J4%2Fz6iNWVUINphHq8BLui88zRYIZm3N6cOBkSTm21fg%3D&reserved=0)
  2. [National Plan for Addressing Gender-based Violence in Higher Education 2024](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.education.gov.au%2Fesos-framework%2Fnational-code-practice-providers-education-and-training-overseas-students-2018&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326824037%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=kcuSxPPyjtPGxSORAYp%2F2O2ZYuao0zxC1Zg8LjbSo7I%3D&reserved=0)
  3. [Higher Education Standards Framework (Threshold Standards) 2021](https://policies.rmit.edu.au/directory/summary.php?legislation=44)
  4. [Universities Australia Sexual Harm Response Guidelines 2023](https://universitiesaustralia.edu.au/wp-content/uploads/2023/07/UA-2023-008-Sexual-Harm-Response-Guidelines-web-v4.pdf).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259#document-top)
# Section 6 - Schedule
(62)  [Domestic and Family Violence Procedure- Schedule 1 - Explanations and Examples](https://policies.rmit.edu.au/document/view.php?id=261).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=259#document-top)
# Section 7 - Definitions
Term |  Definition  
---|---  
Child |  A person who is under the age of 18 years.  
Concern |  An expression of dissatisfaction with the behaviour of a student or staﬀ member, where a response is not expected.  
Consent |  As deﬁned in Section 36 of the Amendment of Crimes Act 1958 (Vic) and Justice Legislation Amendment (Sexual Oﬀences and Other Matters) Act 2022, free and voluntary agreement. Consent cannot be assumed. Consent must be ongoing and mutual. It must be present every time, including for the duration of any sexual act. Consent can be withdrawn at any time. Consent to one act does not mean consent is agreed to in any other act. Consent to an act with one person does not mean consent is agreed to in an act with a diﬀerent person, or with the same person on a diﬀerent occasion. A person engaged in a sexual act must reasonably believe that the other person consents to the act. A person’s belief in consent is not reasonable if they did not, within a reasonable time before or at the time of the act, say or do anything to ﬁnd out whether the other person was consenting. For further information on affirmative consent laws, please refer to [Justice Legislation Amendment](https://content.legislation.vic.gov.au/sites/default/files/2022-09/22-038aa%20authorised.pdf) [(Sexual Oﬀences and Other Matters) Act 2022](https://content.legislation.vic.gov.au/sites/default/files/2022-09/22-038aa%20authorised.pdf).  
Disclosure |  Where a person ﬁrst makes known an incident of sexual harm to RMIT (e.g., by telling another student or staﬀ member, or by directly telling Safer Community). This may or may not lead to a report being made via the Complaints Governance Policy or another reporting avenue.  
Gender-based violence |  Any form of physical or non-physical violence, harassment, abuse or threats, based on gender, that results in, or is likely to result in, harm, coercion, control, fear or deprivation of liberty or autonomy Harm can be physical, sexual, emotional, psychological, social, cultural, spiritual, ﬁnancial and technology- facilitated abuse (including image-based abuse), and stalking.  
International delivery partners |  Institutions in other countries where RMIT programs are delivered jointly by RMIT and the partner institution.  
Intersectionality |  The ways in which different aspects of a person's identity can expose them to overlapping forms of discrimination and marginalisation. Intersectionality addressed and acknowledges gender, sexual orientation, Indigeneity, race, economic status, ability, or other factors can compound the impact of gender-based violence, resulting in certain groups of people being more vulnerable and/or disproportionally impacted than other groups to the effects of gender-based harm, violence, discrimination and harassment.  
RMIT Group |  RMIT University and its controlled entities (RMIT Europe, RMIT Online, RMIT Vietnam and RMIT University Pathways).  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
