[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=265#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=265#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Guidance Note on Conflicts of Interest in Research 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=265)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=265)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=265)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=265)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=265)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=265)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=265)


# Guidance Note on Conflicts of Interest in Research
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=265#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=265#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=265#section3)
  * [Section 4 - Guidance](https://policies.rmit.edu.au/document/view.php?id=265#section4)
  * [Guiding Principles](https://policies.rmit.edu.au/document/view.php?id=265#major1)
  * [Identifying Conflicts of Interest](https://policies.rmit.edu.au/document/view.php?id=265#major2)
  * [Declaring Conflicts of Interest](https://policies.rmit.edu.au/document/view.php?id=265#major3)
  * [Managing Conflicts of Interest](https://policies.rmit.edu.au/document/view.php?id=265#major4)
  * [Individuals](https://policies.rmit.edu.au/document/view.php?id=265#major5)
  * [Managers](https://policies.rmit.edu.au/document/view.php?id=265#major6)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=265#major7)
  * [Section 5 - Definitions and References](https://policies.rmit.edu.au/document/view.php?id=265#section5)
  * [Section 6 - Resources](https://policies.rmit.edu.au/document/view.php?id=265#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This guidance provides an overview of the responsibility of individuals and institutions to identify, declare and manage conflicts of interest in the research context. 
(2)  It supports the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91) and [Conflict of Interest Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90). It is designed to be read alongside the more detailed [RMIT Guide to Responsible Management of Conflicts of Interest in Research](https://rmitheda.force.com/Researcherportal/s/article?id=a6S7F000000bsZBUAY), as well as other relevant Codes and Guides, including the [Australian Code for the Responsible Conduct of Research](https://www.nhmrc.gov.au/about-us/publications/australian-code-responsible-conduct-research-2018).
(3)  Guidance on conflicts of interest in the research training context is addressed separately in the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14) and the [Australian Council for Graduate Research Conflict of Interest Good Practice Guidelines for Disclosing and Managing Interests in Graduate Research](https://www.acgr.edu.au/wp-content/uploads/2022/08/Combined-ACGR-Guidelines-for-Disclosing-and-Managing-Interests-in-Graduate-Research-.pdf).
(4)  Guidance on all other conflicts of interest is addressed in the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91) and [Conflict of Interest Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=265#document-top)
# Section 2 - Authority
(5)  Authority for this guidance note is established by the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=265#document-top)
# Section 3 - Scope
(6)  This guidance applies to all staff, students, visiting researchers and honorary and adjunct appointees undertaking or supporting research at all RMIT University campuses and external research locations, and any research RMIT University is obliged to consider.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=265#document-top)
# Section 4 - Guidance
### Guiding Principles
(7)  The [Australian Code for the Responsible Conduct of Research](https://www.nhmrc.gov.au/about-us/publications/australian-code-responsible-conduct-research-2018) (The Code) defines a conflict of interest as ‘as a situation where an independent observer might reasonably conclude that the professional actions of a person are or may be unduly influenced by other interests’.
  1. Conflicts of interest can be actual, potential or perceived.
  2. Conflicts of interest are not inherently wrong and the existence of a conflict of interest in a research context does not necessarily imply a breach of research integrity. Researchers will almost inevitably have multiple interests that may at times conflict with the conduct of their research.
  3. Conflicts of interest exist on a spectrum, from minor perceived conflicts that can be successfully managed through the disclosure of the interest, to serious actual conflicts that can constitute breaches of professional integrity and/or criminal conduct.


(8)  Under the Code (see Responsibilities of Researchers - R24) and RMIT policy, all individuals involved in research at RMIT have a responsibility to identify, declare and manage conflicts of interest whether they be actual, perceived or potential in nature.
(9)  Individuals involved in research have a responsibility under the Code (R16) to undertake training and education in responsible research conduct, including the management of conflicts of interest. 
(10)  In accordance with NHMRC guidance on conflicts of interest, RMIT also has a responsibility to maintain a record of institutional interests that may be perceived to affect the design, conduct, review, and dissemination of research and appropriately manage any conflicts identified. 
### Identifying Conflicts of Interest
(11)  Individuals involved in research should consider the potential for conflicts arising from all possible interests. Such interests may include but are not necessarily limited to the following:
  1. financial interests, including receiving cash, services, equipment or other recompense from external bodies to support research activities
  2. consultancies
  3. paid or unpaid professional positions or advisory roles, including involvement in start-ups or spin-off organisations, whether such involvement is formal or informal in nature
  4. membership of committees, advisory groups or boards of directors
  5. foreign interests
  6. professional relationships
  7. family and personal relationships.


(12)  A conflict of interest may inappropriately affect, or be perceived to affect the following aspects of research conduct:
  1. research design, data collection and analysis
  2. project approval
  3. research-related business transactions
  4. peer review
  5. dissemination of findings
  6. internal and external allocation of research funding
  7. supervision of staff and Higher Degree by Research candidates.


(13)  It should be noted that competition and enmity, as well as alignment, collaboration, and friendship, may give rise to actual or perceived conflicts of interest.
(14)  Primary responsibility for identifying a conflict of interest lies with the individual to whom the interest accrues, and the process of identifying conflicts of interest should be consistent with the definitions, principles, and essential requirements of the Code and RMIT Policy. RMIT’s Network of Research Integrity Advisors can provide individuals with advice to help in their identification and assessment of conflicts of interest, as needed.
### Declaring Conflicts of Interest
(15)  Disclosure of an identified research-related conflict of interest must be made to a relevant manager in accordance with the [Conflict of Interest Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90).
  1. In the research context, the term ‘relevant manager’ ([Conflict of Interest Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90), clause 12) refers to the relevant research leader best positioned to manage the conflict of interest. This may include, but is not limited to, a direct line manager, a Dean of School, the director of a research centre or a Deputy Dean of Research and Innovation. Importantly, the relevant manager must be independent to the research and research interest. 


(16)  Interests must be declared via the [Conflict of Interest Declaration form](https://policies.rmit.edu.au/download.php?id=162&version=3&associated).
(17)  Where there is doubt or uncertainty as to whether a conflict of interest exists, the interest in question should be declared.
(18)  Individuals involved in research should also:
  1. maintain records of activities that may be relevant to the assessment of whether a conflict of interest exists. Examples include, but are not limited to: consultancies; membership of boards of directors, advisory groups, or committees; or receipt of or delegation to receive funds, services, or equipment from outside bodies to support research activities
  2. disclose any new interest in a timely fashion
  3. comply with the disclosure of interest policies and procedures of external bodies with which they engage or are affiliated. Examples of such external bodies may include funders, conference sponsors or organisers and publishers. Relevant roles may include, but are not limited to: company director, not-for-profit board member, scientific advisor or editor, peer reviewer
  4. update any disclosures of interest as circumstances change, and at least annually during the period during which the research remains active.


### Managing Conflicts of Interest
(19)  Once a conflict has been identified and disclosed it must be managed. This is a joint responsibility of the individual and the relevant manager/s.
(20)  Individuals should not solely manage their own conflicts of interest, as this is not appropriate and may heighten an observer’s perception of bias, undue influence and/or unfairness.
(21)  The appropriate approach is for individuals to consult and involve the relevant manager/s in the management of the conflict. Where there is any divergence or disagreement between an individual and the relevant manager/s in the approach to, or plan for, management of a conflict of interest, the approach of the management team will take precedence.
(22)  Conflict of interest management plans must be documented via the [Conflict of Interest Declaration form](https://policies.rmit.edu.au/download.php?id=162&version=3&associated).
(23)  Conflicts of interest pertaining to HDR supervision must be managed in accordance with clause 9 of the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14).
### Individuals
(24)  In declaring a conflict of interest, individuals should suggest an approach and put forward a draft plan for managing a conflict of interest in a research context to the relevant manager/s. For guidance on management strategies suitable to the level of identified risk, individuals should refer to the ‘6Rs’ of Conflict-of-interest Management, elaborated in the Guide to the Management of Conflicts of Interest. 
(25)  Individuals should work collaboratively with the relevant manager on the management of a conflict of interest, wherever appropriate.
### Managers
(26)  Managers are responsible for reviewing the approach and draft plan for managing a conflict of interest in a research context and ensuring appropriate management in compliance with the [Conflict of Interest Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90).
(27)  Managers should assess the risks a declared conflict of interest presents and develop a management plan and strategy that is appropriate for use in a research context and commensurate with risks identified.
(28)  Managers should refer to the ‘6Rs’ of conflict of interest management elaborated in the Guide to the Management of Conflicts of Interest for guidance on management strategies suitable to the level of risk identified. Managers should work collaboratively on a management plan with the individual subject of a conflict of interest declaration, wherever appropriate.
### Compliance
(29)  All individuals involved in research at RMIT have a responsibility to identify, declare and manage conflicts of interest appropriately and in line with the Australian Code and RMIT policy.
(30)  A failure to appropriately identify, declare and manage conflicts of interest in compliance with RMIT Policy may:
  1. constitute non-compliance with RMIT policy and/or the Code of Conduct and result in disciplinary action, up to and including termination of employment
  2. also constitute a breach/es of the Australian Code and result in corrective and/or disciplinary action
  3. also constitute potential criminal behaviour or conduct (i.e. corruption or fraud) and be referred by RMIT to appropriate law enforcement agencies.


(31)  Alleged breaches of RMIT Policy and the Code of Conduct will be managed in accordance with the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52) and the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122).
(32)  Alleged breaches of research integrity as established in the Australian Code will be reported and managed in accordance with the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28) and [Research Integrity Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=30).
(33)  Where it is believed that a conflict of interest involves illegal or dishonest behaviour, a report can be made to [Stopline](https://www.stopline.com.au/) in accordance with the [Whistleblower Procedure](https://policies.rmit.edu.au/document/view.php?id=48).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=265#document-top)
# Section 5 - Definitions and References
The Australian Code for the Responsible Conduct of Research | The Australian Code for the Responsible Conduct of Research (the Code) sets out principles and responsibilities of trustworthy research. It was developed by the National Health and Medical Research Council (NHMRC), the Australian Research Council (ARC) and Universities Australia.  
---|---  
Actual conflict of interest | In a research context: Where there is a real divergence between the interests of research integrity and the interests of a person or organisation.  
Perceived conflict of interest | In a research context: Where a third party could reasonably form the view that a person or organisation’s interests could improperly influence those of research integrity.  
Potential conflict of interest | In a research context: Where a person or organisation has interests that could conflict with research integrity. This refers to circumstances where it is foreseeable that a conflict may arise in future, and steps should be taken now to mitigate that risk.  
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=265#document-top)
# Section 6 - Resources
(34)  For conflicts of interest in a research context, refer to the following RMIT documents:
  1. [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91)
  2. [Conflict of Interest Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90)
  3. [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28)
  4. [Guide to Responsible Management of Conflicts of Interest in Research](https://rmitheda.force.com/Researcherportal/s/article?id=a6S7F000000bsZBUAY)
  5. [Researcher Portal – Conflicts of Interest](https://www.rmit.edu.au/staff/research/researcher-portal).


(35)  For conflicts of interest in a research training context, refer to:
  1. [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12)
  2. [Australian Council of Graduate Research Good Practice Guidelines for Disclosing and Managing Interests in Graduate Researc](https://www.acgr.edu.au/wp-content/uploads/2022/08/Combined-ACGR-Guidelines-for-Disclosing-and-Managing-Interests-in-Graduate-Research-.pdf)h.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
