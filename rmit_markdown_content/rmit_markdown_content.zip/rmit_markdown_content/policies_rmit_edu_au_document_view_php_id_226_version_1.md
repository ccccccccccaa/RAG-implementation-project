[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=226&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=226&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Data and Information Lifecycle Management Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=226)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=226&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=226&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=226&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=226&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=226&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=226&version=1)


# Data and Information Lifecycle Management Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=226&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=226&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=226&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=226&version=1#section4)
  * [Part A - Institutional Data](https://policies.rmit.edu.au/document/view.php?id=226&version=1#part1)
  * [Planning and Design](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major1)
  * [Creation and Acquisition](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major2)
  * [Management](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major3)
  * [Storage and Retention](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major4)
  * [Disposal](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major5)
  * [Part B - Research Data](https://policies.rmit.edu.au/document/view.php?id=226&version=1#part2)
  * [Part C - Unofficial Information](https://policies.rmit.edu.au/document/view.php?id=226&version=1#part3)
  * [Creation](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major6)
  * [Management ](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major7)
  * [Destruction](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major8)
  * [Responsibilities ](https://policies.rmit.edu.au/document/view.php?id=226&version=1#major9)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=226&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=226&version=1#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure documents the required steps for the effective management of RMIT Group data and information (Information) across the entire lifecycle. It applies to both Institutional and Research Data.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=226&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [](https://policies.rmit.edu.au/document/view.php?id=53)[Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=226&version=1#document-top)
# Section 3 - Scope
(3)  Throughout this procedure, RMIT means the RMIT Group. The [RMIT Group](https://rmit.collibra.com/asset/37ac775e-96e4-43e0-baa8-1d6e598820be) is RMIT University and its controlled entities (e.g. RMIT Vietnam, RMIT Europe, RMIT Online and RMIT University Pathways (RMIT UP)). 
(4)  This procedure applies to all individuals who manage, handle or process information for RMIT, including staff, students, casual employees, contractors, visitors and honorary appointees. This also includes third parties (e.g. suppliers) and agents of the organisation who are contractually bound to RMIT Policy.
(5)  This procedure applies to information in all its forms, both digital and non-electronic formats, and should be read in conjunction with the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28) and the [Information Technology and Security Policy](https://policies.rmit.edu.au/document/view.php?id=75).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=226&version=1#document-top)
# Section 4 - Procedure
## Part A - Institutional Data
(6)  Institutional Data refers to Information that is governed by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53), set out under each of the Information Domains defined in the Information Domain Register. It excludes Research Data as defined by the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28), which is covered in Part B of this procedure. 
(7)  The stages of information lifecycle applicable to Institutional Data include: Planning and Design, Creation and Acquisition, Management, Storage and Retention, and Disposal.
### Planning and Design
(8)  The Information Domain Register is established by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53). It is RMIT’s enterprise data catalogue and must be maintained by and available to everyone with responsibility for managing Institutional Data.
  1. Custodianship of sensitive information must be identified and catalogued in the Information Domain Register.
  2. Information architecture must be documented in the Information Domain Register.
  3. The authoritative source of master data and reference data must be declared and catalogued in RMIT’s Information Domain Register to enable its reuse.


(9)  RMIT’s information assets support RMIT processes and can exist in many formats (e.g. a collection of reports, a database, Information contained in a database, etc.). 
(10)  Data Management Strategies provide documented decisions and direction for the governance, accountability and maintenance of information in each information domain. Data Management Strategies will be endorsed by the Information Governance Board and approved by Information Trustees.
(11)  RMIT records must be digital unless otherwise justified. Digitisation must be lawful and authorised.
### Creation and Acquisition
(12)  Information must be created and managed to provide evidence of RMIT activities, in accordance with the Retention and Disposal Standard. 
(13)  Information must be collected in accordance with [](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/privacy/privacy-policy-and-privacy-collection-statements)[RMIT’s Privacy Statements](https://policies.rmit.edu.au/download.php?id=95&version=2&associated) and in compliance with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(14)  Information acquired from external sources for RMIT use must be governed as per Part A of this procedure. 
(15)  Copies of Institutional Data approved for research use must be governed as per Part B of this procedure.
### Management
(16)  Data structures in systems must be documented and maintained consistently and accurately in a central repository. The introduction or modification of data structures in systems must be governed by the System Administrator.
(17)  Information created, managed and used at RMIT must be of high quality and measured in accordance with RMIT’s [](https://policies.rmit.edu.au/document/view.php?id=229)[Data Quality Standard](https://policies.rmit.edu.au/document/view.php?id=229). The [](https://policies.rmit.edu.au/document/view.php?id=230&version=1)[Data Quality Guideline](https://policies.rmit.edu.au/document/view.php?id=230) provides practical guidance for staff to implement the Standard.
(18)  All projects and initiatives must consider the impact on data and ensure that appropriate data management controls are in place.
(19)  Master data refers to data that is common to different functions and is used in multiple processes. Master data usually describes entities that are participating in a transaction or event (e.g. information about a course, a person, or a location). Reference data is a type of master data that refers to data that is used to categorise other data (e.g. status codes), or related to information beyond the boundaries of the organisation (e.g. fields of study).
(20)  Master data must be managed and stored in alignment with the approach specified in the RMIT Data Management Strategies.
(21)  Common requirements for master data management across all Information Domains are:
  1. master data created, managed and used must be of high quality and there must be processes in place to ensure its quality meets expectations
  2. the data quality of master data must be tracked, managed and improved
  3. accountability and responsibility for the management of master data must be identified
  4. master data must have an identified system of record as its authoritative source
  5. master data must be properly integrated across RMIT systems to preserve integrity (i.e. via the use of a unique identifier).


### Storage and Retention
(22)  Active records refer to information that is required for current use and execution of RMIT processes.
  1. Active records must be managed in compliance with the Retention and Disposal Standard.
  2. When migrating records between systems or formats, the Information Custodian must assess the retention requirements and must ensure that the value of the records is not lost and that the records continue to be managed beyond the life of the system, for as long as they are required. 


(23)  Inactive records refer to information that is no longer required for current use and execution of RMIT processes, and has not been transferred for long term archiving and preservation.
  1. Inactive records must be stored in authoritative source systems, which are compliant and certified for long-term retention of information and must be managed in compliance with the RMIT Retention and Disposal Standard.
  2. Changes to Information Custodian responsibility and/or information classification for inactive records must be managed.


(24)  Preserved records are records that have been transferred for long term archiving and preservation.
  1. Records must be appraised and reclassified prior to preservation.
  2. Preserved records must be managed in compliance with the Retention and Disposal Standard.


### Disposal
(25)  The Retention and Disposal Standard details the requirements for disposal of information at RMIT and includes Section 5 – Retention and Disposal Authority (RDA) which specifies the required retention periods for RMIT Information.
(26)  The [Retention and Disposal Guideline](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Retention-and-Disposal-Guideline.aspx) provides instruction for compliant disposal of RMIT information.
(27)  Disposal of master data and reference data (e.g. deduplication) must preserve the referential integrity of records.
## Part B - Research Data
(28)  Research Data is defined by the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28). It refers to Information in any format generated during research undertaken by RMIT researchers (staff and students). 
(29)  The [Research Data Management Procedure](https://policies.rmit.edu.au/document/view.php?id=86) defines the lifecycle for Research Data. The procedure specifies that researchers must complete Research Data Management Plan prior to commencing research, and defines requirements for the collection; storage; ownership; access and sharing; Indigenous data sovereignty; confidentiality; retention; and destruction of Research Data.
(30)  Research Data of archival and historical value must be managed in compliance with the [Retention and Disposal Standard](https://policies.rmit.edu.au/document/view.php?id=55). 
(31)  Information submitted to RMIT by HDR candidates as part of [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18) is governed under Part A of this document.
(32)  Information submitted to RMIT by researchers as part of [Dissemination of Research Outputs Procedure](https://policies.rmit.edu.au/document/view.php?id=84#:~:text=others%27%20research%20findings.-,Dissemination%20of%20Research%20Findings,practitioners%20and%20the%20wider%20community.) is governed under Part A of this document.
## Part C - Unofficial Information
(33)  Unofficial Information refers to Information that is not covered by Part A or Part B of this procedure. Unofficial Information is unrelated to official RMIT work duties or functions (e.g. holiday photos stored on Microsoft Teams, photo of child’s birth certificate stored on OneDrive, etc.). Content in this category has no operational impact. This information is in scope of acceptable use according to the [](https://policies.rmit.edu.au/document/view.php?id=75)[Information Technology and Security Policy](https://policies.rmit.edu.au/document/view.php?id=75).
### Creation
(34)  Unofficial Information should only be created or stored on RMIT systems when necessary.
(35)  When Unofficial Information is used for RMIT purposes, it may become Institutional Data or Research Data and must be treated according to Part A or Part B as appropriate.
(36)  The [](https://policies.rmit.edu.au/document/view.php?id=76)[Acceptable Use Standard- Information Technology](https://policies.rmit.edu.au/document/view.php?id=76) outlines both acceptable and unacceptable use of RMIT information technology for the storage of unofficial information.
### Management 
(37)  Unofficial Information should be minimised as the storage of such may carry additional risk and costs for RMIT.
(38)  RMIT systems must not be the authoritative source of unofficial information. 
### Destruction
(39)  Unofficial information will be destroyed before or at termination of engagement between RMIT and the Information Custodian.
### Responsibilities 
(40)  Refer to the relevant policy.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=226&version=1#document-top)
# Section 5 - Resources
(41)  Refer to the following documents which are established in accordance with this procedure:
  1. [Retention and Disposal Standard](https://policies.rmit.edu.au/document/view.php?id=55)
  2. [Retention and Disposal Guideline](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Retention-and-Disposal-Guideline.aspx)
  3. [](https://policies.rmit.edu.au/document/view.php?id=229)[Data Quality Standard](https://policies.rmit.edu.au/document/view.php?id=229)
  4. [](https://policies.rmit.edu.au/document/view.php?id=230)[Data Quality Guideline](https://policies.rmit.edu.au/document/view.php?id=230)
  5. [](https://policies.rmit.edu.au/document/view.php?id=161)[Source Data Extract Controls Standard](https://policies.rmit.edu.au/document/view.php?id=161)
  6. [](https://policies.rmit.edu.au/download.php?id=220&version=3&associated)[Master Data Management Standard](https://policies.rmit.edu.au/document/view.php?id=162)
  7. [Data Management Strategies](https://rmiteduau.sharepoint.com/sites/Analytics&Insights/Policy%20resources/Forms/AllItems.aspx?RootFolder=%2Fsites%2FAnalytics%26Insights%2FPolicy%20resources%2FData%20Management%20Strategies&FolderCTID=0x012000D8CEBCB15FC15E48973A1A5C8412E784)
  8. [RMIT ](https://policies.rmit.edu.au/document/view.php?id=86)[Research Data Management Procedure](https://policies.rmit.edu.au/document/view.php?id=86)
  9. [Acceptable Use Standard – Information Technology](https://policies.rmit.edu.au/document/view.php?id=76)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=226&version=1#document-top)
# Section 6 - Definitions
Term | Definition  
---|---  
Digitisation | Digitisation is the conversion of a physical or analogue record to a digital representation.  
Disposal |  The range of processes associated with implementing appraisal decisions which are documented in disposal authorities or other instruments. These include: 
  1. the retention, destruction or deletion of records in or from recordkeeping systems 
  2. the migration or transmission of records between recordkeeping systems 
  3. the transfer of ownership or the transfer of custody of records (for example, to Public Records Office Victoria) 

The lawful disposal of records is an essential and critical component of any records management program.  
Information asset | A body of information, defined and practically managed so it can be understood, shared, protected and used to its full potential.  
Record | is a set of information that will have been created, collated, received or maintained as evidence while conducting the business of RMIT and/or in pursuance of legal obligations.  
Sensitive Information | Defined by the RMIT Privacy Policy in line with Schedule 1 of the Privacy and Data Protection Act 2014 (Vic).  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
