[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=185&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=185&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Controlled and Non-Controlled Entity Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=185)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=185&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=185&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=185&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=185&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=185&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=185&version=1)


# Controlled and Non-Controlled Entity Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=185&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=185&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=185&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=185&version=1#section4)
  * [Proposal for Establishment of a Controlled Entity](https://policies.rmit.edu.au/document/view.php?id=185&version=1#major1)
  * [Proposal for Participation in a Non-Controlled Entity](https://policies.rmit.edu.au/document/view.php?id=185&version=1#major2)
  * [Nominations and Remuneration of Directors of a Controlled Entity](https://policies.rmit.edu.au/document/view.php?id=185&version=1#major3)
  * [Reporting](https://policies.rmit.edu.au/document/view.php?id=185&version=1#major4)
  * [Operations](https://policies.rmit.edu.au/document/view.php?id=185&version=1#major5)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=185&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
Procedures for the formation, management or participation in an Entity by the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=185&version=1#document-top)
# Section 2 - Authority
(1)  Authority for this document is established by the [Controlled and Non-Controlled Entity Policy](https://policies.rmit.edu.au/document/view.php?id=184).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=185&version=1#document-top)
# Section 3 - Scope
(2)  This procedure applies to all Entities within, or proposed to be within, the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=185&version=1#document-top)
# Section 4 - Procedure
### Proposal for Establishment of a Controlled Entity
(3)  A proposal submitted by the Vice-Chancellor (VC) in accordance with the Policy for the formation or management of, or participation in, a Controlled Entity must include:
  1. rationale for the proposal in accordance with the required purposes of the Policy
  2. a detailed financial and legal due diligence report in accordance with the [Controlled Entity Guidelines](https://policies.rmit.edu.au/document/view.php?id=186)
  3. a business plan for the Controlled Entity
  4. draft governing documents that comply with any legislative requirements and include reference to the reporting obligations of the Controlled Entity to RMIT University Council
  5. a detailed risk assessment in accordance with the [Controlled Entity Guidelines](https://policies.rmit.edu.au/document/view.php?id=186)
  6. proposed members of the governing body of the Controlled Entity.


(4)  Appropriate care should be taken when drafting contracts (Refer to the Contract Policy)to ensure controlled entities are not inadvertently established.
### Proposal for Participation in a Non-Controlled Entity
(5)  A proposal submitted by the Vice-Chancellor in accordance with the Policy for the participation in a Non-Controlled Entity must include:
  1. rationale for the proposal
  2. details of any financial or other commitments by the University
  3. governing documents that comply with any legislative requirements
  4. a detailed risk assessment
  5. proposed members of the governing body of the Non-Controlled Entity.


### Nominations and Remuneration of Directors of a Controlled Entity
(6)  Nominations for directorship of a Controlled Entity must:
  1. be made to RMIT University Council (Council) by the VC in a form specified by the University Secretariat
  2. provide details that the proposed director possesses the necessary skills, knowledge and experience necessary to enable the Board of the Controlled Entity to provide proper stewardship and control of the Entity
  3. detail any proposed remuneration arrangements.


(7)  Remuneration of directors of Controlled Entities must be approved by the Chief People Officer and the VC.
(8)  The directors of a Controlled Entity will appoint a Company Secretary or any jurisdictionally equivalent company secretarial position in accordance with the Guidelines.
### Reporting
(9)  Controlled Entities must provide the following to Council or its nominated Subcommittee:
  1. financial statements in a form required by the Chief Financial Officer(quarterly)
  2. safety, risk, insurance, audit and operations report (quarterly)
  3. business plan (annual)
  4. budget, as approved by the Chief Financial Officer (annual)
  5. report of performance against annual business plan, as approved by the VC (annual)
  6. audit and risk report in a form required by the Director, Risk Management (annual)
  7. assurance statement as defined by the Director, Risk Management (annual)
  8. report on commercial activities (annual)
  9. access to the annual financial statements.


(10)  To the extent that the entity undertakes academic or research activities, a report of activities is periodically provided to the Academic Board, in a form required by the Chair, Academic Board. 
(11)  Controlled Entities and the relevant VCE member responsible for a Non-Controlled Entity must immediately advise the VC and Director, Risk Management if there are any:
  1. possible or actual extreme risks as identified by the risk management framework 
  2. actual or possible insurance claims
  3. significant changes to entity performance.


(12)  Controlled Entities and the relevant VCE member responsible for a Non-Controlled Entity must immediately advise the VC and the Executive Director, Governance, Legal and Strategic Operations if there is any actual, threatened or potential litigation which is likely to have a material effect on the Controlled Entity, Non-Controlled Entity or the University.
### Operations
(13)  The Board of Directors must ensure that the Management Committee operates the Controlled Entity in accordance with:
  1. any applicable laws and regulatory requirements
  2. policies of the University, including, without limitation, the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=185&version=1#document-top)
# Section 5 - Resources
(14)  Refer to the following documents which are established in accordance with this procedure:
  1. [Controlled Entity Guideline](https://policies.rmit.edu.au/document/view.php?id=186)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
