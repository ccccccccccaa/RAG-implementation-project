[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=117#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=117#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Remission and Removal of Debt Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=117)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=117)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=117)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=117)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=117)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=117)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=117)


# Remission and Removal of Debt Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=117#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=117#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=117#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=117#section4)
  * [Eligibility](https://policies.rmit.edu.au/document/view.php?id=117#major1)
  * [Criteria for Special Circumstances](https://policies.rmit.edu.au/document/view.php?id=117#major2)
  * [Assessment](https://policies.rmit.edu.au/document/view.php?id=117#major3)
  * [Application Requirements](https://policies.rmit.edu.au/document/view.php?id=117#major4)
  * [Application Receipt and Outcome](https://policies.rmit.edu.au/document/view.php?id=117#major5)
  * [Request for Review](https://policies.rmit.edu.au/document/view.php?id=117#major6)
  * [Provision of False or Misleading Information or Documentation](https://policies.rmit.edu.au/document/view.php?id=117#major7)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  Students who are prevented from completing a course due to special circumstances may apply for a remission or removal of debt or tuition fee liability, or refund or re-credit of paid upfront fees.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=117#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=117#document-top)
# Section 3 - Scope
(3)  This procedure applies to Commonwealth supported students, and upfront fee-paying students including international students.
(4)  This procedure does not apply to students enrolled in Open Universities Australia, RMIT Partnership programs or ELICOS at RMIT University Pathways (RMIT UP).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=117#document-top)
# Section 4 - Procedure
### Eligibility
(5)  A student is eligible to apply for a remission or removal of debt if they:
  1. withdrew from a course after the relevant class enrolment census date; and/or
  2. were prevented from completing a course; and
  3. demonstrate the special circumstances prescribed in clauses (11) to (16) of this procedure.


(6)  Students who meet the eligibility criteria defined in clause (5) may apply for:
  1. remission of their HECS-HELP, FEE-HELP or VET Student Loan debt for that course; and/or
  2. a re-credit or refund of their upfront student contribution payment for that course.


(7)  There is no refund of any up-front paid [Student services and amenities fee (SSAF)](https://policies.rmit.edu.au/download.php?id=138&version=1&associated) or remission of SA-HELP debt after the census date.
(8)  Conditions for applying for remission of debt are prescribed in accordance with applicable legislation.
(9)  RMIT will consider applications where a student can demonstrate that their special circumstances:
  1. were beyond their control
  2. did not make their full impact on the student until on, or after, the census date, and
  3. made it impracticable for the student to complete the requirements for the course during the period in which they undertook (or were to undertake) the course.


(10)  No remission will be considered where a course has been successfully completed.
### Criteria for Special Circumstances
(11)  Special circumstances are considered beyond a student’s control if each of the following conditions is met:
  1. a reasonable person would consider the situation is not due to the student’s direct or indirect action or inaction
  2. the situation is unusual, uncommon, or abnormal
  3. the student is not responsible for the situation.


(12)  Special circumstances are considered not to have made their full impact on the student until on or after the relevant census date if those circumstances presented:
  1. before the census date but worsened after that date
  2. before the census date, but the full effect or magnitude did not become apparent until after that date
  3. on or after the census date.


(13)  Special circumstances that may have made it impracticable for a student to complete course requirements include:
  1. medical circumstances (e.g. where the student’s medical condition has changed to such an extent that they are unfit and unable to continue studying)
  2. family/personal circumstances (e.g. death or severe medical problems within a family, or unforeseen family financial difficulties, so that it is unreasonable to expect a student to continue studies)
  3. employment-related circumstances (e.g. where a student’s employment status or arrangements have changed to the extent that they are unable to continue study and this change is beyond their control); these circumstances do not apply to international students with visas that specify restriction(s) on employment
  4. program-related circumstances (e.g. where RMIT has changed the course it had offered and the student is disadvantaged by either not being able to complete the course or not being given credit upon successful completion towards other courses or programs).


(14)  A student’s inability to complete course requirements may include being unable to:
  1. undertake the necessary private study required, or attend sufficient lectures or tutorials or meet other compulsory attendance requirements in order to meet the compulsory course requirements complete the required assessable work
  2. sit the required examinations
  3. complete any other course requirements as a result of the special circumstances detailed in clause (13).


(15)  Special circumstances do not include:
  1. lack of knowledge or understanding of requirements under this procedure
  2. an applicant’s incapacity to repay a HELP debt.


(16)  A student does not need to demonstrate they were prevented from withdrawing from the unit prior to the census date.
### Assessment
(17)  RMIT will consider whether it was already apparent the student would not meet course requirements at the time the special circumstances emerged.
(18)  If a student has not met the ongoing compulsory requirements of the course, their failure to sit the final examination (and/or deferred examination) does not of itself make it impracticable for them to complete the course. In this case RMIT may decide not to remit/re-credit/refund.
(19)  The requirements for continuous assessment and attendance must be explicitly stated in the University’s rules prior to course commencement and substantiated as required.
### Application Requirements
(20)  Eligible students seeking remission of debt or fee liability must submit an [Application for remission of debt in special circumstances](https://policies.rmit.edu.au/download.php?id=134&version=2&associated) with all required supporting documentation:
  1. within 12 months of the relevant course end date; or
  2. if the student withdrew from the course, within 12 months from the date of that withdrawal.


(21)  RMIT may waive this requirement at its discretion where an applicant demonstrates the application could not be made within relevant time limits.
(22)  Applications must be supported with documentation from an independent source or authority which clearly addresses:
  1. the circumstances upon which the application is based
  2. the affected dates/duration of the circumstances
  3. the level of impact the circumstances had upon the student’s ability to complete the course.


(23)  Supporting documentation must be in English. If supporting documentation is in a language other than English, an authorised translation into English completed by a NAATI-accredited translator must also be submitted.
(24)  A personal statement alone is not sufficient to support an application for remission of debt.
(25)  Statutory declarations are not accepted as supporting documentation.
### Application Receipt and Outcome
#### Notification
(26)  RMIT will acknowledge receipt of an application by email within three working days of submission.
(27)  The outcome notification, reasons for the determination and advice on review opportunities will be provided by email within 60 calendar days from the date of receipt.
#### Successful Application Outcome
(28)  If an application for remission of debt is approved, RMIT will notify the relevant regulatory authorities as required.
(29)  Eligible students will be advised of their eligibility to apply for a refund (via the [Refund of Fees Procedure](https://policies.rmit.edu.au/document/view.php?id=118)).
(30)  RMIT reserves the right to credit any excess fees against current and future semester enrolment liabilities, except where otherwise defined by legislation, or where the student specifically requests a refund of credit via the [Refund of Fees Procedure](https://policies.rmit.edu.au/document/view.php?id=118).
(31)  Students who receive a successful outcome will receive an academic grade of RSC (Remission (removal) of debt under Special Circumstances).
(32)  The RSC grade does not count towards completion of a program and is not included in the calculation of Grade Point Average (GPA) or Weighted Average Mark (WAM).
### Request for Review
(33)  RMIT provides one opportunity for students to seek a review of the original decision.
(34)  A request for a review must:
  1. be lodged no later than 28 calendar days from receiving the outcome advice
  2. if it lodged outside 28 calendar days, specify the impact that the student’s circumstances have had on their capacity to meet the 28-calendar day deadline for the purpose of assessment under cl (41) – (44), including any supporting documentation
  3. quote the file/reference number provided at the top of the outcome notification
  4. be in writing and state the reason(s) for requesting a review


(35)  Students are not required to provide further evidence with a request for review of the original decision but should carefully consider whether such evidence would support the submission.
(36)  RMIT will acknowledge receipt of a review request by email within three working days of submission.
(37)  The review will be undertaken by a staff member who was not involved in the original outcome decision. 
(38)  RMIT will notify the student of the review outcome to either:
  1. confirm the original outcome
  2. vary the original outcome
  3. set the original outcome aside and make a new decision/s.


(39)  The review outcome notification will be provided by email within 28 calendar days from the date of receipt. If the review outcome is unsuccessful, this notification will include the reasons for the determination and advice on external review opportunities.
(40)  Resubmission of an application for the same course/s is not permitted where a denied outcome has already been provided
  1. these applications will not be processed; and
  2. students must instead use the review process available to them.


#### Request for Review Received Outside the 28 Calendar Day Timeframe
(41)  RMIT may exercise discretion in considering requests for a review received later than 28 calendar days from receiving outcome advice on the original application in accordance with RMIT’s aspirations for inclusion, diversity, equity and access.
(42)  In considering whether to exercise discretion to accept a late review request, RMIT must consider any impact the student’s circumstances as specified in their request for review under cl (34) have had on their capacity to meet the 28 calendar day deadline.
(43)  Applications to accept a late review request may be considered when exceptional circumstances outside the student’s control preventing timely submission are established with supporting documentation. These circumstances may include:
  1. where a student was or became incapacitated, or experienced an exacerbation of an existing condition that prevented timely submission, or
  2. where they made a genuine effort to submit the review request during the timely review period, but the application did not reach RMIT for reasons outside of their control.


(44)  A staff member who was not involved in the original decision will consider a late application for review based on:
  1. the time elapsed since the 28 calendar day timeframe
  2. whether the reason/s provided for the late review request are considered valid and exceptional circumstances
  3. the supporting evidence provided in relation to the late review request submission.


(45)  If a late submission for a review is accepted, the review will be conducted in accordance with cl. (36) – (39). If a late submission for review is not accepted, the original outcome will be confirmed in accordance with cl (38).
(46)  Students may request a further and final review of a decision not to accept a late review submission by the senior officer of the operational unit where the original application was submitted:
  1. for Enrolment and Student Records: Associate Director
  2. for Integrity and Assessment Support: Associate Director
  3. for Integrity and Assessment Support (Vietnam): Associate Registrar.


(47)  A further and final review request must:
  1. be made no later than 10 calendar days from receiving the outcome advice
  2. quote the file/reference number provided at the top of the outcome notification
  3. be in writing and state the reason(s) for requesting a further and final review.


(48)  A further and final review will be assessed in accordance with cl (42) - (45), with consideration given to any reasons specified in the request for further and final review.
(49)  There is no further opportunity for review of late review request submissions.
#### External Review
(50)  Students who are dissatisfied with the original outcome or outcome of a timely review determination may seek external review. There is no opportunity for further internal review.
(51)  Students are advised of available external review opportunities with original outcomes and review determinations.
### Provision of False or Misleading Information or Documentation
(52)  Where it is determined that a student has provided false or misleading information or documentation in their application for remission of debt, RMIT will:
  1. notify the student immediately
  2. cease any further action with regards to the application
  3. refer the matter in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).


(53)  RMIT will notify government departments of any suspected offences as appropriate and will provide a copy of the student’s application and any other relevant information or material as requested.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
