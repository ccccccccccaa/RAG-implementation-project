[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=248#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=248#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Gender-Based Violence Response Procedure - Vietnam 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=248)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=248)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=248)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=248)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=248)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=248)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=248)


# Gender-Based Violence Response Procedure - Vietnam
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=248#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=248#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=248#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=248#section4)
  * [Disclosures](https://policies.rmit.edu.au/document/view.php?id=248#major1)
  * [Ways to make a disclosure](https://policies.rmit.edu.au/document/view.php?id=248#major2)
  * [Informal Process](https://policies.rmit.edu.au/document/view.php?id=248#major3)
  * [Ways to make a formal report](https://policies.rmit.edu.au/document/view.php?id=248#major4)
  * [Precautionary measures](https://policies.rmit.edu.au/document/view.php?id=248#major5)
  * [Investigations](https://policies.rmit.edu.au/document/view.php?id=248#major6)
  * [False reports](https://policies.rmit.edu.au/document/view.php?id=248#major7)
  * [Privacy, confidentiality and record keeping](https://policies.rmit.edu.au/document/view.php?id=248#major8)
  * [Internal reporting and continuous improvement](https://policies.rmit.edu.au/document/view.php?id=248#major9)
  * [External reporting](https://policies.rmit.edu.au/document/view.php?id=248#major10)
  * [Section 5 - Compliance](https://policies.rmit.edu.au/document/view.php?id=248#section5)
  * [Section 6 - Other Relevent Policies](https://policies.rmit.edu.au/document/view.php?id=248#section6)
  * [Section 7 - Definitions](https://policies.rmit.edu.au/document/view.php?id=248#section7)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This procedure documents how RMIT Vietnam will support victim-survivors and respond to matters involving gender-based violence and harm.
(2)  This procedure should be read in conjunction with the RMIT policies regarding behavioural standards and conduct which are listed in Section 6 below. Policies and procedures from relevant third parties may also apply in some circumstances (for example, the policies of industry partners hosting students on placement).
(3)  While people of all genders can experience gender-based violence, harm, or abuse, the terms are most often used to describe violence and against women, girls, and LGBTIQA+ people.
(4)  This procedures is part of a policy suite that demonstrates RMIT’s commitment to addressing gender-based harm, gender-based violence, sexual assault and sexual harassment, intimate partner violence, domestic and/or family violence, and other related forms of violence and harm. This commitment includes building a culture of respect, collective care and safety to address the intersecting forms of inequality and disrespect that contribute to violence.
(5)  RMIT acknowledges that intersectionality can compound the impact of discrimination and that certain groups of people will be more vulnerable to the effects of discrimination and harassment than other groups.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248#document-top)
# Section 2 - Authority
(6)  Authority for this document is established by the [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248#document-top)
# Section 3 - Scope
(7)  This procedure applies to all members of the RMIT community, including staff, students and associates (governing body members, representatives, and volunteers) of RMIT Vietnam.
(8)  Third parties are in the scope of this policy where there is a connection with RMIT such as contractors, licensees or lessees, service providers, visitors, international education agents and delivery partners, and partner organisations in Australia or overseas acting for or on behalf of RMIT Vietnam in relation to our students and staff.
(9)  If gender-based violence or harm is reported outside the scope of this procedure, RMIT will provide referrals to appropriate support services.
(10)  The [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) takes precedence over this procedure to the extent of any inconsistency regarding harm to children.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248#document-top)
# Section 4 - Procedure
### Disclosures
(11)  A disclosure refers to the sharing of information about an experience of gender-based violence or harm, which can be made to [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) and Wellbeing team staff. This procedure refers to disclosures made to anyone listed in the policy scope.
(12)  Anyone connected to RMIT Vietnam, including third parties, are supported to make a disclosure to [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) and Wellbeing team staff without fear of sanction or inaction. RMIT Vietnam’s timely response and resolution may depend on the victim-survivor’s willingness to participate in the process.
(13)  All RMIT Vietnam staff receiving a disclosure must inform the discloser about support from [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community). Staff must notify [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) of the disclosure to support RMIT’s whole-of-organisation prevention and support strategies. Staff must inform the discloser of the obligation to notify [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) and seek consent on what information can be shared, including anonymity preferences.
(14)  If gender-based violence or harm is disclosed or reported as occurring outside the scope of this procedure, RMIT Vietnam will provide referrals to specialist support services as appropriate.
### Ways to make a disclosure
(15)  In an emergency or in circumstances of immediate danger on campus, please contact RMIT 24/7 Security Hotline: 1800 2233. 
  1. If the concern arises during [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) working hours (Monday-Friday, 9am-4pm), contact RMIT Vietnam Safer Community Hotline (028) 362 24449
  2. If the concern arises after Safer Community working hours, contact International SOS: (028) 3829 8520


(16)  All persons including staff members, students, researchers, representatives and volunteers who have experienced gender-based harm can contact [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community).
(17)  Individuals wanting to make an informal or formal report of gender-based harm can contact [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) for guidance. [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) provides specialist evidence-based, trauma-informed, safety first, and inclusive and intersectional support and advice regardless of:
  1. where or when the violence or harm occurred, and
  2. whether the person wants to make a disclosure of violence or harm, or
  3. whether the person wants to make a formal report about it.


(18)  [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) offers information on reporting procedures, which may vary depending on the individual's status (student, staff, or third party) and the status of the respondent.
(19)  Students may report an incident of gender-based violence or harm under this Procedure or the Student and Student-Related Complaints Procedure. If not satisfied with RMIT’s response, students may make a complaint to the National Student Ombudsman in Australia.
(20)  Staff may report an incident of gender-based violence or harm under this Procedure or the Staff Complaints Procedure.
(21)  Third parties may report an incident of gender-based violence or harm under this Procedure or the Third Party Complaints Procedure. 
(22)  All disclosures and/or reports made through [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) and the [Complaints Portal](https://www.rmit.edu.vn/utilities/complaints) in Vietnam will receive a response within one business day. 
### Informal Process
(23)  Where a disclosing or reporting person wishes to resolve a matter informally, RMIT may utilise processes that focus on the resolution of the issue rather than the substantiation of the report through a full investigation, such as restorative engagement processes.
(24)  RMIT Vietnam [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) will offer support to all persons who are affected by a disclosure or report of gender-based harm, including persons who make disclosures or reports, as well as the person about whom a report is made. Support may include:
  1. undertaking a risk assessment based on evidence-based factors and support development of safety planning using protective factors including the threat posed to the provider’s community following a disclosure and take appropriate action
  2. offering information, resources, and support using a specialist evidence-based, trauma-informed, safety-first, and inclusive & intersectional approach which also aims to minimise the need for victim-survivors to repeatedly share their stories. It includes arrangements for sharing information on incidents of gender-based violence between higher education providers and student accommodation providers
  3. listening to the discloser(s) and talk through what supports are available, including options associated with informal or formal processes
  4. providing information and support in how to report directly to police
  5. providing information and referrals to specialist services outside of the university to ensure all victim-survivors and perpetrators have access to expert-led support specific to their experiences
  6. providing a referral for a support person to attend meetings for reassurance and emotional support
  7. referring a person to a relevant representative body or support organisation.
  8. [staff wellbeing services](https://www.rmit.edu.au/staff/service-connect/safety-wellbeing/mental-wellbeing) and/or [student counselling services](https://www.rmit.edu.au/students/support-services/health-safety-wellbeing/mental-health-counselling/counselling), privately sourced counselling services, or [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community), or
  9. other support mechanisms or facilities as appropriate.


### Ways to make a formal report
(25)  Individuals who disclose gender-based violence or harm may choose to make a formal report, but it is not mandatory. A formal report involves providing a statement about the incident and seeking a formal timely resolution and response from RMIT Vietnam.
(26)  If a person who has experienced gender-based violence or harm wants to make a report to the police, [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) can support a person to make the report. However, Safer Community cannot make a police report on that person’s behalf. [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) support, includes support to a person who is not a Vietnamese speaker from Safer Community Advisors who are qualified and trained specialists who speak English and Vietnamese.
(27)  In certain circumstances, RMIT Vietnam may have a duty to notify the police in its own name, even if the individual does not wish to. This may occur where there is a serious or imminent risk to safety, or to meet RMIT’s legal obligations particularly related to [Department of Foreign Affairs and Trade (DFAT) Preventing Sexual Exploitation, Abuse and Harassment Policy (2019)](https://www.dfat.gov.au/international-relations/themes/preventing-sexual-exploitation-abuse-and-harassment). See clause 53 below for more details.
(28)  A notification to the police by RMIT in its own name must be approved by the Chief Operating Officer (if the respondent is a staff member and/or a third party) and Academic Registrar (if the respondent is a student), taking into account:
  1. evidence of an unacceptable risk to RMIT’s community, or the public
  2. multiple disclosures, reports, or complaints about the same person
  3. advice from the Critical Incident Management Team in accordance with the [Business Resilience Policy](https://policies.rmit.edu.au/document/view.php?id=67), and other relevant groups including [Health, Safety and Wellbeing](https://www.rmit.edu.au/students/support-services/health-safety-wellbeing), [Risk Management](https://www.rmit.edu.au/students/student-life/rights-responsibilities/risk-management), [Compliance](https://www.rmit.edu.au/about/governance-management/compliance), the Academic Registrar's Group, and Legal Services.
  4. advice from [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community).
  5. the wishes of the person who has experienced the gender-based violence or harm or who made the disclosure or report initially.


(29)  [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) in collaboration with the People team will advise staff who have disclosed or reported the gender-based violence or harm about RMIT’s decision to notify the police and, to the extent possible, will keep the person informed of any actions that result from that notification.
(30)  Persons who make a report, as well as persons who are the subject of a report, will be provided with information about the steps involved for any formal or informal resolution process, and they will be kept appropriately informed about the progress and outcome of those steps in accordance with the relevant policy and procedure.
### Precautionary measures
(31)  [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) may recommend certain temporary or precautionary measures in response to a report of gender-based violence or harm whilst a formal investigation into the incident takes place. This is to protect the wellbeing and safety of all students, staff, and third parties, and where there may be an ongoing risk to the broader RMIT community. [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) will consult with the relevant areas of RMIT in implementing appropriate precautionary measures, including Health, Safety and Wellbeing, Risk Management, Compliance, the Academic Registrar's Group, Legal Services, and Property Services Group.
(32)  In managing a response to a critical incident, the [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) team will provide expert advice and guidance to the Critical Incident Management Team (or equivalent) in [Risk Management](https://www.rmit.edu.au/students/student-life/rights-responsibilities/risk-management), to inform the management of risks and issues associated with gender-based violence and harm.
(33)  Where one or more of the persons involved as respondents or complainants in a report of gender-based violence or harm is a student with RMIT Vietnam, precautionary measures that can be directed by the [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) team may include but are not limited to:
  1. changes to class timetables and class locations
  2. temporary remote learning arrangements
  3. temporary restriction of access to campus
  4. academic adjustments
  5. ‘no contact’ directives
  6. a recommendation regarding an executive suspension, in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), the [Student Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=106), and the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180).


(34)  Where one or more of the persons involved as respondents and/or complainants in a report of gender-based violence or harm is an RMIT Vietnam staff member, precautionary measures that can be implemented through the Policy and Workplace Relations team may include adjustments to working arrangements.
(35)  Precautionary measures are not a punitive measure and do not indicate that RMIT has concluded that a breach of the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52) or the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) has occurred.
### Investigations
(36)  Where a report of gender-based violence or harm involves repeated conduct by a perpetrator, or where the harm or conduct is of a more serious nature, it will be more appropriate to use formal procedures which are directed at establishing whether a report is substantiated. RMIT Vietnam may be required to pause or temporarily suspend certain investigations, if required to do so by police or by other external regulators or authorities.
(37)  [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) will investigate all formal reports/disclosures of gender-based violence and harm through a specialist Senior Investigator, with support from fully qualified and trained Gender Based Violence Advisors for students and with support from Human Resources Employees for staff.
(38)  There are some circumstances where RMIT Vietnam may take action in relation to a disclosure, even if the discloser does not want to make a formal report or have any further action taken. This may occur where there is a serious or imminent risk to the safety of others, or to meet RMIT’s legal obligations. To the extent possible, RMIT will take measures to avoid identifying the victim-survivor. Where such matters involve alleged criminal conduct, RMIT may contact the police and suspend any action under this procedure pending a police investigation.
(39)  RMIT Vietnam will complete the investigation, disciplinary action, and outcomes within a reasonable timeframe from the formalisation of the investigation. However, this timeline may be extended when there are extenuating circumstances such as the need for additional time for coordination and communication when there are external processes and providers, the availability of key participants, the complexity of the case, or any legal proceedings that may impact the timeline.
(40)  RMIT Vietnam will continue to provide appropriate and reasonable assistance and support to prioritise and protect the safety and wellbeing of all parties after the conclusion of any investigative or disciplinary action, including the recovery of any person who has been sexually harmed or assaulted. 
### False reports
(41)  Any person who knowingly makes a false report of gender-based violence or harm may be subject to disciplinary action in accordance with RMIT regulations, policies and procedures.
### Privacy, confidentiality and record keeping
(42)  Disclosures and formal reports of gender-based violence or harm will be handled confidentially in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59). Information may be shared on a need-to-know basis with appropriate RMIT officers or external authorities as part of RMIT’s duty of care obligations or as required by law.
(43)  [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) maintains a confidential register of disclosures and formal reports. All information will be collected, stored, and accessed per RMIT’s [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) and applicable laws. RMIT will also use de-identified, collated data from these disclosures and formal reports to provide high-level, public-facing reporting on known incidents of gender-based violence and harm.
(44)  RMIT will use de-identified data from disclosures and reports to inform preventive interim safety measures, if necessary, to focus on the level and nature of the risk as part of assessment and proactive ongoing monitoring.
(45)  In limited cases information will be provided to the Chief Operating Officer to inform internal decision-making, these may include matters where serious sexual assault has occurred on campus, emergency services have been involved and here a staff member may be temporarily stood down from duties for the purposes of an investigation. Where possible identifying details of the impacted parties will be protected by Safer Community.
(46)  There are some limited circumstances in which RMIT may be required by law to report an incident to the police or a regulator. This may include sharing identifying information about a person who has made a disclosure or report of gender-based violence or harm or about whom the disclosure or report has been made, for the safety and wellbeing of the members of the RMIT Vietnam community, including for the safety of the person identified.
### Internal reporting and continuous improvement
(47)  The Director, Health Safety and Wellbeing immediately advises the Chief Operating Officer when a sexual assault is reported to Safer Community – RMIT University or when any incidents are reported to the Police.
(48)  The Chief People Officer advises the Chief Operating Officer if there has been a termination of employment because of staff misconduct.
(49)  De-identified data will be reported by Health, Safety and Wellbeing every six months, or as required, to the [Vice-Chancellor’s Advisory Group on Gendered Violence Prevention](https://www.rmit.edu.au/about/our-locations-and-facilities/facilities/safety-security/safe-respectful-community), RMIT University Council (Council), and other areas of RMIT as required. Access to this information will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59). The reports:
  1. identify trends and systemic issues
  2. contribute to evaluation of prevention programs, and
  3. identify opportunities for improvements and preventative actions.


(50)  RMIT may provide information to a third party for investigation purposes in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and Staff [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52). Where a requirement to make a report to a third party exists and this information is not able to be provided in a de-identified format, the individual will be consulted prior to the report being made and every effort taken to respect privacy and minimise trauma.
### External reporting
(51)  RMIT will also provide de-identified data to external agencies or bodies, where required, to ensure compliance with legislated reporting requirements including but not limited to those detailed under the [Gender Equality Act 2020](https://policies.rmit.edu.au/directory/summary.php?legislation=48) (Vic) and the[ Workplace Gender Equality Act 2012 (Cth)](https://www.legislation.gov.au/C2004A03332/latest/text). Access to this information will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(52)  If disclosed or reported incidents indicate material breaches in safety or preventative controls, including recurring incidents of gender-based harm, [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) will notify the Director, Education Regulation immediately to determine if it is appropriate to notify the [Tertiary Education and Quality Standards Agency (TEQSA)](https://www.teqsa.gov.au/). If deemed appropriate, a recommendation will be made to the Deputy Vice-Chancellor Education that TEQSA be notified within 14 days of the incident in accordance with Higher Education Standards Framework 2021 and the TEQSA Material Change Notification Policy.
(53)  If disclosed or reported incidents occurred in relation to an activity funded in whole or in part by the Department of Foreign Affairs and Trade (DFAT), [Safer Community - RMIT University](https://www.rmit.edu.vn/students/support/wellbeing-support/safer-community) will notify the Director, Health, Safety and Wellbeing, who will determine if it is appropriate to notify DFAT. If deemed appropriate, a recommendation will be made to the Chief People Officer that DFAT be notified in accordance with the [Department of Foreign Affairs and Trade (DFAT) Preventing Sexual Exploitation, Abuse and Harassment Policy (2019)](https://www.dfat.gov.au/international-relations/themes/preventing-sexual-exploitation-abuse-and-harassment). This notification must be made within two working days of RMIT becoming aware of an alleged incident.
(54)  The Vice-Chancellor and the University Executive Committee are responsible for meeting the obligations of the Reportable Conduct Scheme by reporting to all relevant child safety authorities within a set period if they become aware of a report of child abuse by an RMIT staff, student or associate.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248#document-top)
# Section 5 - Compliance
(55)  Reports of non-compliance with this procedure should be made in accordance with the [Compliance Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=50).
(56)  A breach of this procedure may result in disciplinary action in accordance with the Internal Labour Rules. Depending on the nature and impact of the breach, other actions may also be instigated, including legal action.
(57)  In cases where non-compliance issues arise, the RMIT Vietnam will utilise various investigative tools to actively monitor and address these issues. This may include:
  1. conducting proactive audits
  2. undertaking investigations when non-compliance is suspected.


(58)  This procedure supports RMIT’s compliance obligations regarding:
  1. [Charter of Human Rights and Responsibilities Act 2006 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=46)
  2. [Child Wellbeing and Safety Act 2005 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=47)
  3. [Gender Equality Act 2020 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=48)
  4. [Protected Disclosure Act 2012 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=24)
  5. [Respect@Work – Changes to the Sex Discrimination Act 1984 and the Australian Human Rights Commission Act](https://policies.rmit.edu.au/download.php?id=501&version=2&associated) [1986](https://policies.rmit.edu.au/download.php?id=501&version=2&associated)
  6. [Department of Foreign Affairs and Trade (DFAT) Preventing Sexual Exploitation, Abuse and Harassment Policy](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.dfat.gov.au%2Finternational-relations%2Fthemes%2Fpreventing-sexual-exploitation-abuse-and-harassment&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326788109%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=Fsi4lqRTZHkPS6j9TfydiFJbSQzsmqEqL%2Bnwpg8Nshw%3D&reserved=0) [(2019)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.dfat.gov.au%2Finternational-relations%2Fthemes%2Fpreventing-sexual-exploitation-abuse-and-harassment&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326788109%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=Fsi4lqRTZHkPS6j9TfydiFJbSQzsmqEqL%2Bnwpg8Nshw%3D&reserved=0)
  7. [Higher Education Standards Framework 2021](https://policies.rmit.edu.au/directory/summary.php?legislation=44)
  8. [Education Services for Overseas Students (ESOS) Framework](https://www.education.gov.au/esos-framework)
  9. [Occupational Health and Safety Act 2004](https://www.legislation.vic.gov.au/in-force/acts/occupational-health-and-safety-act-2004/)
  10. [Fair Work Act 2009](https://policies.rmit.edu.au/directory/summary.php?legislation=6)
  11. [Equal Opportunity Act 2010 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/equal-opportunity-act-2010/)


(59)  This policy supports RMIT’s commitment to adhering to sector best practices informed by:
  1. [Australia Human Rights Commission – Guidelines for Complying with the Positive Duty under the Sex Discrimination Act 1984 (Cth) (AHRC)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fhumanrights.gov.au%2Fsites%2Fdefault%2Ffiles%2F2023-08%2FGuidelines%2520for%2520Complying%2520with%2520the%2520Positive%2520Duty%2520%25282023%2529.pdf&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326737813%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=J4%2Fz6iNWVUINphHq8BLui88zRYIZm3N6cOBkSTm21fg%3D&reserved=0)
  2. [National Plan for Addressing Gender-based Violence in Higher Education 2024](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.education.gov.au%2Fesos-framework%2Fnational-code-practice-providers-education-and-training-overseas-students-2018&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326824037%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=kcuSxPPyjtPGxSORAYp%2F2O2ZYuao0zxC1Zg8LjbSo7I%3D&reserved=0)
  3. [Universities Australia Sexual Harm Response Guidelines 2023](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Funiversitiesaustralia.edu.au%2Fwp-content%2Fuploads%2F2023%2F07%2FUA-2023-008-Sexual-Harm-Response-Guidelines-web-v4.pdf&data=05%7C02%7Cpolicy%40rmit.edu.au%7C6dea3962e7bd48db327308dd57ac01ef%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638763118462813224%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=078ODeBJ9FHNczAz1ibmffW%2BWX6OJzvVKXGPNxd7cIw%3D&reserved=0).


Vietnam Specific: 
  1. [The revised Law on Prevention and Combat Against Domestic Violence (2022)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Flawnet.vn%2Fen%2Fvb%2FLaw-13-2022-QH15-prevention-and-combat-against-domestic-violence-86C05.html&data=05%7C02%7Cpolicy%40rmit.edu.au%7C8116c86c053b440a156708dd41b043bb%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738947479717687%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=t0Fq9uGf7Vh4aeD3bj24ZZogktXM6RWVR5FOK%2BI09wY%3D&reserved=0)
  2. [2006 Law on Gender Equity (No.73/2006/QH11 dated 29/11/2006)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Flawnet.vn%2Fen%2Fvb%2F73-2006-QH11-16594.html&data=05%7C02%7Cpolicy%40rmit.edu.au%7C8116c86c053b440a156708dd41b043bb%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738947479740159%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=XjMr1T7t3WxAWkc%2Fi3zOL8Nb6uRNmjr%2BoxuVHsDNaxk%3D&reserved=0)
  3. [Viet Nam Code of Conduct on Sexual Harassment in the Workplace International Labour Organization](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.ilo.org%2Fpublications%2Fviet-nam-code-conduct-sexual-harassment-workplace&data=05%7C02%7Cpolicy%40rmit.edu.au%7C8116c86c053b440a156708dd41b043bb%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738947479750017%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=O1N4XRbTZw2p22v8lNQXsS4yrHgxA2Dop1wQsVf0N3M%3D&reserved=0) - A Code of Conduct paper issued by the Ministry of Labour Invalids and Social Affairs (MOLISA) on preventing sexual harassment.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248#document-top)
# Section 6 - Other Relevent Policies
(60)  RMIT policy suites regarding behavioural standards and conduct that are relevant to this policy include:
  1. [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)
  2. [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52)
  3. [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122)
  4. [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) and [Child Safe Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249)
  5. [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
  6. [Inclusion, Diversity and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248#document-top)
# Section 7 - Definitions
Term  |  Definition   
---|---  
Child  |  In Vietnam, according to Article 1 of the Law on Children, a child is defined as any person below the age of 16. However, RMIT Vietnam has internal guidelines that extend the child safe duty of care to individuals under the age of 18 years.   
Concern  |  An expression of dissatisfaction with the behaviour of a student or staff member, where a response is not expected.   
Consent  |  As defined in Section 36 of the Amendment of Crimes Act 1958 (Vic) and Justice Legislation Amendment (Sexual Offences and Other Matters) Act 2022, free and voluntary agreement. Consent cannot be assumed. Consent must be ongoing and mutual. It must be present every time, including for the duration of any sexual act. Consent can be withdrawn at any time. Consent to one act does not mean consent is agreed to in any other act. Consent to an act with one person does not mean consent is agreed to in an act with a different person, or with the same person on a different occasion. A person engaged in a sexual act must reasonably believe that the other person consents to the act. A person’s belief in consent is not reasonable if they did not, within a reasonable time before or at the time of the act, say or do anything to find out whether the other person was consenting. For further information on affirmative consent laws, please check [Justice Legislation Amendment (Sexual Offences and Other Matters) Act 2022](https://content.legislation.vic.gov.au/sites/default/files/2022-09/22-038aa%20authorised.pdf).   
Disclosure  |  Where a person first makes known an incident of sexual harm to RMIT (e.g., by telling another student or staff member, or by directly telling Safer Community). This may or may not lead to a report being made via the Complaints Governance Policy or another reporting avenue.   
Gender-based violence |  Any form of physical or non-physical violence, harassment, abuse or threats based on gender that results in or is likely to result in harm, coercion, control, fear or deprivation of liberty and autonomy. Harm can be physical, sexual, emotional, psychological, social, cultural, spiritual, financial and technology-facilitated abuse (including image-based abuse), and stalking.  
International delivery partners  |  International delivery partners are institutions in other countries where RMIT programs are delivered jointly by RMIT and the partner institution.  
Intersectionality | The ways in which differenct aspects o a person’s identiy can expose them to overlapping forms of discrimination and marginalisation. Intersectionality addresses and acknowledges gender, sexual orientation, Indigeneity, race, economic status, ability or other factors can compound the impact of gender-based violence, resulting in certain groups of people being more vulnerable and/or disproportionally impacted than other groups to the effects of gender-based violence, harm, discrimination and harassment.  
RMIT Group  |  RMIT University and its controlled entities a(RMIT Europe, RMIT Online, RMIT Vietnam and RMIT University Pathways).   
Sexual assault  |  Is when:  i. a person (A) intentionally touches another person (B) and the touching is sexual  ii. person (B) who was touched did not agree or consent to the touching, and  iii. person (A) did not reasonably believe that person (B) consented.  If person (A) knew that (B) was not consenting, this will be sexual assault; and if person (A) did not believe on reasonable grounds that B was consenting, this will also be sexual assault.  For the purposes of this policy, RMIT also includes the following acts defined in the [Crimes Act 1958 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/crimes-act-1958/): (i) rape, (ii) rape by compelling sexual penetration, (iii) sexual assault by compelling sexual touching, (iv) assault (being the non-consensual application of force) with intent to commit a sexual act, and (v) threat to commit a sexual assault or rape. For succinctness, the specific elements of each are not set out separately in this policy.  Additional examples of and explanations for sexual harm are set out in the Gender-Based Harm Prevention and Response Policy Schedule 1 – Explanations and Examples.  
Sexual exploitation and abuse  |  Any actual or attempted abuse of a position of vulnerability, differential power, or trust for sexual purposes. It includes profiting monetarily, socially, or politically from sexual exploitation of another. The abuse may be actual or threatened intrusion of a sexual nature, whether by force or under unequal or coercive conditions, and includes but is not limited to sexual assault, sexual harm and sexual harassment.  Technology-facilitated sexual exploitation and abuse is the use of technology and new media to facilitate sex-based abuse and harassment. Behaviours can include nonconsensual pornography (“revenge porn”), recorded sexual assaults, deepfakes, sextortion, cyber harassment, cyber dating violence, and cyberstalking.  Additional examples of and explanations for sexual harm are set out in the Gender-Based Harm Prevention and Response Policy Schedule 1 – Explanations and Examples.  
Sexual harm  |  Non-consensual behaviour of a sexual nature that causes a person to feel uncomfortable, frightened, distressed, intimidated, or harmed, either physically or psychologically. Sexual harm includes behaviour that also constitutes sexual harassment, sexual assault and rape. Additional examples of and explanations for sexual harm are set out in the Gender-Based Harm Prevention and Response Policy Schedule 1 – Explanations and Examples.  
Sexual harassment  |  When a person:  (a) makes an unwelcome sexual advance, or an unwelcome request for sexual favours, or  (b) engages in other unwelcome conduct of a sexual nature in relation to a person, in circumstances in which a reasonable person, having regard to all the circumstances, would have anticipated the possibility that the person harassed would be offended, humiliated or intimidated.  Additional examples of and explanations for sexual harm are set out in the Gender-Based Harm Prevention and Response Policy Schedule 1 – Explanations and Examples.  
Third Parties  |  Any person or entity external or separate to RMIT, including contractors, consultants, volunteers, visiting appointees and visitors as well as members of the public.   
Trauma informed |  A strengths-based framework that applies the core principles of safety, trustworthiness, choice, collaboration for shared decision-making, empowerment and respect for diversity. Trauma-informed services recognise the physiological, emotional, psychological and neurological effects of trauma; minimise the risk of re-traumatisation and promote healing; emphasise physical and emotional safety; and focus on the whole context in which a service is provided – not just on what is provided.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
