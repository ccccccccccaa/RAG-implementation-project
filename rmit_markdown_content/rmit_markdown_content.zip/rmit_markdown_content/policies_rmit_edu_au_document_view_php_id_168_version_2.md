[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=168&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=168&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Integrity Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=168)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=168&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=168&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=168&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=168&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=168&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=168&version=2)


# Academic Integrity Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=168&version=2#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=168&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=168&version=2#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=168&version=2#section4)
  * [Commitment to Academic Integrity ](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major1)
  * [Definition of Academic Integrity ](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major2)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major3)
  * [Student Responsibilities](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major4)
  * [Staff Responsibilities](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major5)
  * [College and Portfolio Responsibilities](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major6)
  * [Academic Registrar's Group Responsibilities](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major7)
  * [Academic Integrity Breaches](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major8)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major9)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=168&version=2#major10)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=168&version=2#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=168&version=2#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This policy ensures the university takes a consistent approach to academic integrity across the RMIT Group. It sets out RMIT’s expectations of staff and students in upholding academic integrity standards, supporting an educative approach to academic integrity, and in deterring and detecting breaches of academic integrity.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=168&version=2#document-top)
# Section 2 - Overview
(2)  The academic integrity policy:
  1. promotes ethical academic scholarship and a positive culture of academic integrity aligning with our values
  2. defines staff and student roles and responsibilities with respect to academic integrity outcomes
  3. adopts and encourages an educative approach to addressing and managing breaches of academic integrity
  4. provides a range of tools and resources to support staff and students in understanding good practice
  5. prevents and deters academic integrity breaches
  6. acknowledges and incorporates the established research integrity principles and practices within the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28) informed by the [Australian Code for the Responsible Conduct of Research, 2018](https://policies.rmit.edu.au/directory/summary.php?code=1) (the Code) and supporting guides. 

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=168&version=2#document-top)
# Section 3 - Scope
(3)  This policy applies to all staff and students of the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=168&version=2#document-top)
# Section 4 - Policy
### Commitment to Academic Integrity 
(4)  Staff and students at RMIT commit to conducting themselves in a manner that is consistent with the principles of academic integrity set out in this policy when undertaking teaching, learning, assessment, academic scholarship and research activities.
### Definition of Academic Integrity 
(5)  Academic integrity means that staff and students at RMIT act with the core values of honesty, trust, respect, fairness, and responsibility in education, learning, teaching, training and research, including by acknowledging the sources of ideas; both original and the work of others.
### Principles
(6)  Through the academic integrity policy, RMIT will:
  1. promote and foster a culture of academic integrity across the RMIT Group
  2. adopt an educative approach to academic integrity with shared responsibility for its establishment amongst staff and students
  3. adopt a whole-of-organisation approach to academic integrity involving: 
    1. learning and teaching strategies
    2. staff and student education
    3. early intervention processes
    4. detection of breaches of academic integrity
    5. enforcement mechanisms.


(7)  RMIT undertakes to detect and deter breaches of academic integrity through strategies including but not limited to:
  1. manual detection by academic and teaching staff
  2. using content matching or authenticity software
  3. monitoring websites that enable academic integrity breaches to take place
  4. the management and blocking of websites that breach academic integrity such as assessment file sharing, or illegal websites that offer contract cheating services.


(8)  Academic integrity breach data is:
  1. confidentially and securely maintained
  2. made available for the purposes of managing potential breaches of academic integrity
  3. managed and analysed for quality assurance, learning and teaching and process improvement, procedural fairness, and transparency.


### Student Responsibilities
The intention of these provisions is to provide best-practice guidance in upholding academic integrity and mitigate the risk of future breaches occurring.
(9)  Students share responsibility for maintaining academic integrity at RMIT; this is achieved through:
  1. understanding and adhering to RMIT’s expectations regarding academic integrity
  2. awareness and use of academic integrity educative resources and tools
  3. the honest presentation of academic work
  4. accountability for the authorship and originality of work submitted including cooperating with validation and authentication requests from staff
  5. using assessment declarations, and content matching or authenticity software prior to submission
  6. appropriately and accurately acknowledging the work of others
  7. acknowledging any re-use of original work from previous assessment tasks
  8. adherence to assessment rules
  9. adhering to group processes and outcomes when participating in group assessment
  10. conducting research responsibly in keeping with the principles and practices established in the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28) and [the Code](https://policies.rmit.edu.au/directory/summary.php?code=1)
  11. securing and retaining assessment and developmental materials for the duration of the program
  12. understanding and using academic referencing conventions
  13. awareness and use of academic support services and resources including special consideration, and a range of equitable learning services as required.


### Staff Responsibilities
The intention of these provisions is to provide best-practice guidance in upholding academic integrity and mitigate the risk of future breaches occurring.
(10)  Staff engaged in learning and teaching, assessment, higher degree by research candidate supervision, and related activities, demonstrate a commitment to academic integrity through responsibilities including and not limited to:
  1. supporting students to understand the importance of academic integrity as part of their chosen area of study and promoting a culture that encourages positive academic integrity outcomes
  2. providing academic integrity tools and resources at the commencement of students’ university experience including guidance on what constitutes a breach of academic integrity
  3. implementing early intervention strategies to support prevention of breaches of academic integrity
  4. undertaking professional development and training on educative approaches to academic integrity, including internal workshops and initiatives designed to support staff to maintain academic integrity
  5. supporting a positive learning experience, for example clear notification of assessment deadlines, suitable equipment, materials and environment and other expectations
  6. conducting research responsibly in keeping with the principles and practices established in the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28) and [the Code](https://policies.rmit.edu.au/directory/summary.php?code=1)
  7. providing arrangements for secure collection of assessment items
  8. providing guidance to students on positive group work in assessment
  9. acting on suspected breaches of academic integrity
  10. adhering to principles of procedural fairness when managing potential breaches of academic integrity.


(11)  Schools/industry clusters provide academic integrity breach notifications to the Centre for Education Innovation and Quality (or equivalent) for the purposes of facilitating continuous improvement.
(12)  Staff model their commitment to academic integrity principles through their own professional and scholarly work.
### College and Portfolio Responsibilities
(13)  Colleges and portfolios support a culture of academic integrity by:
  1. providing academic integrity support and training for students and staff
  2. providing educative resources and tools for students and staff that address academic integrity standards and expectations specific to disciplines
  3. supporting staff with professional development
  4. ensuring that students and staff have access to content matching software or authenticity reports
  5. ensuring that students are aware of potential consequences and penalties for breaches of academic integrity
  6. managing oversight and trends of academic breach reporting, via college quality enhancement teams (or equivalent), in conjunction with the Academic Registrar's Group.


### Academic Registrar's Group Responsibilities
(14)  The Academic Registrar's Group is responsible for:
  1. monitoring and responding to high risk academic integrity matters
  2. recording allegations and breaches of academic integrity
  3. in conjunction with the Centre for Education Innovation and Quality scheduled reporting on trends and strategies to mitigate breaches of academic integrity to governing bodies
  4. supporting staff to understand and manage breaches of academic integrity in particular where these intersect with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)
  5. supporting colleges and portfolios with advice, tools and training including the production of authenticity reports
  6. monitoring compliance with this policy.


### Academic Integrity Breaches
(15)  A breach of academic integrity involves acting or behaving in a dishonest, unethical, unfair or irresponsible way in teaching, learning or research activities. Breaches of academic integrity include, but are not limited to the following examples:
  1. plagiarism
  2. significant failure to appropriately and accurately acknowledge the work of others
  3. failure to appropriately and accurately acknowledge one’s own work where original work has been reused from previous assessment tasks (also known as self-plagiarism)
  4. ‘washing’, or the use of software services to disguise plagiarism
  5. submitting the work of another person or from an online study platform as one’s own, or undertaking an assessment task for another person (contract cheating or ghost writing)
  6. collusion or unauthorised collaboration in the preparation or presentation of work
  7. falsification, fabrication, manipulation or misrepresentation of data or results
  8. attempting to gain unfair advantage in an invigilated assessment, breaching the rules for the conduct of invigilated assessment in a manner that defeats or compromises the purposes of the task
  9. behaviour that violates assessment instructions thereby defeating or compromising the purpose of the assessment
  10. unauthorised sharing of course materials and previously submitted assessment items including via online study platforms
  11. misuse or unauthorised use of technology or equipment.


(16)  Allegations of academic integrity breaches will be responded to in a fair, consistent, transparent and timely manner in accordance with the [Academic Integrity Procedure](https://policies.rmit.edu.au/document/view.php?id=179). 
(17)  Prevention, detection, investigation and resolution of potential research integrity breaches are managed in accordance with the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28), [Research Integrity Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=30), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and other RMIT policies as appropriate.
### Compliance
(18)  Breaches of this policy by students or staff members that adversely affect or undermine academic integrity will be managed via the:
  1. [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)
  2. [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52).


### Review
(19)  This policy will be reviewed every five (5) years in accordance with RMIT’s [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=168&version=2#document-top)
# Section 5 - Procedures and Resources
(20)  Refer to the following document which is established in accordance with this policy:
  1. [Academic Integrity Procedure](https://policies.rmit.edu.au/document/view.php?id=179)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=168&version=2#document-top)
# Section 6 - Definitions
Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Academic misconduct |  Conduct by a student that is intended, or likely to have the effect of obtaining, for that student or any other person, an advantage in the performance of assessment by unauthorised, dishonest, unethical or unfair means whether or not the advantage was obtained. See also the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).  
---|---  
Academic Registrar's Group | Student Conduct unit within the Integrity.  
College Quality Enhancement Team (or Equivalent) | teams led by the Senior Manager Quality Enhancement within the colleges.  
Collusion | is unauthorised collaboration. Occurs where more than one student contributes to an assessment task that is submitted as the work of an individual student where the collaboration is not permitted for the assessment task. Collusion may also occur in group work where unauthorised collaboration occurs between groups.  
Contract cheating  | is the use of outsourced material for the purpose of submission by a student for assessment. The person submitting the work is being dishonest by representing it as their own. This differs from traditional forms of plagiarism, which more commonly involves copying of existing submitted or published work. Contract cheating can take on many forms and is not limited to the purchasing of assessment material from online sources. Students may obtain assessments from peers or ‘tutors’ and the arrangement may not involve a financial exchange. Significantly, the submitted work is usually original in nature making it difficult to detect using text matching plagiarism software.  
Copying | occurs when paragraphs, sentences, a single sentence or significant parts of a sentence, or the key points or structure of another person’s work have been used in an assessment without acknowledging the source.  
Fabrication | occurs when a student claims to have carried out tests, experiments, research or observations that have not taken place.  
Falsification | involves the misrepresentation of research data, source material or results, or the presentation of results that are not supported by the evidence.  
Impersonation | involves the completion and submission of an assessment task by another person that dishonestly misrepresents themselves as the person to whom the assessment task was assigned. Impersonation can also take place in the context of invigilated assessment wherein a person completes the assessment on behalf of another whilst dishonestly misrepresenting their identity.  
Plagiarism | the presentation of the work, idea or creation of another person as though it is one’s own. Plagiarism is a form of cheating and is a serious academic offence that may lead to expulsion from the University. Plagiarised material can be drawn from, and presented in, written, graphic or visual form, including electronic data, and oral presentations. Plagiarism occurs when the origin of the material used is not appropriately cited.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
