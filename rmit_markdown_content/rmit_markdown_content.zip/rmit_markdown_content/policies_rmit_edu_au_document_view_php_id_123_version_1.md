[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=123&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=123&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Employee Lifecycle Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=123)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=123&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=123&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=123&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=123&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=123&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=123&version=1)


# Employee Lifecycle Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=123&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=123&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=123&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=123&version=1#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=123&version=1#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=123&version=1#major2)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=123&version=1#major3)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=123&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=123&version=1#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The purpose of this policy is to outline the principles that RMIT follows when undertaking recruitment, remunerating its staff, managing the employment relationship and approaching matters relating to termination of employment.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=123&version=1#document-top)
# Section 2 - Overview
(2)  RMIT is committed to appointing people to roles using fair, transparent recruitment processes and making decisions that are free from unlawful discrimination. 
(3)  RMIT aims to attract great talent, motivate people to stay, provide opportunities for development and reward them fairly and consistently. RMIT provides attractive benefits that meet and often exceed the minimum legal standard.
(4)  Where circumstances lead to the conclusion of an employment relationship, RMIT will ensure this occurs in accordance with the relevant legislation and employment terms.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=123&version=1#document-top)
# Section 3 - Scope
(5)  This policy applies to all prospective and current employees of the RMIT Group, subject to relevant legislation and employment terms.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=123&version=1#document-top)
# Section 4 - Policy
### Principles
(6)  RMIT is committed to attracting great talent, motivating employees to stay, providing opportunities for development and rewarding staff fairly and consistently to enhance the University’s positioning as an employer of choice to internal and external candidates (this includes Aboriginal and Torres Strait Islander employees for RMIT’s Australian entities).
(7)  RMIT will:
  1. determine remuneration for roles using governed and equitable processes
  2. appoint people to roles free of bias and unlawful discrimination
  3. establish processes for the management of the employee lifecycle that are fair, transparent, respectful and confidential
  4. apply equal opportunity and gender equality commitments across the employee lifecycle and implement retention strategies to support retaining diverse talent
  5. create a culturally safe and responsible working environment that enables career advancement and professional development.


(8)  Recruitment and remuneration conditions will comply with the relevant legislation and employment terms and be aligned with RMIT’s strategic plan and teaching, learning, research and service priorities.
(9)  RMIT is committed to addressing the gender pay equity gap and will undertake regular analysis and monitoring, implementing improvements where required. Remuneration will be sufficiently flexible and regularly reviewed to ensure gender bias does not occur at any point in the decision-making processes.
(10)  RMIT recognises that the employment relationship may end for various reasons and will ensure that it complies with relevant legislation and employment terms.
### Responsibilities
(11)  The People team has a responsibility to:
  1. undertake regular analysis of recruitment, remuneration, career development and exit interview trends to identify areas of improvement relating equal opportunity in the employee lifecycle
  2. facilitate training in equal employment principles and anti-discrimination recruitment and selection practices to staff responsible for recruiting (including selection panels) and managing talent
  3. promote training and awareness of policies, procedures and resources that support and give effect to this policy and the employee lifecycle at RMIT
  4. provide clear and transparent processes to inform management of the employment relationship
  5. develop and apply recruitment and retention strategies to support retention and promotion of diverse staff.


(12)  The Chief People Officer or nominated delegate (including for RMIT Group entities) is responsible for:
  1. the review and approval of procedures and resources under this policy to enable its effective implementation
  2. monitoring and reporting on compliance with this policy and related documents


(13)  Managers are responsible for ensuring that:
  1. they liaise with People to understand the benefits and requirements of employment arrangements ranging from casual, fixed-term and continuing and the restrictions related to some kinds of employment arrangements
  2. as far as practicable, selection panels are gender-balanced and diverse in composition
  3. opportunities for promotion via internal recruitment and secondment are available to staff who are on parental and carer’s leave (paid and unpaid), long service leave, other long-term leave arrangements or career breaks
  4. professional development opportunities of direct reports are enabled and managed in accordance with the Professional Development Guideline.


### Review
(14)  This policy will be reviewed at least once every three years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=123&version=1#document-top)
# Section 5 - Procedures and Resources
(15)  Refer to the following documents, which are established in accordance with this policy:
  1. [Employee Probation Procedure](https://policies.rmit.edu.au/document/view.php?id=155)
  2. [Managing Performance Procedure](https://policies.rmit.edu.au/document/view.php?id=154)
  3. [Professional Development Guideline](https://policies.rmit.edu.au/download.php?id=314&version=3&associated)
  4. [Recruitment Relocation Instruction](https://policies.rmit.edu.au/download.php?id=403&version=2&associated)
  5. [Termination of Employment Guideline](https://policies.rmit.edu.au/download.php?id=315&version=5&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=123&version=1#document-top)
# Section 6 - Definitions
(16)  (Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
People |  RMIT’s People team is responsible for maximising employee value through talent acquisition, employee onboarding, talent management, total rewards, employee experience and organisational culture.It includes Human Resources divisions of RMIT entities.  
---|---  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
