[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=20&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=20&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Supervision Code of Practice 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=20)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=20&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=20&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=20&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=20&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=20&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=20&version=1)


# Supervision Code of Practice
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=20&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=20&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=20&version=1#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=20&version=1#section4)
  * [More information](https://policies.rmit.edu.au/document/view.php?id=20&version=1#major1)


# Section 1 - Purpose
(1)  The Supervision Code of Practice consists of five key principles of higher degrees by research (HDR) supervision good practice and is intended to be used by supervisors as a guide to supporting candidates’ learning and development as researchers. It explains the underlying characteristics associated with each principle and the practices associated with enacting each principle.
(2)  Supervisor responsibilities are set out in the RMIT [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14). 
(3)  This Code has been developed based on a review of the literature and relevant policies and guidelines. Relevant resources and reference documents are also included.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=20&version=1#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=20&version=1#document-top)
# Section 3 - Scope
(5)  This document is designed to be used by all supervisors of RMIT HDR candidates. It will also be used to inform candidates of the type of supervisory experience they can expect from their supervisory team.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=20&version=1#document-top)
# Section 4 - Guideline
Principles | Characteristics |  Practices | Resources  
---|---|---|---  
1. Supportive role model Candidates learn and develop as researchers when supervisors are supportive and responsive to their needs and lead by example. |  Supervisors adopt a considered, student-centred approach that is structured yet flexible enough to be adaptable to the needs of individual candidates, the demands of the research project, and changing circumstances. This approach is open and negotiable yet also task driven and directive when necessary. It recognises that candidates learn through a combination of modelling and direct instruction / guidance and also need freedom to explore in order to develop and enact scholarly independence. |  Supportive supervisors: Actively seek to understand candidates’ interests, prior experience, learning styles, strengths and limitations, career goals, personal responsibilities and life experiences to develop mutually agreeable work practices. This may include, for example, negotiating the regularity of meetings and responsibility for record keeping. Manage expectations of the graduate research experience and supervisor-candidate relationship by explicitly identifying preferences to do with working style and other issues. Show candidates how to be a researcher and critically examine their thinking and decision-making processes by modelling how this is done within the discipline. Develop a customised research skills development plan to connect candidates with co-curricular learning and transferable skills development opportunities. |  Australian Code for the Responsible Conduct of Research 2018: supervision of research trainees guidelines (in development) National Statement on Ethical Conduct of Human Research Australian Council of Graduate Research, Guidelines for Quality Research Supervision. University of British Columbia, Principles of Graduate Supervision PhD Up program  
2. Open dialogue Ensuring open, two-way, communication between supervisors and candidate provides the basis for a supportive learning environment. |  Supervisors’ open, timely and clear communication ensures clarity regarding key issues such as expectations, responsibilities and progress. Regular feedback about progress that is both sensitive and frank enables supervisors to develop and maintain trust thereby minimising unnecessary shock and distress on the part of the candidate. Supervisors model dialogic practices such as active listening and questioning with the aim of enhancing critical thinking, creativity, and adaptability. This approach also recognises that learning is reciprocal. |  Open dialogue includes: Regular, ideally weekly, meetings or contact to monitor time bound goals and provide feedback. Discussing progress against agreed project milestones at every supervisory meeting. Active listening combined with questioning in a sensitive and thought-provoking way to prompt critical reflection. Actively seek to advance the candidates research career by ensuring due recognition of ideas and contribution to publications etc. Not assuming candidates are happy because they don’t say otherwise. Instead, candidates are provided opportunities to raise issues, including issues with supervision, in a non-confrontational way. Developing protocols for the management of dissent within the supervisory team and between supervisor and candidate. |  NSW Ombudsman report, Complaints about the supervision of postgraduates  
3. Respect Treating candidates with respect, maintaining professional boundaries and being concerned for their wellbeing creates a supportive and effective supervisor – candidate relationship. |  An ethos of respect and care recognises that people are at the heart of the supervisor-candidate relationship and need to be treated respectfully. People also have diverse needs and backgrounds. Supervisors observe at all times the professional nature of the relationship with candidates and take care not to overstep or blur professional / private boundaries. Supervisors recognise that the diverse gender and cultural backgrounds that make up the research education community positively enriches and enhances research and supports innovation. Supervisors seek to be inclusive and respectful of difference by adapting to meet the multiple capacities and interests of diverse candidates. Difference can also lead to misunderstandings and there may be unspoken assumptions about roles and responsibilities which may not be shared or well understood. Difficult conversations are conducted respectfully by seeking to redress the inherent power differential between supervisors and candidate. |  Behaving respectfully and seeking to be inclusive of difference includes: Taking practical measures to ensure candidates are not placed in uncomfortable or inappropriate situations, i.e. avoiding one on one meetings in overly secluded or confined settings; ensuring social occasions are group-based. Appreciating and making adjustments as necessary to support candidates’ learning due to personal or structural challenges they may face; gender, cultural or other matters which warrant sensitivity; the inherent power imbalances within the supervisor - candidate relationship. Recognising and actively responding to signs of candidate disengagement, such as not responding to emails, missing appointments etc. Pro-actively making referrals to relevant university services or policy provisions in the event of candidate’s showing signs of needing additional or specialist support. |  RMIT Code of Conduct International Education Association of Australia guide for supervisors: enhancing the experience and outcomes of international HDR candidates Australian Code for Responsible Conduct of Research Sexual Harassment Policy Staff/Student Relationships Commitment Statement   
4. Engagement and Impact Connecting candidates with peers, the research community, other partners and end-users.  |  A distributed model of research education promotes learning through extended networks and communities of practice. Candidates are supported to develop as independent researchers through connecting with research communities and partnerships and create impact through collaboration. In this approach, supervisors support candidates to develop as researchers as well as disseminate their research to relevant scholarly, industry and community audiences. By promoting end-user engagement, candidates are encouraged to recognise the potential applications of their research, and the social, economic and other benefits that may arise. |  Promoting engagement includes: Actively inducting and integrating candidates into relevant research communities and communities of practice, from the academic unit to the broader research community, industry and other stakeholders, particularly local peer-to-peer networks. Showing by example how researchers interact and support one another in research communities by including candidates in activities such as conferences and the peer review process. Inducting candidates into research dissemination practices by supporting them to publish and guiding them as to what constitutes good quality journals, conferences and other outlets. Building partnerships between end-users and candidates to support research translation and career development. |  Research Innovation and Entrepreneurship RMIT Enabling Capability Platforms  
5. Ongoing Development Excellence in supervision develops iteratively through ongoing critical reflection and professional development.  |  There is no single formula for good practice in supervision: it will vary by discipline and with reference to the personal styles of supervisors and candidates. With commitment to the spirit of good practice supervisors can develop a robust supervisory approach that is also adaptable to the needs of each candidate and the multitude of different situations which may arise. This occurs through experience, personal reflection, scholarship of research education and engagement with both disciplinary and cross-disciplinary communities of practice. Ongoing, open engagement with professional development can also assist supervisors to maintain and extend their professional skills in this domain. |  Forms of ongoing development include: Developing a supervisory approach and expectations statement to share with candidates as part of the process of negotiating mutual expectations and supervisory arrangements. Participating in professional development opportunities. Actively mentoring junior colleagues and / or building communities of practice. Publishing and disseminating through other means, research and scholarship into research education. |  Develop Me program Introduction to Supervision, moderated online short course Quality in Postgraduate Research conference  
### More information
(6)  For additional information on good practice in HDR supervision contact research.ed@rmit.edu.au
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
