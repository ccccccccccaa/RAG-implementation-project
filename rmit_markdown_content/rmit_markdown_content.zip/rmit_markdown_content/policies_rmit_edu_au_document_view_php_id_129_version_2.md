[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=129&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=129&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Articulation Agreements Guideline 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=129)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=129&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=129&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=129&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=129&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=129&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=129&version=2)


# Articulation Agreements Guideline
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=129&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=129&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=129&version=2#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=129&version=2#section4)
  * [ ](https://policies.rmit.edu.au/document/view.php?id=129&version=2#major1)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=129&version=2#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This guideline provides guidance on the amount of credit that can be granted into RMIT programs when negotiating credit to be awarded within an articulation agreement. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=129&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126) and should be read with reference to the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=129&version=2#document-top)
# Section 3 - Scope
(3)  This document applies to all staff involved in the management of articulation agreements. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=129&version=2#document-top)
# Section 4 - Guideline
(4)  An articulation agreement is an agreement between organisational components of the RMIT Group or between RMIT and another tertiary institution, industry partner or other entity by which eligible students may receive entry into an RMIT program and/or defined amounts of credit towards an RMIT program.
(5)  Some articulation arrangements may require a signed agreement by all parties which may include an annexure/schedule that outlines what has been agreed. Some articulation agreements will only require a written agreement signed by RMIT that details the agreed arrangement including any credit.
(6)  Articulation agreements must take into consideration all RMIT entities who offer the same program.
(7)  The following officers or committees of the destination program may approve articulation agreements made within the RMIT Group, between RMIT University and another Australian or international tertiary institution: 
  1. for articulation agreements for coursework programs, the relevant Deputy Vice-Chancellor(s) or nominee(s) 
  2. for articulation agreements for higher degree by research programs, the Research Committee


(8)  Where a contractual agreement is required, this must be in accordance with the [Delegation of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).
(9)  When negotiating credit to be awarded with other institutions or internal to RMIT, the University will seek to maximise the credit available to students and should take into consideration the maximum credit allowed as detailed under the [Credit Procedure](https://policies.rmit.edu.au/document/view.php?id=37). 
(10)  The Academic Registrar may approve to extend the maximum amount of credit allowed to be granted towards an RMIT coursework program based on studies undertaken at RMIT or from another institution, where all parties are in agreement.
(11)  Articulation agreements must detail when the agreement will expire and will undergo a formal approval process to be renewed. The agreement must also include a provision that allows an agreement to change before it is due to expire where there is a change to either the program that affects the agreement and any credit that may be awarded.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=129&version=2#document-top)
# Section 5 - Definitions
Articulation | Enables a student to progress from one (partial/completed) qualification to another through a defined pathway with admission and/or credit.  
---|---  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
