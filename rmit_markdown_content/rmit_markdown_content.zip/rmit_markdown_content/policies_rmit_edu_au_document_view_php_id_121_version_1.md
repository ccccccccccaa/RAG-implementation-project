[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=121&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=121&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > COVID-19 Admission and Credit Flexibility Approach 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=121)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=121&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=121&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=121&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=121&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=121&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=121&version=1)


# COVID-19 Admission and Credit Flexibility Approach
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=121&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=121&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=121&version=1#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=121&version=1#section4)
  * [Admission Process Adjustments](https://policies.rmit.edu.au/document/view.php?id=121&version=1#major1)
  * [Admission and Credit Policy Adjustments](https://policies.rmit.edu.au/document/view.php?id=121&version=1#major2)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=121&version=1#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Purpose
(1)  In response to the COVID-19 impacts on the education sector, areas of opportunity have been identified where flexibility can be provided to impacted applicants for admission and credit in Semester 2 2020 and Semester 1 2021.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=121&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Admission and Credit Policy](https://policies.rmit.edu.au/document/view.php?id=6).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=121&version=1#document-top)
# Section 3 - Scope
(3)  This document applies to RMIT students affected by COVID-19.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=121&version=1#document-top)
# Section 4 - Guideline
### Admission Process Adjustments
(4)  The following temporary changes to admission processes will apply for entry in Semester 2, 2020 programs unless stated otherwise.
(5)  Acceptance of forecast results for International Baccalaureate Diploma, GCSE, AS and A Levels and Pearson BTEC from all countries for full offers.
(6)  Acceptance of forecast results for Indian High School CBSE/CISCE Year 12 qualifications with an increase in the entry requirement to 5-7% higher than the minimum program requirement depending on their risk category.
  1. Acceptance of all low risk SSVF students, however, high-risk SSVF students will be considered only on a case by case basis with a strict screening process in place. 
  2. Extend the last day to submit the final results until Semester 2, 2020 census date. 
  3. Students unable to meet the entry requirement once results are available will have their enrolment and CoE cancelled, and the student will not be allowed to continue their studies. 


(7)  Removal of the National Examination requirement for Indonesian Year 12 for admission to bachelor degrees.
(8)  Removal of the requirement of Vietnamese National High School Graduation Examination for admissions to RMIT Diploma, Advanced Diploma, and Undergraduate Degrees.
(9)  Acceptance of trial results from Hong Kong Diploma of Secondary Education Examination (HKDSE).
(10)  Acceptance of partially/differently completed qualifications from all countries where there are changes to assessment and grading methodologies due to the impact of COVID-19 on domestic and international admissions.
(11)  Acceptance of online/uncertified documents from all countries for full offers.
(12)  Acceptance of IELTS Indicator and TOEFL iBT Special Home Edition Test as English language proficiency assessment tools for entry to all RMIT University programs including RMIT English Worldwide programs for Semester 2, 2020 and Semester 1, 2021 intakes, until testing centres re-open.
### Admission and Credit Policy Adjustments
(13)  The following table provides an overview of adjustments to policy provisions as approved by the Deputy Vice-Chancellor Education. It should be noted that the policy adjustments described only apply to applicants affected by COVID-19 and who are seeking admission in Semester 2 2020, unless stated otherwise.
Policy/Schedule |  Reference |  Current provision |  Adjustment |  Rationale  
---|---|---|---|---  
[Admission and Credit Policy Schedule 2: Minimum English Language Entry Requirements](https://policies.rmit.edu.au/download.php?id=1&version=2&associated) |  5.1 |  Achieving, within two years before they will commence study in the RMIT program, the minimum score in an English language test approved by Education Committee and published on the English requirements web page. |  Extend the validity of currently accepted official English language proficiency tests from two (2) years to three (3) years. |  All of RMIT’s recognised English proficiency test centres including IELTS, TOEFL. Pearson and Cambridge are currently suspending testing for an indefinite period.  
[Admission and Credit Policy Schedule 2: Minimum English Language Entry Requirements](https://policies.rmit.edu.au/download.php?id=1&version=2&associated) |  6.1 |  Applicants must have completed an English language program delivered by one of the English language providers listed on the English language provider webpage within 12 months before they will commence study. |  Extend the validity of approved English language programs to 24 months. |  The validity of approved English language programs and English language proficiency tests were not consistent across RMIT admissions and do not provide suitable flexibility for applicants impacted by COVID-19. Benchmarking indicates it is common practice to recognise a 24-month validity for approved English language programs which also aligns with the validity of approved English language proficiency tests.  
[Admission and Credit Policy](https://policies.rmit.edu.au/document/view.php?id=6) |  (68) |  Credit transfer is only available for learning that is deemed current by the credit assessor and will not be granted for courses completed more than 10 years before the application for credit is submitted. For exceptions, see the admission and credit process manual for the relevant RMIT institution. |  To allow the application of credit for previous studies completed in 2010 for entry to RMIT programs in 2021. |  The currency of learning requirement has been amended as students in Australia and around the world may not be able to commence study in 2020 due to COVID-19 travel and lockdown restrictions and interruptions to the timetables and exam schedules of education providers. If students delay commencement of their studies until 2021 due to COVID-19 related impacts, their 2010 prior study will fall outside the 10-year timeframe.  
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=121&version=1#document-top)
# Section 5 - Definitions
A Level | Advanced Level  
---|---  
AS Level | Advanced Subsidiary Level  
BTEC | Business and Technology Education Council  
CBSE | Central Board of Secondary Education  
CISCE | Council for the Indian School Certificate Examinations  
GSCE | General Certificate of Secondary Education  
IELTS | International English Language Testing System  
SSVF | Simplified student visa framework  
TOEFL | Test of English as a Foreign Language  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
