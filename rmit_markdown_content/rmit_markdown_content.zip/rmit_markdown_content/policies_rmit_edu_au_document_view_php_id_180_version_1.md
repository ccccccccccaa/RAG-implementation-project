[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=180&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=180&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Conduct Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=180)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=180&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=180&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=180&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=180&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=180&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=180&version=1)


# Student Conduct Regulations
Hide Navigation
  * [Part A - Preliminary](https://policies.rmit.edu.au/document/view.php?id=180&version=1#part1)
  * [Part B - Misconduct](https://policies.rmit.edu.au/document/view.php?id=180&version=1#part2)
  * [Division 1 – General Misconduct](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major1)
  * [Division 2 – Academic Misconduct](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major2)
  * [Division 3 – High Risk Misconduct](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major3)
  * [Part C - Allegations of Misconduct](https://policies.rmit.edu.au/document/view.php?id=180&version=1#part3)
  * [Division 1 – Officer](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major4)
  * [Division 2 – Senior Officers and Vice-Chancellor](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major5)
  * [Division 3 – Student Conduct Board](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major6)
  * [Part D - Penalties](https://policies.rmit.edu.au/document/view.php?id=180&version=1#part4)
  * [Part E - Appeals](https://policies.rmit.edu.au/document/view.php?id=180&version=1#part5)
  * [Part F - Miscellaneous](https://policies.rmit.edu.au/document/view.php?id=180&version=1#part6)
  * [Division 1 – General](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major7)
  * [Division 2 – Transitional Provisions](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major8)
  * [Division 3 – Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=180&version=1#major9)


This is not a current document. To view the current version, click the link in the document's navigation bar.
## Part A - Preliminary
#### 1. Purpose
(1)  The purpose of these Regulations is to:
  1. maintain and protect the academic integrity at the University
  2. regulate the conduct of students who are within the University premises, using University facilities and services or participating in University activities or assessment sessions, and
  3. facilitate the proper functioning of the University.


#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
#### 3. Definitions
(3)  In these Regulations:
  1. academic misconduct means conduct or behaviour as defined under clause (5).
  2. Academic Registrar means the officer who holds the position of Academic Registrar at the University.
  3. assessment session means the specified period at which the assessment task is conducted.
  4. assessment task means any examination, essay, assignment, practical or vocational placement or other work, in whole or in part, which forms part of a student’s academic assessment.
  5. Board means the Student Conduct Board established to hear allegations of student misconduct under these Regulations.
  6. Chair means the chair of the Student Conduct Board or the Student Conduct Appeals Committee or such other chair approved by the Vice-Chancellor.
  7. Committee means the Student Conduct Appeals Committee.
  8. computing and network facilities includes, but is not limited to computers, computer systems, email and other communications networks and information facilities together with associated software, files and data storage and retrieval.
  9. cost of damage means the monetary value of any damage to, or loss of, any property (including the cost of repair or replacement).
  10. day means working days and does not include days when the University is closed.
  11. document fraud means knowingly falsifying, forging or submitting documents that contain misleading or false information.
  12. executive suspension means a decision by the Vice-Chancellor to immediately suspend a student in accordance with clause (15).
  13. expel means to terminate a student’s enrolment at the University, without any right to enrol or re-enrol, unless the Vice-Chancellor otherwise orders.
  14. general misconduct means conduct or behaviour as defined under clause (4).
  15. high risk misconduct means conduct or behaviour as defined under clause (6).
  16. natural justice means the rules against bias and the right to a fair hearing.
  17. officer means any person employed by the University.
  18. plagiarism is the presentation of the work, idea or creation of another person, without appropriate referencing, as though it is one’s own.
  19. principal student organisation means the main body representing students at the relevant campus of the University.
  20. research code means the [Australian Code for the Responsible Conduct of Research](https://policies.rmit.edu.au/directory/summary.php?code=1) as amended from time to time.
  21. rules of evidence means the rules of evidence contained in the Evidence Act 2008 (Vic) applying to proceedings in Victorian courts of law.
  22. secretary means the secretary of the Student Conduct Board or Student Appeals Committee.
  23. senior officer means the dean or head of any school, any member of the Vice-Chancellor's Executive, the Academic Registrar, the Dean of Students, the Dean of the School of Graduate Research, the Deputy Pro Vice Chancellors (Learning and Teaching), the Director Student Services, the University Librarian, any Executive Director, any person acting in any of these positions, and any other person in a senior position nominated by the Vice-Chancellor for the purpose of these Regulations.
  24. serial academic misconduct means academic misconduct of a similar nature previously committed by a student at the University.
  25. support person means a person to assist and accompany a student at a hearing under these Regulations.
  26. suspend means to prohibit a student for a specified period from attending any teaching or assessment session or enter the University premises, use the University’s computing or network facilities, or represent the University, on terms and conditions imposed by the University.
  27. teaching session means any activity carried out by the University as part of the provision of courses for students, including classes, tutorials, lectures and laboratory or workshop sessions, either in person or via the University’s computing or network facilities.
  28. University premises means any buildings, streets, driveways, footways, and any other areas owned or controlled by the University and includes premises on which research, workshops camps, placements, examinations, professional, field or vocational placements are carried out or form part of the course, and any other study activities controlled or supervised by, or in the temporary possession of the University, and shall also include the premises of any interstate or international partner of the University.
  29. Vice Chancellor means the person appointed to the position of Vice-Chancellor and President of the University.


## Part B - Misconduct
### Division 1 – General Misconduct
#### 4. General Misconduct
(4)  A student commits general misconduct if the student:
  1. fails to comply with any reasonable request, order or direction by an officer where the request, order or direction was necessary: 
    1. to maintain an effective and respectful learning environment
    2. to ensure the health and safety of any person (including the student concerned)
    3. to prevent damage to property or University premises
    4. for the proper performance of the officer’s duties at the University, or
    5. to ensure compliance with University policy or procedure
  2. disrupts or inhibits another person’s ability to participate in any University activity or use University premises
  3. behaves in a manner which is disorderly, indecent, offensive or detrimental to the University’s interests and reputation
  4. unlawfully discriminates any person on any grounds, including but not limited to, disability, race, age, gender, sexual preference, physical appearance or religious or political belief
  5. harasses, intimidates or bullies any person (or attempts to)
  6. engages in a course of conduct which causes physical or psychological harm or arouses apprehension or fear, either directly or indirectly, either physically, verbally, electronically or by any other means
  7. wilfully, recklessly or negligently engages in conduct which may physically or psychologically cause injury to any person, including stalking a person
  8. in the course of University activities, wilfully, recklessly or negligently causes damage to or, removes or wrongfully interferes with any property of: 
    1. the University, or
    2. an officer, student or other person
  9. copies or attempts to copy any copyright material including computer software, without the permission of the University or in breach of copyright law
  10. improperly makes use of any University facilities, networks or equipment
  11. publishes, distributes or makes available (in any form or forum) any confidential information of or held by the University or breaches any person’s privacy
  12. makes false representations on any matter (including academic records, health practitioner records or immigration requirements) in his or her capacity as a student or knowingly engages in document fraud in relation to assessment, academic results, records or for purpose of enrolment or entry into a course or program
  13. unlawfully accesses an electronic record belonging to the University, an officer, or another student where the record is accessible via or contained within, the University’s computing and network facilities
  14. fails to pay any fine or comply with any penalty imposed by the University for misconduct by the due date
  15. engages in any other conduct, whether within or outside the University premises, that may be prejudicial to the good order and discipline of the University or is likely to bring the University into disrepute
  16. incites or persuades any other person to engage in behaviour or conduct which amounts to general misconduct
  17. commits a criminal or unlawful act while on University premises or in connection with University activities, or
  18. acts or fails to act in contravention of University legislation, policy, procedure, instruction or published rule.


### Division 2 – Academic Misconduct
#### 5. Academic Misconduct
(5)  A student commits academic misconduct if the student:
  1. cheats or attempts to gain an unfair academic advantage in any assessment task
  2. impersonates, or allows himself or herself to be impersonated by another for any assessment task
  3. plagiarises or submits the work of another person as the student’s own work
  4. knowingly enables another student to plagiarise his or her work
  5. takes into, or uses in connection with, any assessment task any material or device other than material or a device specifically permitted by the University
  6. obtains from, or gives to a student during any assessment session information relating to the assessment task without prior approval
  7. commits a breach of the research code and the University’s published standards for conduct of ethical and responsible research, or
  8. behaves in any manner that may provide a misleading basis for an assessment task.


### Division 3 – High Risk Misconduct
#### 6. High Risk Misconduct
(6)  A student commits high risk misconduct if the student engages in conduct that involves a risk of:
  1. physical or psychological injury to the student or to any other person or the public, or
  2. damage to University premises or to the property of any person or any public property.


## Part C - Allegations of Misconduct
### Division 1 – Officer
#### 7. Reporting Misconduct
(7)  Where an officer has reasonable grounds to believe that a student has committed an act of:
  1. general misconduct
  2. academic misconduct, or
  3. high risk misconduct


the officer must report the alleged misconduct to a senior officer.
### Division 2 – Senior Officers and Vice-Chancellor
#### 8. Senior Officers – Academic and General Misconduct
(8)  Where a senior officer receives an allegation of academic or general misconduct referred under clause (7), the senior officer may determine whether the conduct warrants an investigation.
(9)  If the academic or general misconduct warrants an investigation, the senior officer may:
  1. hear the allegation,
  2. refer the allegation to the Board, or
  3. do anything reasonable in the circumstances to resolve the allegation.


(10)  If the senior officer determines to conduct a hearing, the senior officer must within ten (10) days prior to the hearing notify the student in writing of:
  1. the allegation, the grounds for it and copies of documents containing evidence
  2. the date, time and location of the hearing
  3. the opportunity to: 
    1. be heard, and/or
    2. submit written evidence in response
  4. the right to be accompanied or assisted by a support person, provided that no party will be permitted to have legal representation at the hearing, and
  5. the provisions of this regulation.


(11)  If the senior officer conducts a hearing, the senior officer:
  1. must do so in accordance with these Regulations and the relevant policies and procedures
  2. must act fairly in all the circumstances
  3. is not bound by rules of evidence, technicalities or legal forms, and may make such inquiries and consult such persons as the senior officer decides, and
  4. may require any person or officer to attend the hearing.


(12)  If the senior officer conducts a hearing and a student does not attend the hearing and has not provided a reasonable cause for the absence, the hearing will proceed and any decision of the senior officer will be binding. The University may request written documentation to support the reasonable cause including but not limited to a health practitioner’s report and or a statutory declaration.
(13)  If the senior officer conducts a hearing, the senior officer must either dismiss or uphold the allegation of academic or general misconduct.
(14)  Where the senior officer upholds the allegation of general or academic misconduct, the senior officer may impose a penalty on the student in accordance with Part D of these Regulations.
#### 9. Vice Chancellor – High Risk Misconduct
(15)  Notwithstanding any other provision in these Regulations, the Vice-Chancellor may determine that a student is immediately subject to executive suspension.
(16)  The powers conferred by clause (15) may not be exercised unless the Vice-Chancellor has determined that decision is reasonably necessary to protect against further high risk misconduct.
(17)  The Vice-Chancellor:
  1. is not required to accord a hearing to the student before making the decision
  2. may inform him or herself in any way in relation to any matter, and
  3. may impose terms and conditions on the executive suspension.


(18)  The Vice-Chancellor's decision is final and continues to operate until revoked, varied or expired.
(19)  The Vice-Chancellor must within 24 hours of the decision to executively suspend the student provide written notice to the student:
  1. of the decision, any terms and conditions of the decision, and a summary of the reasons for the decision, and
  2. the provisions of these Regulations.


(20)  A decision to executively suspend a student takes effect immediately.
### Division 3 – Student Conduct Board
#### 10. Student Conduct Board
(21)  There is a Board constituted under these Regulations.
(22)  The Board hears allegations of:
  1. general misconduct
  2. academic misconduct, and
  3. high risk misconduct


submitted in accordance with the relevant policies and procedures in a form determined by the University.
(23)  The Board must within ten (10) days prior to the hearing notify the student in writing of:
  1. the allegation, the grounds for it and copies of documents containing evidence
  2. the date, time and location of the hearing
  3. the opportunity to: 
    1. be heard, and/or
    2. submit written evidence in response
  4. the right to be accompanied or assisted by a support person, provided that no party will be permitted to have legal representation at the hearing, and
  5. the provisions of this regulation.


(24)  Membership of the Board shall comprise:
  1. the Chair
  2. two senior officers, and
  3. an enrolled student nominated by the principal student organization


but shall exclude any senior officer who was involved in the investigation, hearing or referral of the allegation.
(25)  Wherever possible membership of the Board will represent gender equality.
(26)  The Board:
  1. must conduct the hearing in accordance with these Regulations and the relevant policies and procedures
  2. must act fairly in all the circumstances
  3. is not bound by rules of evidence, technicalities or legal forms, and may make such inquiries and consult such persons as it decides, and
  4. may require any person or officer to attend the hearing.


(27)  Where a student does not attend the hearing and has not provided a reasonable cause for the absence, the hearing will proceed and any decision of the Board will be binding. The University may request written documentation to support the reasonable cause including but not limited to a health practitioner’s report and or a statutory declaration.
(28)  The Chair of the Board has final authority on matters related to the conduct of a hearing including, but not restricted to, attendance, adjournment or admission of submissions.
(29)  The Board must determine whether any misconduct occurred.
(30)  Where the Board upholds the allegation of misconduct, the Board may impose a penalty on the student in accordance with Part D of these Regulations.
(31)  A quorum of the Board is the Chair and two members.
## Part D - Penalties
#### 11. Senior Officer - Penalties
(32)  Where a senior officer conducts a hearing and upholds an allegation of academic misconduct or general misconduct against a student under clause (13), the senior officer may:
  1. reprimand the student
  2. record a failure for all or any part of an assessment task
  3. record a failure for a course
  4. require the student to repeat an assessment task
  5. suspend the student for a period not exceeding one compulsory semester or nominated teaching period, and/or
  6. impose a combination of these penalties.


#### 12. Student Conduct Board - Penalties
(33)  Where the Board conducts a hearing and upholds an allegation of misconduct against a student under clause (30), the Board may:
  1. reprimand the student
  2. record a failure for all or any part of an assessment task
  3. record a failure for a course, including the research component of a research program
  4. require the student to repeat an assessment task
  5. cancel any or all results
  6. impose a financial penalty in accordance with the University’s schedule of fees and charges
  7. require the student to pay the cost of any damage
  8. refuse the student access to University premises
  9. exclude the student from using any of the University’s computing and network facilities for a period either partially or fully
  10. suspend the student for a period not exceeding two compulsory semesters or nominated teaching periods
  11. refer to Council a recommendation to revoke an award
  12. expel the student, and/or
  13. impose such other penalty or take such other action as the Board may consider appropriate.


#### 13. Notice and Effect of Decision
(34)  Within ten (10) days of any decision to impose a penalty under Part D of these Regulations, the student must be provided with written notice of the:
  1. Decision and the reasons for the decision
  2. penalty imposed and conditions attached, and
  3. right to appeal the decision under Part E of these Regulations.


(35)  A determination by the senior officer or the Board to suspend or expel a student will:
  1. remain in effect until any appeal to the Committee has concluded and been decided, and
  2. preclude the University from issuing to the student any award of the University, unless specifically waived by the senior officer or the Board.


#### 14. Non-compliance with Decision and Penalty
(36)  Subject to the absolute discretion of the Academic Registrar, the University shall not:
  1. re-enrol
  2. issue and provide any statement of results, or
  3. grant any award


to a student where that student has failed to pay or fulfil any penalty imposed under these Regulations by the prescribed date.
## Part E - Appeals
#### 15. Student Conduct Appeals Committee
(37)  There is a Committee constituted under these Regulations.
(38)  Membership of the Committee comprises:
  1. a Chair
  2. one senior officer, and
  3. an enrolled student nominated by the principal student organisation


provided that no member was associated with the alleged misconduct or previously involved in the original decision.
(39)  Wherever possible membership of the Committee will represent gender equality.
(40)  A student may appeal against a:
  1. decision under Part C, and/or
  2. penalty imposed under Part D.


(41)  The grounds on which the student may appeal to the Committee under this Part E are limited to:
  1. that the decision was made on the basis of personal bias or ill will at the hearing
  2. that a breach of University legislation, policy or procedure by the Board or senior officer has occurred that has had a significant impact on the outcome of the misconduct hearing
  3. that the penalty is unreasonable, excessive or inappropriate, and/or
  4. there is new supporting material of a substantial nature not available at the time of the misconduct hearing.


(42)  An appeal to the Committee must be:
  1. in writing setting out the grounds of the appeal and the evidence on which the student relies, and
  2. lodged with the Committee within twenty (20) days after the date of the decision of the Board or senior officer.


(43)  The Committee must hear the appeal within thirty (30) days from the date the appeal submission was deemed to be complete.
(44)  The Committee must within ten (10) days notify the student in writing of:
  1. the date, time and location of the hearing
  2. the opportunity to: 
    1. be heard, and/or
    2. submit written evidence in response, and
  3. the right to be accompanied or assisted by a support person, provided that no party will be permitted to have legal representation at the hearing.


(45)  The Committee:
  1. must conduct the hearing in accordance with these Regulations and the relevant policies and procedures
  2. must act fairly in all the circumstances
  3. is not bound by rules of evidence, technicalities or legal forms, and may make such inquiries and consult such persons as it decides, and
  4. may require any person or officer to attend the hearing.


(46)  A quorum of the Committee is the Chair and one member.
(47)  The Committee must either:
  1. dismiss the appeal
  2. allow the appeal in whole or in part, or
  3. remit the matter to the Board for a re-hearing.


(48)  If the Committee allows the whole or any part of an appeal, it must confirm, set aside or vary any penalty imposed or substitute another penalty.
(49)  Unless the matter is remitted to the Board under clause(47)c., a decision of the Committee is final.
(50)  Within 10 days of any decision by the Committee under this Part E, the student must be provided with written notice of the reasons for the decision and any penalty imposed.
## Part F - Miscellaneous
### Division 1 – General
#### 16. External Review of Decision
(51)  Nothing in these Regulations is intended to preclude a student from exercising any right to external review of any decision.
(52)  The University may stay any internal process under these Regulations where the student exercises his or her right to external review of a decision involving the same or similar subject matter.
#### 17. Address for notice
(53)  Any notice to a student for the purpose of these Regulations is sufficient if it is in writing and is emailed or posted by registered mail to the student’s allocated University email account or registered address.
(54)  A notice is deemed to have been received if sent by email, 24 hours after the time it was sent by the University or 48 hours if posted by registered mail.
#### 18. Regulation of Proceedings
(55)  Subject to University legislation, a senior officer, the Board and the Committee constituted under these Regulations:
  1. regulates its own proceedings
  2. in hearing any case and making any decision: 
    1. is not bound by the rules or practices as to evidence or procedure
    2. may inform himself, herself or itself in relation to any matter as he, she or it considers appropriate, and
    3. applies the principles of natural justice.


#### 19. Delegations
(56)  The Vice-Chancellor may delegate to a senior officer in writing any of his or her functions or powers under these Regulations other than this power of delegation.
(57)  A senior officer may delegate to a deputy dean or deputy head of school in writing any of his or her functions or powers under these Regulations other than:
  1. a function or power delegated under clause(56), and
  2. this power of delegation.


### Division 2 – Transitional Provisions
#### 20. Transitional Provisions
(58)  In this Division:
  1. commencement date means the day on which these Regulations come into operation.
  2. old regulations means Regulation 6.1.1 Student Discipline in force up until the commencement date of these Regulations.


(59)  Any allegation of misconduct reported to a senior officer in accordance with clause (7) of these Regulations, on and from the commencement date, is to be dealt with under these Regulations.
(60)  Any allegation of misconduct reported to a senior officer in accordance with Part 2 of the old regulations, prior to the commencement date, is to be dealt with under the old regulations.
### Division 3 – Revocation of Regulations
#### 21. Revocation of Regulations
(61)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 6.1.1 Student Discipline.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
