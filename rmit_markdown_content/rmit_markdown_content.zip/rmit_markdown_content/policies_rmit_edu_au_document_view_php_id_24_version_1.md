[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=24&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=24&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Disclosing and Exploiting Intellectual Property Process 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=24)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=24&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=24&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=24&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=24&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=24&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=24&version=1)


# Disclosing and Exploiting Intellectual Property Process
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=24&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=24&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=24&version=1#section3)
  * [Section 4 - Process](https://policies.rmit.edu.au/document/view.php?id=24&version=1#section4)
  * [More information](https://policies.rmit.edu.au/document/view.php?id=24&version=1#major1)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Purpose
(1)  This resource describes how new inventions are disclosed by creators to the University for the purposes of Intellectual Property assessment, protection and commercialisation.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=24&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=24&version=1#document-top)
# Section 3 - Scope
(3)  This process applies to all University staff and students who are creators of intellectual property.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=24&version=1#document-top)
# Section 4 - Process
(4)  Intellectual Property and Commercialisation Team (IPC Team) at the University work with creators at the University to help with protecting both patentable and unpatentable inventions and assisting with taking such inventions to the marketplace.
(5)  Creators who believe they have developed an invention with the potential for commercialisation will firstly contact the IP&C Team by writing to ip.commercialisation@rmit.edu.au.
(6)  The IPC Team will then provide the Creators with an Invention Disclosure Document (IDD) to enable the Creators to fully describe their invention.
(7)  Creators will complete and submit the IDD to the IPC Team for evaluation.
(8)  The IPC Team will then work with the creators to:
  1. establish entitlement of the University to the invention disclosed including rights to protect and commercialise the invention. This may involve working with the creators to gather all information on any existing grants through which the invention may have been developed as well as any contracts/research agreements with external parties outlining IP ownership, commercialisation rights etc.
  2. review the disclosure and communicate with the creators to provide a preliminary determination of the need and potential for protecting the technology and the approximate market potential.
  3. list and finalise all creator details (including any external inventors/creators)
  4. identify any student involvement and requirements for Student Participation Agreements
  5. formalise inventorship
  6. list potential industry contacts and any market information that would be useful to evaluate the commercial potential of the invention


(9)  Once an IDD has been completed, the IPC Team will continue to work with the creators throughout the process of securing IP protection, discussing potential commercialisation options as well as identifying and marketing the invention to potential industry partners to explore commercialisation.
### More information
(10)  For more information, please contact the Intellectual Property and Commercialisation Team at ip.commercialisation@rmit.edu.au
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
