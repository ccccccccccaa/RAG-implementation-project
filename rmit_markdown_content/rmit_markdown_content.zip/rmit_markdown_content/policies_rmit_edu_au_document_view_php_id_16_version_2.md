[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=16&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=16&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Candidature Duration and Enrolment Variation Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=16)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=16&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=16&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=16&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=16&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=16&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=16&version=2)


# HDR Candidature Duration and Enrolment Variation Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=16&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=16&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=16&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=16&version=2#section4)
  * [Duration of Candidature and Research Commencement Date](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major1)
  * [Variations to Candidature](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major2)
  * [Study Load](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major3)
  * [Leave](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major4)
  * [Study Away and Change of Location](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major5)
  * [Program Transfer](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major6)
  * [Transfer to Another University ](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major7)
  * [Early Submission for Examination ](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major8)
  * [Readmission Within Maximum Duration](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major9)
  * [Extension Beyond Maximum Duration](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major10)
  * [Cancellation Due to Exceeding Maximum Duration](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major11)
  * [Cancellation Due to Unresponsive Candidate](https://policies.rmit.edu.au/document/view.php?id=16&version=2#major12)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure sets out the rules and processes relating to higher degree by research (HDR) candidature duration and enrolment variation.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=16&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=16&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all HDR candidates.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=16&version=2#document-top)
# Section 4 - Procedure
### Duration of Candidature and Research Commencement Date
(4)  Permitted HDR candidature duration is calculated using Equivalent Full-Time Student Load (EFTSL) as follows:
  1. PhD: minimum 3.0 EFTSL and maximum 4.0 EFTSL.
  2. Masters by research: minimum 1.0 EFTSL and maximum 2.0 EFTSL.


(5)  Research commencement date is stated in the candidate’s offer of admission and is the date from which candidature duration is calculated.
(6)  Candidates unable to start by the research commencement date must notify the School of Graduate Research (SGR) immediately and may need to seek a deferment via email to their senior supervisor to ensure that their candidature duration is correctly calculated. Deferments are subject to rules set out in the HDR Admissions and Scholarships Procedure.
  1. SGR will process deferments on receipt of email confirmation by the senior supervisor of the new, agreed research commencement date.
  2. Failure to seek a deferment in the event of a candidate not enrolling by the research commencement date within one month will result in the candidate’s offer of admission lapsing, which may also affect visa and scholarship status.


(7)  Candidates must remain enrolled for the duration of their candidature unless on an approved leave of absence.
  1. Candidates may be enrolled by SGR in training and development activity post-submission, such as research internships. They may not themselves enrol in classes for this purpose.


### Variations to Candidature
(8)  Variations to candidature are subject to approval by the ADVC RT&D, unless otherwise specified in this procedure, on provision of supporting evidence and subject to any applicable scholarship terms and conditions.
### Study Load
(9)  Candidate enrolment shall be either full-time (1.0 EFTSL per 12 months), or part-time (0.5 EFTSL per 12 months).
(10)  Full-time commitment will average at least four days per week over the course of a year. Part-time commitment will average at least two days per week over the course of a year. Any work, paid or otherwise, undertaken by the candidate outside of their research project must not affect their ability to maintain this commitment.
(11)  International candidates studying in Australia on a student visa must complete and submit a Recommendation to Reduce Enrolment Load Form and supporting documentation (CASP, medicate certificates, etc.) to their HDR Delegated Authority. If the recommendation is endorsed, the Research Training Services (RTS) team in SGR submits the documentation for approval by the ADVC RT&D.
(12)  All other candidates can request change between full- and part-time study load for an enrolment period by submitting a request to their senior supervisor and notifying RTS. 
### Leave
(13)  Candidates are entitled to a total of 20 working days’ annual leave per year. 
(14)  Candidates must discuss any proposed leave period with their senior supervisor prior to applying for any type of leave.
(15)  Candidates are entitled to a total of twelve (12) months’ leave of absence (LOA) per candidature to cover medical, compassionate or compelling circumstances which prevent the candidate carrying out research, subject to provision of appropriate documentation and any terms and conditions of their scholarship/sponsorship.
(16)  Candidates are entitled to up to six (6) months’ parental leave, including adoption leave for each child born or adopted during candidature, subject to provision of appropriate documentation and any terms and conditions of their scholarship/sponsorship.
(17)  Requests for parental leave may be granted in addition to the standard leave of absence provisions.
(18)  Candidates may apply for all types of leave of absence, including parental leave, by submitting a Leave of Absence Form with supporting documentation to RTS. 
(19)  Candidates receiving a scholarship or sponsorship must contact their provider to discuss the potential impact of LOA on their scholarship/sponsorship.
(20)  Candidates whose research has ethics approval, or an ethics approval pending, must notify the secretary of the relevant ethics committee when any application by them for LOA is granted, as this can impact their ethics approval. 
(21)  If the application for LOA is less than the total amount permissible for candidature (12 months) the LOA form must be submitted for approval by the HDR DA, after consultation with the supervisory team. If approved, the application is processed by RTS.
(22)  If the application for LOA is greater than the total amount permissible for candidature (12 months) or the candidate has been granted an extension beyond maximum duration, the LOA form must be submitted for endorsement by the HDR DA, after consultation with the supervisory team. If the application is endorsed, RTS must submit the documentation for approval by the ADVC RT&D.
(23)  SGR will notify candidates of the outcome of their LOA application.
(24)  Candidature maximum and milestone due dates are adjusted for any periods of approved LOA and candidates must cease working on their research during this period.
(25)  Access to University facilities and resources will be restricted during a period of LOA.
(26)  A candidate may request a review of a decision to vary or reject their application for leave in accordance with the [Enrolment Processes](https://policies.rmit.edu.au/document/view.php?id=45) and [Enrolment Procedure – Leave of Absence](https://policies.rmit.edu.au/document/view.php?id=115).
### Study Away and Change of Location
(27)  The University has a duty to manage the risk to enrolled candidates’ safety and wellbeing and to assure the quality of their experience. 
(28)  For this reason, candidates must inform the University of their intent to spend any time away from their normal location of study for the purposes of their research, to ensure appropriate risk assessments and controls have been put in place to cover their travel and activity in accordance with the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97). Failure to do so will limit the University’s ability to support candidates’ safety and wellbeing.
(29)  Candidates changing their normal location of study for a period of three months or more must notify RMIT of their ‘change of location’ by submitting a Notification of Change of Study Location Form to RTS.
(30)  Changing location between Australia and a country outside of Australia will have implications for those candidates requiring a student visa.
  1. Where an international candidate on a student visa is planning a permanent change of location outside of Australia, on receipt of the form, SGR will notify RMIT’s International Compliance office that the candidate is leaving Australia and no longer requires a confirmation of enrolment (eCoE).
  2. Candidates must update their RMIT record with any change to address and contact details as a result of a study away period or a change of location.


### Program Transfer
(31)  For candidates wishing to transfer between HDR programs or to RMIT from another university, the transfer may be supported, subject to entry and admission conditions being met, if:
  1. less than 3.0 EFTSL has been consumed in a PhD, or
  2. less than 1.0 EFTSL consumed in a masters by research.


(32)  A transfer after 3.0 EFTSL (PhD) or 1.0 EFTSL (masters by research) may take place in exceptional circumstances, subject to approval by the ADVC RT&D.
(33)  Candidates may request a transfer to another HDR program by submitting an application via the RMIT University Application Service. Candidates must discuss their proposed change of program with their supervisory team (and proposed supervisory team, if a change of supervisor is required) before submitting supporting documentation to RTS (see clause 38-40 below).
(34)  The transfer application must be endorsed by the HDR DA in the school offering the proposed program, after consultation with the proposed supervisory team.
(35)  If approved, candidates will receive an offer of admission to their new program from SGR.
(36)  In accordance with the [HDR Sanctions Assessment Process](https://policies.rmit.edu.au/document/view.php?id=21), candidates who are subject to sanctions assessment must have a new sanctions assessment completed by their senior supervisor (or proposed senior supervisor) before any transfer can be processed.
(37)  The following supporting documentation is required for transfer at the same level (masters to masters or PhD to PhD):
  1. the reasons for the request 
  2. a summary of the work completed 
  3. an outline of the work remaining 
  4. a timeline for the completion of the work remaining 
  5. evidence of support from the senior supervisor (or proposed senior supervisor) 
  6. a Change of Supervisor Form, if a change of supervisor is required (see the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14) for further details).


(38)  Transfer from a masters to a PhD program
  1. Candidates who wish to transfer from a masters to a PhD program must demonstrate that they can expand the scope of their research to doctoral level by presenting a PhD-level confirmation of candidature in place of a masters-level second milestone review. The [HDR Progress Management Procedure](https://policies.rmit.edu.au/document/view.php?id=15) provides further information on milestone reviews. 
  2. Supporting documentation must include: 
    1. milestone review outcome notification from SGR inviting the candidate to transfer program
    2. evidence of support from the senior supervisor (or proposed senior supervisor)
    3. a Change of Supervisor Form, if a change of supervisor is required.


(39)  Transfer from a PhD to a masters program
  1. Candidates who wish to transfer from a PhD to masters program must demonstrate that they can reduce the scope of their research to masters-level by presenting a masters-level milestone.
  2. Supporting documentation must include: 
    1. masters-level milestone review outcome notification from SGR inviting the candidate to transfer program
    2. evidence of support from the senior supervisor (or proposed senior supervisor)
    3. a Change of Supervisor Form, if a change of supervisor is required.


### Transfer to Another University 
(40)  Candidates wishing to transfer to another university may obtain documentation about their candidature, including transcripts, from SGR on request at the point of cancellation.
### Early Submission for Examination 
(41)  Candidates who wish to submit for examination before the minimum duration of candidature stated in the Higher Degrees by Research Policy must submit a case for early submission to RTS. The case must include:
  1. the background of the request, and
  2. support from their senior supervisor.


(42)  The case must be endorsed by the HDR DA. If the recommendation is endorsed, RTS must submit the documentation for approval by the ADVC RT&D.
### Readmission Within Maximum Duration
(43)  Candidates who wish to apply for readmission within maximum duration must submit an application via the RMIT University Application Service. Candidates must discuss their proposed readmission with their supervisory team before submitting supporting documentation to RTS.
(44)  Supporting documentation must include:
  1. the background of the request
  2. a summary of work completed prior to the cancellation of enrolment
  3. an outline of the work remaining
  4. a timeline for the completion of the work remaining
  5. a change of supervisor form, if a change of supervisor is required.


(45)  If approved for readmission, the candidate will be issued an offer with a revised maximum completion date and advised to enrol online.
### Extension Beyond Maximum Duration
(46)  Candidates may apply for an extension beyond maximum duration by submitting a Candidate Action and Support Plan (CASP). Candidates should discuss their extension and develop their CASP with their supervisory team before submitting it to RTS. For more details on CASPs see the [HDR Action and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=13).
(47)  Extensions beyond maximum duration of candidature are not automatic and, if approved, are strictly capped at the duration of the approved, accompanying CASP.
(48)  The extension application must be endorsed by the HDR DA, after consultation with the supervisory team. If the application is endorsed, RTS must submit the documentation for approval by the ADVC RT&D.
(49)  International candidates studying in Australia on a student visa will be advised how to apply for a new eCoE for a visa extension if their extension beyond maximum is approved.
### Cancellation Due to Exceeding Maximum Duration
(50)  Candidates and their supervisory team will receive at least two automated notifications that the candidate is approaching their maximum completion date.
(51)  Candidates who do not submit by their maximum completion date, or their extension end-date, will be notified that they have exceeded maximum duration of candidature. This notification will inform candidates of the options available to them and advise that, if they do not take any action, the ADVC RT&D will request that the Academic Registrar cancel the candidate’s enrolment.
(52)  Candidates whose enrolment is cancelled for exceeding maximum duration are eligible to apply for readmission for the purpose of examination within three years of their cancellation. See the [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18) for further information.
### Cancellation Due to Unresponsive Candidate
(53)  A candidate may be considered unresponsive and having abandoned their program of study under one or more of the following circumstances:
  1. Failure to return to their studies after a period of approved leave of absence.
  2. Failure to maintain regular communication and interaction with their supervisory team and to respond to reasonable attempts by the University to contact them. 


(54)  Primary supervisors who have had no response from a candidate after reasonable attempts will notify the HDR DA. It is recommended that action be taken no later than two months follow last contact with the candidate. 
(55)  Where the HDR DA is satisfied the supervisory team have not had any recent contact with the candidate, they will notify RTS of the candidate’s status and provide supporting information.
(56)  Following discussion with the HDR DA, RTS will notify the candidate of the options available to them and advise, if they do not respond to University correspondence within 20 working days and re-engage with their studies, the ADVC RT&D or delegate will request that the Academic Registrar cancel their enrolment. Where the candidate is an international student, RTS will notify the relevant parts of the University. 
(57)  Candidates whose enrolment is cancelled due to being unresponsive may be eligible to apply for Readmission within Candidature as prescribed in this procedure or [Readmission for Submission](https://policies.rmit.edu.au/document/view.php?id=18).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
