[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=130&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=130&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Currency of Learning Guideline 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=130)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=130&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=130&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=130&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=130&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=130&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=130&version=3)


# Currency of Learning Guideline
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=130&version=3#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=130&version=3#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=130&version=3#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=130&version=3#section4)
  * [Currency of Learning](https://policies.rmit.edu.au/document/view.php?id=130&version=3#major1)
  * [Internal Credit Older Than 10 Years](https://policies.rmit.edu.au/document/view.php?id=130&version=3#major2)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This document describes the time limitations and conditions that apply to any previous study or learning nominated as the basis for credit transfer towards an RMIT course or program.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=130&version=3#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=130&version=3#document-top)
# Section 3 - Scope
(3)  This guideline applies to all applications for program and course credit.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=130&version=3#document-top)
# Section 4 - Guideline
### Currency of Learning
(4)  To ensure currency of learning in external learning is used as the basis of an application for credit towards an RMIT course, any previous learning must have been successfully completed within the last 10 years before the student’s commencement of the RMIT program (unless clause (8) applies).
(5)  Where an applicant is seeking credit based on an entire qualification, the qualification must have been completed within the past 10 years before the student’s commencement of the RMIT program. 
(6)  The conferral date of a qualification is not used to identify currency of learning: rather, credit assessors refer to the student’s transcript of results showing the years in which courses were completed. This does not apply to masters advanced standing: see Credit Procedure: Masters Advanced Standing. 
(7)  Where the original learning was completed earlier than the recency limit for credit, and there is evidence of ongoing professional work and/or professional development in the discipline of the award, the student may apply for recognition of prior learning. 
### Internal Credit Older Than 10 Years
(8)  The requirement for previous study to have been completed within the past 10 years does not apply to previous study in:
  1. the same or a closely related RMIT program, such as a graduate diploma that is an exit award from a masters program, or
  2. a previous version of the same program. 


(9)  Currency of learning also applies to study undertaken in unrelated RMIT programs. It does not apply to previous study that is considered to be study in the same program, where credit is used as an administrative means of transferring the student’s previous enrolment to a closely-related program. 
(10)  Programs may set limits on the amount of credit for previous study completed long ago in the same or a closely related program, to ensure that the student will have met the current learning outcomes of the current award. 
  1. Where a school/industry cluster/college wishes to apply internal credit that is older than 10 years they may do so with the approval of the Deputy Dean (or equivalent). 


(11)  Where a student applies for entry to a closely related program or for re-entry to a past or linked program and the school/industry cluster/college wishes to deny credit for previous RMIT study completed more than 10 years before, this must be stated in writing to the student either: 
  1. at the point of admission, if the student declares their previous RMIT study at admission, or 
  2. at the point when the student applies for credit, if they did not declare their previous study at RMIT at admission but reveal it when they apply for credit later. 


(12)  Where selection is performed by a central unit on behalf of the school/industry cluster/college, the admissions team must consult the program about what to do if an applicant has previous study in a similar RMIT program completed more than 10 years before. 
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
