[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=174#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=174#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Unsatisfactory Progress Process 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=174)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=174)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=174)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=174)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=174)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=174)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=174)


# HDR Unsatisfactory Progress Process
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=174#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=174#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=174#section3)
  * [Section 4 - Process](https://policies.rmit.edu.au/document/view.php?id=174#section4)
  * [College review of CASP](https://policies.rmit.edu.au/document/view.php?id=174#major1)
  * [College Review of Candidate Progress](https://policies.rmit.edu.au/document/view.php?id=174#major2)
  * [Candidature Termination](https://policies.rmit.edu.au/document/view.php?id=174#major3)
  * [Appeals Against Termination](https://policies.rmit.edu.au/document/view.php?id=174#major4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This document sets out the process for addressing unsatisfactory academic progress by Higher Degree by Research (HDR) candidates following the implementation of a Candidate Action Support Plan (CASP) as outlined in the [HDR Progress Management and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=15).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=174#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [HDR Progress Management and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=15). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=174#document-top)
# Section 3 - Scope
(3)  The process applies to all staff responsible for monitoring and managing HDR academic progress and all HDR candidates in the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=174#document-top)
# Section 4 - Process
### College review of CASP
(4)  Following a candidate’s continued unsatisfactory academic progress after the implementation of a CASP, the HDR Delegated Authority (HDR DA) will refer the matter to the college nominee.
(5)  Within 10 working days of referral, the college nominee will determine if any of the following has occurred: 
  1. a failure by the University as represented by the supervisory team, HDR DA, school administration or University services, which has materially affected the candidate’s ability to maintain good progress, or
  2. the candidate’s inability or refusal to complete the actions detailed for them in the CASP, or
  3. a combination of the above. 


(6)  If required, the college may also:
  1. interview the HDR DA and/or supervisory team
  2. conduct a confidential interview with the candidate.


(7)  The college nominee will submit a report of the audit to the School of Graduate Research (SGR) and a recommendation as to whether the candidate should:
  1. be permitted a further period of action and support
  2. if applicable, be permitted a third attempt at the milestone supported by a CASP
  3. attend a Research Candidate Progress Committee (RCPC).


(8)  Where a deficit in support provided by the University is identified, the audit report should also include a remediation plan.
(9)  The Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) or nominee will consider the recommendations from the college audit for approval, and determine subsequent action as needed.
(10)  SGR will monitor implementation of any remediation plan developed following college review.
### College Review of Candidate Progress
(11)  Where the college audit finds that responsibility for not meeting the conditions of the CASP lies with the candidate, the college will convene an RCPC to determine whether the candidature is viable.
  1. The Research Training Services (RTS) team in SGR must notify the candidate via email and invite them to attend, at least 15 working days prior to the meeting (unless otherwise agreed with the candidate). 
  2. Candidates must be enrolled and are afforded all the entitlements of enrolment during the college review of candidate progress.


(12)  The RCPC is convened by the college and will comprise the following members:
  1. Committee Chair (college nominee)
  2. school HDR DA
  3. an independent senior academic from another school in the same college, who is registered as an internal supervisor.


(13)  RCPC meetings must be in person or via video conferencing.
(14)  The candidate’s supervisory team is invited to provide evidence at the RCPC. At least one of the candidate’s supervisors must attend in this capacity. 
(15)  The candidate’s supervisors cannot be members of the RCPC panel and must not be present during Committee deliberations.
(16)  Reports and written submissions to the RCPC are to be provided to the members of the RCPC panel only.
(17)  Candidates may take one support person to the RCPC.
(18)  Candidates will be offered an opportunity to make a written submission to the committee.
  1. If they accept, their submission should provide evidence on all relevant issues and special circumstances affecting academic performance.
  2. They must also provide grounds to RMIT that clearly define how they will improve their progress.
  3. Wherever possible, this written submission must be supported by relevant independent documentation.


(19)  An RCPC can proceed without a written submission for a candidate and without their attendance at the meeting.
(20)  After consideration of all available evidence by the Committee, the Chair of the RCPC can recommend to the ADVC RT&D or nominee that:
  1. there is a valid case for the candidate to be allowed to continue in their program with an additional period of action and support, or
  2. the candidature is terminated due to unsatisfactory academic progress.


(21)  The RTS team in SGR will provide the RCPC meeting Minutes to the candidate, RCPC members, and the supervisors within 5 working days of the RCPC meeting.
(22)  The notification of the final RCPC outcome from the ADVC RT&D or nominee will be provided to the candidate by the RTS team in SGR via email within 15 working days of the meeting.
### Candidature Termination
(23)  Where an RCPC recommends that the candidature is terminated, and if the ADVC RT&D or nominee approves the recommendation, all documentation is forwarded to the Academic Registrar's Group (ARG) for a review of compliance with RMIT policies. 
  1. If, after ARG review, a termination of candidature decision is found to be non-compliant, SGR will inform the candidate, school and college that the candidate will require a further period of action and support. 
  2. If the termination documentation is compliant, ARG will commence the process of cancellation of enrolment.
  3. The notification of the intention to cancel enrolment will be provided to the candidate by ARG.


### Appeals Against Termination
(24)  A candidate may appeal against a decision to terminate their candidature to the University Appeals Committee (UAC) via the Academic Registrar. The appeal process is detailed in the [Assessment, Academic Progress and Appeals Regulations](https://policies.rmit.edu.au/document/view.php?id=190).
(25)  A candidate may lodge an appeal on the following grounds:
  1. there is evidence of a breach of University legislation, policy or process in the handling of the additional support process which has had significant impact on the determination to terminate the candidature, and/or
  2. there is significant new, relevant evidence that was not available at the time of the Research Candidate Progress Committee meeting.


(26)  Candidates must lodge their appeal application no later than 20 working days from the date the notification of intention to cancel their enrolment is sent to them by the university. The lodgement date will be specified in the notification of the intention to cancel enrolment.
(27)  A candidate is entitled to maintain their enrolment during an appeal against a decision to terminate their HDR candidature. If the appeal application is unsuccessful, the process to initiate enrolment cancellation by the Academic Registrar's Group will not be undertaken until the candidate is notified of the outcome of the appeal. Candidates will continue to consume candidature during this time.
(28)  Where an international candidate studying in Australia has their candidature terminated for unsatisfactory academic progress, the Academic Registrar will cancel the candidate’s confirmation of enrolment in accordance with the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
(29)  If candidature is terminated, any further enrolment in a Higher Degree by Research program at RMIT can only be achieved by the person re-applying for admission after a period of 12 months, in accordance with the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
