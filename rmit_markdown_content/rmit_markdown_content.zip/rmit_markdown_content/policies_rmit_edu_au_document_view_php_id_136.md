[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=136#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=136#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Destruction of Information Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=136)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=136)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=136)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=136)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=136)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=136)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=136)


# Destruction of Information Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=136#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=136#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=136#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=136#section4)
  * [Requirements for the Destruction of Information](https://policies.rmit.edu.au/document/view.php?id=136#major1)
  * [Destruction of records under Normal Administrative Practice (NAP)](https://policies.rmit.edu.au/document/view.php?id=136#major2)
  * [Destruction of records under a Retention and Disposal Authority (RDA)](https://policies.rmit.edu.au/document/view.php?id=136#major3)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=136#major4)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=136#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides requirements to ensure Information is destroyed pursuant to obligations in the [Public Records Act 1973](https://policies.rmit.edu.au/directory/summary.php?legislation=38).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=136#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=136#document-top)
# Section 3 - Scope
(3)  This procedure applies to RMIT Group staff, students, temporary employees, contractors, visitors and third parties who create, use, manage, handle or process data and information defined by Part A (Institutional Data) or Part B (Research Data) of the [Data and Information Lifecycle Management Procedure](https://policies.rmit.edu.au/document/view.php?id=226). 
(4)  In addition to this procedure, destruction of Research Data must follow requirements in the Research Data Management Plan. 
(5)  Data and Information defined in Part C (Unofficial Information) of the [Data and Information Lifecycle Management Procedure](https://policies.rmit.edu.au/document/view.php?id=226) is not in the scope of this procedure and authority for its destruction sits with the Chief Information Officer (CIO).
(6)  This procedure should be read in conjunction with the [Retention and Disposal Standard](https://policies.rmit.edu.au/document/view.php?id=55).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=136#document-top)
# Section 4 - Procedure
### Requirements for the Destruction of Information
#### Legal Requirements
(7)  Destruction of RMIT Records is conducted lawfully from either of the following:
  1. Destruction of records under the principle of Normal Administrative Practice (NAP), defined below.
  2. Destruction of records covered by a RMIT Retention & Disposal Authority (RDA), defined below. 


(8)  Records which have a retention period specified in the RMIT RDA may be destroyed when the records meet all conditions below:
  1. Records have met the minimum retention period specified in the RMIT Retention and Disposal Authority (RDA), within the [Retention and Disposal Standard](https://policies.rmit.edu.au/document/view.php?id=55).
  2. Records are reasonably unlikely to be needed in a current or future legal proceeding. This includes any civil or criminal proceeding or an inquiry where evidence may be given before a court or person acting judicially, such as a Royal Commission or Board of Inquiry. 
  3. Records are not required for meeting any [Freedom of Information Act (FOI)](https://policies.rmit.edu.au/directory/summary.php?legislation=8) applications which are not yet finalised. 
  4. Records are not required for audits or investigations which are not yet finalised. 


#### Business Requirements
(9)  Destruction of RMIT records must be planned and integrated into the University’s business processes and programs, including information governance.
(10)  Records designated for destruction must no longer be required by the responsible work unit, school or college, or for any other justifiable business or operational purpose.
#### Authorisation
(11)  Destruction actions and retention periods for information must be justified.
(12)  Destruction actions must be based on an informed decision-making process.
(13)  Destruction of RMIT records must be authorised.
(14)  Internal authorisation must be sought prior to destruction. 
#### Documentation
(15)  The University must be able to evidence that implementation of destruction decisions was authorised and lawful. Documentation must include:
  1. relevant classes from the Retention and Disposal Authority (RDA)
  2. a full description of the information being destroyed
  3. a record of all approvals, and
  4. assurance/statement of destruction. Refer to the [RMIT Destruction of Information Data Template](https://rmiteduau.sharepoint.com/:w:/r/sites/Analytics&Insights/_layouts/15/Doc.aspx?sourcedoc=%7BB2AA70FA-D6CC-49A7-BD7B-CF931E7F27B1%7D&file=Destruction%20of%20Information%20Template.docx&action=default&mobileredirect=true&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMzA5MjkxMTIwNyIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D) for more information.


#### Timeliness
(16)  Once authorised, records must be disposed of or destroyed in a timely manner.
#### Security and Irreversibility
(17)  Destruction should be undertaken with a level of security commensurate to the Information Classification of the record.
(18)  Records destruction must be monitored to ensure it has been undertaken accurately.
(19)  Destruction of records must be secure and irreversible such that records be inadvertently released or lost. 
### Destruction of records under Normal Administrative Practice (NAP)
(20)  Records which can be destroyed via Normal Administrative Practice (NAP) principles are not subject to the retention requirements in the RDA, are pre-authorised for destruction and do not require documentation.
(21)  NAP allows for the destruction of: 
  1. working documents, such as notes or calculations, used to assist in the preparation of other records and duplicate copies.
  2. minor drafts and transitory documents, where the content is reproduced elsewhere, and the information will not be needed to show how the work has progressed or actions approved.
  3. minor updates of content, such as those in databases, which will not be needed to show actions, decisions, or approvals. 


### Destruction of records under a Retention and Disposal Authority (RDA)
(22)  Requirements for the Destruction of Information must be met and documented this via the RMIT [Destruction of Information Data Template](https://rmiteduau.sharepoint.com/:w:/r/sites/Analytics&Insights/_layouts/15/Doc.aspx?sourcedoc=%7BB2AA70FA-D6CC-49A7-BD7B-CF931E7F27B1%7D&file=Destruction%20of%20Information%20Template.docx&action=default&mobileredirect=true&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMzA5MjkxMTIwNyIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D). 
### Responsibilities
(23)  All decisions relating to the destruction of information must be approved and overseen by RMIT employees with the appropriate delegations, as defined in the [Public Records Act 1973](https://policies.rmit.edu.au/directory/summary.php?legislation=38) and outlined below.
(24)  The Chief Data and Analytics Officer oversees information governance at RMIT University, which includes the destruction of data and information.
(25)  Any staff member who has custody and responsibility over certain bodies of information at RMIT can propose information for destruction and is responsible for:
  1. initiating the destruction process by identifying information for destruction and completing a proposal for destruction in line with the requirements described above.
  2. obtaining required approvals for the destruction.
  3. ensuring decisions and the destruction are documented and the documentation retained.
  4. engaging other RMIT teams for review if required (i.e. Legal Services and Freedom of Information team)


(26)  Information Trustees (as defined in the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53)) are accountable for reviewing and approving information destruction.
  1. The Information Trustee brings a knowledge of the high-level functions and goals of their area and makes a judgement as to the reasonable likeliness of current and future requirement for the information.
  2. If the Trustee decides not to approve destruction, they must provide justification for its further retention and document the reasons for ongoing business need.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=136#document-top)
# Section 5 - Definitions
For the purposes of this procedure:
Record |  Is a set of information created, collated, received, or maintained as evidence while conducting the business of RMIT and/or in pursuance of legal obligations.   
---|---  
Disposal |  The range of processes associated with implementing appraisal decisions which are documented in disposal authorities or other instruments. These include: 1. the retention, destruction or deletion of records in or from recordkeeping systems 2. the migration or transmission of records between recordkeeping systems 3. the transfer of ownership or the transfer of custody of records (for example, to PROV) The lawful disposal of records is an essential and critical component of any records management program.  
Destruction | The process of eliminating or deleting records, beyond any possible reconstruction.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
