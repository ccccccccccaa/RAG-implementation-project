[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=188#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=188#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Colleges Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=188)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=188)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=188)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=188)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=188)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=188)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=188)


# Academic Colleges Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=188#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=188#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=188#minor2)
  * [Part B - ACADEMIC COLLEGES](https://policies.rmit.edu.au/document/view.php?id=188#part2)
  * [3. Colleges](https://policies.rmit.edu.au/document/view.php?id=188#minor3)
  * [Part C - REVOCATION OF REGULATIONS](https://policies.rmit.edu.au/document/view.php?id=188#part3)
  * [4. Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=188#minor4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to make provision for the establishment of Colleges.
#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
## Part B - ACADEMIC COLLEGES
#### 3. Colleges
(3)  Subject to University legislation, each college:
  1. carries out such teaching, research, training, examinations and other higher education and vocational educational and training activities as the Academic Board approves, and
  2. regulates its own administrative and academic affairs in accordance with the relevant policies and procedures.


(4)  Each college has the following members:
  1. all staff of the college howsoever employed
  2. all students enrolled in the college, and
  3. such other persons as may be prescribed by the Regulations.


## Part C - REVOCATION OF REGULATIONS
#### 4. Revocation of Regulations
(5)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 2.9.1 The Portfolio Boards.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
