[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=128#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=128#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Asset Management Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=128)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=128)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=128)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=128)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=128)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=128)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=128)


# Asset Management Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=128#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=128#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=128#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=128#section4)
  * [University Assets](https://policies.rmit.edu.au/document/view.php?id=128#major1)
  * [Recognition of Assets](https://policies.rmit.edu.au/document/view.php?id=128#major2)
  * [Stocktake](https://policies.rmit.edu.au/document/view.php?id=128#major3)
  * [Depreciation and Amortisation](https://policies.rmit.edu.au/document/view.php?id=128#major4)
  * [Revaluation](https://policies.rmit.edu.au/document/view.php?id=128#major5)
  * [Change of Location, Transfer and Loan](https://policies.rmit.edu.au/document/view.php?id=128#major6)
  * [Asset Maintenance and Disposal](https://policies.rmit.edu.au/document/view.php?id=128#major7)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=128#major8)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=128#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=128#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides business rules to ensure compliance with accounting standards related to capitalisation and depreciation/amortisation of tangible and intangible assets used by the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=128#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Financial Management Policy](https://policies.rmit.edu.au/document/view.php?id=70).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=128#document-top)
# Section 3 - Scope
(3)  This procedure applies to all RMIT Group assets, including library collections and works of art.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=128#document-top)
# Section 4 - Procedure
### University Assets
(4)  All assets purchased, constructed or loaned must be recorded in the University’s accounting systems to enable RMIT to comply with relevant accounting standards. This includes all:
  1. assets costing over $5,000 (excluding GST)
  2. assets leased by RMIT with a purchase price over $5,000 and a lease duration of 12 months or more
  3. library assets and works of art, regardless of value.


### Recognition of Assets
(5)  The cost of an item of property, plant and equipment (PPE) will only be recognised as an asset if:
  1. it is probable that future economic benefits associated with the item will flow to the entity; and
  2. the cost of the item can be measured reliably.


(6)  The initial cost of an asset should include:
  1. the purchase price, including import duties
  2. any directly attributed costs associated with bringing the asset to a position of use (e.g. delivery fees)
  3. an initial estimate of costs of decommissioning the item, where the University is obligated to do so.


(7)  Central Finance Operations will initially identify assets requiring capitalisation. Organisational units may specifically highlight items required to be capitalised.
### Stocktake
(8)  PPE stocktake is undertaken on a three-year progressive cyclical basis to ensure that proper control of RMIT’s PPE is maintained by staff and controlled by management of the University.
(9)  Leased assets will undergo stocktake on a yearly basis due to the mobility and volatility of the nature of the assets leased.
(10)  Central Finance Operations is responsible for providing the details of fixed assets on a regular basis.
(11)  Responsibility for the control of fixed assets rests with the relevant operational areas of the University.
### Depreciation and Amortisation
(12)  Each PPE and leased asset must be depreciated.
  1. PPE depreciation is calculated on a straight-line basis over the estimated useful life of the asset
  2. leased assets are depreciated based on the lease’s term on a straight-line basis.


(13)  An intangible asset is amortised on a straight-line basis over its estimated useful life from the date it is available for use but to a maximum period of ten years.
  1. Useful life of an asset must be reviewed and confirmed for year-end reporting.
  2. The value of intangible assets must be assessed for impairment for each year-end.


### Revaluation
(14)  An independent valuation to ensure that fair value is determined from market-based evidence must be undertaken at least
  1. every three years, for all land and buildings
  2. every five years, for artwork.


### Change of Location, Transfer and Loan
(15)  Operational areas must notify Central Finance Operations about any asset change of location, transfer to another area, loan to an outside institution or loan to an RMIT staff member.
(16)  Loans to outside institutions and/or RMIT staff must have the prior approval of the Chief Financial Officer. It is the borrower’s responsibility to cover costs associated with removal and return, and to insure against losses.
### Asset Maintenance and Disposal
(17)  All assets must be kept with due regard for safety and security and maintained in good working order.
  1. Maintenance, control and safety of assets remain the responsibility of the individual departments.
  2. All surpluses, unserviceable or obsolete assets should be disposed of without undue delay.
  3. Responsible areas of the leased assets must ensure that all leased assets meet the relevant occupational, health and safety requirements.


(18)  The University must ensure the disposal of assets is correctly accounted for with an appropriate audit trail in place.
(19)  In the event of early termination of lease or disposal of a leased asset, Central Finance Operations must be notified in a timely manner.
### Responsibilities
(20)  Individual schools are responsible for obtaining appropriate approval for capital expenditure.
(21)  Procurement is responsible for reviewing work in progress (WIP) projects.
(22)  Information Technology Services is responsible for reviewing IT-related WIP projects, whether it be a tangible or intangible asset.
(23)  Areas of the University that receive donated assets must advise Central Finance Operations about each donation and the fair value of the donation.
(24)  Staff purchasing assets are responsible for ensuring that all purchases meet the relevant occupational, health and safety requirements
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=128#document-top)
# Section 5 - Resources
(25)  Refer to the following documents which are established in accordance with this procedure:
  1. [Asset Management Guideline](https://policies.rmit.edu.au/document/view.php?id=142)
  2. [Asset Capitalisation Guideline](https://policies.rmit.edu.au/document/view.php?id=141)
  3. [Asset Disposal Instruction](https://policies.rmit.edu.au/document/view.php?id=143)
  4. [Asset Management FAQs](https://policies.rmit.edu.au/download.php?id=182&version=2&associated)
  5. [Stocktake Instruction](https://policies.rmit.edu.au/document/view.php?id=144)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=128#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Asset |  RMIT assets include:
  1. property, plant and equipment (PPE) purchased, constructed or developed with RMIT resources, irrespective of source of funds that are owned and controlled by the respective entity
  2. PPE loaned or donated by/to RMIT
  3. intangible assets
  4. leased assets (where the lease term is longer than 12 months or the leased item’s purchase price exceeds $5,000).

  
---|---  
Asset exclusions |  Exclusions are only acceptable when local financial legislation conflicts with RMIT University’s policy. Exceptions must be reported to the Chief Financial Officer for reporting and consolidation purposes.  
Fixed Assets Register |  The Fixed Asset Register is maintained by the Financial Services Group, and records the cost, depreciation, transfer, disposal and location details of all accountable fixed assets.  
Intangible assets |  An asset that is not physical in nature.  
Leased PPE |  A rented or hired asset with a lease term longer than 12 months and a purchase value for the leased item greater than or equal to $5,000. Examples include, but are not limited to:
  1. building rental leases managed by Property Services
  2. rental of computers and other IT equipment managed by ITS Group
  3. hire of RICOH multi-functional printers managed by Procurement.

  
Property, plant and equipment (PPE) |  Property, plant and equipment with a capitalisation value as approved by the management of the University on an annual basis and with a useful life over one year: ·
  1. plant
  2. office furniture
  3. motor vehicles
  4. land and buildings
  5. furniture and fittings
  6. equipment
  7. artwork
  8. library collection
  9. leasehold improvements
  10. assets held off-campus

  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
