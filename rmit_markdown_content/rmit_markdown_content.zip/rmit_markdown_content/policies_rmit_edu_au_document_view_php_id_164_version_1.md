[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=164&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=164&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Procedure - Maximum Time to Complete a Coursework Program 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=164)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=164&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=164&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=164&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=164&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=164&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=164&version=1)


# Enrolment Procedure - Maximum Time to Complete a Coursework Program
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=164&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=164&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=164&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=164&version=1#section4)
  * [Overview](https://policies.rmit.edu.au/document/view.php?id=164&version=1#major1)
  * [Maximum Time to Complete A Coursework Program ](https://policies.rmit.edu.au/document/view.php?id=164&version=1#major2)
  * [Study Load](https://policies.rmit.edu.au/document/view.php?id=164&version=1#major3)
  * [Maximum Time Calculations](https://policies.rmit.edu.au/document/view.php?id=164&version=1#major4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This procedure outlines the maximum time allowed for coursework students to complete their program and details how to calculate maximum time for each type of program.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=164&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=164&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to: 
  1. all coursework students, and
  2. staff who administer enrolment matters.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=164&version=1#document-top)
# Section 4 - Procedure
### Overview
(4)  Students are required to complete all study to fulfil the requirements of their coursework program within certain time limits to ensure: 
  1. currency of knowledge for RMIT graduates, and 
  2. the University has the capacity to accept new students. 


(5)  Students who cannot complete the program within the maximum time may be classified by the Program Assessment Board as at risk in accordance with RMIT’s academic progress processes. 
### Maximum Time to Complete A Coursework Program 
(6)  Where students are required to study full-time as a condition of enrolment in the particular program, the maximum time for completion is the normal full-time duration plus 50% of the normal full-time duration (see Table 1). 
  1. Students studying on an Australian student visa must adhere to the requirements of their student visa. 


(7)  For all other students, the maximum time for completion is defined as follows: 
  1. In an undergraduate coursework program, the maximum time is the normal part-time duration plus 50% of the normal part-time duration up to a maximum of 20 teaching periods or 10 years, unless otherwise specified (see Table 2). 
  2. In a postgraduate coursework program, the maximum time is twice the normal part-time duration. 
  3. If a program has a non-standard volume of learning because all students enter on the basis of a qualification for which they would otherwise have to receive a substantial block of credit (e.g. a 192 credit points bachelor degree or a 96 credit points master degree) then the maximum time for completion is calculated as described. 


### Study Load
(8)  Tables 1 and 2 set out the normal durations and maximum times for all students in the types of program listed.
#### Table 1: Full-Time Duration and Maximum Time
(9)  Applies to students where full-time study is required as a condition of enrolment in the program or a visa condition. 
Type of program  | Normal duration (teaching periods)  | Maximum time (teaching periods) | Maximum time (years)*  
---|---|---|---  
Higher education diploma (96 credit points)  | 2 | 3 | 1.5  
Associate degree | 4 | 6 | 3  
Three-year bachelor degree  | 6 | 9 | 4.5  
Four-year bachelor degree (includes double degrees, bachelor honours degrees)  | 8 | 12 | 6  
Five-year double degree  | 10 | 15 | 7.5  
One-year bachelor honours degree  | 2 | 3 | 1.5  
Graduate Certificate | 1 | 2 | 1  
Graduate Diploma | 2 | 3 | 1.5  
Master by coursework  | 4 | 6 | 3  
Juris Doctor | 6 | 9 | 4.5  
#### Table 2: Part Time Duration and Maximum Time
(10)  Applies to students where full-time study is not a requirement as a condition of enrolment in the program. 
Type of program  | Normal duration (teaching periods)  | Maximum time (teaching periods) | Maximum time (years)*  
---|---|---|---  
Higher education diploma (96 credit points)  | 4 | 8 | 3  
Associate degree | 8 | 12 | 6  
Three-year bachelor degree  | 12 | 18 | 9  
Four-year bachelor degree (includes double degrees, bachelor honours degrees)  | 16 | 24 | 12  
Five-year double degree  | 20 | 30 | 15  
One-year bachelor honours degree  | 4 | 6 | 3  
Graduate Certificate | 2 | 4 | 2  
Graduate Diploma | 4 | 8 | 4  
Master by coursework  | 8 | 16 | 8  
Juris Doctor | 12 | 24 | 12  
(11)  *The maximum time permitted when a program is delivered in two standard semesters a year.
### Maximum Time Calculations
(12)  To calculate the time a student has been enrolled in a program (the time enrolled), the time starts on the start date of the first class in which the student is enrolled in the program. 
(13)  Optional teaching periods such as the Spring and Summer Semesters in Melbourne are not included in the calculation of the time enrolled. Where, however, the program structure requires students to enrol in those semesters, they are counted in the calculation. 
(14)  Work experience in industry or co-op years that are part of the approved program structure are included in both the program’s normal duration and the student’s enrolled time. 
(15)  The following periods of time are excluded from the calculation of a student’s time enrolled: 
  1. approved leave of absence 
  2. exclusion for sustained unsatisfactory academic performance 
  3. suspension under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). 


(16)  Where a continuing student fails to enrol, their enrolment is discontinued, and they go on to apply for readmission to the program or to a replacement program that is considered by the University to be the same program, all of the intervening time is considered to be part of the student’s time enrolled, as the University has not initiated or approved the student’s absence. 
(17)  Where a student is transitioned to a new version of a program or a replacement program, the student’s time enrolled is still considered to have started from the first day of the first teaching period in which they were enrolled in their original program. This will be specified in the letter informing them of the transition arrangements. 
(18)  Where a student is admitted to an unrelated program, the count of time enrolled starts from the first day of the first teaching period in which the student is enrolled in the new program.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
