[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=17&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=17&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Posthumous Submission and Examination Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=17)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=17&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=17&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=17&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=17&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=17&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=17&version=1)


# HDR Posthumous Submission and Examination Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=17&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=17&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=17&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=17&version=1#section4)
  * [Eligibility](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major1)
  * [Death of a Candidate During Examination](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major2)
  * [Review of the Research](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major3)
  * [Authority to Approve Requests for Posthumous Examination](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major4)
  * [Preparation of Research for Examination](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major5)
  * [Submission](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major6)
  * [Posthumous Examination](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major7)
  * [Post-examination](https://policies.rmit.edu.au/document/view.php?id=17&version=1#major8)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=17&version=1#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure provides information about the processes for posthumous submission and examination of research undertaken by an HDR candidate who becomes deceased before being able to complete their degree. Allowing posthumous submission and examination is regarded as respectful recognition of the amount of effort made by the candidate and their supervisory team in progressing the research to a near-complete stage.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=17&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=17&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all RMIT HDR candidates who meet the eligibility criteria, regardless of location.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=17&version=1#document-top)
# Section 4 - Procedure
### Eligibility
(4)  Within one year of the death of an HDR candidate their research work may be considered for posthumous examination if:
  1. the candidate was enrolled at RMIT in the relevant course of study at the time of their death; or had an active enrolment at RMIT in the 12 months prior to their death; and
  2. they had a successful outcome for their third milestone review; and
  3. an application to undertake this process is made on behalf of the candidate, with the consent of the family; and
  4. the work is substantially complete and of an appropriate level to be examined for the degree, as attested to by two independent assessors (see section 3).


### Death of a Candidate During Examination
(5)  In the unfortunate event that a candidate dies while their HDR submission is being examined, and examiners recommend revisions to be made, the senior supervisor may choose to undertake the revisions on behalf of the candidate.
### Review of the Research
(6)  The senior supervisor will request that the process for a posthumous submission and examination is initiated normally within one year of the death of the candidate.
(7)  The HDR Delegated Authority (HDR DA) in consultation with the senior supervisor, will identify two assessors to be appointed to review the available work to determine whether the research is substantially complete and of an appropriate level to be examined for the degree.
(8)  Assessors must be independent of the supervision of the research but need not be external to the university.
(9)  The senior supervisor must provide a brief statement outlining the research to facilitate the assessors understanding of the candidate's research contribution, and, in cases in which the work is not complete, outline the remaining work which was planned.
(10)  Assessors must unanimously agree that sufficient papers, reviews, laboratory or project work, or other verifiable evidence, have been completed by the candidate so that a coherent summary of the research can be given to the examiners.
(11)  Where minor amendments to the work are recommended, these should be clearly specified by the assessors. Minor amendments can include tasks such as preparation of table of contents, pagination of the document, arrangement of materials into appendices where this had not been done, minor textual amendments for clarity or to account for gaps left by the candidate, or any additions to the text of the candidate’s work necessary to prepare it for examination. The changes to the text must fall short of substantive additions to this text.
### Authority to Approve Requests for Posthumous Examination
(12)  Once the work has been assessed as being appropriate for examination, a written request for posthumous submission and examination of the research must be made to the Graduate Research Committee (GRC) Executive group by the HDR DA in the school where the candidate was enrolled.
(13)  The senior supervisor must prepare the request and include the:
  1. candidate’s full name
  2. student identification number
  3. name of the qualification for which the individual was a candidate
  4. name/s and address/es of the next-of-kin who endorse the request
  5. two assessors’ reports.


(14)  The GRC Executive has final approval for the request to proceed with the examination.
### Preparation of Research for Examination
(15)  If posthumous examination is approved, the examination process and the possible outcomes will be explained to the next-of-kin by the senior supervisor.
(16)  If the assessors or the GRC Executive require minor amendments to be made to the research prior to its examination, it is the responsibility of the senior supervisor to undertake these within two months of the GRC approval for the examination.
(17)  A list of any minor amendments or modifications to the research by the senior supervisor must be included in the statement.
(18)  The statement used for the assessors (section 9) is then updated by the senior supervisor for presentation to the examiners to explain the candidate's research contribution to the work to be examined.
### Submission
(19)  The usual process for nominating examiners is followed.
(20)  The research is submitted for examination following the usual submission process with the following changes:
  1. the senior supervisor lodges the submission for examination
  2. there is no requirement for a current enrolment.


### Posthumous Examination
(21)  Examiners are advised of the circumstances of the posthumous submission. A modified version of the examination report pro forma and the guide for examiners reflecting the modified examination criterion are sent for this purpose.
(22)  In the case of the candidate having been undertaking research which would normally be examined through an experiential presentation the requirement for a presentation and defence of the research is waived.
(23)  Examiners must recommend one of the following outcomes:
  1. R1 - Yes, evidence exists to indicate that, had the candidate lived, and in the normal course of events, the requirements for the degree would have been satisfied – degree to be conferred.
  2. R2 - Yes, evidence exists to indicate that, had the candidate lived, and in the normal course of events, the requirements for the degree would have been satisfied – degree to be conferred subject to minor amendments.
  3. R5 - No, there is insufficient evidence to indicate that, had the candidate lived, and in the normal course of events, the requirements for the degree would have been satisfied – the degree will not be conferred.


(24)  For the award to be granted both examiners’ reports must record that there exists a reasonable expectation that, had the candidate lived, and in the normal course of events, the requirements for the degree would have been satisfied.
### Post-examination
(25)  After the examination has been classified, SGR sends advice to the members of the supervisory team, the Dean/Head of School and the HDR DA. A separate notification is sent to the examiners to advise them of the examination classification.
(26)  The Dean/Head of School is responsible for advising the candidate’s family of the examination outcome.
(27)  If the examination has a successful outcome, the senior supervisor is responsible for the submission of the final archival version of the research.
(28)  The examination outcome is recorded against the last semester of the candidate’s enrolment.
(29)  In order for the award to be conferred the Conferral and Graduation Policy and associated procedure must be followed.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=17&version=1#document-top)
# Section 5 - Procedures and Resources
(30)  Refer to the:
  1. Graduate Research Committee – Terms of Reference


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
