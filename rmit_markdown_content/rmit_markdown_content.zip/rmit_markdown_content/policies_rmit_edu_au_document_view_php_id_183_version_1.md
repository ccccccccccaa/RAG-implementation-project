[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=183&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=183&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Long Term Storage of Information Standard 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=183)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=183&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=183&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=183&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=183&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=183&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=183&version=1)


# Long Term Storage of Information Standard
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=183&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=183&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=183&version=1#section3)
  * [Section 4 - Standard](https://policies.rmit.edu.au/document/view.php?id=183&version=1#section4)
  * [Movement and Storage Requirements](https://policies.rmit.edu.au/document/view.php?id=183&version=1#major1)
  * [Format](https://policies.rmit.edu.au/document/view.php?id=183&version=1#major2)
  * [Copies](https://policies.rmit.edu.au/document/view.php?id=183&version=1#major3)
  * [Export](https://policies.rmit.edu.au/document/view.php?id=183&version=1#major4)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Purpose
(1)  Information is one of RMIT’s most valuable assets. It must remain accessible, protected and trustworthy for as long as legally required.
(2)  RMIT must comply with [Public Records Office Victoria (PROV) standards](https://policies.rmit.edu.au/download.php?id=43&version=2&associated) issued under the [Public Records Act 1973](https://policies.rmit.edu.au/directory/summary.php?legislation=38). These standards specify how the information we create as part of our work – or records - must be managed.
(3)  This standard must be used to manage data and information when it needs to be moved from an active, high availability location to a less active, medium/low availability location/s.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=183&version=1#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=183&version=1#document-top)
# Section 3 - Scope
(5)  This standard applies to any person or entity of the RMIT Group, including staff, students, temporary employees, contractors, visitors and third parties who manage RMIT information in line with the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53). 
(6)  This Standard applies in any situation where RMIT data and information is being stored and may include (but is not limited to) on-site, RMIT controlled offsite, third party managed or any other storage location.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=183&version=1#document-top)
# Section 4 - Standard
### Movement and Storage Requirements
(7)  The movement and storage of data and information must support the retention of data and information for as long as it is required for legal and business purposes, including for data analytics purposes. 
  1. Selection of storage locations must be informed by retention requirements, including the ability to apply legal retention periods as per the [Retention and Disposal Standard](https://policies.rmit.edu.au/document/view.php?id=55) and the longevity of the location/platform. 


(8)  The movement and storage of data and information must provide sufficient protection over time. 
  1. Data and information must be protected from misuse, loss, deterioration or damage and inherit or have appropriate information security classifications applied as per the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53). 


(9)  The movement and storage of data and information must support timely discovery and access, by supporting the application of appropriate metadata. 
(10)  Ownership and accountability for data and information remains with the Information Trustee across its lifecycle, regardless of age or location. 
(11)  Information in long term storage must have an appropriate disaster recovery and business resilience plan in place.
### Format
(12)  Data and information should be stored in technology-neutral, sustainable formats wherever possible, and in accordance with [PROS 19/05 S3: Long Term Sustainable Formats](https://policies.rmit.edu.au/download.php?id=265&version=1&associated).
### Copies
(13)  Data and information required for long periods must be stored in locations that conform to this Standard and all other Information Governance and ITS resources. The following represent principles should be considered for storage systems: 
  1. Redundancy and diversity Make multiple independent copies of digital material, using different storage media, and store these in different geographic locations. 
  2. Fixity, monitoring, repair Use fixity measures such as checksums to record and regularly monitor the integrity of each copy of the digital material, using alternate copies to repair corruption/loss if required. 
  3. Technology and vendor watch, risk assessment, and proactive migrations Understand that storage technologies, products and services all have a short lifetime; be proactive in migrating storage before digital material becomes at risk 
  4. Consolidation, simplicity, documentation, provenance and audit trails Minimise the proliferation of legacy media types and storage systems used for preservation; document how digital materials have been acquired and transferred into the storage systems as well as how the storage systems are set-up and operated and use this to provide audit information on data authenticity.


(14)  A copy of data and information created for back–up must not be used as a long-term storage solution. 
### Export
(15)  An export function must allow timely, cost efficient and complete extraction of all information, data and metadata in technology-neutral, sustainable formats wherever possible.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
