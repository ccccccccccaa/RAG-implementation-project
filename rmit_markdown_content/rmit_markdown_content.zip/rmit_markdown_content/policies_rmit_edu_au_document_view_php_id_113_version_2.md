[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=113&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=113&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=113)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=113&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=113&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=113&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=113&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=113&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=113&version=2)


# Enrolment Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=113&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=113&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=113&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=113&version=2#section4)
  * [Enrolment](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major1)
  * [Non-Award Enrolments](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major2)
  * [Enrolment Loads](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major3)
  * [Minimum Age for Enrolment](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major4)
  * [Enrolment Variation](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major5)
  * [Continuity of Enrolment](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major6)
  * [Leave of Absence](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major7)
  * [Cancellation of Program Enrolment](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major8)
  * [Enrolment Variation on Administrative Grounds](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major9)
  * [Overload Enrolment](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major10)
  * [Extension of Enrolment Entitlements Under Some Exceptional Circumstances](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major11)
  * [Citizenship/Residency Status Change](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major12)
  * [Effect of Exclusion, Suspension or Expulsion](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major13)
  * [Student Fees and Charges](https://policies.rmit.edu.au/document/view.php?id=113&version=2#major14)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=113&version=2#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure provides the rules and requirements for enrolment of students at RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=113&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=113&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all students enrolled in programs and courses offered by the RMIT Group including RMIT University, RMIT Vietnam, RMIT Training, RMIT Online, and RMIT partner institutions.
(4)  It applies to pathway programs provided by RMIT Training and RMIT Vietnam including Foundation Studies and UniSTART.
(5)  This procedure does not apply to:
  1. short courses and other industry training courses provided by RMIT Training and RMIT Online
  2. English Language Intensive Courses for Overseas Students (ELICOS) training programs provided by RMIT English Worldwide at RMIT Training.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=113&version=2#document-top)
# Section 4 - Procedure
### Enrolment
(6)  A student must formally enrol or re-enrol on or before the date prescribed each year by following the process published on the RMIT institution website. RMIT provides all information necessary for students to complete their enrolment in a timely manner.
(7)  Colleges and schools will provide program and course enrolment advice.
(8)  A person must enrol in line with the program’s requirements, and any academic or course selection advice from colleges and schools.
  1. Students in a Commonwealth Supported Place are not permitted to enrol in courses in their program which do not contribute to the requirements of the award. Additional courses may be studied via Single and Short Courses.


(9)  A person who is not enrolled by the published deadline for the relevant teaching period is not considered to be a student and does not have the responsibilities or entitlements described and provided for students.
  1. Responsibilities for student visa holders continue to remain in effect until a confirmation of enrolment (CoE) is cancelled by RMIT.


(10)  Higher education students undertaking an award program who fail to re-enrol by the published deadline must seek permission to continue their program; permission to enrol or take leave of absence (LOA)is granted at RMIT’s discretion.
### Non-Award Enrolments
(11)  Where eligibility requirements are met, a person may enrol in one or more courses on a non-award basis.
### Enrolment Loads
(12)  For the purposes of completing a program in the minimum time, full-time study load for an award program is:
  1. 96 credit points in a year for higher education programs (except higher education coursework programs offered in Vietnam)
  2. 108 credit points in a year for higher education coursework programs offered in Vietnam
  3. the nominal hours for the program divided by the full-time duration of the program for vocational education programs in a year.


(13)  The minimum study load for a full-time program enrolment is:
  1. 100% for student visa holders unless otherwise approved by the school/college
  2. 75% of the full-time study load specified in clause (12) (or a pro-rata proportion where the duration is less than one year) for all programs except for higher education coursework programs offered in Vietnam, and higher degrees by research (HDR) candidates where a full-time load is 100%)
  3. 96 credit points in a year for higher education coursework programs offered in Vietnam.


### Minimum Age for Enrolment
(14)  Students must be at least 16 years of age on the commencement date of the program, course or unit in which they wish to enrol.
  1. Approval to enrol students younger than 16 years of age is granted to RMIT Vietnam for its English For Teens non-AQF Program only. 


(15)  The Academic Registrar will only permit the enrolment of an international student studying in Australia on a student visa who is under 18 years of age if they provide:
  1. written consent of a parent or legal guardian to the enrolment, and
  2. written permission for the University to provide student information to a parent or legal guardian upon request.


(16)  Prior to enrolling an individual who will be under the age of 17 years at the time of the commencement of training into a program funded under the VET Funding Contract:
  1. for students who have not yet completed Year 10, correspondence from a Department Regional Director that exempts that individual from school attendance must be sighted and retained.
  2. for students who have completed Year 10, correspondence from the school Principal that exempts that individual from school attendance must be sighted and retained.


### Enrolment Variation
(17)  Once enrolment has been completed, students can vary their enrolment in accordance with the deadline published by the institution.
(18)  Enrolment variations must comply with:
  1. program and course rules and requirements
  2. prescribed dates
  3. visa requirements, as applicable
  4. any enrolment procedures or additional instructions issued to the student by the institution.


(19)  A student must consider the effect of any variation of enrolment or load on their tuition fees, student contributions, scholarships and visa where applicable.
  1. A course withdrawal (drop) may incur an academic and/or financial penalty as prescribed in the [Approved Schedule of Fees and Charges](https://policies.rmit.edu.au/download.php?id=128&version=1&associated).
  2. A course withdrawal up to and including the census date does not incur an academic penalty.


(20)  Transfer provider requests prior to completion of the first six (6) calendar months of the student's principal program must be approved for international students studying in Australia on a student visa.
### Continuity of Enrolment
(21)  To maintain continuity of enrolment in a program a student must, by the deadline published by the relevant institution, either:
  1. re-enrol for the following academic year, or
  2. obtain approval for LOA


### Leave of Absence
(22)  A student who wishes to suspend their studies and retain their place in a program for a specified period of time must apply for LOA by the relevant date to retain their rights as a continuing student.
(23)  To be eligible to apply for LOA, the student must be currently enrolled in an RMIT award program and have been an enrolled student on the census date in their first semester.
(24)  Coursework and non-award students follow the process prescribed by the Leave of Absence Procedure.
(25)  HDR students must follow the process prescribed by the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16).
### Cancellation of Program Enrolment
(26)  A student may cancel their enrolment without penalty up to the dates and according to the processes prescribed by the relevant institution.
(27)  Formal cancellation of enrolment may incur a financial penalty as prescribed by the [Approved Schedule of Fees and Charges](https://policies.rmit.edu.au/download.php?id=128&version=1&associated).
(28)  Any student who transfers from an RMIT institution to another registered provider must cancel their enrolment at RMIT.
(29)  International and intending international students studying in Australia on a student visa who withdraw from the program at the delivery location either before or after the agreed starting day of the program, will be reported to the Australian government. 
### Enrolment Variation on Administrative Grounds
(30)  A Dean/Head of School or the Academic Registrar may instruct a student to vary their enrolment to comply with the requirements of a policy or procedure of the institution.
(31)  Where the student does not comply with an enrolment instruction, the institution may enforce the instruction by:
  1. varying the student’s enrolment directly
  2. dropping the student’s enrolment and notifying them accordingly.


### Overload Enrolment
(32)  Students may apply to enrol in courses above the standard full-time study load for their program, in a particular study period, subject to approval from:
  1. RMIT University: the relevant college/school (coursework) or the ADVC RT&D (HDR)
  2. RMIT Vietnam: as specified in the relevant program guide
  3. exchange or study abroad student studying at RMIT University: Global Experience Office.


### Extension of Enrolment Entitlements Under Some Exceptional Circumstances
(33)  A student is entitled to complete the assessment without further enrolment in the course but (where relevant) to have a confirmation of enrolment for student visa purposes where they have been:
  1. granted an assessment adjustment for a course, or
  2. received an interim grade of NEX or RNF for a course.


(34)  A student who is active in an HDR program but who has had their courses dropped due to their thesis being submitted (on TSUB status) is entitled to receive an RMIT student card and have access to relevant facilities until such time as they submit the final archival copy of their thesis.
(35)  There is no requirement for any further enrolment in a course but (where relevant) the student may be provided with a CoE for student visa purposes.
### Citizenship/Residency Status Change
(36)  If a student’s citizenship or residency status changes after enrolment, the student is responsible for immediately notifying RMIT and providing evidence of their status.
(37)  A student’s change in citizenship or residency status will be effective from the next applicable census date after the student has provided evidence of the change.
(38)  Enrolment in a Commonwealth Supported Place (CSP) may be offered in these circumstances provided that:
  1. a place is available within the current course quota or, if not, with the approval of the relevant Deputy Vice-Chancellor; and
  2. the student’s application for a CSP is competitive under the provisions of the Australian government’s fairness requirement.


### Effect of Exclusion, Suspension or Expulsion
(39)  A person who has been expelled from an RMIT institution is:
  1. no longer an RMIT enrolled student
  2. not permitted to enrol in any program or course at any RMIT institution (including programs or courses offered by an RMIT institution via another provider)
  3. not entitled to use the services offered by any RMIT institution to enrolled students.


(40)  A person who has been suspended from an RMIT institution is, for the period of the suspension:
  1. not permitted to enrol in any program or course at any RMIT institution (including programs or courses offered by an RMIT institution via another provider such as Open Universities Australia)
  2. not entitled to use the services offered by any RMIT institution to enrolled students.


(41)  At the end of a specified period of suspension from the RMIT institution, a student:
  1. has the right to resume their studies in the same program they were studying when suspended, subject to the availability of the program or an equivalent replacement program
  2. is required to meet any conditions for resumption of their studies that have been set by the institution.


(42)  A person who has been excluded from an RMIT program:
  1. is not permitted to enrol in any courses for the program during the period of their exclusion
  2. may apply for admission to other programs of the institution, or another RMIT institution
  3. is not entitled to use the services offered by any RMIT institution to enrolled students.


(43)  A student is entitled to maintain their enrolment during an internal appeal against, or a recognised external review of, a decision to exclude them for unsatisfactory academic progress
(44)  Student visa holders must maintain an active enrolment until all appeal avenues are exhausted.
### Student Fees and Charges
(45)  The [Approved Schedule of Fees and Charges](https://policies.rmit.edu.au/download.php?id=128&version=1&associated) is published annually under the authority of the RMIT University Council and outlines all fees that may be charged by RMIT for enrolment or other engagement with RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=113&version=2#document-top)
# Section 5 - Resources
(46)  Refer to the following documents which are established in accordance with this procedure:
  1. Maximum Time to Complete a Program


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
