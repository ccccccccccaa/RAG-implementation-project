[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Awards Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=191)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=191)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=191)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=191)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=191)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=191)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=191)


# Awards Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#minor2)
  * [Part B - COURSEWORK AWARDS](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#part2)
  * [3. Types of Awards](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#minor3)
  * [Part C - HIGHER DEGREES BY RESEARCH](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#part3)
  * [4. Types of Awards](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#minor4)
  * [Part D - ADMISSION, COMPLETION AND CONFERRAL OF AWARDS](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#part4)
  * [5. Requirements for admission and completion](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#minor5)
  * [6. Approval to Confer](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#minor6)
  * [Part E - REVOCATION OF AWARDS](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#part5)
  * [7. Revocation of Awards Committee](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#minor7)
  * [Part F - REVOCATION OF REGULATIONS](https://policies.rmit.edu.au/document/view.php?id=191&_gl=1*u63zht*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#part6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to make provision about awards granted by the University.
#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
## Part B - COURSEWORK AWARDS
#### 3. Types of Awards
(3)  The following types of coursework awards are offered by the University:
  1. Masters by coursework
  2. Graduate diploma
  3. Graduate certificate
  4. Bachelor degree with honours
  5. Bachelor degree
  6. Associate degree
  7. Advanced diploma
  8. Diploma
  9. Undergraduate Certificate
  10. Certificate IV
  11. Certificate III
  12. Certificate II, and
  13. Certificate I.


## Part C - HIGHER DEGREES BY RESEARCH
#### 4. Types of Awards
(4)  The following types of higher degrees by research are offered by the University:
  1. Doctoral Degree
  2. Degree of Master of Research, and
  3. Higher Doctoral Degree.


(5)  The doctoral degree will be awarded for an original research submission in the form of:
  1. a thesis
  2. a project and exegesis, or
  3. a collection of refereed publications and exegesis


together with any required and approved coursework.
(6)  The degree of master of research will be awarded for an original research submission in the form of:
  1. a thesis, or
  2. a project and exegesis,


together with any required and approved coursework.
(7)  The higher doctoral degree will be awarded for an original research submission in the form of:
  1. previously published, substantial and internationally-recognised scholarly work, and
  2. an exegesis.


## Part D - ADMISSION, COMPLETION AND CONFERRAL OF AWARDS
#### 5. Requirements for admission and completion
(8)  The University will publish the requirements for admission to candidature, and completion of awards.
(9)  To be eligible for conferral of an award, a candidate must have fulfilled the requirements for completion of the award approved by Academic Board.
#### 6. Approval to Confer
(10)  Council may approve that an award be conferred on, or granted to a candidate.
(11)  Council may prescribe:
  1. the form and styles of all awards
  2. the form to be used in the presentation of candidates for awards, and
  3. the procedure and circumstances in which the University may issue a testamur for any award conferred.


(12)  No candidate shall have any award conferred unless the candidate has:
  1. paid the prescribed fees, and
  2. paid any charge, fee or fine whatsoever which the candidate may owe to the University.


(13)  The Academic Registrar keeps a register of which students have received an award of the University including the title of the award and the date it was conferred.
(14)  Council may posthumously confer any award on any candidate who has satisfied the provisions of the relevant policies or procedures.
## Part E - REVOCATION OF AWARDS
#### 7. Revocation of Awards Committee
(15)  Where a revocation of awards committee (the committee) is established in accordance with the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177):
  1. such committee comprises three (3) members of Council, and
  2. any recommendation made by the committee to Council must be approved by a majority of members of Council.


## Part F - REVOCATION OF REGULATIONS
(16)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 5.1.2 Conferring of Awards
  2. Regulation 5.1.3 Roll of Award Recipients
  3. Regulation 5.1.4 Degree of Doctor of Philosophy
  4. Regulation 5.1.5 Degrees of Master by Research
  5. Regulation 5.1.6 Professional Doctorate
  6. Regulation 5.1.7 Degrees of Master by Coursework
  7. Regulation 5.1.8 Bachelor Degrees
  8. Regulation 5.1.9 Degree of Doctor of Philosophy (by Publication)
  9. Regulation 5.1.10 Associate Degrees
  10. Regulation 5.7.1 Revocation of Awards Committee.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
