[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=112&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=112&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > RMIT Ombuds Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=112)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=112&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=112&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=112&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=112&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=112&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=112&version=1)


# RMIT Ombuds Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=112&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=112&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=112&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=112&version=1#section4)
  * [The RMIT Ombuds](https://policies.rmit.edu.au/document/view.php?id=112&version=1#major1)
  * [Requesting a Review of a Decision, Outcome or Finding](https://policies.rmit.edu.au/document/view.php?id=112&version=1#major2)
  * [Conduct of Parties to a Review](https://policies.rmit.edu.au/document/view.php?id=112&version=1#major3)
  * [Reviewing a Decision, Outcome or Finding](https://policies.rmit.edu.au/document/view.php?id=112&version=1#major4)
  * [Review Resolution](https://policies.rmit.edu.au/document/view.php?id=112&version=1#major5)
  * [Record Keeping](https://policies.rmit.edu.au/document/view.php?id=112&version=1#major6)
  * [Reporting](https://policies.rmit.edu.au/document/view.php?id=112&version=1#major7)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure details how staff and students can seek an independent and confidential review of a decision or outcome regarding their complaint.
(2)  The purpose of the procedure is to support and encourage an organisational culture where student and staff members' rights to raise concerns are recognised and supported.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=112&version=1#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the Complaints Governance Policy.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=112&version=1#document-top)
# Section 3 - Scope
(4)  This procedure applies to prospective, current and former students or staff complainants who have exhausted all other relevant internal avenues of redress and have evidence of a breach of policy, procedure or procedural fairness.
(5)  This procedure does not apply to any decision made under a policy or associated procedure that provides an appeal, review or alternative complaint mechanism; except for the [Student and Student-Related Complaints Policy](https://policies.rmit.edu.au/document/view.php?id=33).
  1. Where such mechanisms exist, complaints to the RMIT Ombuds can only be made regarding the process that was followed, and not the final decision.
  2. These excluded decisions include: 
    1. for students - outcomes of appeals against assessment outcomes, progress and exclusion decisions, special consideration cancellation and research candidature termination decisions, findings of the Student Conduct Board, Student Conduct Appeals Committee or a senior officer in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) or Student Conduct Regulations.
    2. for staff - decisions made or findings of reviewers, unsatisfactory performance review committees, misconduct investigation committees, relevant senior officers or the Vice-Chancellor in accordance with the processes in Part H (Unsatisfactory performance, misconduct and serious misconduct) of the RMIT University Academic and Professional Staff Enterprise Bargaining Agreement 2018
    3. decisions related to research misconduct under the [Management of Breaches of Research Integrity Procedure](https://policies.rmit.edu.au/document/view.php?id=30)
    4. any decision made by RMIT University Council (Council), Academic Board or an external organisation.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=112&version=1#document-top)
# Section 4 - Procedure
### The RMIT Ombuds
(6)  The RMIT Ombuds (Ombuds) has the power to investigate and seek evidence for reviews concerning alleged breaches of policy, process or procedural fairness.
(7)  The Ombuds cannot review the merits of a complaint outcome or decision, but only whether the resolution has been consistent with policy and process and has been procedurally fair.
(8)  The Ombuds cannot overturn a decision or outcome but can make recommendations that RMIT review the decision.
(9)  The principles of fairness, academic integrity and natural justice are observed in the Ombuds's determinations.
(10)  The rules of procedural fairness are followed in the conduct and reporting of Ombuds reviews.
### Requesting a Review of a Decision, Outcome or Finding
(11)  Current and former staff and students can request a review of a decision, outcome or finding via email or phone, or via a third party with the requestor’s written consent.
  1. Former staff members must have been employed within the past 12 months and former students must have graduated or discontinued enrolment within the previous 12 months, unless the matter raised is of sufficient gravity and impact and could not have reasonably been raised within that timeframe.
  2. Requests for review can’t be made anonymously.


(12)  The Ombuds office acknowledges receipt of the request within a reasonable time, usually within one (1) working day of submission.
(13)  Following receipt, an assessment is made to determine whether the request meets the scope outlined above. Where the request does not meet the scope, the person making the request is referred to the relevant responsible area, which is advised of the inquiry and provided with a copy of the advice that has been given.
(14)  Authorisation to disclose or distribute information to other parties is generally required by the Ombuds office, however any disclosure of information will be limited to those reasonably required for the review or investigation and resolution of the matter and must be consistent with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59). In the absence of such authorisation, the Ombuds may decline to investigate.
### Conduct of Parties to a Review
(15)  All parties to a review must respect the confidentiality of the review and must not discuss the details with anyone other than their support person or advocate while the review is in progress. Limitations apply to confidentiality where risks to health and safety are present or in matters involving persons under 18 years of age.
(16)  If the complainant takes the complaint to an external forum (such as a court or tribunal), the Ombuds may discontinue the review.
(17)  Parties to a review must act in good faith. The Ombuds will not investigate frivolous, vexatious, mischievous or malicious complaints, and the submission of such may lead to disciplinary action.
(18)  Staff and students must not suffer disadvantage or be subjected to victimisation as a result of assisting an Ombuds enquiry or seeking review through the Ombuds.
### Reviewing a Decision, Outcome or Finding
(19)  Where the enquiry is in scope the Ombuds office notifies the person making the request that the review can progress.
(20)  The Ombuds reviews all relevant existing information on the previous decision, outcome or finding made by RMIT, including copies of the previous resolutions or outcomes, investigation and meeting notes and copies of relevant emails sent and received regarding the matter, and may request any further information and meetings with key participants considered necessary for the investigation.
(21)  The Ombuds office provides regular updates to the person requesting the review and a timeframe for the determination.
(22)  The Ombuds office maintains an updated file on the investigation which includes copies of all correspondence sent and received, and a contact register which records the dates of all actions taken by the office.
### Review Resolution
(23)  The Ombuds proposes options for resolution with the relevant parties and endeavours to resolve the matter to the satisfaction of all parties.
(24)  On conclusion of the review, the Ombuds:
  1. informs the complainant and the respondent, in writing, of the decision and reasons for it and of any further avenues of review
  2. provides a report to the relevant senior manager (and copied to the relevant member of the Vice-Chancellor's Executive) which may include recommendations regarding policy compliance, procedural fairness and process improvement. If relevant, the Ombuds may recommend that the original decision/finding/outcome be set aside, and the process be recommenced, or a decision be reviewed and remedial action considered.


(25)  The Ombuds may request a report from the General Counsel and University Secretary on actions taken as a result of their recommendation.
### Record Keeping
(26)  Records of requests for review are kept in accordance with legislative and RMIT requirements.
  1. The Digitisation Plan for the Ombuds office is followed.
  2. An electronic HP Contact Manager folder is kept for every incoming enquiry to the Ombuds office. All correspondence and documents pertaining to the enquiry are securely stored within these folders.
  3. Information management follows the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).


### Reporting
(27)  An annual report on enquiries and requests for review received throughout the reporting period is submitted to Council, through the Chancellor. A copy is also provided to the Vice-Chancellor.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
