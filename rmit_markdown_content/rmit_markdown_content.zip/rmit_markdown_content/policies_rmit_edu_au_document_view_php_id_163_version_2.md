[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=163&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=163&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Timetable Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=163)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=163&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=163&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=163&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=163&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=163&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=163&version=2)


# Timetable Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=163&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=163&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=163&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=163&version=2#section4)
  * [Timetable Priorities](https://policies.rmit.edu.au/document/view.php?id=163&version=2#major1)
  * [Scheduling](https://policies.rmit.edu.au/document/view.php?id=163&version=2#major2)
  * [Teaching Spaces](https://policies.rmit.edu.au/document/view.php?id=163&version=2#major3)
  * [Planning](https://policies.rmit.edu.au/document/view.php?id=163&version=2#major4)
  * [Publication and Changes](https://policies.rmit.edu.au/document/view.php?id=163&version=2#major5)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=163&version=2#major6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure defines guidelines and responsibilities for a consistent and centralised timetabling practice which enhances the student learning experience, provides equitable outcomes and ensures the most efficient and effective use of our human and physical resources.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=163&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Property Management Policy](https://policies.rmit.edu.au/document/view.php?id=77).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=163&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all face-to-face timetabled classes held at the City, Bundoora and Brunswick campuses of RMIT.
(4)  It does not apply to:
  1. short or single courses, ad-hoc events and industry/partner activities delivered on Melbourne campuses
  2. timetabling for RMIT Online and RMIT Vietnam.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=163&version=2#document-top)
# Section 4 - Procedure
### Timetable Priorities
(5)  The scheduling of learning and teaching activities must:
  1. achieve learning outcomes
  2. support student completion of a standard program structure in minimum time
  3. provide outcomes that enhance the student experience
  4. maximise the use of the University’s facilities and teaching resources
  5. maximise efficiencies for academic and teaching staff.


(6)  The following considerations must be taken in account when scheduling timetables:
  1. classes will be scheduled taking into account scarcity of resources
  2. first-year classes will have precedence for day timetabling (8:30am – 6:30pm) over later year classes
  3. classes that occupy large blocks of time will be scheduled prior to those which occupy small block of time
  4. classes of a longer duration will be prioritised in ‘upper’ floors of buildings to reduce vertical transport use
  5. classes will be scheduled into venues that closest meet the requirements of the teaching activity including planned class size
  6. precedence will be given to classes requiring specialised facilities in multi-use space access for students and or staff with disabilities will take precedence, matching resources with accessibility.


### Scheduling
(7)  Schools to complete class scheduling prior to the planned timetable scheduling period commencing the 1st Monday of September of the preceding calendar year.
(8)  All class scheduled synchronous classes offered by the University under a face-to-face course offering in SAMS must be timetabled on the university’s timetable system.
(9)  Scheduling to prioritise student centric outcomes as the primary objective as governed by the planned student enrolment pathways.
### Teaching Spaces
(10)  All lecture theatres and generic classrooms must be centrally managed.
(11)  All teaching spaces must be booked via the prescribed scheduling system.
(12)  Timetabling Services is responsible for assigning and coordinating specialist teaching spaces in conjunction with the managing college and/or school to identify any standard setup/set down time allowances to be built into the location resource.
(13)  All teaching spaces must be prioritised to standard teaching activities from ‘0’ week of respective calendars prior to being made available for assessments, enrolments, orientation, balloting, exhibitions or ad-hoc activities.
### Planning
#### Time Considerations
(14)  Classes must be timetabled within the spread of University’s teaching hours.
(15)  Standard delivery periods are defined as follows:
  1. standard DAY delivery period is 8:30am to 6:30pm Monday to Friday
  2. standard EVENING delivery period is 6:30pm to 9:30pm Monday to Friday.


(16)  To improve room availability, multi-hour classes must be scheduled commencing from 8.30am to maximise utilisation.
(17)  Classes of non-whole hour duration (1.5 hours, 2.5 hours, etc.) will be be scheduled back to back to facilitate optimal spatial use.
(18)  City, Brunswick and Bundoora West teaching periods must commence on the half hour.
(19)  Bundoora East campus teaching periods must commence on the hour to facilitate student and staff movement between Bundoora East and West campuses.
(20)  Classes will end ten (10) minutes prior to published end time to enable room changeover and allow students to move to the next class.
#### Breaks
(21)  Breaks in the timetable must be scheduled between the hours of 11.30am and 2.30pm for staff and students.
(22)  Any teaching booking of duration of 4 hours or more must have a break period incorporated into the delivery block.
(23)  Bundoora and Brunswick common lunch hour must remain class-free unless otherwise approved by the campus director.
#### Other Considerations
(24)  Wherever possible, classes scheduled on evenings, weekends and public holidays must consolidate rooms into energy efficient spaces and buildings rather than spread across teaching facilities on a relevant campus, to support the University’s greenhouse gas emissions reduction target.
(25)  Where possible and when student centric outcomes are not compromised, timetables should be scheduled to achieve a nominal minimum booked frequency to facilitate the temporary closure of venues, to support the University’s greenhouse gas emissions reduction targets.
(26)  Speciality teaching spaces defined as needing lab support must be timetabled within the scope of hours determined by the controlling college.
(27)  Classes must be allocated to resources as per the academic requirements provided, i.e., class size, equipment, space type.
(28)  Programs or courses with periods of professional experience must only be timetabled for those weeks when campus resources are required, to enable rooms to be timetabled for other purposes when students are undertaking off-campus activities.
(29)  Intensives and other non-standard teaching must minimise impact on standard semester classes.
(30)  A staff member’s timetable will operate in accordance with their employment terms and conditions.
### Publication and Changes
(31)  Full-year timetables will be published prior to the close of re-enrolment for the following year to permit students to make informed choices about course selection.
(32)  Changes to the timetable, post-publication, will be minimised; valid reasons for changes include:
  1. unexpected academic or teaching staff changes
  2. unexpected surge/decline in enrolled student numbers
  3. health or safety hazards
  4. adjustments required to accommodate staff or students with special needs
  5. late changes to Vocational Education Training Packages
  6. changes to student placement arrangements.


(33)  Changes to the published timetable relating to a change of day/time and/or delivery will require the approval of the college Dean or delegate as determined by the Deputy Vice-Chancellor for the respective college.
(34)  Changes to published timetable will generate appropriate notification to staff and students as necessary.
### Responsibilities
(35)  Timetabling Services has a responsibility to:
  1. ensure the University’s timetabling process is conducted in a coordinated, efficient and effective manner
  2. minimise the need for students and staff to travel between campuses on the same day
  3. minimise the spread of classes across the week and avoid large gaps of time during the day for students
  4. assist with the resolution of timetable clashes and escalate matters to the Senior Manager, Timetable Services as required.


(36)  Program Managers or equivalent are responsible for providing program-specific information to ensure the timetable meets all requirements.
(37)  Where a Program Manager or delegate is not identified, responsibility for the provision of program specific information is delegate to next senior level responsible person within the organisation structure.
(38)  Academic and Teaching staff are responsible for submitting course teaching requirements and their hours of work unavailability through the prescribed channels.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
