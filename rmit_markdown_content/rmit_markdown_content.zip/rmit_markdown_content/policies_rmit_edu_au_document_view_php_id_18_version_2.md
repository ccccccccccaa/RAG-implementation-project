[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=18&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=18&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Submission and Examination Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=18)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=18&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=18&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=18&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=18&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=18&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=18&version=2)


# HDR Submission and Examination Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=18&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=18&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=18&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=18&version=2#section4)
  * [Before Submission](https://policies.rmit.edu.au/document/view.php?id=18&version=2#major1)
  * [Submission](https://policies.rmit.edu.au/document/view.php?id=18&version=2#major2)
  * [Examination](https://policies.rmit.edu.au/document/view.php?id=18&version=2#major3)
  * [Research Embargo](https://policies.rmit.edu.au/document/view.php?id=18&version=2#major4)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=18&version=2#section5)
  * [Section 6 - Resources](https://policies.rmit.edu.au/document/view.php?id=18&version=2#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure provides the rules and classifications for the submission and examination of research towards a Higher Degree by Research (HDR) at RMIT and is supported by the RMIT [Dissemination of Research Outputs Procedure](https://policies.rmit.edu.au/document/view.php?id=84).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all staff and examiners responsible for monitoring and managing the submission and examination of Higher Degrees by Research and all HDR candidates in the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=2#document-top)
# Section 4 - Procedure
### Before Submission
#### Appointment of Examiners
(4)  Appointment of examiners must be conducted in accordance with RMIT Principles for nominating HDR examiners and the [ACGR Conflict of Interest in Examination Guidelines](https://policies.rmit.edu.au/download.php?id=277&version=3&associated).
(5)  All examiners must be external to the University and must:
  1. be of appropriate standing in the relevant field of study,
  2. hold a qualification equal to the level of the award they are examining or have equivalent experience and expertise,
  3. have previous experience as a supervisor or examiner at the AQF level at which they will examine, and
  4. be from different institutions


(6)  Candidates may request the exclusion of specific individuals as their examiners at least three (3) months prior to submission.
(7)  A completed Recommended Panel of Examiners form with all required attachments must be submitted to the School of Graduate Research (SGR) at least two (2) months prior to the candidate’s intended submission date. 
(8)  It is the supervisors’ responsibility to provide details of any actual, perceived or potential conflicts of interest with proposed examiners. 
(9)  Candidates must not be told the names of their examiners except where their examination includes an oral presentation or performance in the presence of the examiners. 
(10)  The Recommended Panel of Examiners is subject to review and approval by the HDR Delegated Authority (HDR DA) and Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) or nominee.
(11)  In cases where a confidentiality agreement is required, SGR will prepare and arrange execution of an examiner’s confidentiality agreement prior to commencing the examination. If an examiner is unable or unwilling to sign the deed then a new examiner will have to be nominated. 
#### Eligibility to Submit
(12)  To be eligible to submit their research for examination, candidates must have:
  1. been enrolled for at least the minimum duration of candidature as prescribed by the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16)
  2. successfully completed all prescribed coursework components of the program, or received an exemption from the component/s (Refer to the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16))
  3. successfully completed all compulsory milestone reviews, or received an exemption from the milestone/s
  4. a current enrolment and active candidature
  5. successfully completed research to the standard and specification of the program in accordance with the [Australian Qualifications Framework](https://policies.rmit.edu.au/download.php?id=18&version=1&associated)
  6. supervisory and school approval to submit for examination (if no approval will be given, see Approval to Submit for Examination clauses).


### Submission
#### Submission Requirements
(13)  Research for examination must: 
  1. be original work which is unified and coherent in content, and
  2. address a single, significant research question/theme in a field or area of professional practice, and 
  3. have been completed under supervision during the period of enrolment for the degree, including transferred candidature, and 
  4. not include work which has been submitted previously, in whole or in part for any other academic award, and
  5. include a thesis or dissertation which is uploaded and submitted to SGR via the digital repository in PDF format, and
  6. include a digital record of candidates’ published research outputs, artefacts or experiential presentations which embody candidates’ research undertaken during the course of candidature. 


(14)  Examination submissions must include a thesis or dissertation which provides the:
  1. purpose
  2. scholarly or practical context for the research
  3. process and methodology
  4. presentation of the results, analysis and conclusions of the research.


(15)  Examination submissions may also include components such as research outputs and artefacts, for example: published articles, creative works, software and professional reports or policy documents.
(16)  The candidate must declare any published research outputs by completing the Research Outputs Declaration. 
(17)  Where two or more candidates collaborate on a project which will form the content of their submission for examination:
  1. the contributions of each candidate must have sufficient individual value to the discipline or practice to be worthy of separate examination
  2. each collaborator’s contributions to the overall research outcomes must be declared in each of the uniquely titled research submissions.


(18)  Candidates enrolled in a Joint PhD must only be required to produce a single thesis/project for examination at both institutions and may be required to complete an oral defence or viva voce as part of the examination. 
(19)  Candidates must maintain their research ethics approval until they have received confirmation of a “Passed” result. 
#### Doctoral Citation
(20)  PhD candidates must provide a doctoral citation during submission to be eligible to graduate. 
#### Approval to submit for examination
(21)  Candidates and senior supervisors must confirm that the research complies with the [Australian Code for the Responsible Conduct of Research, 2018](https://policies.rmit.edu.au/directory/summary.php?code=1) and has been prepared in accordance with legislative, copyright and privacy requirements.
(22)  Candidates’ submissions must adhere to the prescribed RMIT format as well as the standards and conventions for scholarly work which apply in the relevant discipline of field, such that they may be assessed without prejudice by leading experts of that discipline or field. 
(23)  Following submission, providing all submission requirements are fulfilled, SGR on behalf of the ADVC RT&D or nominee will approve the thesis or dissertation for examination.
(24)  The submission date is the date that the thesis or dissertation is uploaded to SGR via the digital repository, provided it is approved for examination by the ADVC RT&D or nominee. 
(25)  Candidates who meet the eligibility criteria to submit may choose to submit without school approval, subject to approval by the ADVC RT&D or nominee. 
#### Readmission for the Purpose of Examination
(26)  Individuals may be readmitted for the purpose of examination within three years of their cancellation date, if their HDR candidature has been cancelled for any reason.
(27)  Individuals must submit a completed, examinable draft of their thesis or dissertation, along with any associated artefact(s) where relevant, to their former senior supervisor or HDR DA if the senior supervisor is no longer available.
(28)  The HDR DA must ensure that candidates meet the eligibility criteria for submission.
(29)  Following a candidate’s readmission, the senior supervisor or HDR DA overseeing the submission is responsible for:
  1. nominating examiners
  2. providing a statement attesting that the research topic is current and has not been superseded by subsequent research in the field
  3. recommending that the work is ready for examination to the Dean/Head of School or HDR DA.


(30)  The candidate is required to submit their thesis or dissertation via the digital repository within 10 working days of re-enrolment.
### Examination
#### Examination Processes
(31)  Research for examination is disseminated to examiners via a digital repository as prescribed in the HDR Examination principles. 
(32)  Only the ADVC RT&D or nominee may communicate with examiners on behalf of RMIT while the research is under examination.
(33)  Except for contact during a presentation forming part of the examination process:
  1. supervisors and candidates must have no contact with examiners during the examination process. If an examiner attempts to make contact, individuals must not engage and immediately notify the examinations team in SGR,
  2. no contact is permitted between examiners while the research is under examination, and
  3. the examiners’ identities must not be disclosed to the candidate until after the final classification has been given, and only with permission of the examiner.


(34)  The examination period extends from the date examiners are provided with the research submission to the date a final classification has been determined and registered. 
(35)  Examiners must prepare independent and individual written reports of their assessment and submit these directly to the examinations team in SGR, accompanied by the Examiner’s Report Form indicating a recommended classification in accordance with Table 1 in [Schedule 1 – HDR Examination Recommendations and Classifications](https://policies.rmit.edu.au/download.php?id=289&version=1&associated).
  1. R1: Passed
  2. R2: Passed subject to minor amendments
  3. R3: Passed subject to major amendments
  4. R4: Revise and resubmit, or
  5. R5: Failed. 


(36)  Master by Research candidates commencing on or after 1 January 2016 will receive a numeric grading for a successfully completed Master by Research degree at RMIT in accordance with [Schedule 1](https://policies.rmit.edu.au/download.php?id=289&version=1&associated).
(37)  Examiners are requested to provide their reports within six (6) weeks of receipt of the submission. Examinations are monitored and any extensions are managed by the examinations team in SGR in line with the Examination Principles.
(38)  Where a presentation of the research in a venue is required, examiners will be provided with the digital submission four (4) weeks prior to the presentation event and must provide their final reports within two weeks following the event.
(39)  The ADVC RT&D or nominee may replace an examiner and/or annul their report where:
  1. the examiner fails to return a completed examination report by the due date
  2. there has been unauthorised contact between the examiner and the candidate or their supervisors during the examination
  3. an unacceptable conflict of interest is discovered during or after the examination, and/or
  4. the ADVC RT&D or nominee determines that the examination has otherwise not been properly conducted.


(40)  Where a replacement examiner has been appointed, any report received from the examiner who has been replaced will not be considered. 
(41)  In the event of an examiner or any other relevant party raising concerns about the integrity of the research during the examination process, the examinations team in SGR will immediately refer the matter to the ADVC RT&D or nominee, and: 
  1. SGR will suspend the examination and notify the examiners, school and the candidate
  2. a Designated Person will investigate in accordance with the [Research Integrity Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=30)
  3. recommendations arising from the investigation may include application of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180).


#### Requirements for Presentation for Examination – Practice-based Research
(42)  Presentations for examination are managed by the candidate’s enrolling school.
(43)  Examinations must be convened by a person appointed as Convenor by the ADVC RT&D or nominee. Persons who have acted in a supervisory or consultative capacity must not be appointed as the Convenor.
(44)  Presentations of research for examination must not occur without the appointed Convenor being present.
(45)  In the case of an oral presentation by the candidate, the time allowed is:
  1. PhD candidates – one-hour oral presentation plus half- to one-hour discussion with the examiners.
  2. Master by Research candidates – half-hour oral presentation plus up to half hour discussion with the examiners.


(46)  The Convenor is not permitted to comment on the content of the research and is responsible for ensuring that each examiner is uncompromised in their ability to make an independent evaluation of the research.
(47)  The presentation of the research must be recorded digitally to enable electronic archival.
#### Examination Results
(48)  Following the receipt of all examiners’ reports and recommendations, the ADVC RT&D or nominee will classify the examination in accordance with Table 2 in [Schedule 1](https://policies.rmit.edu.au/download.php?id=289&version=1&associated). Examination classifications are: 
  1. C1: Passed
  2. C2: Passed with minor amendments
  3. C3: Passed with major amendments
  4. C4: Revise and resubmit
  5. C5: Failed


(49)  In order to pass, an HDR submission must receive two externally provided pass recommendations on the same version of the submitted work.
(50)  A third examiner will be appointed if:
  1. the examiners’ recommendations diverge, as per [Schedule 1](https://policies.rmit.edu.au/download.php?id=289&version=1&associated), or
  2. the ADVC RT&D or nominee conculdes that the result is undetermined.


(51)  The third examiner examines the submission independently, is not given the reports of the co-examiners, and has the full set of options available to them in assessing the thesis or dissertation in accordance with Table 1 in [Schedule 1](https://policies.rmit.edu.au/download.php?id=289&version=1&associated).
(52)  In cases where the examination includes an artefact or oral presentation, SGR will provide the third examiner a digital recording of the artefact and/or a recording of the full presentation.
(53)  The classification of the examination is determined in accordance with the majority recommendation of the examiners, in accordance with Table 3 and Table 4 of [Schedule 1](https://policies.rmit.edu.au/download.php?id=289&version=1&associated), following receipt of examiners’ recommendations. 
(54)  After the examination outcome has been classified, SGR must send a notification to the candidate, their supervisors, the HDR DA, and the Dean/Head of School and the examiners, to advise them of the examination classification.
(55)  SGR must forward the examiners’ reports to the candidate’s senior supervisor to enable them to provide academic guidance on any necessary amendments.
(56)  In the event of one or both examiners recommending an R5 ‘Failed’ after re-examination of a doctoral or Master by Research HDR submission, the examinations team in SGR will recommend that the ADVC RT&D or nominee convene a meeting of the Graduate Research Committee Executive to review and ratify a final classification of the HDR submission.
(57)  The GRC Executive may refer the work to an external adjudicator where appropriate. A record of the Graduate Research Committee Executive’s decisions in respect of the examination will be transmitted to the candidate and their supervisor(s) following classification.
(58)  If the work is referred to an adjudicator, the adjudicator’s decision will be final. 
(59)  For research classified as C5 (Failed):
  1. the candidate will not be awarded the degree for which they were enrolled and will not be permitted to revise and resubmit their research for re-examination for the same degree
  2. one copy of the examined thesis or dissertation becomes the property of RMIT and shall be filed with the candidate’s official records
  3. a record of the fail will be placed on the RMIT student system 
  4. in the event of one or both examiner(s) recommending an R5 ‘Failed’ for an examination or re-examination of a doctoral submission, the examiner(s) are required to confirm whether they consider the research to be suitable for examination at the level of a Master by Research.


#### Master by Research Grades
(60)  Master by Research examinations follow the rules prescribed in this procedure and [Schedule 1](https://policies.rmit.edu.au/download.php?id=289&version=1&associated).
(61)  All Master by Research grades must be approved by the ADVC RT&D or nominee before they are finalised. 
(62)  Candidates are informed of their overall grade when they receive their final examination classification. Individual grades are not disclosed. 
#### Re-examination Process – Following a Classification of C4 (Revise and Resubmit) (Doctoral or Master by Research)
(63)  Where a candidate is given the interim classification C4 ‘Revise and Resubmit’ for re-examination, they have one opportunity to ensure the thesis or dissertation meets the requirements for the award of the degree on second examination and:
  1. A re-examination is undertaken with the original examiners, if they are willing and available to re-examine the revised submission, or with replacement examiners such that the revised work still receives assessment from two independent, external experts.
  2. All material submitted and recommendations made in the context of a re-examination supersedes all previous material and recommendations, with the exception of the candidate’s response to the examiners’ remarks provided in the initial examination.


(64)  The revision period is 12 months for PhD candidates and six months for Master by Research candidates. If a candidate does not resubmit within this timeframe, they will be awarded a classification of C5 ‘Failed’.
(65)  International candidates who receive a C4 ‘Revise and Resubmit’ classification should not required to remain in Australia to complete revisions for re-examination. 
(66)  Resubmitting candidates must include a list or requested amendments with the revised thesis. This list must include justification for any amendments not made. 
(67)  The original and any replacement examiners of a revised and resubmitted thesis are provided with:
  1. the revised thesis or dissertation,
  2. the candidate’s response to examiners’ reports, listing the amendments made to address the initial examiners’ requirements and justification for any amendments not made at the request of those examiners, and
  3. the de-identified co-examiners’ reports to determine if the required amendments and revisions have been made. 


(68)  Examiners of a revised and re-submitted thesis must provide a recommendation of ‘passed’ or ‘failed’. 
(69)  Where two examiners examine a re-submitted thesis and their recommendations diverge, a third examiner is appointed. The third examiner must examine the submission independently and must not be provided with the reports of their co-examiners. 
(70)  The final classification of the examination is determined in accordance with the majority recommendation of the examiners, in accordance with Table 5 and Table 6 of [Schedule 1](https://policies.rmit.edu.au/download.php?id=289&version=1&associated). 
(71)  The result of the second examination is final.
#### Request for Extension of time To Submit Amendments
(72)  The candidate must request an Extension of Time to Submit Amendments before the nominated resubmission or lodgement date passes. Extensions are not guaranteed. 
(73)  A candidate may apply for approval of an extension to the resubmission or archival date, where the candidate cannot meet the nominated date for the resubmission of their research for re-examination or the lodgement date for the archival of their research.
(74)  Failure to re-submit or lodge a thesis or dissertation by the date specified by SGR may lead to the examination being classified as ‘Failed’. Candidates will be notified if this process is being initiated.
#### Appeal Against Final Examination Results
(75)  Candidates whose examination has been completed and who have a result of ‘Failed’ may appeal against any perceived procedural irregularities in the conduct of their HDR examination that has had significant impact on the examination result. 
(76)  Candidates must ensure their appeal application is received by the Secretary of the University Appeals Committee within 20 working days of the date of the formal notification from SGR of their final examination outcome.
#### Lodgement of the Final Archival and Completion of the Degree
(77)  After a candidate’s research has been classified by the ADVC RT&D or nominee, any amendments requested by the examiner(s) must be completed by the candidate, or a defence presented as to why they do not need to be undertaken.
(78)  Candidates must provide a list of amendments/points of defence for uploading with their final archival submission.
(79)  Candidates whose research includes artefacts and/or presentation in a venue in addition to their dissertation must provide a digital record of these for archival storage.
(80)  Completion and graduation processes require that:
  1. the final electronic archival submission of the thesis or dissertation and any related digital records are uploaded to the digital repository within the timeline specified by the University and after completion of any appropriately supervised amendments deemed necessary by the University
  2. the candidate is not indebted to the University
  3. the candidate has fulfilled the academic and administrative requirements for the award of the degree.


(81)  When the final archival submission has been approved for lodgement by the senior supervisor and the Dean/Head of School (or HDR DA):
  1. a record of the completion is provided to the ADVC RT&D or nominee, who will approve the research for archival and recommend the candidate for award
  2. the final archival submission is uploaded into the [RMIT Research Repository](https://researchrepository.rmit.edu.au/discovery/search?vid=61RMIT_INST:ResearchRepository) after which the research will be publicly available
  3. the result for the research component of the program will be entered on the student record
  4. SGR will provide written notification of the satisfactory completion of the degree to the Academic Registrar, candidate, their supervisors, the Dean/Head of School and HDR DA, and any sponsor(s) of international onshore candidates.


### Research Embargo
(82)  Candidates who wish to apply for an embargo on the publication of their research in the RMIT Research Repository must meet the requirements for embargo detailed in Table 1.
#### Table 1: Grounds for Embargo
Requirement | Maximum duration | Level of approval  
---|---|---  
The candidate has signed a publishing agreement or is planning to publish their work which requires some restriction on the availability of the submission. | Up to two years | ADVC RT&D  
Option for extension of embargo for one year | ADVC RT&D  
The candidate provides evidence that they have permanently re-assigned copyright of their submission to a third party and this assignment explicitly disallows the publication of the submission in the research repository. | Permanent | ADVC RT&D  
There is an existing formal agreement, or the candidate is involved in the development of a formal agreement that commercially or otherwise sensitive material will not be publicly disclosed. This includes patents, research produced under a funded contract (e.g. Student Participation Agreement or confidentiality agreement). | Duration as per agreement or up to two years | ADVC RT&D  
Option for extension of embargo for one year | ADVC RT&D  
The research contains material that must be kept confidential due to legal, cultural, ethical or national security reasons. | Permanent | GRC Executive  
(83)  Candidates can request an embargo on any submitted component of their research whilst allowing other components to be published in the [RMIT Research Repository](https://researchrepository.rmit.edu.au/discovery/search?vid=61RMIT_INST:ResearchRepository).
(84)  Candidates whose research meets the grounds for embargo must ensure their embargo applications are submitted prior to their archival submission; and that any subsequent application for an extension to the embargo is submitted at least two months prior to the embargo’s expiry.
(85)  The outcome of an application will be determined in accordance with Table 1: Grounds for Research Embargo, listed above.
(86)  In exceptional circumstances and on production of compelling evidence, the GRC Executive may grant:
  1. an embargo that does not meet the prescribed criteria
  2. further extension to an embargo.


(87)  Notification of the outcome is provided to the candidate, their senior supervisor and the school HDR DA.
(88)  Archival research which has been approved for embargo is stored in a restricted repository until the embargo expiration date, when it is published.
(89)  In cases where an embargo has been approved but no longer required, the candidate or their supervisor should inform the examinations team in SGR to enable the candidate’s submission to be published in the public domain.
#### Posthumous Examination
(90)  In cases where an HDR candidate is deceased before submission of their thesis or dissertation, their work may be considered for posthumous examination if: 
  1. the candidate was enrolled at RMIT in the relevant course of study at the time of their death; or had an active enrolment at RMIT in the 12 months prior to their death; and
  2. they had a successful outcome for their third milestone review; and
  3. an application to undertake this process is made on behalf of the candidate, with the consent of the family; and 
  4. the work is substantially complete and of an appropriate level to be examined for the degree, as attested to by two independent assessors.


(91)  Applications for posthumous examinations are submitted by the senior supervisor with the support of the HDR DA in the school where the candidate was enrolled.
(92)  The GRC Executive has final approval for a request to proceed with a posthumous examination.
(93)  If a posthumous examination is approved, submission and examination procedures will be followed in accordance with the HDR Posthumous Submission and Examination Guidelines. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=2#document-top)
# Section 5 - Schedules
(94)  This procedure includes the following schedule:
  1. [Schedule 1 – HDR Examination Recommendations and Classifications](https://policies.rmit.edu.au/download.php?id=289&version=1&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=2#document-top)
# Section 6 - Resources
(95)  Refer to the following documents:
  1. [Principles for nominating HDR Examiners](https://policies.rmit.edu.au/download.php?id=357&version=2&associated)
  2. HDR Examination principles
  3. HDR Posthumous Submission and Examination Guidelines
  4. [HDR Forms](https://policies.rmit.edu.au/download.php?id=68&version=2&associated)
    1. Recommended Panel of Examiners form
    2. Extension of time to submit new amendments form 
    3. Request for embargo form


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
