[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=153&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=153&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Managing Conduct Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=153)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=153&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=153&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=153&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=153&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=153&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=153&version=2)


# Managing Conduct Procedure
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=153&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=153&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=153&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=153&version=2#section4)
  * [Application](https://policies.rmit.edu.au/document/view.php?id=153&version=2#major1)
  * [Handling Reports and Complaints About Conduct](https://policies.rmit.edu.au/document/view.php?id=153&version=2#major2)
  * [Assessing a Report or Complaint](https://policies.rmit.edu.au/document/view.php?id=153&version=2#major3)
  * [Responding to a Report or a Complaint](https://policies.rmit.edu.au/document/view.php?id=153&version=2#major4)
  * [Workplace Investigations](https://policies.rmit.edu.au/document/view.php?id=153&version=2#major5)
  * [Privacy and Confidentiality](https://policies.rmit.edu.au/document/view.php?id=153&version=2#major6)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=153&version=2#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=153&version=2#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This procedure details how RMIT manages complaints, reports or concerns relating to misconduct or serious misconduct by staff and others defined in the scope, and includes:
  1. non-disciplinary actions available to help address all issues
  2. the process RMIT follows when deciding whether a person has engaged in misconduct
  3. disciplinary actions available if misconduct has occurred.


(2)  RMIT’s approach to misconduct matters is designed to ensure the facts are adequately understood before determining outcomes, and that all parties have an opportunity to be heard and supported.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=2#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=2#document-top)
# Section 3 - Scope
(4)  This policy covers the RMIT Group, which is RMIT University and its controlled entities (RMIT Europe, RMIT Online, RMIT University Pathways (RMIT UP), RMIT Vietnam).
(5)  This policy applies to RMIT University Council members, Council committee members, controlled entity board members, employees (including employees who are also students), researchers, contractors and volunteers of the RMIT Group, both in Australia and overseas, subject to any relevant legislation (collectively referred to in this policy as staff).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=2#document-top)
# Section 4 - Procedure
### Application
(6)  This procedure is used to address suspected, reported or known forms of misconduct or serious misconduct which occurs in connection with RMIT or the workplace.
(7)  In some instances, another appropriate RMIT procedure or process may be followed as an alternative. This includes, but is not limited to:
  1. a process for addressing staff conduct in an applicable enterprise agreement
  2. an RMIT procedure for managing staff under-performance where the conduct in question might be dealt with as either underperformance and/or misconduct
  3. procedures for dealing with suspected or reported fraud or corruption by a staff member.


(8)  Where matters are to be addressed under more than one procedure or process, RMIT must determine a fair and sensible order for events to proceed. Other matters which might reasonably overlap with this procedure include complaints or reports within the scope of the:
  1. Fraud and Corruption Control Procedure
  2. [Compliance Procedure](https://policies.rmit.edu.au/document/view.php?id=307)
  3. [Whistleblower Procedure](https://policies.rmit.edu.au/document/view.php?id=48)
  4. [Student and Student-Related Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=34)
  5. [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
  6. [Student Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=106)
  7. [Third-Party Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=111)
  8. [Gender-Based Violence Response Procedure - Australia](https://policies.rmit.edu.au/document/view.php?id=219)
  9. [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28), or
  10. a complaint or report being managed by an external agency.


### Handling Reports and Complaints About Conduct
(9)  Reports or complaints related to staff conduct must follow the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110) and Procedure.
(10)  People and Central Complaints and Investigations provide resources on how to:
  1. make a complaint or report about staff conduct
  2. advise a person who has made a report, or parties involved in the report or complaint, of their rights and expectations in the management of the report or complaint.


(11)  Depending on the circumstances and nature of the complaint, staff who have made a report or a complaint may receive:
  1. an outline of the process expected to be followed
  2. updates on progress where appropriate and reasons for any lengthy delays
  3. notice that under certain circumstances RMIT may continue to pursue the matter even if: 
    1. a report or complaint is withdrawn
    2. the staff member who has made a report or complaint or who is the subject of the report or complaint resigns, or their association with RMIT comes to an end
  4. notice when the matter has been closed.


(12)  Staff who are the subject of a report or a complaint may receive:
  1. an outline of the process expected to be followed
  2. updates on progress where appropriate and reasons for any lengthy delays
  3. sufficient information to understand the report or complaint (where appropriate and lawful) and adequate time to respond in a considered manner
  4. sufficient information to understand the reason for any decision made during the complaints process (where applicable)
  5. notice that under certain circumstances RMIT may continue to pursue the matter even if: 
    1. a report or complaint is withdrawn
    2. they or the staff member who has made a report or complaint resigns, or their association with RMIT comes to an end


(13)  Where a staff member who has made a report or complaint displays unreasonable conduct (as defined in the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110)) RMIT may restrict access to the complaint management services. This may include a decision by the Chief People Officer or delegate to close the report or complaint and decline any further response.
(14)  RMIT strictly prohibits the making of knowingly false or misleading complaints intended to harm or deceive. Vexatious or malicious reports or complaints found to be made in bad faith may result in disciplinary action.
(15)  A staff member may make a report or complaint anonymously, but this may limit the effectiveness of an investigation and impact the outcome. All reasonable efforts are taken to preserve anonymity where requested, but it is not always possible to do so. This is clearly communicated to the staff member making the report or complaint.
### Assessing a Report or Complaint
(16)  RMIT assesses issues arising from a report or complaint confidentially, sensitively, and as quickly as reasonably possible. Consideration is given to whether additional information is required to properly assess the matter.
(17)  There are circumstances where RMIT may not accept or proceed with a complaint. This may include but is not limited to where the conduct issue raised is unfounded or is trivial. Where a complaint is not accepted, reasons are provided to the complainant.
### Responding to a Report or a Complaint
(18)  RMIT considers how best to manage the issues arising from a report or complaint having regard to factors including but not limited to:
  1. the seriousness and extent of the issues
  2. the health, safety and wellbeing of the parties
  3. the available information and witnesses
  4. any legislative obligations
  5. any earlier or related issues
  6. the impact in the workplace
  7. the standards and reputation of RMIT.


(19)  The Safer Community team must be notified of reports or complaints involving sexual harassment, sexual assault, family violence and child safety.
(20)  RMIT may take interim measures when considering how to manage issues raised by a report or complaint, including but not limited to directing a staff member to:
  1. work from a different campus, building or location
  2. work from home
  3. be suspended with pay
  4. temporarily not attend the workplace, including for events or meetings
  5. temporarily have modified reporting lines or duties
  6. any other measure appropriate in the circumstances to protect health, wellbeing, safety, assets and RMIT’s reputation.


(21)  A decision to suspend a staff member with pay must be approved by the Chief People Officer or their delegate. In Vietnam, additional local legal obligations also apply.
(22)  RMIT may decide to manage the issues by taking non-disciplinary action and/or conducting a workplace investigation. The outcome of a workplace investigation may result in a decision to take disciplinary or non-disciplinary action against a staff member. Examples of disciplinary and non-disciplinary actions are provided in [Schedule 1](https://policies.rmit.edu.au/download.php?id=196&version=2&associated).
### Workplace Investigations
(23)  RMIT case manages issues that it determines require a workplace investigation and determines the appropriate manner in which the workplace investigation is conducted.
(24)  Staff who are the subject of a report or complaint concerning misconduct are notified in writing if a workplace investigation is to occur.
(25)  Where there are concerns about health, safety and wellbeing, RMIT may take interim measures as outlined in clause 20 above.
(26)  Where RMIT decides to undertake a workplace investigation, this may be conducted by either a suitable representative from People team, Central Complaints and Investigations, Safer Community team, Legal Services or an external investigator appointed by People or Central Complaints and Investigations (the investigator).
  1. If the matter is referred to an external investigator, this procedure continues to apply.


(27)  The investigator follows a procedurally fair process and determines the allegations to be tested based on the information provided by the complainant or otherwise available. As new information is introduced during a workplace investigation, the investigator may decide to modify or add to the allegations to be tested.
(28)  Staff may be directed to attend a workplace investigation meeting to discuss the matters in question, on more than one occasion.
(29)  Staff can have an appropriate support person present at any meeting during the process which may lead to disciplinary action. 
(30)  When attending a meeting the support person must not:
  1. unduly delay or disrupt the process or meeting
  2. act as a representative or advocate on behalf of the staff member (subject to any legal entitlement to do so).


(31)  A support person cannot be a person involved in the complaint or report or whose presence may create a conflict of interest for participants– for example, a possible witness or decision maker.
(32)  The inability to find a suitable support person is not an acceptable reason to delay the workplace investigation process.
(33)  The investigator provides the relevant manager and/or People with their findings.
(34)  At the conclusion of a workplace investigation a range of possible disciplinary and non-disciplinary actions may result from the findings and the investigator may make broad recommendations. Decisions about disciplinary action are made in accordance with any existing laws, local regulations, or enterprise agreements.
(35)  Before any proposed disciplinary action is carried out, the staff member is given an opportunity to respond to the proposed disciplinary action. The relevant decision maker considers the response before deciding what disciplinary action is to be taken.
(36)  Any decision to take disciplinary action is not limited by a requirement for prior disciplinary action to have occurred. For example:
  1. termination of employment or contract of engagement might occur as an outcome, even if there have been no prior formal warnings
  2. a final written warning may be issued even if there has been no previous written warning.


(37)  If the staff member who is the subject of a report or complaint ceases employment or their association with RMIT before the conclusion of the workplace investigation, RMIT may choose to provide them with the opportunity to comment on the report or complaint.
  1. RMIT may also hold the report concerning the conduct and any workplace investigation findings on file to be revisited if the person wishes to work, hold an honorary position, or be associated with RMIT in the future.


(38)  The person(s) who made the initial report or complaint is not informed of any disciplinary action imposed.
(39)  A previously closed investigation may be reopened if new information is presented that RMIT considers to be material.
### Privacy and Confidentiality
(40)  All parties and support persons involved in a matter dealt with under this procedure must treat the details, their involvement, the names of other associated parties and all reports, findings, recommendations and actions as private and confidential. Where a party to a complaint is found to have breached the privacy of another person, they may be subject to disciplinary action.
(41)  Limitations may apply to privacy and confidentiality:
  1. where risks to health and safety are present
  2. in matters involving persons under 18 years of age, or
  3. in circumstances where information is otherwise permitted or required to be shared by law.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=2#document-top)
# Section 5 - Schedules
(42)  This procedure includes the following schedule(s):
  1. [Schedule 1 – Examples of Disciplinary and Non-Disciplinary Actions](https://policies.rmit.edu.au/download.php?id=196&version=2&associated).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=2#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Volunteer |  Includes any person (whether a member of the public or student) undertaking volunteering for RMIT who may have an actual or perceived authority equivalent to a staff member, in relation to the event, activity or undertaking for which they are volunteering. It extends to volunteers of RMIT clubs, such as club officers.  
---|---  
Workplace investigation |  An investigation into allegations of misconduct and/or serious misconduct conducted by an investigator. Disciplinary actions are available following a workplace investigation where allegations of misconduct and/or serious misconduct have been substantiated.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
