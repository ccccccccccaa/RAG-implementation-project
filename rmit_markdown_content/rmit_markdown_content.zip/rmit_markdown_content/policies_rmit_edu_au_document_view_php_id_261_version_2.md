[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=261&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=261&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Domestic and Family Violence Procedure Schedule 1 - Definitions 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=261)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=261&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=261&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=261&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=261&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=261&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=261&version=2)


# Domestic and Family Violence Procedure Schedule 1 - Definitions
Hide Navigation
  * [Section 1 - Definitions](https://policies.rmit.edu.au/document/view.php?id=261&version=2#section1)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Definitions
The following definitions apply to the [Domestic and Family Violence Procedure](https://policies.rmit.edu.au/document/view.php?id=259).
#### Domestic and Family Violence
(1)  RMIT applies the definitions of domestic and family violence from the [Family Violence Prevention Act 2008 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/family-violence-protection-act-2008/). This includes:
  1. behaviour by a person towards a current or past family member of that person if that behaviour: 
    1. is physically or sexually abusive, such as assault
    2. is emotionally or psychologically abusive, such as behaviour by a person towards another person that torments, intimidates, harasses or is offensive to the other person, including stalking, or repeated derogatory taunts
    3. is economically abusive, such as unreasonably denying the family member the financial autonomy that they would otherwise have had, such as coercing them into signing a contract for a loan, or preventing a person from gaining employment, or unreasonably withholding financial support needed to meet the reasonable living expenses of the family member or their child at a time when the family member is entirely or predominantly dependent on the person for financial support
    4. is threatening or is coercive, or
    5. in any other way controls or dominates the family member and causes that family member to feel fear for the safety or wellbeing of that family member or another person; or
  2. behaviour by a person that causes a child to hear or witness, or otherwise be exposed to the effects of, behaviour referred to in paragraph (a). Examples of domestic and family violence include: 
    1. intentionally damaging or destroying property; intentionally causing death or injury to an animal
    2. preventing the family member from making or keeping connections with their family, friends or culture
    3. unlawfully depriving the family member, or any member of the family member’s family, of their liberty.


(2)  Domestic and family violence may occur between intimate partners or ex partners, including those in same sex relationships, between siblings, by adolescent or adult children and their parents, or between extended family members.
(3)  Family members includes where a person reasonably regards the other person as being like a family member, having regard to the circumstances of the relationship such as:
  1. the nature of the social and emotional ties between the relevant person and the other person
  2. whether the relevant person and the other person live together or relate together in a home environment
  3. the reputation of the relationship as being like family in the relevant person's and the other person's community
  4. the cultural recognition of the relationship as being like family in the relevant person's or other person's community
  5. the duration of the relationship between the relevant person and the other person and the frequency of contact
  6. any financial dependence or interdependence between the relevant person or other person
  7. any other form of dependence or interdependence between the relevant person and the other person
  8. the provision of any responsibility or care, whether paid or unpaid, between the relevant person and the other person
  9. the provision of sustenance or support between the relevant person and the other person.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
