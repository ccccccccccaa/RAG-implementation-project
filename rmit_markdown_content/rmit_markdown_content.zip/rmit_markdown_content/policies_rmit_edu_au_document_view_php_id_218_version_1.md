[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=218&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=218&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Sexual Harm Prevention and Response Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=218)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=218&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=218&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=218&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=218&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=218&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=218&version=1)


# Sexual Harm Prevention and Response Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=218&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=218&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=218&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=218&version=1#section4)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=218&version=1#major1)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=218&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=218&version=1#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  The purpose of this policy is to set out the principles of RMIT’s approach to preventing and responding to sexual harm. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218&version=1#document-top)
# Section 2 - Overview
(2)  This policy establishes a framework to support and enable the prevention of sexual harm at RMIT, and RMIT’s responses to sexual harm.
(3)  This policy and its corresponding procedures are specific to sexual harm; however, they should be read in conjunction with those RMIT policies regarding behavioural standards and conduct. In particular:
  1. for students about whom a report of sexual harm is made, this policy should be read in conjunction with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and its corresponding procedures
  2. for staff about whom a report of sexual harm is made, this policy should be read in conjunction with the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52) and the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122), and its corresponding procedures
  3. other RMIT regulations, policies and procedures, and those of relevant third parties may also apply in some circumstances (for example, the policies of industry partners hosting RMIT students on placement).


(4)  This policy also sets out definitions for key concepts such as consent, sexual harm, sexual harassment and sexual assault. Additional explanations and examples for these terms are set out in the corresponding resources.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218&version=1#document-top)
# Section 3 - Scope
(5)  This policy applies to all students within the RMIT Group, with the same scope as the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
(6)  This policy applies to all staff and associates of the RMIT Group, including:
  1. RMIT University Council members, employees, researchers, representatives and volunteers
  2. contractors, tenants, licensees or lessees, and service providers where there is a connection with RMIT or when attending RMIT premises
  3. customers and visitors when engaged in activities with or for RMIT, or when attending RMIT premises
  4. partner organisations or people acting for or on behalf of RMIT in relation to our students and staff (including clubs and societies, and student representative organisations).
  5. in Australia and overseas (subject to relevant legislation). 


(7)  This policy applies:
  1. at all times when persons are working for, travelling with or for RMIT, or representing RMIT, including overseas
  2. during and outside normal working or study hours
  3. to all RMIT locations and premises, including but not limited to: 
    1. RMIT campuses, premises and facilities
    2. RMIT owned, operated, affiliated or endorsed accommodation
    3. off-campus venues, activities and events where staff, students or third parties are representing RMIT (e.g. sporting events, cultural events, competitions, placements, conferences)
    4. virtual spaces using RMIT systems, IT infrastructure or assets.


(8)  This policy applies to RMIT Vietnam, and RMIT Vietnam procedures give effect to the principles in this policy.
(9)  Any person can make a disclosure or report of sexual harm under this policy if there is a connection to RMIT, including third parties who are external to RMIT and persons other than a victim-survivor. However, the steps which RMIT can take in response to a disclosure or report may depend on whether the person who is the victim-survivor wishes to participate or to utilise RMIT’s processes.
(10)  If sexual harm is disclosed or reported as occurring outside the scope of this policy, RMIT will provide referrals to support services as appropriate.
(11)  If a disclosure or report is made that a person who is external to RMIT has caused sexual harm, RMIT may be limited in its ability to investigate or impose restrictions on that person directly.
(12)  The following policies take precedence over this one to the extent of any inconsistency:
  1. the Child Safety Policy, regarding sexual harm relating to children, and
  2. the Domestic and Family Violence Policy, regarding sexual harm in the context of domestic and family violence [in development].

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218&version=1#document-top)
# Section 4 - Policy
(13)  Human Rights: RMIT considers all forms of sexual harm unacceptable and a violation of human rights.
(14)  Prevention: RMIT seeks to prevent sexual harm by promoting a safe, respectful learning and work environment. RMIT advances gender equality, and a culture of respect.
(15)  The rights of victim-survivors:
  1. RMIT supports a rights-based, victim-survivor centred approach, where physical, emotional, psychological, cultural, and spiritual safety and wellbeing of a person who has experienced sexual harm is prioritised.
  2. RMIT provides for timely and trauma-informed responses to sexual harm. RMIT is committed to demonstrating compassion and empathy to victim-survivors, and to minimising the trauma which can be associated with disclosing or reporting sexual harm, as well as with the processes which can follow, such as investigation.
  3. RMIT’s processes support confidentiality, privacy and, to the extent possible, anonymity.


(16)  Accountability and education: RMIT’s leaders are accountable for the prevention of sexual harm. RMIT will empower its staff and students through education to support a shared understanding of sexual harm, what behaviours are unacceptable, what steps can be taken to prevent it, and how to respond to sexual harm.
(17)  Consistent and informed approach:
  1. RMIT has a range of ways to report or disclose sexual harm, and a range of support avenues for persons who have experienced sexual harm.
  2. RMIT’s processes and avenues are safe and transparent (subject to confidentiality and privacy).
  3. RMIT’s processes are evidence based and allow RMIT to collect, analyse and report on data to identify trends, underlying issues, and emerging risks; which informs our response.


(18)  Integrity in our processes: RMIT will ensure our policy and procedures are evidence-based and maintained according to current best practice. Our processes will be informed by procedural fairness, will protect against victimisation, and will support those who make disclosures or reports. Our processes will be designed to resolve or reach finality regarding disclosures or reports as efficiently as possible.
(19)  Support for diverse needs: RMIT acknowledges that a person’s experiences, needs and perspectives are informed by their prior experiences, background and identity, and that certain groups of people are disproportionately impacted by sexual harm, including the following:
  1. people of diverse genders, sexes or sexualities, including those who identify as LGBTQIA+
  2. Aboriginal and Torres Strait Islander peoples
  3. people with a disability, and
  4. people from a culturally and linguistically diverse background. 


RMIT also acknowledges that a person’s race, age, socio-economic background, religion, family circumstances, migration status, and all other aspects of a person’s identity may determine what support they need in the context of responding to and preventing sexual harm; and RMIT will work to meet these needs.
### Responsibilities
(20)  All members of the RMIT community identified in the Scope section above are responsible for their behaviour and actions. They are required to:
  1. model acceptable and appropriate behaviour in line with the standards outlined in the RMIT [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52).
  2. promote respectful culture and practice within their sphere of influence
  3. increase awareness of and encourage compliance with relevant policy and procedures
  4. engage with relevant education, training and awareness raising opportunities provided by RMIT to develop skills necessary to support a respectful, safe, and inclusive community
  5. comply with their reporting and record keeping obligations, as required.


(21)  The Vice-Chancellor's Executive (VCE) is responsible for providing a safe, nonviolent, gender equal and inclusive environment for all members of the RMIT community.
(22)  The Vice-Chancellor’s Gender Based Violence Advisory Group is responsible for leading the development and implementation of RMIT’s strategy on gender-based violence prevention.
(23)  The Safer Community team is responsible for providing culturally safe and appropriate support services to staff and students including referral to sexual harm counselling services, an interpreter, and referral to RMIT’s [Equitable Learning Services](https://policies.rmit.edu.au/download.php?id=52&version=1&associated) for disability aides or other support.
(24)  Senior RMIT committees will regularly examine de-identified data to identify trends and systemic issues, evaluate prevention programs, and enable RMIT to identify opportunities for improvements and implement changes where required.
(25)  Managers at RMIT are responsible for advocating education about the principles in this policy, and taking prompt action in accordance with the procedures under this policy.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218&version=1#document-top)
# Section 5 - Procedures and Resources
(26)  Refer to the following documents which are established in accordance with this policy:
  1. [Sexual Harm Response Procedure](https://policies.rmit.edu.au/document/view.php?id=219)
  2. [Sexual Harm Response Procedure – Vietnam](https://policies.rmit.edu.au/document/view.php?id=248)
  3. [Sexual Harm Explanations and Examples](https://policies.rmit.edu.au/document/view.php?id=220)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218&version=1#document-top)
# Section 6 - Definitions
Child | A person who is under the age of 18 years.  
---|---  
Concern | An expression of dissatisfaction with the behaviour of a student or staﬀ member, where a response is not expected.  
Consent | Free agreement, given voluntarily and on an informed basis. [Additional examples of and explanations for consent are set out in [Resources](https://policies.rmit.edu.au/document/view.php?id=220)]  
Disclosure | Where a person ﬁrst makes known an incident of sexual harm with RMIT. This may or may not lead to a report being made via the Complaints Governance Policy or another reporting avenue.   
Sexual assault | Is when: i. a person (A) intentionally touches another person (B) and the touching is sexual ii. person (B) who was touched did not agree or consent to the touching, and iii. person (A) did not reasonably believe that person (B) consented. If person (A) knew that (B) was not consenting, this will be sexual assault; and if person (A) did not believe on reasonable grounds that B was consenting, this will also be sexual assault. For the purposes of this policy, RMIT also includes the following acts defined in the [Crimes Act 1958 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/crimes-act-1958/): (i) rape, (ii) rape by compelling sexual penetration, (iii) sexual assault by compelling sexual touching, (iv) assault (being the non-consensual application of force) with intent to commit a sexual act, and (v) threat to commit a sexual assault or rape. For succinctness, the specific elements of each are not set out separately in this policy.   
Sexual harm |  Non-consensual behaviour of a sexual nature that causes a person to feel uncomfortable, frightened, distressed, intimidated, or harmed, either physically or psychologically. Sexual harm includes behaviour that also constitutes sexual harassment, sexual assault and rape. [Additional examples of and explanation of sexual harm are set out in the Resources]  
Sexual harassment | When a person: (a) makes an unwelcome sexual advance, or an unwelcome request for sexual favours, or (b) engages in other unwelcome conduct of a sexual nature in relation to a person, in circumstances in which a reasonable person, having regard to all the circumstances, would have anticipated the possibility that the person harassed would be offended, humiliated or intimidated. [Additional examples of and explanation of sexual harm are set out in the Resources]  
Report | An expression of dissatisfaction with the behaviour of a student or staﬀ member, where a response or resolution is explicitly or implicitly expected.  
Third Parties | Any person or entity external or separate to RMIT, including contractors, consultants, volunteers, visiting appointees and visitors as well as members of the public.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
