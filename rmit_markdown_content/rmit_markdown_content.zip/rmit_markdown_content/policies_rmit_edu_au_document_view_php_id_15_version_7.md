[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=15&version=7#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=15&version=7#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Progress Management and Support Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=15)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=15&version=7)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=15&version=7)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=15&version=7)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=15&version=7)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=15&version=7)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=15&version=7)


# HDR Progress Management and Support Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=15&version=7#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=15&version=7#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=15&version=7#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=15&version=7#section4)
  * [Progress Management](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major1)
  * [Requirement for Regular, Documented Supervision Meetings](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major2)
  * [Candidature Milestone Review Process](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major3)
  * [Candidates Who Need Action and Support for Their Academic Progress](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major4)
  * [Action and Support Management](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major5)
  * [Next Steps After a Period of Action and Support](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major6)
  * [Convening a Milestone Review Panel](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major7)
  * [Scheduling of Milestone Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major8)
  * [Closed Milestone Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major9)
  * [Exemptions from Milestone Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major10)
  * [Written Components of Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major11)
  * [Convening and Running a Milestone Review](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major12)
  * [Assessment of Progress at a Milestone Review](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major13)
  * [Subsequent Milestone Attempts](https://policies.rmit.edu.au/document/view.php?id=15&version=7#major14)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=15&version=7#section5)
  * [Section 6 - Resources](https://policies.rmit.edu.au/document/view.php?id=15&version=7#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets out the rules and processes for supporting and managing academic progress in Higher Degree by Research (HDR) programs.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=7#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=7#document-top)
# Section 3 - Scope
(3)  The procedure applies to all staff responsible for monitoring and managing HDR academic progress and supervision and all HDR candidates in the RMIT Group. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=7#document-top)
# Section 4 - Procedure
### Progress Management
(4)  Candidates will have their progress and the quality of their research regularly monitored.
(5)  Progress is managed through:
  1. regular supervision meetings,
  2. completion of coursework and other appropriate skills development training,
  3. formative assessment of progress and researcher capability through three candidature milestones, and
  4. provision of other relevant services and support available to enrolled students. 


(6)  The University will identify and support candidates to address progress issues which may arise during their program of study. 
### Requirement for Regular, Documented Supervision Meetings
(7)  Supervisors are required to monitor their candidates’ overall academic progress, their preparedness for milestone reviews and submission for examination through regular meetings and review of work submitted at regular intervals.
(8)  Within the first three (3) months of candidature, candidates and their supervisors must agree on:
  1. an outline of the research project for the duration of candidature with key components of the project detailed (e.g. literature review; whether an ethical review of the proposed research is required),
  2. how the research will be presented for examination according to the norms and standards of the discipline, including where necessary, a plan for recording digitally additional integral elements of work to be examined,
  3. any periods, locations, purpose and description of fieldwork, lab work etc.,
  4. periods of attendance at a partner institution/organisation (if applicable),
  5. potential ethics and institutional biosafety requirements and timing of ethics approval, including a documented plan for gaining and maintaining any required ethics approval in accordance with the RMIT [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28).
  6. an indicative plan for the production of research outputs,
  7. candidate training needs additional to any mandatory coursework to support good progress and successful graduate outcomes.


(9)  Supervisors and candidates will agree on a supervision meeting schedule which may be revised depending on the candidate’s study load and stage of candidature. As a guide, meetings should normally occur at least once a fortnight or part-time equivalent.
(10)  Candidates and their supervisors are responsible for keeping a record of all supervision meetings on file for reference including tasks the candidate must undertake, and the responsibilities of the supervisor. 
(11)  Records of supervisory meetings must be accessible by the candidate and the supervisory team for future reference. They must also be produced on request by the school HDR Delegated Authority (HDR DA) or the School of Graduate Research (SGR). 
### Candidature Milestone Review Process
(12)  A candidate’s academic progress is formally assessed through the three candidature milestone reviews: confirmation of candidature; second milestone review; and the third milestone review.
(13)  For candidates enrolled through a collaborative research training agreement or joint PhD, candidature milestones should align with the requirements of the partner institutions where possible. Milestones which are completed at a partner institution and involve the RMIT supervisors on the panel, will be deemed to be the equivalent of RMIT milestones and will not be required to be duplicated at RMIT.
(14)  Subject to the remainder of this Procedure, candidates may permitted up to two attempts to achieve a milestone. Where a candidate has failed two milestone attempts, the case must be referred to the college nominee for review within 10 working days of the milestone outcome notification being sent to the candidate. From this point, the matter follows the College review process listed in the [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174).
(15)  Where milestones are not attempted or achieved in a timely manner, a Candidate Action and Support Plan (CASP) must be put in place.
(16)  Where a candidate successfully completes a milestone without ethics approval, a CASP must be put in place.
### Candidates Who Need Action and Support for Their Academic Progress
(17)  An HDR CASP must be developed and implemented when a candidate’s satisfactory progress is at risk for any reason.
(18)  A period of action and support may be initiated by the candidate, the milestone review panel, the HDR DA, or the Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) or nominee if:
  1. a candidate fails to attend two or more regular supervision meetings without providing evidence of exceptional/compassionate circumstances
  2. there are documented circumstances beyond the candidate’s control which are impeding their academic progress
  3. there is documented evidence of failure by the candidate to: 
    1. consistently produce work requested for review by their supervisor to the required standard,
    2. complete one or more coursework courses, or
    3. otherwise follow their agreed research plan.
  4. the candidate has missed a milestone due date
  5. the candidate has been unable to achieve the requirements of their milestone and/or their milestone requires major amendments
  6. the candidate applies for an extension beyond maximum duration of candidature
  7. the project is pending ethics approval and requires support to ensure this will not impact progress
  8. the candidate successfully completes a milestone review but has ethics approval pending.


(19)  Where extenuating circumstances cause an impact on the academic progress of a cohort of HDR candidates, a specialised CASP may be developed. Processes and timelines may vary from the standard CASP process listed in this procedure. 
(20)  Action and support should not be used for student conduct matters. Refer to the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) for more information. 
### Action and Support Management
(21)  Once a requirement for action and support is established, the HDR DA in conjunction with Research Training Services (RTS) team in SGR will provide notice within ten (10) working days to the candidate and supervisors of a scheduled action and support meeting. 
(22)  The purpose of the meeting is to develop a CASP outlining required action for the candidate and their supervisors to return the candidate to satisfactory progress, as well as any additional support to be provided. 
(23)  The HDR DA or nominee will chair the meeting. The primary senior supervisor and the candidate will attend along with the associate or joint senior supervisor/s (at the Chair’s discretion).
(24)  The candidate may take a support person to the meeting.
(25)  Action and support meetings should be face to face, either in person or via video conferencing.
(26)  The CASP form is the formal record of the meeting and of the University’s commitment to provide action and support. 
(27)  The HDR DA is responsible for reviewing and endorsing the CASP and may require amendments where appropriate. 
(28)  The HDR DA must submit the CASP to the RTS team in SGR within 10 working days of the CASP meeting. 
(29)  SGR may provide further advice and guidance regarding the development, implementation and review of a CASP if required. 
(30)  The candidate must work with their supervisors to implement the plan by the proposed end date, even if the candidate does not:
  1. attend an action and support meeting,
  2. contribute to the development of a CASP, or 
  3. sign the CASP within 10 working days of its development.


(31)  The duration of a CASP is determined by the HDR DA up to a maximum duration of three months or part-time equivalent.
(32)  A full set of documentation from the action and support meeting must be developed to ensure the action and commitments agreed by the school, supervisors and candidate are recorded. The CASP documentation must include:
  1. a summary of the candidate’s perspective on barriers to progress,
  2. recommendations by the senior supervisor and/or HDR DA for additional support for the candidate, and
  3. an action plan developed and endorsed by the candidate, their supervisor/s, and the HDR DA which must consist of tasks for the candidate and the supervisory team where appropriate, that: 
    1. are clear, detailed and specific – the candidate, supervisory team and HDR DA should have the same understanding of each task after reading the action plan
    2. have set deadlines that are achievable within the time frame of the CASP (in the event of any unexpected absence, the action plan should be reviewed and updated to reflect any delays, as appropriate)
    3. include reasonable time for any specific training or access to/provision of facilities required
    4. set tasks and deadlines for the supervisory team, such as providing feedback within a set period of time to support the candidate’s return to progress.


(33)  CASPs may be monitored and reviewed by the RTS team in SGR, and the ADVC RT&D or nominee may instruct: 
  1. amendments to be made to the CASP
  2. any remedial action or additional support deemed necessary to uphold academic standards, support HDR progress, and to ensure compliance with University policy
  3. that a new CASP should be created when enrolment variations take place during the CASP period.


### Next Steps After a Period of Action and Support
(34)  No more than two consecutive CASPs may be agreed for the same candidate unless approved by the ADVC RT&D or nominee. 
(35)  At the end of a period of action and support, the HDR DA will determine whether the conditions of the CASP have been met. If the candidate:
  1. is deemed to be making satisfactory progress, the period of action and support will end
  2. continues to require additional support, a new CASP may be developed (in accordance with this procedure)
  3. fails to make satisfactory progress or refuses to engage with the CASP, the HDR DA will either require a second, consecutive CASP or refer the matter to the College nominee for review within 10 working days of the CASP’s expiry date.


(36)  Refer to the [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174) for further information. 
### Convening a Milestone Review Panel
(37)  The HDR DA or supervisory team will convene the review panel and must ensure there is no potential, perceived or actual conflict of interest between the panel members and/or the candidate. Where possible, the review panel members should remain consistent for each milestone throughout candidature.
(38)  A review panel normally comprises:
  1. a Chair, who will be the school HDR DA or another senior supervisor from the school
  2. a minimum of one supervisor who is a senior or a joint senior supervisor
  3. at least one member who is independent of the supervisory team. This member of the panel must be a registered supervisor (or, if external to the university, have a doctoral qualification or equivalent).


(39)  Additional supervisors may be appointed to the panel where appropriate. However, all supervisors must agree on a single, team position with respect to any decisions the panel may make on the outcome.
### Scheduling of Milestone Reviews
(40)  All candidature milestone reviews must be scheduled within the following milestone windows:
Degree | Timing of confirmation of candidature | Timing of second milestone review | Timing of third milestone review  
---|---|---|---  
PhD | From 0.5 and no later than 1 EFTSL after candidate’s research commencement date | From 1.5 and no later than 2 EFTSL after candidate’s research commencement date | From 2.5 and no later than 3 EFTSL after candidate’s research commencement date  
Master by Research | From 0.25 and no later than 0.5 EFTSL after candidate’s research commencement date | From 0.75 and no later than 1 EFTSL after candidate’s research commencement | From 1.5 and no later than 1.75 EFTSL after candidate’s research commencement date  
(41)  Approved leave of absence and changes to study load will adjust the milestone review window for future milestones only. Overdue milestones are unaffected by changes of study load or approved leave of absence.
(42)  Candidates are required to present their research to a forum of the relevant research community and the candidate is expected to take questions from review panel members and the wider audience.
(43)  Where a candidate is not able to attend a scheduled milestone review due to compassionate or compelling circumstances, they must notify their senior supervisor and HDR DA as early as possible and provide documentation to support their request to reschedule their milestone.
(44)  All costs associated with milestone review, regardless of location, will be borne by the enrolling school.
### Closed Milestone Reviews
(45)  In exceptional circumstances, a candidate may request approval to present their milestone solely to a review panel rather than in a public forum. This request must be made at least two months prior to the scheduled milestone presentation. Candidates make the request by submitting a case and supporting documentation, including evidence of support from their senior supervisor, to HDR DA and the RTS team in SGR.
(46)  The case is considered for endorsement by the HDR DA, after consultation with the supervisory team. If the request is endorsed, the HDR administrator must submit the documentation for approval by the ADVC RT&D or nominee.
### Exemptions from Milestone Reviews
(47)  In some circumstances, such as transferring to RMIT from another institution, candidates may apply for an exemption for any milestone review by submitting a request to their senior supervisor, including evidence from their previous institution of the successful completion of equivalent milestone(s) for their current research project. Support for the exemption from their senior supervisor is required before the request can be processed. This should be done at the point of application for admission.
(48)  The case is considered, and if deemed appropriate, approved by the HDR DA, after consultation with the supervisory team.
(49)  Candidates who seek re-admission for the purpose of examination may be exempt from completing the third milestone review, providing the school is satisfied that the candidate’s research is ready for examination. (Refer to [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18)). 
### Written Components of Reviews
(50)  All review presentations must be accompanied by submission of appropriate written and supporting materials to the review panel as specified in [Schedule 1](https://policies.rmit.edu.au/document/view.php?id=237) and be of an appropriate scholarly standard.
(51)  Candidates are required to produce work of the appropriate quality and length for each milestone as per guidance from their supervisory team and/or HDR DA.
### Convening and Running a Milestone Review
(52)  The candidate must submit all documentation at least 15 working days before the scheduled date of the milestone.
(53)  Candidates must notify their school of any specific technical requirements 10 working days before their presentation. Schools are to make available to candidates any necessary equipment for projection of sound/visual or text-based presentations.
(54)  A review panel must confirm that any necessary approvals or arrangements are in place, such as: human, animal research ethics, institutional biosafety, copyright clearances and/or intellectual property. Where these are not in place, the candidate will work with their supervisors and/or HDR DA to develop and implement a Candidate Action and Support Plan following the milestone to ensure a swift resolution and to prevent any further impact on progress.
(55)  Candidates must be provided with informal feedback at the end of the milestone review. 
(56)  During the milestone review, the panel Chair must invite candidates to provide confidential feedback on their candidature and supervision, without the supervisory team present. Candidates may also submit feedback on their supervisory experience to SGR. Any record of feedback will remain confidential between the candidate, panel Chair and SGR, unless the candidate permits disclosure.
(57)  The review panel must confer in camera, as soon as possible, but not more than one week after the presentation to agree to their recommended outcome of the review. The Chair of the panel has the final determination of candidate’s milestone status.
(58)  The panel must provide detailed, written feedback to the candidate, and include any amendments, necessary or recommended, for the candidate and supervisors.
(59)  The Chair of the review panel must finalise and endorse the milestone review report after the meeting. The Chair must submit the report to SGR within 10 working days of the review presentation.
(60)  Milestone review documentation is subject to regular auditing and moderation.
(61)  Following a review of any milestone documentation submitted for approval, the ADVC RT&D or nominee may:
  1. delay the finalisation of a milestone outcome pending provision of further information or documentation
  2. overrule a milestone outcome
  3. instruct any remedial action deemed necessary, to uphold academic standards, support HDR progress, and to ensure compliance with University policy.


(62)  SGR notifies candidates of the outcome of all milestone reviews. Those who achieve their milestone are regarded as having made satisfactory progress.
### Assessment of Progress at a Milestone Review
(63)  Panel members will assess candidates progress against the criteria listed in [Schedule 1](https://policies.rmit.edu.au/document/view.php?id=237). 
(64)  The Chair of the review panel may refer milestone reports to the ADVC RT&D or nominee prior to determining an outcome where an independent review would be useful. 
(65)  Milestone review outcomes include:
  1. Milestone achieved 
  2. Major amendments required
  3. Major amendments not achieved


(66)  Criteria for milestone review outcomes are listed in [Schedule 1](https://policies.rmit.edu.au/document/view.php?id=237).
### Subsequent Milestone Attempts
(67)  If a candidate is given an outcome of major amendments required, the RTS team in SGR instructs a CASP to be developed and advises that they must present their milestone a subsequent time, addressing the required amendments. The HDR DA must organise an action and support meeting in accordance with this procedure. 
(68)  Where a candidate is required to present a subsequent time:
  1. the CASP must include the timeframe for resubmitting and presenting the milestone, and
  2. the panel must assess whether the requested amendments were made.


(69)  Where a candidate is required to present a milestone for the second time and the milestone is not achieved, the candidate is considered to be making unsatisfactory progress. The case must be referred to a college review within 10 working days of the milestone outcome notification being sent to the candidate (Refer to the [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174)).
(70)  Where the resulting action of the college review provides a candidate the opportunity to attempt a milestone for a third time and the outcome is unsuccessful, the matter must be referred to the Research Candidature Progress Committee (RCPC) within 10 working days of the milestone outcome notification being sent to the candidate. (Refer to the [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174)).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=7#document-top)
# Section 5 - Schedules
(71)  This procedure includes the following schedules:
  1. [HDR Progress Management and Support Schedule 1 - Milestone Submission Requirements, Assessment Criteria and Outcomes](https://policies.rmit.edu.au/document/view.php?id=237)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=7#document-top)
# Section 6 - Resources
(72)  Refer to the following documents:
  1. [HDR Forms](https://policies.rmit.edu.au/download.php?id=68&version=2&associated): 
    1. HDR Candidate Action and Support Plan (CASP)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
