[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=105#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=105#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Information Technology - User Device Security Standard 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=105)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=105)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=105)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=105)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=105)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=105)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=105)


# Information Technology - User Device Security Standard
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=105#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=105#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=105#section3)
  * [Section 4 - Standard](https://policies.rmit.edu.au/document/view.php?id=105#section4)
  * [Corporate (RMIT-Owned) Devices](https://policies.rmit.edu.au/document/view.php?id=105#major1)
  * [Using a Non-RMIT Managed Device](https://policies.rmit.edu.au/document/view.php?id=105#major2)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The purpose of this standard is to:
  1. manage information security risks associated with user devices, and
  2. protect RMIT information and prevent unauthorised access.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=105#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Information Technology and Security Policy](https://policies.rmit.edu.au/document/view.php?id=75).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=105#document-top)
# Section 3 - Scope
(3)  This Standard applies to all staff, researchers, contractors, visitors, and any other parties (collectively referred as “Users”) who have access to the IT assets of RMIT University and its controlled entities (“RMIT”). It is applicable for all devices (RMIT managed as well as non-RMIT managed devices that are used for the conduct of RMIT business) including but not limited to computers, laptops, tablets, phones, wearables, computer peripherals, and the internet of things.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=105#document-top)
# Section 4 - Standard
### Corporate (RMIT-Owned) Devices
(4)  All devices and mobile services must be procured through Information Technology Services (ITS) using the approved mobile device process. ITS is responsible for maintaining a central register of devices.
(5)  Device procurement must comply with the [Business Expenses Policy](https://policies.rmit.edu.au/document/view.php?id=66) as well as [Procurement and Expenditure Policy](https://policies.rmit.edu.au/document/view.php?id=221).
(6)  Cost centre managers are responsible for ensuring that devices and SIMs are returned by users when their engagement with RMIT terminates.
(7)  Devices provided by RMIT remain the property of RMIT and can be revoked or reassigned as needed.
(8)  RMIT has the rights to remove unauthorised or modified applications from devices and related content without notice or warning if it is deemed to be a security risk.
(9)  RMIT may temporarily retain any device assigned to an individual to complete security or forensic investigation.
(10)  RMIT may remotely lock, wipe, or reconfigure any device if it is deemed to be a security risk. 
(11)  Damaged devices must be repaired at an authorised service agent nominated by ITS. Costs associated with the repairs are paid by the owning cost centre.
(12)  Lost or stolen devices must be reported immediately via the ITS Service and Support centre.
(13)  Authorised users requiring international roaming services on an RMIT device whilst travelling overseas must complete an international roaming request at least five (5) days prior to departure.
### Using a Non-RMIT Managed Device
(14)  Information generated by RMIT users relating to RMIT business or operations remains the property of RMIT and is accessible by authorised RMIT staff.
(15)  RMIT reserves the right to disconnect a non-RMIT managed device and disable services to that device without notification if it is deemed to be a security risk.
(16)  RMIT is not responsible for any damaged, lost or stolen non-RMIT managed device an RMIT user may choose to use while conducting RMIT business nor for non-RMIT data damaged or lost on that device.
(17)  Activity within RMIT work related apps, tools and tasks being conducted on non-RMIT managed device may be tracked to meet the legal and regulatory requirements of RMIT.
(18)  Users must use only authorised applications to interact with RMIT data, and to ensure that all software used for RMIT business is legally licensed. The use of illegally obtained or unapproved applications is strictly prohibited.
(19)  Users must maintain a non-RMIT managed device compatible with RMIT’s published technical specifications (e.g. Hardening Standard) which will be updated by ITS as needed. Users should only use devices meeting these specifications to access RMIT network and data.
(20)  When using a non-RMIT managed device (e.g. mobile or laptop) to access RMIT systems or data, users must:
  1. keep the operating system and applications up to date; most updates include security patches
  2. keep a current antivirus software version running 
  3. keep a screen lock enabled that uses a unique authentication method, PIN, pattern or fingerprint
  4. enable a ‘find my device’ capability and ensure it is usable if the device is lost or stolen
  5. use only Microsoft Office as the email client to access RMIT email
  6. change their RMIT account password immediately if their device is lost or stolen
  7. not store RMIT data locally on the device memory
  8. have hard disk encryption enabled. 


(21)  Users must provide access to non-RMIT managed devices when notified that the device has been selected as in scope for e-discovery or if required for any investigation of a regulatory notifiable data breach or information security incident or litigation or if compelled by a court of law.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
