[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=11&version=4#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=11&version=4#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=11)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=11&version=4)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=11&version=4)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=11&version=4)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=11&version=4)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=11&version=4)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=11&version=4)


# Enrolment Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=11&version=4#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=11&version=4#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=11&version=4#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=11&version=4#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=11&version=4#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=11&version=4#major2)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=11&version=4#major3)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=11&version=4#major4)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=11&version=4#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=11&version=4#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This policy establishes the principles for supporting the enrolment of students at RMIT Group institutions.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=4#document-top)
# Section 2 - Overview
(2)  RMIT is a self-accrediting University and Registered Training Organisation enrolling students in Australian Qualifications Framework (AQF) accredited and non-AQF programs and courses in Australia, overseas campuses and international partner locations. RMIT is also a registered Commonwealth Register of Institutions and Courses for Overseas Students (CRICOS) provider and enrols students in University pathway programs.
(3)  Through this policy, RMIT recognises the ongoing relationship that exists between the University and enrolled students and ensures the obligations of each party for the duration of the enrolment are clearly articulated.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=4#document-top)
# Section 3 - Scope
(4)  This policy applies to:
  1. all staff responsible for student administration and enrolment activities, and
  2. students enrolled in programs and courses offered by RMIT University including RMIT Vietnam, RMIT Training, RMIT Online and international partners.


(5)  This policy also applies to pathway programs provided by RMIT Training and RMIT Vietnam including English Language Intensive Courses for Overseas Students (ELICOS) training programs and Foundation Studies.
(6)  This policy excludes short courses and other industry training courses provided by RMIT Training and RMIT Online.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=4#document-top)
# Section 4 - Policy
### Principles
(7)  Students enrolled in a program or course are subject to RMIT statutes, regulations and policies, and any procedures of the relevant RMIT institution.
(8)  Where University requirements have been met, enrolled students are entitled to:
  1. academic and student support services and appropriate learning resources offered by the institution
  2. attend or participate in teaching sessions and other scheduled activities
  3. assessment of their learning and performance
  4. research training and supervision, in the case of higher degree by research programs
  5. receive results (except in short courses and some English skills acquisition courses where there is no summative assessment).


(9)  RMIT is committed to providing:
  1. information relating to enrolment and enrolment variation which is clear and accessible to students
  2. transparent processes and accuracy of records.


(10)  Appropriate appeal provisions will be available in respect to enrolment decisions.
### Responsibilities
(11)  Enrolled students are responsible for ensuring:
  1. their enrolment and personal details as recorded by the University are accurate for the duration of their program
  2. all fees and charges are paid by the due dates
  3. they are familiar with the [Student Charter](https://policies.rmit.edu.au/download.php?id=74&version=1&associated)
  4. they read and comply with the [Statement of Student Responsibilities](https://policies.rmit.edu.au/download.php?id=75&version=1&associated)
  5. their enrolment complies with government and visa requirements, where applicable
  6. they notify RMIT of any changes to their circumstances that may impact their enrolment status at RMIT.


(12)  The Academic Registrar is responsible for:
  1. establishing and maintaining procedures and resources for enrolment in RMIT University award programs and courses
  2. ensuring changes or decisions relating to enrolment are communicated to students
  3. authorising notifications to external authorities, including mandatory reporting
  4. ensuring current and accurate information about critical timelines, student visa obligations and enrolment processes are available to students
  5. amending a student’s enrolment or details to meet University and/or legal compliance requirements, and may cancel, suspend or terminate an enrolment where the student has breached certain obligations
  6. reviewing this policy and supporting documents.


(13)  The Chief Executive Officer, RMIT Training establishes and maintains enrolment procedures and resources for ELICOS training programs and English language preparatory courses, and resources to support pathway programs delivered at RMIT Training. 
(14)  The Associate Deputy Vice-Chancellor Research Training and Development establishes and maintains procedures and resources for enrolment in higher degree by research programs.
(15)  All staff responsible for administering enrolment activities must follow this policy, associated procedures and resources.
### Compliance
(16)  Breaches of this policy by a staff member will be managed via the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52).
(17)  Breaches of this policy by a student will be managed via the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
### Review
(18)  This policy will be reviewed at least once every three years in accordance with the [Policy Governance Framework](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=4#document-top)
# Section 5 - Procedures and Resources
(19)  Refer to the following documents which are established in accordance with this policy:
  1. [Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=113)
  2. [Enrolment Procedure - Mobility](https://policies.rmit.edu.au/document/view.php?id=114.1.1)
  3. [Enrolment Procedure - Leave of Absence](https://policies.rmit.edu.au/document/view.php?id=115.1.1)
  4. [Enrolment Procedure – Maximum Time to Complete a Coursework Program](https://policies.rmit.edu.au/document/view.php?id=164)
  5. [Enrolment – COVID-19 Vaccination Requirements Procedure](https://policies.rmit.edu.au/document/view.php?id=209)
  6. [Enrolment Procedure - Discontinuation of Student Program](https://policies.rmit.edu.au/document/view.php?id=116.2.1)
  7. [Refund of Fees Procedure](https://policies.rmit.edu.au/document/view.php?id=118)
  8. [Remission and Removal of Debt Procedure](https://policies.rmit.edu.au/document/view.php?id=117)
  9. [Enrolment Instruction – Officers of the Student Union](https://policies.rmit.edu.au/document/view.php?id=167)
  10. [Enrolment Instruction – Death of a Student](https://policies.rmit.edu.au/document/view.php?id=166)
  11. [Enrolment Instruction - Managing a Missing Student](https://policies.rmit.edu.au/document/view.php?id=165.1.1)
  12. RMIT Training (including RMIT English Worldwide) 
    1. [REW Enrolment and Enrolment Variation Procedure](https://policies.rmit.edu.au/download.php?id=221&version=3&associated)
    2. [REW Refund and Transfer of Fees Procedure](https://policies.rmit.edu.au/download.php?id=234&version=4&associated)
    3. [REW Refund and Transfer of Fees Instruction](https://policies.rmit.edu.au/download.php?id=233&version=2&associated)
    4. [RMIT Training Student Attendance Instruction](https://policies.rmit.edu.au/download.php?id=222&version=2&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=4#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Student visa | Refers to a visa issued by the Department of Home Affairs, Australia, that has study entitlements and is subject to Education Services for Overseas Students (ESOS) requirements. Other visa types may have study entitlements but are not subject to ESOS.  
---|---  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
