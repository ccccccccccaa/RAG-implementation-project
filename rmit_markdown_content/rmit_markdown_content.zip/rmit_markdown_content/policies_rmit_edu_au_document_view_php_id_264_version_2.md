[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=264&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=264&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Assessment and Assessment Flexibility - Online Invigilated Examination Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=264)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=264&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=264&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=264&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=264&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=264&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=264&version=2)


# Assessment and Assessment Flexibility - Online Invigilated Examination Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=264&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=264&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=264&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=264&version=2#section4)
  * [Responsibilities ](https://policies.rmit.edu.au/document/view.php?id=264&version=2#major1)
  * [Privacy](https://policies.rmit.edu.au/document/view.php?id=264&version=2#major2)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides the rules for online examinations or assessments that must be invigilated to meet professional accreditation and regulatory requirements. These examinations are only available under exceptional circumstances to students who are unable to attend campus or examination venues for in-person examination, and only for approved courses.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=264&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=264&version=2#document-top)
# Section 3 - Scope
(3)  In addition to assessment requirements outlined in the [Assessment Processes](https://policies.rmit.edu.au/document/view.php?id=38), this procedure provides the rules for online examinations:
  1. that must be invigilated to meet professional accreditation or regulatory requirements, and
  2. that are offered as an exception when a student is unable to attend in-person on campus or the examination venue due to circumstances outside their control.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=264&version=2#document-top)
# Section 4 - Procedure
(4)  Online invigilated examinations may be made available to students who, due to circumstances outside their control, are unable to attend in-person examinations that fulfil a mandatory accreditation requirement.
(5)  Online invigilated examinations or assessments reproduce in-person examination conditions by:
  1. preventing access to unauthorised information
  2. authenticating student identity, and
  3. providing the opportunity to monitor and analyse student behaviour during examinations and retrospectively as required, via real-time and recorded invigilation.


(6)  When approved for an online invigilated examination students are advised that:
  1. they are required to follow all rules provided to them
  2. they are required to show invigilators their examination space and their student ID
  3. they must enable the required software, i.e. lockdown browser
  4. they must permit sharing of the computer desktop if requested, and
  5. the entire examination will be recorded and the recording stored for 12 months for the purpose of reviewing the examination should concerns be raised about a potential breach of academic integrity.


(7)  Students are required to participate in a practice, familiarisation examination or simulation to test the reliability and quality of required software, internet connectivity and equipment suitability and set-up prior to the official examination.
  1. Practice or familiarisation examinations must provide examples of the methods of asking and responding to questions (e.g. multiple choice, short answer) so students are able to practice with the types of questions they will be asked.
  2. Practice examinations or tests do not need to replicate the length of the formal exam, do not need to be related to course content and are not considered a formal assessment item that will contribute to a student’s final grade.


(8)  Online invigilated examinations are scheduled for the same time and duration as in-person instances of the examination.
  1. Supplementary or deferred examinations are scheduled during the appropriate examination periods and will be the same duration as in-person instances of the examinations.


(9)  Recordings of online invigilated exams will continue during any interruptions in the examination environment, including students leaving to attend bathroom breaks or to facilitate equitable learning plans, and may be reviewed to assess whether there has been a potential breach of academic integrity.
(10)  RMIT undertakes preventative action to mitigate foreseeable risks to academic integrity and to prevent reoccurrences of breaches in online invigilated examinations.
(11)  Potential breaches of academic integrity are managed in accordance with the [Academic Integrity Policy](https://policies.rmit.edu.au/document/view.php?id=168) and [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) as appropriate.
#### Identity Verification
(12)  Students are required to use their RMIT student card to verify their identity. If a student does not have access to their student card, they may provide approved formal photographic identification such as a drivers licence or passport.
(13)  Appropriate arrangements are made to verify a student’s identity in a manner that is respectful of any religious or cultural requirements.
(14)  Headwear or covering must not be worn in an examination unless required for medical reasons or religious observance.
#### Assessment Flexibility 
(15)  Students experiencing extenuating circumstances or who have specific needs are appropriately supported and can seek assessment arrangements and equitable learning plans in accordance with the [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7).
(16)  Requests to re-sit or vary the time or date of an online examination due to exceptional circumstances will only be granted by [Special Consideration](https://policies.rmit.edu.au/download.php?id=170&version=1&associated) or provisions made through a student’s approved Equitable Learning Plan (ELP).
(17)  Students who fail to ensure system requirements are met before the examination will not be granted additional time, special consideration or a deferred assessment if problems which could have been identified through a practice online examination arise during the examination.
### Responsibilities 
(18)  Students sitting an online invigilated exam are responsible for preparing for examination conditions by:
  1. confirming they have access to suitable computer equipment and software that is tested and ready for use, including fully charged batteries or access to power cables as required, stable internet connection, and an operational webcam and microphone
  2. reviewing and understanding examination instructions, rules and requirements prior to the examination
  3. understanding the requirement to use the webcam and microphone if and as requested
  4. ensuring they have prepared to sit their examination in the correct time zone
  5. ensuring they have the correct access (i.e. URL) to the examination
  6. arranging a quiet, private, well-lit space that will not be interrupted and is appropriate to examination conditions
  7. clearing work area of all non-permitted items
  8. ensuring all non-permitted software is shut down
  9. being appropriately attired as though attending an in-person examination 
  10. logging in at least 20 minutes prior to the published start time to complete identity verification or the time nominated in examination instructions
  11. having approved photographic identification readily accessible
  12. following all instructions of the invigilator, and
  13. monitoring the time remaining in the examination.


(19)  Course coordinators are responsible for:
  1. ensuring that students who are approved to sit an online invigilated exams are informed of all technical and system requirements
  2. providing instructions for the conduct of an online invigilated examination, including instructions for action to take in the event of issues arising during the examination
  3. having contingencies in place in the case of technical issues experienced by invigilators.


(20)  Course coordinators must be contactable during an exam or have a suitable nominee in place to assist with issues as they arise.
(21)  Associate Deputy Vice-Chancellor Learning and Teaching (or equivalent) are responsible for:
  1. confirmation that professional accreditation bodies require invigilated examinations for a course, and
  2. approving courses that may provide online invigilated examinations to meet accreditation or regulatory requirements for students who are unable to attend these examinations in-person.


### Privacy
(22)  Students are advised before sitting an online invigilated examination that they will be monitored and recorded during the examination and the recording will be held for up to 12 months for review if required.
(23)  Only authorised staff have access to recordings and these staff are only authorised to access recordings for the purpose of investigating potential breaches of academic integrity.
(24)  All online invigilated examination recordings are stored securely and entirely within RMIT information technology infrastructure.
(25)  The collection, accuracy, use, storage, disclosure, retention and disposal of students’ personal information and recordings will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and local regulations as appropriate
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
