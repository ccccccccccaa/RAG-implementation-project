[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=194#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=194#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Elections Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=194)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=194)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=194)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=194)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=194)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=194)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=194)


# Elections Regulations
Hide Navigation
  * [Part A - Preliminary](https://policies.rmit.edu.au/document/view.php?id=194#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=194#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=194#minor2)
  * [3. Definitions](https://policies.rmit.edu.au/document/view.php?id=194#minor3)
  * [4. Scope of These Regulations](https://policies.rmit.edu.au/document/view.php?id=194#minor4)
  * [Part B - Administration of Elections](https://policies.rmit.edu.au/document/view.php?id=194#part2)
  * [Division 1 – Electoral Roll](https://policies.rmit.edu.au/document/view.php?id=194#major1)
  * [5. Returning Officer to Keep Electoral Roll](https://policies.rmit.edu.au/document/view.php?id=194#minor5)
  * [6. Electoral Roll](https://policies.rmit.edu.au/document/view.php?id=194#minor6)
  * [7. Application to Be Included on the Electoral Roll](https://policies.rmit.edu.au/document/view.php?id=194#minor7)
  * [Division 2 – Retention of Documents](https://policies.rmit.edu.au/document/view.php?id=194#major2)
  * [8. Returning Officer to Retain Documents](https://policies.rmit.edu.au/document/view.php?id=194#minor8)
  * [Part C - Entitlement to Participate in Elections](https://policies.rmit.edu.au/document/view.php?id=194#part3)
  * [9. Entitlement to vote](https://policies.rmit.edu.au/document/view.php?id=194#minor9)
  * [10. Entitlement to Be Nominated for Election](https://policies.rmit.edu.au/document/view.php?id=194#minor10)
  * [Part D - Conduct of Elections](https://policies.rmit.edu.au/document/view.php?id=194#part4)
  * [Division 1 – Nomination of Candidates](https://policies.rmit.edu.au/document/view.php?id=194#major3)
  * [11. Nomination of Candidates](https://policies.rmit.edu.au/document/view.php?id=194#minor11)
  * [Division 2 – Procedure Where There Is No Contest](https://policies.rmit.edu.au/document/view.php?id=194#major4)
  * [12. Unopposed Candidates](https://policies.rmit.edu.au/document/view.php?id=194#minor12)
  * [13. Insufficient Candidates](https://policies.rmit.edu.au/document/view.php?id=194#minor13)
  * [Division 3 – Procedure Where There Is a Contest](https://policies.rmit.edu.au/document/view.php?id=194#major5)
  * [14. Election if More Candidates Than Vacancies](https://policies.rmit.edu.au/document/view.php?id=194#minor14)
  * [15. Notice of Ballot](https://policies.rmit.edu.au/document/view.php?id=194#minor15)
  * [16. Voting Procedure](https://policies.rmit.edu.au/document/view.php?id=194#minor16)
  * [Division 4 – Counting Ballots](https://policies.rmit.edu.au/document/view.php?id=194#major6)
  * [17. Counting Votes](https://policies.rmit.edu.au/document/view.php?id=194#minor17)
  * [18. Votes Received Late Not to Be Counted](https://policies.rmit.edu.au/document/view.php?id=194#minor18)
  * [19. Scrutineers](https://policies.rmit.edu.au/document/view.php?id=194#minor19)
  * [20. Invalid Votes](https://policies.rmit.edu.au/document/view.php?id=194#minor20)
  * [21. Determining the Validity of Votes](https://policies.rmit.edu.au/document/view.php?id=194#minor21)
  * [Part E - Determining the Results of an Election](https://policies.rmit.edu.au/document/view.php?id=194#part5)
  * [22. Where One Candidate Is to Be Elected](https://policies.rmit.edu.au/document/view.php?id=194#minor22)
  * [23. Where Two or More Candidates Are to Be Elected](https://policies.rmit.edu.au/document/view.php?id=194#minor23)
  * [Part F - Disseminating Results](https://policies.rmit.edu.au/document/view.php?id=194#part6)
  * [Part G - Casual Vacancies](https://policies.rmit.edu.au/document/view.php?id=194#part7)
  * [25. Filling Vacancies](https://policies.rmit.edu.au/document/view.php?id=194#minor24)
  * [Part H - Miscellaneous](https://policies.rmit.edu.au/document/view.php?id=194#part8)
  * [Division 1 – Misconduct](https://policies.rmit.edu.au/document/view.php?id=194#major7)
  * [26. Misconduct](https://policies.rmit.edu.au/document/view.php?id=194#minor25)
  * [Division 2 – Validity of elections](https://policies.rmit.edu.au/document/view.php?id=194#major8)
  * [27. Validity of election](https://policies.rmit.edu.au/document/view.php?id=194#minor26)
  * [Division 3 – Campaigning](https://policies.rmit.edu.au/document/view.php?id=194#major9)
  * [28. Campaigning](https://policies.rmit.edu.au/document/view.php?id=194#minor27)
  * [Division 4 – Revocation](https://policies.rmit.edu.au/document/view.php?id=194#major10)
  * [29. Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=194#minor28)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - Preliminary
#### 1. Purpose
(1)  The purpose of these Regulations is to make provision for elections conducted by or on behalf of the University.
#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
#### 3. Definitions
(3)  In these Regulations:
  1. ballot period means the period during which persons may vote at an election.
  2. election documents means completed nomination forms, ballot documents, entries or data, electoral rolls and other records relating to an election, in hard copy or electronic format.
  3. remaining candidate means a candidate not already elected or excluded from the count.
  4. retention period means the period expiring on the last of the three dates referred to in clause (11).
  5. statutory election means an election which the Vice-Chancellor or University Secretary has determined is an election to which these Regulations and Part 9 of the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) applies.


#### 4. Scope of These Regulations
(4)  These Regulations apply to a statutory election.
(5)  A determination by the Vice-Chancellor or University Secretary may apply to specified elections or elections for membership of a specified body.
## Part B - Administration of Elections
### Division 1 – Electoral Roll
#### 5. Returning Officer to Keep Electoral Roll
(6)  The returning officer compiles electoral rolls for the purposes of elections conducted under these Regulations.
(7)  Electoral rolls may categorise voters according to voter eligibility requirements of elections to be conducted under these Regulations.
#### 6. Electoral Roll
(8)  An electoral roll contains, in respect of each person entitled to be on that roll:
  1. the person’s name, and
  2. any further information about the person which the returning officer considers to be appropriate to identify the person or to determine the person’s eligibility to vote or nominate in an election.


#### 7. Application to Be Included on the Electoral Roll
(9)  A person may apply to the returning officer to be included on an electoral roll if:
  1. his or her name is not on the electoral roll, and
  2. the person believes that he or she is entitled to be included on the electoral roll.


(10)  If the returning officer is satisfied that the person is entitled to be included on the electoral roll, the returning officer must enter the person’s name on the electoral roll.
### Division 2 – Retention of Documents
#### 8. Returning Officer to Retain Documents
(11)  The returning officer retains election documents until the later of:
  1. three (3) months after the date of the election
  2. if a dispute relating to the conduct or result of the election has arisen, three (3) months after the resolution of the dispute or the date on which the duly elected candidate commences his or her term, whichever is the later, and
  3. the expiry of any applicable retention period applying to public records under the Public Records Act 1973.


(12)  The returning officer ensures that at the end of the retention period, election documents are dealt with in accordance with the relevant policies and procedures.
## Part C - Entitlement to Participate in Elections
#### 9. Entitlement to vote
(13)  A person is entitled to vote at an election if, at the time of voting, the person’s name is on the relevant electoral roll.
(14)  A person is entitled to vote in all categories in which they are eligible for any election.
Example 1 A person is enrolled as both a postgraduate student and an undergraduate student. The person may vote in both categories.
Example 2 A person is enrolled as student and is a staff member of the University. The person may vote in both categories.
#### 10. Entitlement to Be Nominated for Election
(1) A person is entitled to be nominated for election if the person’s name is on the relevant electoral roll.
## Part D - Conduct of Elections
### Division 1 – Nomination of Candidates
#### 11. Nomination of Candidates
(15)  The returning officer calls for nominations of candidates from the relevant electorate not less than two (2) weeks before the first day of a ballot period.
(16)  A call for nominations:
  1. is in a form determined by the returning officer, and
  2. specifies a date, being not less than one (1) week before the first day of the ballot period, by which nominations are to be received by the returning officer.


(17)  In determining the method of calling for nominations the returning officer takes into consideration the objective of ensuring that the call comes to the attention of the relevant electorate.
### Division 2 – Procedure Where There Is No Contest
#### 12. Unopposed Candidates
(18)  If the number of eligible candidates nominated for election to a body in a particular category does not exceed the number of vacancies in that category, the returning officer declares those candidates duly elected.
#### 13. Insufficient Candidates
(19)  This regulation 13 applies:
  1. to all of the vacancies if: 
    1. no candidates are nominated for election to a body in a particular category, or
    2. all candidates nominated for election to a vacancy withdraw before being elected, or
  2. to the number of vacancies which are not filled if: 
    1. the number of candidates nominated for election to a body in a particular category is less than the number of vacancies, or
    2. a candidate nominated for election to a vacancy withdraws before being elected, resulting in the number of remaining candidates being less than the number of vacancies.


(20)  Where clause (19) or clause (43)b. or c. applies, the returning officer notifies the relevant member of the University staff of the vacancy and of the requirements of this regulation.
(21)  A member of University staff who has received a notification under clause (20) advises the chair of the body who must appoint suitable persons to fill the vacancies.
(22)  A person appointed under clause (21) must have the like qualifications (if any) that would have made the person eligible to nominate in the election.
(23)  Notwithstanding clause (21), it is not obligatory to appoint a person to fill a vacancy if:
  1. there is no suitable person willing or available to be appointed to fill the vacancy, or
  2. for the purpose of clause (43)b. or c. the casual vacancy occurs within six (6) months before the expiry of the term of office.


### Division 3 – Procedure Where There Is a Contest
#### 14. Election if More Candidates Than Vacancies
(24)  If the number of candidates nominated for election to a body in a particular category exceeds the number of vacancies, the returning officer conducts a ballot in accordance with these Regulations.
#### 15. Notice of Ballot
(25)  The returning officer publishes a notice of ballot not less than one (1) week before the final day of the ballot period.
(26)  In determining the method of notification the returning officer takes into consideration the objective of ensuring that the notice comes to the attention of the relevant electorate.
(27)  A notice of ballot must specify the ballot closing time.
#### 16. Voting Procedure
(28)  Votes may be cast and recorded in a manner determined by the returning officer.
Note This provision allows the returning officer to determine that voting will be by paper or online or using any other system or method and may include postal or other forms of voting.
(29)  The manner for conducting elections under these Regulations is included in the notice of ballot under regulation 15.
(30)  Elections are determined by the optional preferential and proportional representation systems of voting as the election requires under Part E of these Regulations.
### Division 4 – Counting Ballots
#### 17. Counting Votes
(31)  After the ballot closing time, the returning officer:
  1. a) examines all votes cast
  2. b) determines whether any votes are invalid, and
  3. c) counts the valid votes in accordance with these Regulations.


#### 18. Votes Received Late Not to Be Counted
(32)  Except as provided in these Regulations, votes received after the ballot closing time are not counted.
(33)  If the Vice-Chancellor and the returning officer are of the opinion that voting has been affected by an Act of God or industrial action, they may direct that votes received after a time specified by them, being not later than 5.00pm one (1) week after the last day of the ballot period, be examined and counted.
#### 19. Scrutineers
(34)  Subject to confidentiality restrictions as determined by the returning officer, a person nominated by a candidate in an election may review the result of the election.
(35)  A scrutineer must not be a contesting candidate.
#### 20. Invalid Votes
(36)  A vote is invalid if:
  1. the vote has been cast in a manner other than as specified in these Regulations or the instructions given by the returning officer
  2. the person who voted is not eligible to vote at the election, or
  3. a person voted more than once in a category.


#### 21. Determining the Validity of Votes
(37)  Notwithstanding regulation 20 the returning officer may determine a vote is valid if in the opinion of the returning officer it is fair and reasonable to do so.
(38)  The returning officer’s decision that a vote is invalid is final.
## Part E - Determining the Results of an Election
#### 22. Where One Candidate Is to Be Elected
(39)  If only one (1) candidate is to be elected, the voting system is optional preferential:
  1. a voter records their vote on the ballot paper by placing the figure 1 against the name of the candidate for whom they vote as their first preference, and
  2. a voter may place the figures 2, 3, 4 and so on, as the election requires, against the respective names of such other candidates as they may wish, indicating by such numerical sequence the order of preference for all or any of the candidates.


#### 23. Where Two or More Candidates Are to Be Elected
(40)  If two (2) or more candidates are to be elected, the voting system is proportional representation, that is, a voter records their vote on the ballot paper by placing the figure 1 against the name of the candidate for whom they vote as their first preference and the figures 2, 3, 4 and so on for all the candidates listed.
## Part F - Disseminating Results
(41)  After determining the results of an election, the returning officer, by electronic communication, declares the successful candidate or candidates duly elected.
(42)  Upon declaring the successful candidate or candidates, the returning officer will make the distribution of votes for each election available on the RMIT website.
## Part G - Casual Vacancies
#### 25. Filling Vacancies
(43)  Positions filled by a statutory election that becomes vacant before the end of a term of office are filled as follows:
  1. if the position was contested and a ballot was conducted under Part D, Division 3 of these Regulations and the position becomes vacant after the person has been declared elected but before the term of office begins, the candidate with the next highest number of votes is declared elected
  2. if the position was contested and a ballot was conducted under Part D, Division 3 of these Regulations and the position becomes available after the term of office begins, regulations 13(20)-(23) apply, and
  3. if the position was uncontested and the candidate was elected unopposed under Part D, Division 2 of these Regulations, clauses (20) to (23) apply.


(44)  A person elected or appointed under clause (43) is entitled to hold office during the remainder of the term.
## Part H - Miscellaneous
### Division 1 – Misconduct
#### 26. Misconduct
(45)  A person must not, in connection with a University election, record a vote which he or she is not entitled to record.
(46)  It is general misconduct for the purposes of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180) and the relevant enterprise agreement if a person records a vote which he or she is not entitled to record.
### Division 2 – Validity of elections
#### 27. Validity of election
(47)  An election, including the conduct and outcome of an election is valid notwithstanding a procedural irregularity which, in the opinion of the returning officer or the Vice-Chancellor, would not have affected the result.
(48)  In the event of a technical failure, the returning officer, at their discretion may apply an equitable remedy, including, but not limited to, extending the ballot closing time. The application of an equitable remedy does not affect the validity of an election.
### Division 3 – Campaigning
#### 28. Campaigning
(49)  Candidates must ensure their conduct throughout the elections process accords with the law, the University legislation, the RMIT Code of Conduct and the relevant policies and procedures.
### Division 4 – Revocation
#### 29. Revocation of Regulations
(50)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 9.1.1 Elections.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
