[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=153&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=153&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Managing Conduct Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=153)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=153&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=153&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=153&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=153&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=153&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=153&version=1)


# Managing Conduct Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=153&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=153&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=153&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=153&version=1#section4)
  * [Application](https://policies.rmit.edu.au/document/view.php?id=153&version=1#major1)
  * [Standards for Handling Reports and Complaints About Conduct](https://policies.rmit.edu.au/document/view.php?id=153&version=1#major2)
  * [Assessing a Report or Complaint](https://policies.rmit.edu.au/document/view.php?id=153&version=1#major3)
  * [Responding to a Report or a Complaint](https://policies.rmit.edu.au/document/view.php?id=153&version=1#major4)
  * [Workplace Investigation](https://policies.rmit.edu.au/document/view.php?id=153&version=1#major5)
  * [Privacy and Confidentiality](https://policies.rmit.edu.au/document/view.php?id=153&version=1#major6)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=153&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=153&version=1#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure details how RMIT University, RMIT University Pathways (RMIT UP) and RMIT Online (RMIT) will manage complaints, reports or concerns relating to misconduct or serious misconduct by staff and others defined in the scope, and includes:
  1. non-disciplinary actions available to help address all issues
  2. the process RMIT will follow when deciding whether a person has engaged in misconduct
  3. disciplinary actions available if misconduct has occurred. 


(2)  RMIT’s approach to misconduct matters is designed to ensure the facts in question are adequately understood before determining outcomes, and that all parties have an opportunity to be heard and supported.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=1#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=1#document-top)
# Section 3 - Scope
(4)  This procedure applies to all:
  1. RMIT employees, researchers and contractors
  2. volunteers and honorary/visiting affiliates
  3. other personnel that are involved in RMIT operations and activities (collectively referred to in this procedure as worker and associate).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=1#document-top)
# Section 4 - Procedure
### Application
(5)  This procedure can be used to address any suspected, reported or known forms of misconduct or serious misconduct which occurs in connection with RMIT or the workplace.
(6)  In some instances, another appropriate RMIT procedure or process may be followed as an alternative. This includes:
  1. a process for addressing staff conduct in an applicable enterprise agreement
  2. an RMIT procedure for managing staff underperformance where the conduct in question might be dealt with as either underperformance and/or misconduct.


(7)  Where matters are to be addressed under more than one procedure or process, RMIT must determine a fair and sensible order for events to proceed. Other matters which might reasonably overlap with this procedure include complaints or reports within the scope of the:
  1. [Student and Student-Related Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=34);
  2. [Student Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=106);
  3. [Third-Party Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=111);
  4. [Whistleblower Procedure](https://policies.rmit.edu.au/document/view.php?id=48);
  5. [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28); or
  6. a complaint or report being managed by an external agency.


### Standards for Handling Reports and Complaints About Conduct
(8)  Reports or complaints related to staff conduct must follow the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110).
(9)  People provides resources on how to:
  1. make a complaint or report about workers' and associates' conduct
  2. advise a person who has made a report or parties involved in the report or complaint, of their rights and expectations in the management of the report or complaint.


(10)  Expectations include, but are not limited to, providing persons who have made a report or a complaint and persons who are the subject of the report or complaint:
  1. regular updates on progress and reasons for any lengthy delays;
  2. full details of the report or complaint (where appropriate and lawful) and adequate time to respond in a considered manner;
  3. information to understand the grounds for any decision made with respect to the handling of the matter;
  4. information to persons who have made a report or complaint, or are subject to the report or complaints, about the appropriate appeal or review process at the conclusion of the matter; and
  5. notice that under certain circumstances RMIT may continue to pursue the matter even if: 
    1. a report or complaint is withdrawn
    2. the worker and associate who is the subject of the report or complaint resigns, or their association with RMIT comes to an end.


(11)  Where a person who has made a report or complaint displays unreasonable conduct (as defined in the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110)), People may restrict access to the complaint management services. This may include a decision by the Chief People Officer or delegate to close the report/complaint and decline any further response.
(12)  Where a person making a report or complaint wishes to remain anonymous this may limit the effectiveness of an investigation and impact the outcome. Where possible this will be clearly communicated to the person making the report or complaint.
### Assessing a Report or Complaint
(13)  RMIT will assess issues arising from a report or complaint confidentially, sensitively and as quickly as reasonably possible. Consideration will be given to additional information required to assess the matter and decide upon the most appropriate way to manage the issue.
(14)  If the worker or associate whose conduct is being managed under this procedure ceases employment or their association with RMIT before that process is concluded, the Chief People Officer or their delegate may elect to proceed with an investigation.
  1. In appropriate cases, RMIT may choose to provide the person with the opportunity to comment on the reported conduct and any proposed findings.
  2. RMIT may also hold the report concerning the conduct on file, to be revisited if the person wishes to work, hold an honorary position, or be associated with RMIT in the future.


### Responding to a Report or a Complaint
(15)  RMIT will consider how best to manage the issues arising from the report or complaint having regard to factors such as (but not limited to):
  1. the seriousness of the issues
  2. the wellbeing of the parties
  3. available information
  4. evidence and witnesses provided
  5. any legislative obligations
  6. the age of the complaint
  7. any earlier or related issues
  8. the impact in the workplace
  9. the standards and reputation of RMIT.


(16)  The Safer Community team must be made aware of reports or complaints involving sexual harassment, sexual assault, family violence and child safety.
(17)  RMIT may take interim measures when considering how to manage issues. It may be necessary for a worker or associate to:
  1. work from a different location
  2. work from home
  3. be stood down with pay
  4. temporarily no longer attend campus, campus events or campus club meetings
  5. any other measure appropriate in the circumstances to protect health, safety, assets and reputation.


(18)  A decision to be stood down with pay must be approved by the Chief People Officer or their delegate.
(19)  The Chief People Officer or delegate may decide to manage the issues by taking non-disciplinary actions and/or conducting a workplace investigation followed by further non-disciplinary and/or disciplinary actions. Examples of disciplinary and non-disciplinary actions are provided in [Schedule 1](https://policies.rmit.edu.au/download.php?id=196&version=2&associated).
(20)  The opinion of the person bringing forward the complaint or report will be considered when deciding how to respond. A decision to initiate a workplace investigation followed by possible disciplinary action is made at the sole discretion of the Chief People Officer or their delegate.
(21)  Reports or complaints may be dismissed as an outcome of initial assessment where the conduct issue is unfounded or is unreasonable.
### Workplace Investigation
(22)  The Chief People Officer or their delegate/s will case manage issues that require a workplace investigation and will determine the manner in which it will be conducted.
(23)  Workers and associates who are the subject of a report or complaint concerning misconduct will be notified in writing if a workplace investigation is to occur.
(24)  Where there are concerns about safety and wellbeing, RMIT may take action to remove or isolate workers and associates from the campus or workspace while a workplace investigation is carried out.
(25)  Where RMIT decides to undertake a workplace investigation, this may be conducted by either a suitable representative from People or an external investigator appointed by People (the investigator).
  1. If the matter is referred to an external investigator, this procedure will continue to apply.


(26)  The investigator will follow a procedurally fair process and will decide what allegations are to be tested. As new information is introduced during a workplace investigation the investigator may decide to modify and/or add to the allegations to be tested.
(27)  A Worker and associate member may be directed to attend a workplace investigation meeting to discuss the issues in question, and more than one meeting may be required.
(28)  Workers and Associates are entitled to have a support person present at any meeting which occurs during a workplace investigation. The role of the nominated support person is to provide advice and support wellbeing.
(29)  When attending a meeting the support person must not:
  1. unduly delay or disrupt the process/meeting;
  2. act as a representative or advocate on behalf of the Worker and Associate.


(30)  A support person must not be a person involved in the complaint or report – for example, a possible witness or decision maker.
(31)  An inability to find a suitable support person will not be an acceptable reason to delay the Workplace Investigation process.
(32)  The investigator will provide the relevant manager and/or People with their findings and, where appropriate, their views as to whether any conduct found could be misconduct and/or serious misconduct.
(33)  Persons who have been involved in a workplace investigation as complainants and respondents will be notified of the findings relevant to them and will have an opportunity to understand the conclusions of the investigator.
(34)  A range of possible disciplinary and non-disciplinary actions may result from the findings of a workplace investigation. Relevant managers will make decisions about disciplinary action with appropriate advice and support from People.
(35)  Before any proposed disciplinary action is carried out, the worker and associate will be given an opportunity to respond to the proposed disciplinary action. The decision maker will consider the response before deciding upon the disciplinary action to be taken.
(36)  Any decision to take disciplinary action will not be limited by a requirement for ‘stepped’ outcomes. For example:
  1. termination of employment or contract of engagement might occur as an outcome even if there have been no prior formal warnings
  2. a final written warning may be issued even if there has been no previous written warning.


(37)  The person(s) who made the initial report or complaint will not usually be informed of any disciplinary action imposed.
(38)  People may choose to reopen an investigation into a matter that is closed if new information is presented that the Chief People Officer or delegate considers to be material.
### Privacy and Confidentiality
(39)  All parties and support persons involved in a matter dealt with under this procedure must treat the details, their involvement, the names of other associated parties and all reports, findings, recommendations and actions as private and confidential.
(40)  Limitations apply to privacy and confidentiality:
  1. where risks to health and safety are present;
  2. in matters involving persons under 18 years of age; or
  3. in circumstances where information is otherwise permitted or required to be shared by law.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=1#document-top)
# Section 5 - Schedules
(41)  This procedure includes the following schedule(s):
  1. [Schedule 1 – Examples of Disciplinary and Non-Disciplinary Actions](https://policies.rmit.edu.au/download.php?id=196&version=2&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=153&version=1#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Volunteer |  Includes any person (whether a member of the public or student) undertaking volunteering for RMIT who may have an actual or perceived authority equivalent to a staff member, in relation to the event, activity or undertaking for which they are volunteering. It extends to volunteers of RMIT clubs, such as club officers.  
---|---  
Workplace investigation |  An investigation into allegations of misconduct and/or serious misconduct conducted by an investigator. Disciplinary actions are available following a workplace investigation where allegations of misconduct and/or serious misconduct have been substantiated.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
