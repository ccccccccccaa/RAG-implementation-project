[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=218#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=218#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Gender-Based Violence Prevention and Response Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=218)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=218)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=218)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=218)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=218)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=218)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=218)


# Gender-Based Violence Prevention and Response Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=218#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=218#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=218#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=218#section4)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=218#major1)
  * [Section 5 - Compliance](https://policies.rmit.edu.au/document/view.php?id=218#section5)
  * [Section 6 - Subordinate Policy Documents](https://policies.rmit.edu.au/document/view.php?id=218#section6)
  * [Section 7 - Other Relevant Policies](https://policies.rmit.edu.au/document/view.php?id=218#section7)
  * [Section 8 - Definitions](https://policies.rmit.edu.au/document/view.php?id=218#section8)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The purpose of this policy is to set out the principles underpinning RMIT’s commitment to preventing and responding to gender-based harm and violence, and to outline the responsibilities of members of the RMIT community. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218#document-top)
# Section 2 - Overview
(2)  This policy establishes a framework to support and enable the prevention of and response to gender-based harm and violence at RMIT, reflecting our commitment to creating a safe place for all staff and students where everyone feels included, respected and supported.
(3)  The policy defines key concepts such as consent, gender-based harm, gender-based violence, sexual harm, sexual harassment and sexual assault, disclosure and response. Additional explanations and examples for these terms are set out in the corresponding resources.
(4)  This policy and its corresponding procedures should be read in conjunction with the RMIT policies regarding behavioural standards and conduct listed in Section 7 below. Policies and procedures of relevant third parties may also apply in some circumstances (for example, the policies of industry partners hosting RMIT students on placement).
(5)  RMIT acknowledges that intersectionality can compound the impact of discrimination and that certain groups of people will be more vulnerable to the effects of discrimination and harassment than other groups.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218#document-top)
# Section 3 - Scope
(6)  This policy applies to all members of the RMIT community, including staff, students and associates (RMIT University Council members, representatives, and volunteers) of the RMIT Group. The RMIT Group is RMIT University and its controlled entities – RMIT Europe, RMIT Online, RMIT University Pathways and RMIT Vietnam.
(7)  Third parties are in the scope of this policy where there is a connection with RMIT such as contractors, licensees or lessees, service providers, visitors, international education agents and delivery partners, and partner organisations in Australia or overseas acting for or on behalf of RMIT in relation to RMIT students and staff.
(8)  If gender-based harm and violence is reported outside the scope of this policy, RMIT will provide referrals to appropriate support services.
(9)  The [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) takes precedence over this one to the extent of any inconsistency regarding harm to children.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218#document-top)
# Section 4 - Policy
#### Principles
(10)  Collective commitment: RMIT is committed to leading long-term social and cultural change to prevent gender-based harm and violence, recognising the urgent need for action.
(11)  Zero tolerance: RMIT has zero-tolerance for gender-based harm and violence, supported through leadership accountability, clear policies, and comprehensive education.
(12)  Leadership: RMIT executives oversee the application of this policy, fostering a safe environment and respectful culture, and ensuring continuous improvement of processes to prevent and respond to gender-based harm and violence.
(13)  Confidentiality and privacy: RMIT is committed to protecting the confidentiality and privacy of individuals involved in gender-based harm and violence cases, in accordance with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(14)  Accountability: RMIT prohibits the use of its resources for violence, and prioritises safety with support to encourage those who cause harm to seek support.
(15)  Procedural Fairness: RMIT ensures procedural fairness with impartial and transparent processes where all parties can present their perspectives and evidence reinforcing trust and justice.
(16)  Human Rights: RMIT views all gender-based harm and violence as unacceptable and a violations of human rights.
(17)  Inclusive and intersectional approach: RMIT acknowledges that diverse identity aspects, such as race, age, and socio-economic background, influence the support needed for addressing gender-based harm and violence. RMIT addresses intersectional needs, ensuring tailored support and interventions.
(18)  Trauma-informed: RMIT adopts a rights-based, victim-survivor centred approach, prioritising safety and wellbeing and ensuring victim-survivors' voices and needs guide all support efforts, fostering an environment of compassion and respect.
(19)  Transparency and integrity: RMIT maintains evidence-based policies and procedures aligned to best practices, protecting against victimisation and supporting those who disclose or report harms.
(20)  Preventing harm: RMIT has a dedicated prevention team, [RMIT Prevention and Respect](https://www.rmit.edu.au/about/our-values/respect-rmit), to lead all work associated with the prevention of gender-based harm and violence, sexual harassment and sexual assault, focused on governance, awareness, learning, and innovative projects.
(21)  Dedicated and supportive response: RMIT provides a dedicated response service for students and staff to seek support for gender-based harm and violence, sexual harassment, sexual assault, or any concerning, unwanted, uncomfortable and/or threatening behaviour. 
### Responsibilities
(22)  All members of the RMIT community are required to:
  1. role model accountable and appropriate behaviour in line with the standards outlined in the RMIT [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), and [Staff-Student Personal Relationships Procedure](https://policies.rmit.edu.au/document/view.php?id=258).
  2. promote respectful culture and practice within their sphere of influence.
  3. increase awareness and ensure compliance with relevant policies and procedures.
  4. undertake and complete all mandatory a training and awareness raising to develop skills necessary to support a respectful, safe, and inclusive community.
  5. comply with reporting and record keeping obligations, as required.


(23)  The University Executive is responsible for providing a safe, non-violent, gender equal and inclusive environment for all members of the RMIT community.
(24)  The Chief Operating Officer (COO), is the central authority for the implementation of this policy and ensuring there is a clear reporting line through central committees and executive bodies, and effective management and oversight by senior management.
(25)  Each member of the Vice-Chancellor’s Gender-Based Violence Prevention Advisory Group is accountable for leading the development and implementation of RMIT’s [Addressing Gender-Based Violence Strategic Action Plan 2023-2027](https://www.rmit.edu.au/content/dam/rmit/au/en/about/our-values/respect-rmit/respect-strategic-action-plan.pdf) within their areas of influence.
(26)  Nomination, Renumeration and People Committee regularly examines de-identified data to identify trends and systemic issues and enable RMIT to identify opportunities for improvements and implement changes where required. The Committee provides formal reports and any disciplinary or investigation actions data to the Council.
(27)  Managers at RMIT are responsible for providing opportunities for their teams to receive education and training about the principles in this policy to supplement the mandatory training, and taking prompt action where needed in accordance with the procedures under this policy.
(28)  The Prevention and Respect and the Safer Community teams in Health, Safety and Wellbeing are responsible for delivering RMIT’s [Addressing Gender-Based Violence Strategic Action Plan 2023-2027](https://www.rmit.edu.au/content/dam/rmit/au/en/about/our-values/respect-rmit/respect-strategic-action-plan.pdf).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218#document-top)
# Section 5 - Compliance
(29)  Reports of non-compliance with this policy suite should be made in accordance with the [Compliance Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=50).
(30)  A breach of this policy or corresponding procedures may result in disciplinary action. Depending on the nature and impact of the breach, other actions may also be instigated. Alleged or actual conduct by staff or students that constitutes gender-based harm or violence will be handled in accordance with the Code of Conduct, Workplace Behaviour Policy, or Student Conduct Policy, as applicable.
(31)  This policy supports RMIT’s compliance obligations regarding:
  1. [Charter of Human Rights and Responsibilities Act 2006 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=46)
  2. [Child Wellbeing and Safety Act 2005 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=47)
  3. [Gender Equality Act 2020 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=48)
  4. [Protected Disclosure Act 2012 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=24)[ ](https://policies.rmit.edu.au/directory/summary.php?legislation=24)
  5. [Respect@Work – Changes to the Sex Discrimination Act 1984 and the Australian Human Rights Commission Act 1986](https://policies.rmit.edu.au/download.php?id=501&version=2&associated)
  6. [Department of Foreign Affairs and Trade (DFAT) Preventing Sexual Exploitation, Abuse and Harassment Policy (2019)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.dfat.gov.au%2Finternational-relations%2Fthemes%2Fpreventing-sexual-exploitation-abuse-and-harassment&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326788109%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=Fsi4lqRTZHkPS6j9TfydiFJbSQzsmqEqL%2Bnwpg8Nshw%3D&reserved=0)
  7. [Higher Education Standards Framework (Threshold Standards) 2021](https://policies.rmit.edu.au/directory/summary.php?legislation=44)
  8. [Education Services for Overseas Students (ESOS) Framework](https://www.education.gov.au/esos-framework)
  9. [Occupational Health and Safety Act 2004](https://policies.rmit.edu.au/directory/summary.php?legislation=15)
  10. [Fair Work Act 2009](https://policies.rmit.edu.au/directory/summary.php?legislation=6)
  11. [Victorian Equal Opportunity Act 2010](https://www.legislation.vic.gov.au/in-force/acts/equal-opportunity-act-2010/030).


(32)  This policy supports RMIT’s commitment to adhering to sector best practices and is informed by:
  1. [Australia Human Rights Commission – Guidelines for Complying with the Positive Duty under the Sex Discrimination Act 1984 (Cth) (AHRC)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fhumanrights.gov.au%2Fsites%2Fdefault%2Ffiles%2F2023-08%2FGuidelines%2520for%2520Complying%2520with%2520the%2520Positive%2520Duty%2520%25282023%2529.pdf&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326737813%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=J4%2Fz6iNWVUINphHq8BLui88zRYIZm3N6cOBkSTm21fg%3D&reserved=0)
  2. [National Plan for Addressing Gender-based Violence in Higher Education 2024](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.education.gov.au%2Fesos-framework%2Fnational-code-practice-providers-education-and-training-overseas-students-2018&data=05%7C02%7Cpolicy%40rmit.edu.au%7C5120b51f2ce94b4cb7c308dd41aadf09%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738924326824037%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=kcuSxPPyjtPGxSORAYp%2F2O2ZYuao0zxC1Zg8LjbSo7I%3D&reserved=0)
  3. [Universities Australia Sexual Harm Response Guidelines](https://universitiesaustralia.edu.au/wp-content/uploads/2023/07/UA-2023-008-Sexual-Harm-Response-Guidelines-web-v4.pdf).


Vietnam Specific: 
  1. [The revised Law on Prevention and Combat Against Domestic Violence (2022)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Flawnet.vn%2Fen%2Fvb%2FLaw-13-2022-QH15-prevention-and-combat-against-domestic-violence-86C05.html&data=05%7C02%7Cpolicy%40rmit.edu.au%7C8116c86c053b440a156708dd41b043bb%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738947479717687%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=t0Fq9uGf7Vh4aeD3bj24ZZogktXM6RWVR5FOK%2BI09wY%3D&reserved=0)
  2. [2006 Law on Gender Equity (No.73/2006/QH11 dated 29/11/2006)](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Flawnet.vn%2Fen%2Fvb%2F73-2006-QH11-16594.html&data=05%7C02%7Cpolicy%40rmit.edu.au%7C8116c86c053b440a156708dd41b043bb%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738947479740159%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=XjMr1T7t3WxAWkc%2Fi3zOL8Nb6uRNmjr%2BoxuVHsDNaxk%3D&reserved=0)
  3. [Viet Nam Code of Conduct on Sexual Harassment in the Workplace International Labour Organization](https://aus01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.ilo.org%2Fpublications%2Fviet-nam-code-conduct-sexual-harassment-workplace&data=05%7C02%7Cpolicy%40rmit.edu.au%7C8116c86c053b440a156708dd41b043bb%7Cd1323671cdbe4417b4d4bdb24b51316b%7C0%7C0%7C638738947479750017%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=O1N4XRbTZw2p22v8lNQXsS4yrHgxA2Dop1wQsVf0N3M%3D&reserved=0) - A Code of Conduct paper issued by the Ministry of Labour Invalids and Social Affairs (MOLISA) on preventing sexual harassment.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218#document-top)
# Section 6 - Subordinate Policy Documents
(33)  Refer to the following documents which are established in accordance with this policy:
  1. [Gender-Based Violence Prevention and Response Policy - Schedule 1 - Explanations and Examples](https://policies.rmit.edu.au/document/view.php?id=220)
  2. [Gender-Based Violence Response Procedure - Australia](https://policies.rmit.edu.au/document/view.php?id=219)
  3. [Gender-Based Violence Response Procedure - Vietnam](https://policies.rmit.edu.au/document/view.php?id=248)
  4. [Gender-Based Violence Response Procedure - Schedule 1 - Investigation Process](https://policies.rmit.edu.au/document/view.php?id=331)
  5. [Domestic and Family Violence Procedure - Australia](https://policies.rmit.edu.au/document/view.php?id=259)
  6. [Domestic and Family Violence Procedure - Vietnam](https://policies.rmit.edu.au/document/view.php?id=332)
  7. [Domestic and Family Violence Procedure - Schedule 1 - Explanations and Examples](https://policies.rmit.edu.au/document/view.php?id=261).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218#document-top)
# Section 7 - Other Relevant Policies
(34)  RMIT policy suites regarding behavioural standards and conduct that are relevant to this policy include:
  1. [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)
  2. [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52)
  3. [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122)
  4. [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) and [Child Safe Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249)
  5. [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
  6. [Inclusion, Diversity and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=218#document-top)
# Section 8 - Definitions
Term | Definition  
---|---  
Child | In Australia, an individual under the age of 18 years. In Vietnam, according to Article 1 of the Law on Children, any person below the age of 16. However, RMIT Vietnam has internal guidelines that extend the child safe duty of care to individuals under the age of 18 years.   
Concern | An expression of dissatisfaction with the behaviour of a student or staff member, where a response is not expected.  
Consent | As defined in Section 36 of the Amendment of Crimes Act 1958 (Vic) and Justice Legislation Amendment (Sexual Offences and Other Matters) Act 2022, free and voluntary agreement. Consent cannot be assumed. Consent must be ongoing and mutual. It must be present every time, including for the duration of any sexual act. Consent can be withdrawn at any time. Consent to one act does not mean consent is agreed to in any other act. Consent to an act with one person does not mean consent is agreed to in an act with a different person, or with the same person on a different occasion. A person engaged in a sexual act must reasonably believe that the other person consents to the act. A person’s belief in consent is not reasonable if they did not, within a reasonable time before or at the time of the act, say or do anything to find out whether the other person was consenting. For further information on affirmative consent laws, please check [Justice Legislation Amendment (Sexual Offences and Other Matters) Act 2022](https://content.legislation.vic.gov.au/sites/default/files/2022-09/22-038aa authorised.pdf).  
Disclosure | Where a person first makes known an incident of gender-based or other form of harm to RMIT (e.g., by telling another student or staff member, or by directly telling Safer Community). This may or may not lead to a report being made via the Complaints Governance Policy or another reporting avenue.  
Gender-based violence | Any form of physical or non-physical violence, harassment, abuse or threats based on gender that results in or is likely to result in harm, coercion, control, fear, or deprivation of liberty or autonomy. Violence and harm can be physical, sexual, emotional, psychological, social, cultural, spiritual, financial and technology-facilitated abuse (including image-based abuse), and stalking.  
International delivery partners | Institutions in other countries where RMIT programs are delivered jointly by RMIT and the partner institution.   
Intersectionality | The ways in which different aspects of a person’s identity can explose them to overlapping forms of discrimination and marginalisation. Intersectionality addresses and acknowledges gender, sexual orientation, Indigeneity, race, economic status, ability, or other factors can compound the impact of gender-based violence, resulting in certain groups of people being more vulnerable and/or disproportionally impacted than other groups to the effects of gender-based harm, violence, discrimination and harassment.  
RMIT Group | RMIT University and its controlled entities (RMIT Europe, RMIT Online, RMIT University Pathways, RMIT Vietnam)  
Sexual Assault | Is when: i. a person (A) intentionally touches another person (B) and the touching is sexual ii. person (B) who was touched did not agree or consent to the touching, and iii. person (A) did not reasonably believe that person (B) consented. If person (A) knew that (B) was not consenting, this will be sexual assault; and if person (A) did not believe on reasonable grounds that B was consenting, this will also be sexual assault. For the purposes of this policy, RMIT also includes the following acts defined in the [Crimes Act 1958 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/crimes-act-1958/): (i) rape, (ii) rape by compelling sexual penetration, (iii) sexual assault by compelling sexual touching, (iv) assault (being the non-consensual application of force) with intent to commit a sexual act, and (v) threat to commit a sexual assault or rape. For succinctness, the specific elements of each are not set out separately in this policy. Additional examples of and explanations for sexual harm are set out in Schedule 1 – Explanations and Examples.   
Sexual exploitation and abuse |  Any actual or attempted abuse of a position of vulnerability, differential power, or trust for sexual purposes. It includes profiting monetarily, socially, or politically from sexual exploitation of another. The abuse may be actual or threatened intrusion of a sexual nature, whether by force or under unequal or coercive conditions, and includes but is not limited to sexual assault, sexual harm and sexual harassment. Technology-facilitated sexual exploitation and abuse is the use of technology and new media to facilitate sex-based abuse and harassment. Behaviours can include nonconsensual pornography (“revenge porn”), recorded sexual assaults, deepfakes, sextortion, cyber harassment, cyber dating violence, and cyberstalking. Additional examples of and explanations for sexual harm are set out in [Schedule 1 – Explanations and Examples](https://policies.rmit.edu.au/document/view.php?id=220).  
Sexual harm | Non-consensual behaviour of a sexual nature that causes a person to feel uncomfortable, frightened, distressed, intimidated, or harmed, either physically or psychologically. Sexual harm includes behaviour that also constitutes sexual harassment, sexual assault and rape. Additional examples of and explanations for sexual harm are set out in Schedule 1 – Explanations and Examples.  
Sexual harassment |  When a person: (a) makes an unwelcome sexual advance, or an unwelcome request for sexual favours, or (b) engages in other unwelcome conduct of a sexual nature in relation to a person, in circumstances in which a reasonable person, having regard to all the circumstances, would have anticipated the possibility that the person harassed would be offended, humiliated or intimidated. Additional examples of and explanations for sexual harm are set out in [Schedule 1 – Explanations and Examples](https://policies.rmit.edu.au/document/view.php?id=220).  
Third parties | Any person or entity external or separate to RMIT, including contractors, consultants, volunteers, visiting appointees and visitors as well as members of the public.  
Trauma informed |  A strengths-based framework that applies the core principles of safety, trustworthiness, choice, collaboration for shared decision-making, empowerment and respect for diversity. Trauma-informed services recognise the physiological, emotional, psychological and neurological effects of trauma; minimise the risk of re-traumatisation and promote healing; emphasise physical and emotional safety; and focus on the whole context in which a service is provided – not just on what is provided.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
