[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=175&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=175&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Cultural Collection Asset Guideline: RMIT University Art Collection 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=175)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=175&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=175&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=175&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=175&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=175&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=175&version=1)


# Cultural Collection Asset Guideline: RMIT University Art Collection
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=175&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=175&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=175&version=1#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=175&version=1#section4)
  * [Collection Scope](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major1)
  * [Acquisitions](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major2)
  * [Acquisition Process](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major3)
  * [Collection Storage & Conservation](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major4)
  * [Deaccessioning](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major5)
  * [Access](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major6)
  * [Loans](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major7)
  * [Born Digital and Digital Collections](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major8)
  * [Legal/Ethical Obligations](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major9)
  * [Copyright](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major10)
  * [Privacy](https://policies.rmit.edu.au/document/view.php?id=175&version=1#major11)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This guideline ensures the RMIT University Art Collection, an RMIT cultural asset, is cared for and managed in accordance with the [Cultural Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=74) and the [ICOM Code of Ethics for Museums](https://policies.rmit.edu.au/download.php?id=216&version=1&associated). 
(2)  The RMIT University Art Collection (Collection) is a public collection that acquires, preserves and provides access to modern and contemporary art, reflecting the University’s ideals of excellence in creativity and innovation, for the enrichment of students, educators, academics, historians, researchers, and the wider community.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=175&version=1#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Cultural Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=74).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=175&version=1#document-top)
# Section 3 - Scope
(4)  These guidelines apply to all RMIT University employees and other individuals acting on behalf of the University working within the Collection.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=175&version=1#document-top)
# Section 4 - Guideline
### Collection Scope
#### Collection Themes
(5)  The Collection reflects historical and theoretical trends in modern and contemporary Australian and international art by collecting works that reflect excellence and innovation including:
  1. works by current RMIT University staff, past staff, or alumni with a significant existing artistic practice;
  2. works by significant and emerging Australian artists with a demonstrable connection to the existing collection or history of the University
  3. exceptional works by international artists with a demonstrable connection to the existing collection or history of the University.


#### Historic Period/Time Period
(6)  The Collection collects modern and contemporary art from the 19th century to the present day.
#### Geographic Area/Region
(7)  The geographic focus of the collection is Australia, extending to international art and objects that may provide artistic, historical or geographic context to the existing collection
#### Physical Items to be Collected
(8)  The Collection collects modern and contemporary art, including but not limited to:
  1. traditional visual artistic media, such as painting, drawing, photography, ceramics, sculpture and works on paper
  2. contemporary sound, new media, multi-media and other works in digital and/or reproductive technologies that are innovative
  3. public art, including sculpture, architectonic, interior design, and landscape works for external or internal exhibition on campus, as well as maquettes, models and design drawings for artworks
  4. modern and contemporary decorative arts, craft and works of design with an aesthetic focus, including gold and silversmithing, ceramics, glass, fashion and textiles, hollowware and furniture
  5. historical and biographical archives related to artists in the Collection, or their works.


#### Collection Development
(9)  Priorities for collection development will be identified annually by the Technical Collections Coordinator in collaboration with the Art Collection Advisory Panel.
(10)  Collection priorities will be shared with the Cultural Collections Acquisition Committee (CCAC) at the first CCAC meeting each year.
### Acquisitions
#### Method of Acquisition
(11)  The Collection will acquire items by donation, bequest, purchase or transfer of title.
(12)  The Collection will not accept:
  1. conditional donations.
  2. permanent loans. Extended loans for established periods of time will be negotiated as required (see Loans).


(13)  Items offered to RMIT for the Collection under the Cultural Gifts Program will be assessed in accordance with the Cultural Gifts Program guidelines.
(14)  The Collection will conduct acquisition processes in accordance with the [ICOM Code of Ethics for Museums](https://policies.rmit.edu.au/download.php?id=216&version=1&associated).
(15)  All acquisition proposals will be considered by the CCAC, with final approval resting with the Deputy Vice-Chancellor Design and Social Context (or their approved delegate).
#### Acquisition Criteria
(16)  Proposed acquisitions must meet the following criteria:
  1. Legal Requirements: The Collection will only accept items where the donor/vendor has clear legal title to the item.
  2. Provenance and Documentation: The history of the item must be known and associated documentation and support material can be provided.
  3. Storage: Acceptance of large items (or collections) will be conditional on storage space being available as well as resources required to house them appropriately.


(17)  Proposals will be further assessed according to the following criteria:
  1. Significance: Items that are significant for their historic, aesthetic, scientific/research or social/spiritual value.
  2. Relevance: Items that relate to their collection purpose and collection scope.
  3. Condition, Intactness, Integrity: Items should be in good condition, suitable for research or display and not requiring extensive conservation work or treatment.
  4. Interpretive and Teaching Potential: Items that enhance the interpretation of collection themes or align with the University’s teaching and learning objectives.
  5. Rarity: Rare examples of a particular kind of item.
  6. Representativeness: Excellent representative examples of a particular kind of item.
  7. Duplications: Items that duplicate items already within the collection or elsewhere within RMIT will not be accepted unless they are of superior condition and/or historic value.


### Acquisition Process
#### General
(18)  Any travel costs in excess of $100, associated with assessment or acquiring of a potential collection item, must be approved beforehand by the Collections and Archives Manager.
(19)  No material should be brought onsite without prior approval from the CCAC. In instances of exceptional circumstances approval may be given by the Collections and Archives Manager (or their representative) for early receipt of material.
(20)  In general, material will be considered unavailable for research, teaching and learning purposes until fully processed.
#### Offers of Donation / Transfer
(21)  In general, the first point of contact is the Technical Collections Coordinator. Potential Donors should be referred to the Technical Collections Coordinator.
(22)  Potential donors, in liaison with the Technical Collections Coordinator, may be required to complete an Offer of Donation Form to record the context, history, significance and associations of the material, and will provide any supporting documentation demonstrating provenance. Relevant information will be compiled by the Technical Collections Coordinator in the Acquisition Proposal Form.
(23)  The Technical Collections Coordinator will:
  1. appraise offers of donation against the Collection Scope and Acquisition Criteria, and include this in the Acquisition Proposal Form
  2. ensure the Acquisition Proposal Form is complete and sent to the Manager, Collections and Archives at least two weeks prior to the next CCAC meeting.


(24)  The Manager, Collections and Archives will send proposed acquisitions documentation and meeting agenda to the Acquisitions Committee at least one week prior to meetings.
(25)  The CCAC will recommend the offer of donation be approved or declined.
(26)  Final approval for acquisitions rests with the Deputy Vice-Chancellor Design and Social Context, or their approved delegate.
(27)  On approval of the proposed donation, the donor will be informed of the outcome and required to sign a Deed of Gift assigning legal ownership for the material to the Collection.
(28)  The material will be transferred onsite for inventory, registering (or cataloguing), physical numbering, photographing (or digitisation) and rehousing.
  1. Should any material be brought on site prior to offer assessment and rejected by the Acquisitions Committee, the material will be returned to the donor with an explanatory letter within 30 days.


(29)  If the material for whatever reason is not claimed by the donor or it is not able to be returned, RMIT may treat any such material as uncollected goods according to the [Australian Consumer Law and Fair Trading Act 2012](https://policies.rmit.edu.au/directory/summary.php?legislation=37).
#### Purchases
(30)  The Technical Collections Coordinator will be responsible for all vendor negotiations and, in general, be the first point of contact with them.
(31)  Any member of the Art Collection Advisory Panel may make recommendations for acquisitions by purchase via the Acquisition Proposal Form.
(32)  The Technical Collections Coordinator will ensure:
  1. acquisition proposals are appraised against the Collection Scope and Acquisition Criteria, and
  2. the Acquisition Proposal Form is complete and sent to the Collections and Archive Manager at least two weeks prior to the next CCAC meeting.


(33)  The Collections and Archives Manager will send proposed acquisitions documentation and meeting agenda to the Acquisitions Committee at least one week prior to meetings.
(34)  Items acquired for the Collection by purchase must obtain financial approval from the appropriate delegate.
  1. Should the total price for a purchased collection item exceed the capitalisation threshold of $5000 (including costs incurred in getting the asset to a position of use (e.g. import duties, delivery fees), the Technical Collections Coordinator will inform the Finance in accordance with the [Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=128).


### Collection Storage & Conservation
(35)  The Collection aims to achieve high standards of collection care and storage.
  1. Collection storage areas will be secure, tidy and sealed against the weather.
  2. Access to storage areas will be controlled and monitored by the Technical Collections Coordinator.
  3. Ultra-violet light will be excluded from storage areas.
  4. When storage areas are not in use lights must be turned off.
  5. Preference will be given to conservation quality storage materials.
  6. No material will enter collection stores without first being quarantined.
  7. Storage areas will be regularly cleaned and checked for pests and other problems in accordance with the RMIT Cultural Collections Integrated Pest Management Plan.
  8. Collection items will be allocated a permanent storage location and, when not in immediate use, will be stored there at all times.
  9. Any change of location (including temporary) will be recorded immediately in the collection management system by trained personnel.
  10. Items should not be stored on the floor.
  11. Untrained personnel may not handle, clean, treat or restore collection items without supervision of collection staff.
  12. Researchers will be given guidance on how to appropriately handle specific materials prior to handling collections items and where required PPE will be provided to them.
  13. All professional staff and volunteers handling collection materials will be required to participate in annual refresher training, to be led by collections staff.


### Deaccessioning
#### Criteria for Deaccessioning
(36)  An item may be considered for deaccessioning if:
  1. the item does not meet the collection purpose or scope
  2. the item poses threats to health and safety to the staff and the public
  3. the physical condition of the item is so poor that restoration is not practicable or would compromise its integrity 
    1. items that are damaged beyond reasonable repair and are of no use for study or teaching purposes may be destroyed
  4. the item breaches Aboriginal, Torres Strait Islander or other community group cultural guidelines
  5. the Collection is unable to care adequately for the item because of its particular requirements for storage or conservation
  6. the item is a duplicate that has no added value as part of a series.
  7. the item is of poor quality and lacks aesthetic, historical and/or scientific value for exhibition or study purposes and no longer meets the Acquisition Criteria
  8. the authenticity or attribution of the item is determined to be false or fraudulent, and the fraudulent item lacks sufficient aesthetic, historical and/or research value to warrant retention 
    1. in disposing of a presumed forgery, the Collection shall consider all related legal, curatorial and ethical consequences, and should avoid releasing the item to public auction. 
  9. the Collection’s possession of the item is inconsistent with applicable law or ethical principles, e.g., the item was, or may have been, stolen or illegally exported or imported, or the item may be subject to other legal claims for return or restitution
  10. the item is no longer consistent with the Collection’s mission or collecting goals
  11. a substantiated request for the return of the item to its original owner/donor is received
  12. the work of art lowers the overall quality of representation of an artist or collection area.


#### Deaccessioning Process
(37)  Collections staff will identify and propose material to the CCAC for consideration, with close reference to the criteria stated above.
(38)  Deaccessioning proposals will be presented via the Acquisition Proposal Form and contain:
  1. a brief description of the item and provenance (if known)
  2. acquisition details and legal status
  3. reasons for recommending deaccessioning.


(39)  Where possible and appropriate:
  1. donors, or their legal representative, will be contacted and notified of intent to deaccession
  2. the artist will be contacted and notified of intent to deaccession.


(40)  The item identified for de-accession must be held for a twelve-month ‘cooling off’ period before it is finally disposed, unless it poses an unacceptable hazard to personnel or to other collections, in which case it may be disposed earlier in consultation with RMIT Workplace Health & Safety.
(41)  When deaccessioned, the above details will be recorded on the item’s file and will be available for inspection if required. Accession numbers will not be reallocated to other items.
(42)  Staff, volunteers, committee members and their families are prohibited from purchasing, or otherwise obtaining, any de-accessioned item.
(43)  Any funds realised from the deaccessioning and disposal of an item will be used solely for the benefit of the collection in accordance with the [Guidelines on Deaccessioning of the International Council of Museums](https://policies.rmit.edu.au/download.php?id=217&version=1&associated).
(44)  Where the Collection has decided to dispose by exchange, the agreement for exchange may include provision for payment or receipt of money in addition to the deaccessioned object, in recognition of the difference in value between the objects exchanged.
(45)  Where possible and relevant, the name of the donor or the fund from which a deaccessioned work of art was originally acquired is to be credited to a new acquisition.
#### Disposal Methods
(46)  Approved methods of disposal in priority order are:
  1. return to original donor (unless the item was acquired under the Australian Government’s Cultural Gifts Program)
  2. transfer to a like-minded, relevant, public collecting institution
  3. redistribution within RMIT as an educative/interpretive tool
  4. sale by public auction (unless the item was acquired under the Australian Government’s Cultural Gifts Program)
  5. destruction.


### Access
(47)  Access to the Collection is facilitated in the following ways:
  1. collection holdings will be made accessible via the RMIT website
  2. physical collection items are made available for research purposes by appointment under strict staff supervision
  3. where possible, collections engagement will be enhanced through open storage, exhibition and public programs
  4. the Collection will lend items to other organisations for exhibition. It will not lend to private collectors, students or individuals excepting sub-collections acquired for that express purpose.


### Loans
#### General
(48)  The Collection may:
  1. lend and borrow material to help meet its purpose
  2. end items to other collecting organisations. It will not lend to private collectors, students or individuals.


(49)  The Collection does not accept permanent, long-term or conditional loans.
(50)  Loan forms must specify the agreed insurance coverage to be met by the Borrower. Loans documentation will be managed by the Technical Collections Coordinator.
#### Inward Loans Process
(51)  Inward loans shall only be accepted for specific exhibitions or research and for fixed periods of time.
  1. Inward loans are recorded in the Loans Register.
  2. A representative of both the Collection and the lender will be required to sign an agreed inward loan form. Each party will hold a copy of this agreement.
  3. This form will record conditions of the loan and the period of the loan.


(52)  The Collection agrees to exercise the same care with respect to loans as it does for its own collection.
(53)  Loans shall remain in the possession of the Collection for the time specified on the form.
(54)  The Collection may request to renew loans if required. Documentation recording renewal must be signed by the Collection and the lender.
(55)  The Collection will recognise the asset at current market value at insurance value set by the Lender and agreed to by Central Risk Management.
(56)  The Collection will inform Central Finance Operations of receipt of any loaned item in accordance with the [Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=128).
#### Outward Loans Process
(57)  A formal loan agreement will be signed and retained by both parties, outlining any conditions and the period of the loan.
(58)  A full condition report, handling and display instructions will be prepared by the Technical Collections Coordinator and will accompany the loaned item, to be signed by appropriate representative of the Borrower at indicated intervals.
(59)  The maximum loan period is 12 months. Applications for extension of this period must be made prior to the loan expiry date.
(60)  The Borrower will be required to provide a Certificate of Currency and insurance, environmental and facility reports as requested.
(61)  Loans will remain in the possession of the borrower until returned to the Collection.
(62)  For any item listed on the asset register loaned to an outside institution, the Technical Collections Coordinator will notify Central Finance Operations of the change of location, in accordance with the [Asset Management Procedure](https://policies.rmit.edu.au/document/view.php?id=128).
### Born Digital and Digital Collections
#### Archives and Digitisation
(63)  The Collection acknowledges that digital collections are as important as physical and analogue collections. 
(64)  Decisions on born digital material will be subject to the same acquisition criteria and processes as non-digital items.
(65)  Digital Preservation Process will include the following steps:
  1. Quarantine: Items are checked for viruses and completeness.
  2. Preservation: Items are preserved (normalised, or converted, into open formats)
  3. Storage: Items are deposited for long-term storage in a digital archive.
  4. Back-up: Digital items are regularly backed-up (daily by ITS; monthly to external hard-drive by collections staff).


(66)  Digitisation projects will be guided by the National Library of Australia’s Digitisation Guidelines for Image Capture Standards and the National Archives of Australia’s Technical Specification for Digitising Audio Visual Records. 
#### Digital Art
(67)  All digital art data will be checked for viruses and completeness against lists provided by government agencies before being introduced to RMIT servers, clouds or digital archives.
(68)  Digital artworks will be preserved and stored in the condition they were acquired.
(69)  Efforts will be made at the point of acquisition to clarify and record the University’s right to make back-up copies, emulate, refresh and migrate data in the future, as well as the artist’s intent with regards to obsolescence.
(70)  Where back-up copies exist, they will be deposited for long-term storage in an external hard drive.
(71)  Where appropriate, in order to combat obsolescence, the following measures will be undertaken:
  1. Refreshing: data will be moved to a new storage system without changing file format; this will be undertaken periodically as new technology stabilises.
  2. Emulation: writing or otherwise obtaining programs that allow older software to run on new operating systems.
  3. Migration: altering the format in which data is stored to allow it to be read by new technology without emulation.


(72)  Under no condition will these measures be undertaken without consultation with the artist of their representatives, where possible, or without adherence to the intellectual and moral rights as outlined in section 11.2
(73)  Digital data to which no moral rights or conditions otherwise adhere will be normalised, or converted, into open formats and regularly backed up to cloud and internal servers.
#### Oral Histories
(74)  The Collection will observe the legal, ethical and moral obligations in the recording, transcribing and subsequent use of oral history interviews in accordance with the Oral History Association of Australia’s Guidelines for Ethical Practice as well as the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28).
(75)  An Oral History Agreement must be signed by the person interviewed, which clearly states the purpose and intended uses of the interviews and what copyright provisions apply.
(76)  The Collection aims to have full copyright over any material it collects with regards to oral histories.
(77)  Associated material collected as a result of any interview (e.g. diaries, photographs, etc.) will be subject to the same collection Acquisition Criteria as outlined in this document.
### Legal/Ethical Obligations
(78)  The Collection endorses Article 31 of the [United Nations Declaration on the Rights of Indigenous Peoples](https://policies.rmit.edu.au/download.php?id=211&version=1&associated) which states that Indigenous peoples have the right to maintain, control, protect and develop their cultural heritage, traditional knowledge and traditional cultural expressions.
(79)  The Collection recognises First Nations Peoples' ownership of their Indigenous Cultural and Intellectual Property that may be held in our collections and works proactively with Aboriginal and Torres Strait Islander staff members and communities to provide access to collections. This includes any cultural heritage and knowledge recorded in published works.
(80)  The management and display of collection items and/or documentation pertaining to any Aboriginal and Torres Strait Islander material will comply with the:
  1. Australian Museums and Galleries Association (AMAGA) Indigenous heritage policy First Peoples: Connecting Custodians (2020) (draft),
  2. Aboriginal and Torres Strait Islander Protocols for Libraries, Archives and Information Services (2012),
  3. [Dhumbah Goorowa Reconciliation Plan 2019-2020](https://policies.rmit.edu.au/download.php?id=213&version=1&associated).


(81)  In doing so, the Collection will promote standards of excellence in practice, in accordance with National and State Libraries Australasia National position statement for Aboriginal and Torres Strait Islander library services and collections, with a focus on the following:
  1. The right of Aboriginal and Torres Strait Islander peoples to: 
    1. be informed about collections items that exist relating to them, their culture, language and heritage
    2. determine any use and access provisions for collection items that relate to them, their culture, language, history and perspectives.
    3. request the removal of or limiting of access to content that should not be accessed due to cultural restrictions.
  2. The development of strategies to return usable copies of collection material to cultural owners to support cultural and language maintenance or revitalisation.
  3. Aboriginal and Torres Strait Islander people will be: 
    1. consulted in relation to the catalogue description and classification of collection materials, and opportunities will be made for them to annotate and describe material that relates to themselves and their communities
    2. consulted and involved with all aspects of any interpretation of any collection items that exist relating to them, their culture, language and heritage, whether for exhibition, publication or educational purposes.
  4. Aboriginal and Torres Strait Islander communities consulted about and before any digital content that might be made available online, including websites and social media.
  5. Where materials are accessible, whether online or physically, access will be preceded by a notice advising Aboriginal and Torres Strait Islander people of potentially sensitive or distressing content such as images, sounds and names of deceased persons; images of people who have not yet been identified; and historical images containing nudity.


(82)  These principles will form the basis of an ongoing dialogue between stakeholders and the Collection, and will be periodically reviewed and revised in order to better facilitate understanding, collaboration and organisational goals.
### Copyright
(83)  To the extent permitted by law and to the extent necessary to enable RMIT to exercise its rights, the Collection will uphold all intellectual rights (as defined in Article 2 of the [Convention Establishing the World Intellectual Property Organisation (WIPO Convention) (1967)](https://policies.rmit.edu.au/download.php?id=218&version=1&associated)), and all moral rights, rights of integrity and rights of attribution inherent in an acquisition.
### Privacy
(84)  The Collection will adhere to the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and affirms RMIT’s commitment to privacy and its approach to the responsible handling of personal and sensitive information in all its forms, consistent with relevant legislation.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
