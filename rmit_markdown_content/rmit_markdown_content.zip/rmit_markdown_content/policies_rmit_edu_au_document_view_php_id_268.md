[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=268#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=268#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Open Scholarly Works Dissemination Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=268)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=268)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=268)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=268)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=268)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=268)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=268)


# Open Scholarly Works Dissemination Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=268#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=268#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=268#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=268#section4)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=268#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=268#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets out requirements for the open dissemination and release of RMIT research and educational scholarly works.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=268#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Open Scholarship Policy](https://policies.rmit.edu.au/document/view.php?id=267).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=268#document-top)
# Section 3 - Scope
(3)  This procedure applies to all staff, students, and affiliates, including conjoint, adjunct, emeritus, honorary and visiting appointments of the University and its controlled entities (known as the RMIT Group).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=268#document-top)
# Section 4 - Procedure
#### Indigenous Cultural and Intellectual Property (ICIP)
(4)  Consistent with RMIT's commitment to the significance of [Indigenous Cultural and Intellectual Property](https://www.artslaw.com.au/information-sheet/indigenous-cultural-intellectual-property-icip-aitb/), RMIT educators, researchers and students will:
  1. not disseminate educational and research scholarly works using Indigenous Cultural and Intellectual Property without the approval and involvement of the holders of such Indigenous Cultural and Intellectual Property
  2. acknowledge the source of the Indigenous Cultural and Intellectual Property from which such intellectual property is derived
  3. apply the [AIATSIS Code of Ethics for Aboriginal and Torres Strait Islander Research](https://policies.rmit.edu.au/download.php?id=255&version=2&associated) in their research practice,
  4. seek out appropriate discipline specific codes to ensure Indigenous Cultural and Intellectual Property is respected, protected and recognised.


#### Open Research
(5)  RMIT is committed to the widest possible dissemination of its research output and acknowledges increased visibility and impact afforded by open research. RMIT encourages its researchers to consider making research outputs open, and acknowledges the cultural, social and economic benefit of this.
(6)  Researchers will submit the Author Accepted Manuscript (AAM) of published research output to RMIT’s Institutional Repository as soon as possible post publication, or after the set embargo period, following the relevant instructions on the [Researcher Portal](https://policies.rmit.edu.au/download.php?id=102&version=2&associated). 
(7)  Research outputs may be restricted from open dissemination for an indefinite period due to contractual obligations, commercial or cultural sensitivities by the appropriate delegate.
(8)  By submitting scholarly research publications to RMIT’s Institutional Repository, RMIT authors agree to grant RMIT a perpetual, royalty free, world-wide, non-exclusive licence to store their work, and to make it permanently available in RMIT’s Institutional Repository.
(9)  Subject to any contractual, funding or publisher licence conditions, RMIT researchers should deposit their accepted manuscripts into the University’s Institutional Repository, noting that:
  1. Where contractual, funding or other restrictions prevent the deposit of the scholarly output, bibliographic details of data (metadata) underpinning published research is to be shared via the University’s Institutional Repository.
  2. Where a publisher embargo or other conditions exist that restrict open access, the University Library Repository Team will comply with any embargo or other restrictions before making the manuscript available by open access.
  3. Researchers with Australian Research Council (ARC) or National Health and Medical Research Council (NHMRC) funded or national or international funding must abide by the open access policies of the funder.
  4. Depositing material in the University’s Institutional Repository does not transfer copyright ownership to RMIT. Ownership of remains with the author or publisher as defined within the publisher agreement 


(10)  The University Library will provide, administer, and manage the University’s Institutional Repository. The University Library Repository Team will manage publication restrictions as required, verify access rights, and manage relevant embargo periods.
(11)  The University Institutional Repository accepts traditional and non-traditional research outputs. The following can be deposited:
  1. Research outputs which have been peer-reviewed but do not meet the requirements for ERA-reportable research (e.g. very brief research articles, editorials, textbooks, clinical guides or reference articles).
  2. Non-Traditional Research Outputs (NTROs), which include creative works, performance, recorded/rendered works, curated exhibitions or events, research reports, portfolios. NTROs can also include software, coding, website creation, databases, and commissioned reports of various kinds.
  3. Research data that is information, records, and files that are collected or used during the research process. Including but not limited to laboratory notebooks, field notebooks, primary research data from your experiments, field observations, questionnaires, focus groups and surveys, sound and video recordings, photographs, models, artefacts from an archaeological dig and computer code.
  4. Grey literature which is published, and unpublished literature produced outside of the normal publishing channels but connected to larger research projects. Examples include statistical publications, working papers, conference papers, newsletters, bulletins, brochures, policy, handbooks, discussion papers.
  5. Scholarly outputs that are not peer reviewed but connected to research projects, including technical papers, reports, letters, commentaries, or discussion papers and non-refereed conference 
  6. Higher Degree by Research theses.


(12)  RMIT researchers will ensure the protection of any commercially valuable research output in line with the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23) and any third-party agreements.
#### Open Education
(13)  RMIT encourages academic staff to explore and adopt open education and learning that is inclusive, accessible and equitable by design. This includes:
  1. Implementing open learning design (sharing ideas about curriculum design in a transparent way) 
  2. Releasing their teaching resources, (via an open licence) 
  3. Adopting open pedagogical practices that foster co-creation of knowledge (allowing learners to contribute to the knowledge commons), and
  4. Implementing open assessment practices (such as the use of non-disposable assignments and open collaboration practices).


(14)  RMIT encourages the authorship, creation, and use of open educational resources in programs and courses that foster RMIT graduates who are:
  1. Ethical Global Citizens – Communicating and collaborating with people from diverse backgrounds with a commitment to responsible practice, diversity, inclusion and respect. 
  2. Connected – Establishing connections with relevant professional peer, community, industry and government networks.
  3. Culturally Inclusive - Respectful in recognising the significance of Indigenous Cultural and Intellectual Property, and representative of all cultures as outlined in RMIT’s Diversity and Inclusion Framework and Action Plans, and Principles for Aboriginal and Torres Strait Islander Perspectives in Learning and Teaching. 
  4. Adaptive – Having intellectual agility and skills to develop solutions. Self-awareness and reflection on learning and experiences. 
  5. Digitally Adept – Using a blend of human and digital skills to learn, solve problems, innovate, communicate and collaborate.
  6. Expert – Transferring the depth of knowledge and skills and applying it to their disciplinary expertise in real life contexts. 
  7. Critically engaged - Intellectual independence and judgement to engage critically with information.


(15)  RMIT requires that all users comply with the [Inclusion, Diversity, Equity and Access (IDEA) Framework](https://www.rmit.edu.au/about/our-values/diversity-and-inclusion) as far as is reasonably possible.
(16)  RMIT recommends that open educational resources should be published via an open platform to maximise their discovery and use by others. 
  1. RMIT educators where appropriate are encouraged to release materials produced in the course of teaching under an open licence. This may include (but is not limited to) lectures, lecture notes and material, study guides, assessment materials, images, multi-media presentations, web content, and case studies. It should be noted that: 
    1. Where significant investment has contributed to the creation of an educational resource, RMIT educators will refer to the appropriate delegated authority (Dean) before releasing the educational resource under an open licence. 
    2. Where an educational resource has been created as part of an externally funded activity, contractual conditions of the funding must be considered before releasing the educational resource under an open licence.
    3. Where an education resource contains Indigenous cultural knowledges and perspectives, RMIT educators will ensure the use and release of the resource under an open licence meets [cultural safety obligations and standards](https://wd3.myworkday.com/rmit/learning/course/d5af1562ea320101c8b3b50a48c80000?type=9882927d138b100019b928e75843018d).


(17)  RMIT University supports the use of Creative Commons licensing for the release of open educational resources and recommends the use of Creative Commons Attribution Non-Commercial, Non-commercial licence (CC BY-NC). However, educators are free to choose the license that meets their purposes.
#### Intellectual Property (IP)
(18)  The dissemination and release of intellectual property (including copyright) is governed by RMIT’s [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23). In the open dissemination of research and educational scholarly output, the provisions of the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23) must be applied.
(19)  In the dissemination of research and educational scholarly works, RMIT staff, students and affiliates will ensure they have the necessary rights of ownership to release research and educational scholarly works as open access to the widest possible audience. Consideration must be given to contractual, copyright and licensing issues to ensure:
  1. the author is the copyright holder, or
  2. permission has been obtained from the copyright holder, or
  3. contractual terms allow open access dissemination of the work


(20)  RMIT authors will ensure:
  1. open access release of scholarly works is compliant with the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23)
  2. the open access release does not infringe the intellectual property rights of third parties.
  3. open access release of scholarly works containing Indigenous Cultural Knowledge and Intellectual Property does not infringe the rights of the holders of Indigenous cultural knowledges.


(21)  Under the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23), students own all IP in the works that they create during their studies, which includes material submitted for assessment. Different provisions in the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23) apply to researchers and paid PhD students.
(22)  Where the IP in a resource is created and owned by students, the students as copyright holders can assign an open licence to the work.
(23)  Where RMIT owns the copyright in an educational resource, the moral rights of the creator must be appropriately acknowledged when released under an open licence, and the copyright owner(s), author(s), date and Creative Commons licence applied must be visibly attributed.
(24)  Scholarly works and activities that involve Indigenous Cultural and Intellectual Property and/or its use must be managed in accordance with the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23), and the [AIATSIS Code of Ethics for Aboriginal and Torres Strait Islander Research](https://policies.rmit.edu.au/download.php?id=255&version=2&associated).
(25)  RMIT authors will ensure open access dissemination of scholarly works is compliant with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59). Consent must be obtained for the disclosure of identifiable and sensitive information of persons, including students. RMIT authors are responsible for removing:
  1. identifiable information, including information from which the identity of an individual can be reasonably ascertained (for example, name, address, mobile phone number, email address, photo, voice recording, employment records, student record, medical record, etc.)
  2. sensitive information of individuals that could be used to discriminate against an individual including racial or ethnic origin, sexual preferences or practices, political opinions, membership of a political association, religious beliefs or associations, philosophical beliefs, union membership or criminal record.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=268#document-top)
# Section 5 - Resources
(26)  Refer to the following documents which are established in accordance with this procedure:
  1. [RMIT Indigenous Research Plan (2023-2025)](https://rmiteduau.sharepoint.com/:b:/s/ResearchInnovationHub/EaLalS9oxBpEjlWUPEtDfVkB0M3AVjMqaYOI-T_g7_NQ8g?e=EN6K3w)
  2. [RMIT Education Plan](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub/SitePages/Education-Plan.aspx)
  3. [RMIT Inclusion, Diversity, Equity and Access (IDEA) Framework](https://www.rmit.edu.au/about/our-values/diversity-and-inclusion)
  4. [Cultural safety at RMIT - Workday Learning module](https://wd3.myworkday.com/rmit/learning/course/d5af1562ea320101c8b3b50a48c80000?type=9882927d138b100019b928e75843018d)
  5. Aboriginal and Torres Strait Islander perspectives
  6. [RMIT Indigenous perspectives in the curriculum](https://rmit.libguides.com/aboriginal-and-torres-strait-islander-perspectives/curriculum)
  7. [RMIT Respect for Indigenous Cultures in Australia](https://www.rmit.edu.au/about/our-values/respect-for-australian-indigenous-cultures)
  8. [Indigenous Knowledge IP Hub – IP Australia](https://www.ipaustralia.gov.au/understanding-ip/indigenous-knowledge-ip/how-to-engage-with-indigenous-knowledge)
  9. [Pathways & Protocols: a filmmaker’s guide to working with Indigenous people, culture and concepts – Screen Australia](https://www.screenaustralia.gov.au/about-us/doing-business-with-us/indigenous-content/indigenous-protocols)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=268#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Accepted manuscript | Is a version of a research output that must have been through the peer review process, and must have been accepted for publication, and all proposed changes to it must have been made  
Indigenous Knowledge Authority | Is a traditional knowledge custodian who must be an Aboriginal or Torres Strait Islander person or persons who has a relationship with that traditional knowledge  
Indigenous Cultural and Intellectual Property (ICIP) | Indigenous Cultural and Intellectual Property refers to the rights that Aboriginal and Torres Strait Islander peoples have, and want to have, to protect their Cultural and Intellectual Property. Sometimes the words “Cultural Heritage” are used to mean the same thing. Refer to the [ICIP Information Sheet](https://www.artslaw.com.au/information-sheet/indigenous-cultural-intellectual-property-icip-aitb/) for a full list of the ICIP rights that must be considered in relation to this policy.  
Open dissemination | Is the release of scholarly output without a fee to access it  
Open educational practices | Are teaching practices, techniques and tools that will foster knowledge creation and sharing in an open environment  
Open educational resources | Are teaching practices, techniques and tools that will foster knowledge creation and sharing in an open environment  
Open licence | Is a copyright licence that grants permission for the distribution, access, use, and reuse of a copyright work with limited or no restrictions  
Open pedagogy | Are models of teaching in an open forum that will be characterised by collaboration, sharing and co-creation with students  
Open research practices | Are research practices that will enable and promote collaboration, transparency and reproducibility throughout the entire research lifecycle  
Open scholarly practices | Are a range of educational and research practices through which knowledge and scholarly resources are openly disseminated  
Open scholarship | Is the creation and sharing of knowledge in the educational and research scholarly environment that will encompass openness  
Scholarly educational output | Is any work that is openly published, such as texts, teaching resources, quizzes, images and videos, and other learning materials that can be shared and reused  
Scholarly impact | Is the influence and effect that knowledge and scholarly resources have on the world and will include all aspects of educational and research impact  
Scholarly research output | Is a traditional or non-traditional research output and may include academic journal articles, books, conference papers, exhibitions, presentations, performances, media interviews, theses, research data  
Self-archive | Is a process where an author will deposit a free copy of a scholarly output online to provide open access to it  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
