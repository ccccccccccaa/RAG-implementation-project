[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=13&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=13&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Action and Support Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=13)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=13&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=13&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=13&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=13&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=13&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=13&version=1)


# HDR Action and Support Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=13&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=13&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=13&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=13&version=1#section4)
  * [Candidates Who Need Action and Support for Their Academic Progress](https://policies.rmit.edu.au/document/view.php?id=13&version=1#major1)
  * [Action and Support Management](https://policies.rmit.edu.au/document/view.php?id=13&version=1#major2)
  * [CASP Criteria](https://policies.rmit.edu.au/document/view.php?id=13&version=1#major3)
  * [College Review of CASP Process](https://policies.rmit.edu.au/document/view.php?id=13&version=1#major4)
  * [College Review of Candidate Progress](https://policies.rmit.edu.au/document/view.php?id=13&version=1#major5)
  * [Process for Candidature Termination](https://policies.rmit.edu.au/document/view.php?id=13&version=1#major6)
  * [Appeals Against Termination – Eligibility and Processes](https://policies.rmit.edu.au/document/view.php?id=13&version=1#major7)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=13&version=1#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure sets out the rules and processes for addressing unsatisfactory academic progress by higher degrees by research (HDR) candidates.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=1#document-top)
# Section 3 - Scope
(3)  The procedure applies to all staff responsible for HDR management and supervision and all HDR candidates of the University and its controlled entities (known as the RMIT Group).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=1#document-top)
# Section 4 - Procedure
### Candidates Who Need Action and Support for Their Academic Progress
(4)  Completing an HDR program requires the acquisition and development of advanced knowledge, skills and techniques, alongside precise project management to generate complex outputs within a tight time-frame. While HDR candidates are expected to take the initiative in managing their workload, there will be times when they require additional direction and guidance to support a return to satisfactory progress. The University is committed to ensuring that any action and support required is provided effectively and in a timely manner. This is done through the development and implementation of an HDR Candidate Action and Support Plan (CASP).
(5)  A candidate may request action and support from their senior supervisor and/or Higher Degree by Research Delegated Authority (HDR DA) where they themselves identify a need. This is done by requesting a meeting with their supervisory team and/or HDR DA to discuss their progress. 
(6)  The HDR DA will nominate the candidate for action and support if:
  1. a candidate fails to attend two or more regular supervision meetings without providing evidence of exceptional/compassionate circumstances
  2. there are circumstances beyond the candidate’s control which are impeding their academic progress
  3. there is documented evidence of failure by the candidate to: 
    1. consistently produce work requested for review by their supervisor to the required standard;
    2. complete one or more coursework courses; or
    3. otherwise follow their agreed research plan
  4. the candidate has missed a milestone due date
  5. the candidate has been unable to achieve the requirements of their milestone within four weeks of the due date
  6. the candidate applies for an extension beyond maximum duration of candidature.


(7)  The Associate Deputy Vice-Chancellor, Research Training and Development (ADVC RT&D) will instruct action and support for candidates where the need is identified.
### Action and Support Management
(8)  Nominations or requests for candidate action and support must be made in writing to the HDR DA.
(9)  The HDR DA takes the decision on whether action and support is required unless instructed by the ADVC RT&D.
(10)  Once a requirement for action and support is established, the HDR DA provides written notice within 10 working days to the candidate, supervisors, and the School of Graduate Research (SGR) of a scheduled action and support meeting.
(11)  The meeting’s purpose is to discuss reasons action and support are needed, and to develop a CASP which will outline the action for the candidate and their supervisors, as well as any additional support to be provided, in order to return the candidate to satisfactory progress. 
(12)  Attendees will comprise the HDR DA, who will chair the meeting, the primary senior supervisor and the candidate. The presence of any associate or joint senior supervisor/s is at the Chair’s discretion.
(13)  The candidate may take a support person to the meeting.
(14)  Action and support meetings should be face-to-face, either in person or via video conferencing. 
(15)  The candidate will be provided with a copy of the CASP and is still expected to work with their supervisors to implement the plan by the proposed end date, if the candidate does not:
  1. attend an action and support meeting;
  2. contribute to the development of a CASP; or
  3. sign the CASP within 10 working days of its development.


(16)  A CASP represents the formal record of the meeting and of the University’s commitment to the provision of action and support.
(17)  The HDR DA is responsible for reviewing and endorsing the CASP and may require amendments where appropriate. 
(18)  SGR may provide further advice and guidance regarding the development, implementation and review of a CASP if required.
(19)  The HDR DA must submit the CASP to SGR within five working days of its formalisation.
(20)  CASPs may be monitored and reviewed by SGR, and the ADVC RT&D (or nominee) may:
  1. instruct amendments to be made to the CASP
  2. instruct any remedial action or additional support deemed necessary to uphold academic standards, support HDR progress, and to ensure compliance with University policy.


(21)  At the end of the nominated CASP period, the HDR DA must review the candidate’s progress against the CASP.
(22)  If all the conditions of the CASP have been met, the HDR DA will close the period of action and support by instructing the School administrator to mark the CASP as ‘complete’ on the candidate record.
(23)  Where conditions of the CASP(s) have not been met, or where a candidate has refused to acknowledge a CASP by the end date, the HDR DA must refer the matter to a College representative (College Graduate Research Committee representative or nominee) for review within three working days of the CASP’s expiry date (see section 4). In this case the School administrator marks the CASP as ‘referred’ on the candidate record.
### CASP Criteria
(24)  The duration of a CASP is determined by the HDR DA up to a maximum duration of three months or part-time equivalent. A second, consecutive CASP may be developed of up to the same maximum duration if deemed appropriate by the HDR DA. 
(25)  No more than two consecutive CASPs may be agreed for the same candidate, unless approved by the ADVC RT&D.
(26)  It is important that a full set of documentation from the action and support meeting is developed to ensure the action and commitments agreed by School, supervisors, and candidate are recorded. The CASP documentation must include:
  1. a summary of the candidate’s perspective on barriers to progress
  2. recommendations by the senior supervisor and/or HDR DA for additional support for the candidate which may include, but is not limited to: 
    1. school-based support, such as increased supervisory meetings, regular meetings with the HDR DA and/or supporting an increase in hours per week spent on research
    2. variations to candidature, such as reducing study load, applying for leave of absence (LOA), reviewing the supervisory arrangements and/or applying for an extension beyond maximum (refer to the [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16))
    3. referrals to other RMIT services, such as wellbeing services and/or academic support services
  3. an action plan developed and endorsed by the candidate, their supervisor/s, and the HDR DA which must consist of tasks for the candidate, and the supervisory team where appropriate, that: 
    1. are clear, detailed and specific – the candidate, supervisory team and HDR DA should have the same understanding of each task after reading the action plan
    2. have set deadlines that are achievable within the time frame of the CASP (in the event of any unexpected absence, the action plan should be reviewed and updated to reflect any delays, as appropriate)
    3. include reasonable time for any specific training or access to/provision of facilities required
    4. set tasks and deadlines for the supervisory team, such as providing feedback within set period of time to support the candidate’s return to progress.


### College Review of CASP Process
(27)  Within 10 working days of referral, the College Graduate Research Committee (CGRC) representative or nominee will determine whether the conditions of the CASP have not been met due to:
  1. any failure by the University as represented by the supervisory team, HDR DA, School administration or University services, which has materially affected the candidate’s ability to maintain good progress; or
  2. the candidate’s inability or refusal to complete the actions detailed for them in the CASP; or
  3. a combination of the above.


(28)  This is done through reference to:
  1. all documentation relating to the candidate’s candidature, progress, supervisory meetings and the support provided to the candidate, supplied by the School
  2. any relevant evidence supplied by the SGR.


(29)  The College may also, if required:
  1. interview the HDR DA, supervisory team
  2. conduct a confidential interview with the candidate.


(30)  The College representative will submit to the SGR a report of the audit and a recommendation as to whether the candidate:
  1. should be permitted a further period of action and support
  2. should attend a Research Candidate Progress Committee (RCPC).


(31)  Where a deficit in support provided by the University is identified, the audit report should also include a remediation plan.
(32)  The ADVC RT&D will consider the recommendations from the College audit for approval, and determine subsequent action as needed.
(33)  SGR will monitor implementation of any remediation plan developed following College review.
### College Review of Candidate Progress
(34)  Where the College CASP audit finds that responsibility for not meeting the conditions of the CASP lies with the candidate, the College will convene an RCPC to determine whether the candidature is viable. In this case:
  1. Candidates must be notified of an RCPC via email, and invited to attend, by the Secretary of the RCPC at least 15 working days prior to the meeting. The RCPC Secretary will be an administrator nominated by the College. 
  2. Candidates must be enrolled and are afforded all the entitlements of enrolment during the College Review of Candidate Progress.


(35)  The RCPC will comprise the following members and is convened by the College:
  1. committee Chair (CGRC member or nominee)
  2. School HDR DA
  3. an independent senior academic from another school in the same College, who is registered as a Category 1 supervisor.


(36)  RCPC meetings must be conducted in person or via video conferencing.
(37)  The candidate’s supervisory team is invited to provide evidence at the RCPC. At least one of the candidate’s supervisors must attend in this capacity. 
(38)  The candidate’s supervisors may not be members of the RCPC and must not be present during committee deliberations.
(39)  All documentation relating to the College audit must also be provided to the RCPC.
(40)  Candidates may take one support person to the RCPC.
(41)  Candidates are offered the opportunity to make a written submission to the committee. If they accept, their submission should provide evidence on all relevant issues and special circumstances affecting academic performance. They must also provide grounds to RMIT that clearly define how they will improve their progress so that it can be assessed as ‘satisfactory’. Wherever possible, this written submission must be supported by relevant independent documentation.
(42)  Any written submission is to be provided by the candidate to the Secretary of the RCPC at least five working days prior to the meeting. Late submissions will be accepted at the discretion of the committee chair.
(43)  In the case of a candidate who does not attend the RCPC, or lodge a written submission, the meeting will be held and the committee will make a recommendation based on the evidence available.
(44)  After consideration of all available evidence by the committee, the chair of the RCPC can recommend to the ADVC RT&D:
  1. that there is a valid case for the candidate to be allowed to continue in their program, because there is insufficient evidence of unsatisfactory progress; in this case the candidate is renominated for action and support; or
  2. that the candidature is terminated due to unsatisfactory academic progress.


(45)  The recommendation must be documented on the Research Candidate Progress Committee Outcome form (RCPC Outcome form).
(46)  The RCPC Outcome form and meeting minutes are provided to the candidate, RCPC members, any supervisors who attended the meeting, and the SGR by the RCPC secretary within five working days of the RCPC meeting. SGR is also sent a complete set of the supporting documentation at this time.
(47)  The notification of the final RCPC outcome from the ADVC RT&D, will be provided to the candidate via email within five working days of SGR receiving the recommendation from the RCPC.
### Process for Candidature Termination
(48)  Where an RCPC recommends that the candidature is terminated, and if the ADVC RT&D approves the recommendation, all documentation is forwarded to the Academic Registrar's Group (ARG) for a review of compliance with RMIT policies. The candidate will receive a notification of the outcome via email within 10 working days of ARG receiving the progress documentation from SGR.
  1. If, after review, a termination of candidature decision is found to be non-compliant by ARG, SGR will inform the candidate, School and College that the candidate will require a further period of action and support. A new CASP must then be developed by the School.
  2. If the termination documentation is compliant, ARG will commence the process of cancellation of enrolment and notify the candidate of the intention to cancel enrolment.


### Appeals Against Termination – Eligibility and Processes
(49)  A candidate may appeal against a decision to terminate their candidature which has been based on their having unsatisfactory academic progress to the University Appeals Committee (UAC) via the Academic Registrar. The appeal process detailed in the Assessment, Academic Progress and Appeals Regulations should be followed.
(50)  A candidate may lodge an appeal on the following grounds:
  1. there is evidence of a breach of University legislation, policy or procedure in the handling of the additional support process which has had a meaningful impact on the determination to terminate the candidature; and/or
  2. there is significant new, relevant evidence that was not available at the time of the RCPC meeting.


(51)  Candidates must lodge their appeal application no later than 20 working days from the date the notification of intention to cancel their enrolment is sent to them by the university. This date will be specified in the notification of the intention to cancel enrolment.
(52)  A candidate is entitled to maintain their enrolment during an internal appeal against a decision to terminate their HDR candidature due to unsatisfactory academic progress. The process to initiate enrolment cancellation by ARG will not be undertaken until the candidate is notified of the outcome of the UAC hearing. Candidates will continue to consume candidature during this time.
(53)  Where an international candidate studying in Australia has their candidature terminated for unsatisfactory academic progress, the Academic Registrar will cancel the candidate’s confirmation of enrolment in accordance with the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
(54)  If candidature is terminated, any further enrolment in an HDR program at RMIT can only be achieved by the person re-applying for admission, in accordance with the [Admission and Credit Policy](https://policies.rmit.edu.au/document/view.php?id=6).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=1#document-top)
# Section 5 - Procedures and Resources
(55)  Refer to the following [HDR Forms](https://policies.rmit.edu.au/download.php?id=68&version=2&associated):
  1. Candidate Action and Support Plan (CASP)
  2. Research Candidate Progress Committee (RCPC) Outcome Form


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
