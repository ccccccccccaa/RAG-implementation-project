[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=119#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=119#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Work Integrated Learning Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=119)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=119)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=119)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=119)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=119)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=119)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=119)


# Program and Course Work Integrated Learning Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=119#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=119#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=119#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=119#section4)
  * [Overview](https://policies.rmit.edu.au/document/view.php?id=119#major1)
  * [Program and course requirements](https://policies.rmit.edu.au/document/view.php?id=119#major2)
  * [Program and course guides](https://policies.rmit.edu.au/document/view.php?id=119#major3)
  * [WIL Agreements](https://policies.rmit.edu.au/document/view.php?id=119#major4)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=119#major5)
  * [Changes or cancellation of WIL activities in WIL courses](https://policies.rmit.edu.au/document/view.php?id=119#major6)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=119#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=119#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets the rules for Work Integrated Learning activities.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119#document-top)
# Section 3 - Scope
(3)  This procedure applies to all Work Integrated Learning courses offered by the RMIT Group.
(4)  WIL does not include:
  1. Higher Degrees by Research
  2. apprenticeships and traineeships
  3. guest speakers or lecturers from industry, government, or community
  4. programs and courses delivered by a third-party provider under a partnership agreement
  5. work experience as co-curricular activities, or
  6. any other non-assessed activities.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119#document-top)
# Section 4 - Procedure
### Overview
(5)  Work Integrated Learning (WIL) is an educational approach that uses relevant work-based experiences to allow students to integrate theory with the meaningful practice of work as an intentional and assessed component of the curriculum. Defining elements of this educational approach require that students engage in authentic and meaningful work-related tasks and must involve three stakeholders: the student, RMIT and the workplace/community.
(6)  WIL may encompass a range of models and approaches to learning and assessment with discipline theory, knowledge and skills as an integral part of program and course design.
(7)  WIL provides the opportunity for students to gain professional and/or vocational experience in their chosen field by completing approved activities that, when successfully completed, count towards their program of study.
(8)  The term ‘WIL Coordinator’ is used throughout this document to mean either the WIL practitioner, WIL Coordinator or nominee (these could be an academic, teaching or professional staff member).
(9)  All WIL activities must:
  1. integrate theoretical learning with practical application in professional contexts that engage students in meaningful and consequential learning activities
  2. be integrated throughout the program to enable students to achieve course and program learning outcomes, RMIT Capabilities and vocational education employability skills as they progress through the program
  3. include student preparation, supervision and monitoring of progress and reflective practice or debriefing
  4. be aligned to the requirements of professional registration, accrediting bodies and training package rules (where applicable)
  5. involve the student undertaking authentic assessment in line with RMIT’s [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7)
  6. comply with relevant government legislation and regulations, RMIT policies, procedures and resources
  7. be undertaken in a safe workplace context, whether on campus, off campus, or online.


(10)  Industry engagement in WIL activities is expected to:
  1. involve students interacting with organisations (industry, government and community) through discipline relevant projects and work placements
  2. include continuous feedback from all stakeholders to ensure ongoing evaluation and quality improvements
  3. be negotiated with partner organisations (where relevant) and designed to be safe, accessible, equitable and mutually beneficial for all stakeholders
  4. involve relevant practitioners or partners actively working in industry, community, or government organisations, and, where located in Australia, the partners can provide an actively registered business name or ABN, or other appropriate business or company registration identifier.


(11)  WIL Coordinators must ensure WIL activities will not cause unnecessary or unreasonable hardship for students or partner organisations, outside of the stated WIL requirements in the program guide.
(12)  WIL activities can be offered face-to-face, online or in a blended approach.
### Program and course requirements
(13)  Programs offering WIL must comprise the following minimum number of WIL units, courses, or credit points:
  1. Certificate III, Certificate IV, Diploma, or Advanced Diploma programs other than apprenticeships, traineeships: one unit of competency or WIL activity specified in the program rules
  2. Associate Degree, Graduate Diploma, Masters by Coursework: 12 credit points
  3. Higher Education Diploma: 6 credit points
  4. Bachelor degree, Bachelor honours degree other than one-year (96 credit point) Bachelor honours degree: 24 credit points
  5. double degree comprising Bachelor degrees and/or bachelor honours degrees: 24 credit points. The WIL courses in double degrees must, however, provide the learning outcomes of the core WIL courses of both component single degrees.


(14)  In higher education, designated WIL courses that are core to the program must comprise WIL activities that align with at least 50% of the assessment. It is preferable that the WIL assessment is a hurdle requirement to pass the course. WIL in elective or optional courses do not need to meet the 50% assessment requirement.
(15)  For vocational education and training programs where WIL activities are spread across more than the minimum of units of competency or cluster of units, WIL activities must be appropriately incorporated into the assessment requirements consistent with the training package rules.
(16)  WIL courses may offer different types of WIL at different locations and with different cohorts if these are deemed to be equivalent and to meet course learning outcomes.
(17)  The Programs Committee can approve exemptions from the above requirements of WIL components in higher education programs where:
  1. professional accreditation requirements prevent WIL being offered within the normal program duration
  2. the program is primarily intended as a credit pathway to a higher program that meets the WIL requirements in the previous section
  3. the program is designed to provide a specific skill such as a language proficiency rather than an employability outcome
  4. progressive learning of professional skills requires that WIL placements be distributed as an assessment component weighted at less than 50% in numerous courses, or
  5. in a dual or double degree, requirements for meeting prescribed learning outcomes within a reduced volume of learning prevent WIL experiences being offered.


(18)  Program Managers can approve an alternative to the WIL activity in vocational education and training programs where the:
  1. workplace or project-based WIL activity is not a mandatory requirement of the program or course and there is no requirement for assessment to occur in the workplace
  2. simulated WIL activity is not a mandatory requirement of the program or course and there is no requirement for assessment to occur in a simulated workplace.


### Program and course guides
(19)  The requirements for information relating to WIL in program and course guides are prescribed by the [Program and Course Guide Instruction](https://policies.rmit.edu.au/document/view.php?id=203) and must include the eligibility requirements of both academic prerequisites and non-academic requirements (which may include, but are not limited to immunisations and vaccinations, visas, Working with Children Checks, Police Checks, NDIS Worker Screening Check and responsibilities for associated costs), including those aligned to the requirements of professional registration and accrediting bodies (where applicable).
### WIL Agreements
#### Agreement requirements
(20)  WIL agreements, and any corresponding Student Undertakings or commitments, insurance and other relevant documentation such as roles, rights and responsibilities of all stakeholders are to be completed before commencement of a WIL activity.
(21)  Agreements and any corresponding Student Undertakings, or other documents put into place between students, RMIT and partner organisations may vary according to higher education or vocational education and training contexts, specific discipline requirements, location (online, local, interstate, international or national regulatory requirements) and whether the student will be paid a stipend or scholarship or engaged separately as an employee, or not; or whether RMIT will make any payments to the partner organisation for hosting the student.
(22)  WIL Coordinators must ensure that all parties are adequately prepared and informed in a timely manner about their duties, roles, rights and responsibilities for participating in WIL activities.
(23)  WIL arrangements must be consistent with the guidance available from Fair Work Australia regarding placements for the purposes of credit towards study, as well as work experience and internships. For students on overseas placements, workplace arrangements must comply with local employment and workplace legislation, including safety.
(24)  Ownership and rights regarding intellectual property created through or used as part of the WIL activity must be agreed between the student, RMIT and the partner and documented, before an activity starts. Students must properly understand what they can and cannot do with intellectual property resulting from or provided to them in a WIL activity, as well as confidential information or proprietary material of the partner organisation.
(25)  Any WIL agreements requiring translation must be undertaken by a translation service accredited by the National Accreditation Authority for Translators and Interpreters. The cost of the translation and interpreting services are charged to the relevant school/industry cluster or nominated area.
(26)  Partner organisations may request that RMIT use the partner organisation’s WIL agreement. Any such agreement must be reviewed by RMIT Legal Services prior to signing.
#### Authorisations and signatories
(27)  WIL agreements must be used for all WIL activities (including paid) involving partner organisations (including RMIT), regardless of whether the activity is on campus, off campus or online, and must have the appropriate RMIT approval as set out in the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).
(28)  RMIT staff must not commit RMIT to any additional legal or other obligations or costs without seeking appropriate advice from Legal Services.
(29)  In situations where an overarching WIL agreement or memorandum of understanding is in place establishing a relationship between a partner organisation and RMIT, students must sign a Student Undertaking (also known as a Schedule – Student Undertaking) that acknowledges:
  1. their acceptance and understanding of their roles, rights and responsibilities during WIL activities with that partner organisation, and
  2. the roles, rights and responsibilities of RMIT and the partner organisation.


#### Record management
(30)  RMIT WIL agreement templates, change annexures, the Student Undertakings and information sheets must be accessed from the RMIT staff WIL website to ensure the most up-to-date version is used.
(31)  Completed WIL agreements, change annexures, associated information sheets and Student Undertakings are to be managed by the WIL Coordinator (or delegate).
(32)  Electronic copies of the WIL agreement, Student Undertaking, change annexure, insurance documents and WIL Risk Assessment Checklist must be filed in:
  1. TRIM, for RMIT Vietnam
  2. InPlace, which is the designated WIL data collection system for RMIT Australia and for any other global WIL experiences.


A copy must also be provided to the student and the partner organisation prior to the commencement of the WIL activity. Any physically signed hard copies of these documents must be stored in accordance with the school/industry cluster’s regular records management practice or sent to RMIT Archives.
(33)  The collection of personal information must be undertaken in accordance with the RMIT [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and [Retention and Disposal Standard](https://policies.rmit.edu.au/document/view.php?id=55).
### Responsibilities
#### Eligibility
(34)  College/school/industry cluster WIL teams will complete due diligence and risk assessment related to health, safety and wellbeing when engaging industry or community partners to ensure risks are adequately managed by the partner.
(35)  The relevant WIL Coordinator or Course Coordinator will assess a student’s eligibility to undertake a WIL activity against the requirements prescribed in the program or course guide, including mandatory requirements or applicable acceptance criteria.
(36)  Before any student who is 17 years or younger starts an off-campus WIL activity, the WIL Coordinator or Course Coordinator must ensure supervising staff of the partner organisation (the provider of the placement or activity) supplies proof before the placement begins that supervising staff have current, valid Working with Children Check.
(37)  Students must fulfil all mandatory requirements and meet any applicable acceptance criteria, including those required by a partner organisation, in relation to a WIL activity before commencing the activity. Where a partner organisation or professional body requires students to submit a satisfactory Police Check, Working with Children Check, NDIS Check or other mandated compliance requirement including immunisation, vaccination, licences, and first aid certificates before commencing the WIL activity, and the student does not do this by the timeline communicated by the WIL Coordinator, RMIT may not be able to approve that the student commences the WIL activity. 
(38)  Where a student does not fulfil applicable hurdle assessment or mandatory requirements or meet any applicable acceptance criteria, including those required by a partner organisation, for a WIL activity before commencing the activity, the consequences may include the student:
  1. being unable to complete the relevant course, undertake applicable assessment, or meet other timing or pre-requisites for the course or program, which may delay other course or program activities
  2. receiving a fail (NN) or hurdle fail result (NH) or not yet competent result (NYC) for the course, including if the compliance deadline is after the relevant census date for that course
  3. needing to take other steps, including meeting with the relevant Program Manager, to re-map their studies or program, including re-scheduling where possible.


(39)  Where WIL activities are to be completed overseas, students must be registered in [Student Mobility Management Systems](https://outbound.rmit.edu.au/index.cfm?FuseAction=Abroad.Home) (Mobi) and processed through Global Learning. Refer to the [Travel Instruction - Leading Student Travel](https://policies.rmit.edu.au/document/view.php?id=302).
#### Provision of information
(40)  The WIL Coordinator has a responsibility to ensure students are informed:
  1. of their roles, rights and responsibilities throughout the WIL activity as documented in the WIL agreement and Student Undertaking, as well as the applicable eligibility requirements or pre-conditions such as the provision of proof of immunisations, vaccinations, Police Checks, Working with Children Checks, or where to find out about applicable eligibility requirements
  2. of required conduct and safety policies and procedures on campus, online and at partner organisation workplaces
  3. that if the student decides to end a WIL activity early, to contact their designated RMIT contact as soon as practicable, and
  4. that RMIT student wellbeing, student support and Safer Community services remain available if the student experiences unreasonable or unsafe workplace behaviour or sexual harm during the WIL activity.


(41)  Where applicable, the WIL Coordinator must also ensure:
  1. students are assigned to, and/or are approved for, appropriate WIL activities
  2. reasonable adjustments to WIL activities are made for students with a disability, long-term illness or a mental health condition, where those students have disclosed the need for the adjustments, including by way of an [Equitable Learning Plan](https://www.rmit.edu.au/students/support-services/equitable-learning), and the reasonable adjustment is required for the student to participate in or continue to participate in, or derive or continue to derive, any substantial benefit from the WIL placement.


(42)  The WIL Coordinator has a responsibility to inform partner organisations:
  1. of their roles, responsibilities, and obligations regarding students, including to supervise and monitor student progress if the activity is a placement
  2. that they must provide an induction or orientation for students in relation to applicable policies and procedures in their workplaces, including in relation to safety, if the activity is a placement
  3. that they must immediately notify RMIT of any health, safety or well-being concerns relating to the student
  4. any reasonable adjustments that are required for the student to engage in the WIL activity.


#### Monitoring and supervision
(43)  The WIL Coordinator is responsible for ensuring the ongoing processes for monitoring and supervising student progress throughout the WIL activity are determined before commencement of the activity and documented in the Schedule – Student Undertaking.
(44)  Monitoring, supervising and reporting on the student learning progress and assessment outcomes are the responsibility of both RMIT and the partner organisation.
#### Occupational health and safety
(45)  The WIL Coordinator and partner organisation must ensure potential risk management issues, such as hazards, are identified before commencement of the WIL activity using the appropriate risk assessment document and that risk mitigations are put in place.
(46)  Risk assessments must consider travel arrangements where students are undertaking WIL activities in a rural location, interstate or overseas. Refer to the [Travel Procedure - Student](https://policies.rmit.edu.au/document/view.php?id=108).
(47)  In line with RMIT Health, Safety and Wellbeing processes and [Student Safety Measures Procedure](https://policies.rmit.edu.au/document/view.php?id=173), WIL Coordinators must report all WIL emergencies, critical incidents or identified hazards to the partner organisation supervisor, RMIT Health, Safety and Wellbeing through the relevant online incident reporting system, and the program manager.
#### Students studying in Australia on a student visa
(48)  It is the responsibility of students studying in Australia on a student visa to be aware of their current visa conditions in terms of paid, unpaid or volunteer work and any impact an offshore WIL activity may have on future visa applications.
(49)  Students studying in Australia on a student visa are only permitted to work (which includes paid and unpaid industry placement WIL hours) a maximum number of hours per fortnight while classes are in session unless the work-based training hours have been registered for their program on CRICOS (Commonwealth Register of Institutions and Courses for Overseas Students). Refer to the [Department of Home Affairs](https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/student-500/temporary-relaxation-of-working-hours-for-student-visa-holders) for current number of hours permitted or other conditions.
### Changes or cancellation of WIL activities in WIL courses
(50)  In situations where WIL activities are no longer supported by a partner organisation and must be ended before originally anticipated, the Course Coordinator will use reasonable endeavours to facilitate alternative WIL activities where possible, considering:
  1. lead times for arranging new partner organisations
  2. the requirements of any accrediting bodies
  3. the duration and nature of the activity to be provided, and
  4. assessments required as part of the relevant course or program.


(51)  In the case of WIL activity cancellation by a partner organisation, the affected student should be prioritised for a new activity by the Course Coordinator, where possible, to minimise any impact on the student’s progression in the program. The nature and duration of the activity, the credit points allocated, specific learning outcomes required to be achieved, any corresponding assessments, and therefore any potential substitute activities may affect what alternatives can be provided for an affected student.
(52)  For WIL activities that are still able to continue but have significant changes to mode of delivery, activities, assessment, or any other significant change, the WIL Coordinator must ensure that a change annexure is completed to update the WIL Agreement details, as well as updating data and records in InPlace.
#### Student request to end a WIL activity early
(53)  If a student wants to end their WIL activity early, they must put their request in writing to their WIL Coordinator or Program Manager setting out their reasons for wanting to end it prior to the anticipated end date. The WIL Coordinator or Program Manager:
  1. may seek advice from relevant subject matter experts in considering all the relevant circumstances of the request, including Risk, Safer Community, and ARG, and obtain any additional relevant information to assess the request. In considering a request, the WIL Coordinator or Program Manager should put in place any interim, precautionary or safety measures as appropriate to manage risk, including under the [Student Safety Measures Procedure](https://policies.rmit.edu.au/document/view.php?id=173) or other relevant policies
  2. must provide a response to the student within a reasonable timeframe, setting out whether the activity should continue, stop, or for an alternative activity to be progressed. The decision should consider: 
    1. the nature of the student’s reasons and the activity
    2. accrediting requirements
    3. assessments
    4. consequences for other course and program progression
    5. availability and duration of other activities, and
    6. any other relevant circumstances or requirements, including the application of other relevant policies and procedures.


#### School or industry cluster or partner organisation ending a WIL activity early
(54)  A partner organisation or the relevant school or industry cluster may decide that it can no longer proceed with a student’s WIL activity, or that the activity must be stopped prior to the anticipated end date for a range of reasons. These reasons include, but are not limited to:
  1. the partner’s inability to continue supervision or meet other expectations in the WIL agreement
  2. concerns raised by a student, or
  3. the student's conduct or performance during a WIL activity.


(55)  The relevant school or industry cluster may also decide to end an activity based on information which a partner organisation or a student has provided.
(56)  If the partner organisation decides to end an activity early, the school or industry cluster will seek relevant information from the partner which has informed their decision.
  1. Where a partner or the school or industry cluster ends an activity because of concerns or issues regarding a student’s performance or competency, behaviour, or compliance with their obligations, the school or industry cluster will seek as much relevant information as possible about the circumstances leading to the partner’s decision. Information may include records or a summary of behaviours or performance, any documentation provided to the student by the partner, steps taken by the partner to improve or address concerns such as meetings, additional training or coaching, feedback or other adjustments.
  2. The school or industry cluster will also seek information from the student about the activity, the partner and any other relevant circumstances, such as their own records, accounts or feedback.


(57)  Where the basis for the end of a WIL activity relates to behaviour or conduct of the student which may also constitute misconduct under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), the school or industry cluster will apply the relevant processes under that policy suite, including regarding investigations and the provision of procedural fairness.
(58)  Where the basis for the end of a WIL activity relates to competency or performance, the school or industry cluster will inform the student, and will meet with the student to provide an opportunity for the student to respond, or provide any other relevant information. Unsatisfactory progress (poor performance) and feedback on assessment must be managed in accordance with the [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7).
(59)  In all instances where a WIL activity is ended early the WIL Coordinator, Program Manager and relevant Dean, Head of School or Cluster Director must make a decision about the student’s progress in relation to the WIL course to which the WIL activity corresponds. The decision may be determined:
  1. by the outcome of and consequences following any [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) process
  2. with reference to the circumstances leading to the end of the WIL activity, and the materials and information provided by the partner and the student
  3. by the options which are practically available for progress, such as alternative WIL activities within a relevant teaching period, semester or course term
  4. by considering the learning outcomes, course requirements, program structure, and any other assessment requirements, such as whether the WIL activity is a hurdle requirement for a course, as well as what assessment outcomes or grades (e.g. pass, or NN, NH fail) are applicable. Depending on the course and program structure, and partner availability, it may be necessary for a student to undertake a placement or project in a subsequent teaching period, which also requires the student to re-enrol in the course
  5. by any other relevant facts or circumstances regarding the student, the partner, and the WIL activity.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119#document-top)
# Section 5 - Resources
(60)  Refer to the following documents which are established in accordance with this procedure:
  1. [Program and Course Work Integrated Learning Procedure RACI Matrix](https://policies.rmit.edu.au/download.php?id=444&version=1&associated)
  2. [](https://www.rmit.edu.au/staff/teaching/student-employability/work-integrated-learning)[Work Integrated Learning](https://policies.rmit.edu.au/download.php?id=164&version=3&associated) for staff including InPlace and online resources for WIL Coordinators
  3. [WIL Ready for Staff](https://policies.rmit.edu.au/download.php?id=165&version=1&associated) learning module.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119#document-top)
# Section 6 - Definitions
Term | Definition  
---|---  
Overarching agreement or relationship agreement | The agreement put in place between RMIT and a partner organisation at the commencement of the relationship which is designed to support multiple WIL activities, such as consecutive WIL placements, or WIL projects which involve more than one student.  
Placements |  These activities are generally on-site placements in a workplace or community setting, can be onshore, offshore or online, and may be paid or unpaid. Common terminology for WIL placement activities includes practical placement, practicum, cooperative education, clinical placements, fieldwork and internship.  
Projects | WIL projects are co-designed with industry and/or community partners. Industry engaged projects commonly require teams or individual students to undertake a real project that is based on real problems or addresses needs of industry or community. It may include capstone projects, collaborative research projects, multi-disciplinary projects or work-based projects. Industry partners are engaged in the project and provide feedback to students. Industry engaged WIL projects may be paid or unpaid. They may take place on campus, off campus, offshore or online.  
Simulated workplace environments |  WIL activities in simulated workplace environments may be necessary for ethical, safety or professional reasons or when other forms of industry engaged WIL are unavailable.  These environments are designed to simulate real workplaces in their function, equipment and mode of operation so that students can experience a variety of scenarios and inter-related activities similar to real work experience in the industry or profession to which the program leads. This type of WIL can occur face-to-face or online, on campus or off campus, and is usually unpaid.  
WIL activity | A placement, project or simulated workplace environment providing a work-based experience to allow students to integrate theory with the meaningful practice of work as an intentional and assessed component of the curriculum.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
