[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=197&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=197&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Titles Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=197)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=197&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=197&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=197&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=197&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=197&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=197&version=2)


# Titles Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=197&version=2#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=197&version=2#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=197&version=2#minor2)
  * [3. Definitions](https://policies.rmit.edu.au/document/view.php?id=197&version=2#minor3)
  * [Part B - TITLES](https://policies.rmit.edu.au/document/view.php?id=197&version=2#part2)
  * [4. Appointment](https://policies.rmit.edu.au/document/view.php?id=197&version=2#minor4)


This is not a current document. To view the current version, click the link in the document's navigation bar.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to make provision for conferral of honorary titles on persons who are associated with the University in a substantial way, including persons who are not employed or appointed to established or recurrent positions.
#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No.1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
#### 3. Definitions
(3)  In these Regulations:
  1. Emeritus professor means a person who is retired from academic or employment activity or, in exceptional circumstances, former professor of the University who is not retiring from academia, of significant scholarly and distinguished service to the University.
  2. Honorary professor or honorary associate professor means (i) a retired member of the University’s academic, vocational education or professional staff, or (ii) a retired academic of another university who wishes to continue or develop a significant academic association with the University. In both instances, it is recognised that research may still be conducted but the person should be retired from academic employment/activity.
  3. Adjunct professor, or adjunct associate professor, or adjunct senior fellow, adjunct fellow, or adjunct associate means an academic from another university or institution whose appointment will develop and strengthen scholarly engagement and other research and/or learning and teaching culture, capability and activities within the University.
  4. Adjunct professor of practice, or adjunct industry associate professor, or adjunct senior industry fellow, or adjunct industry fellow, or adjunct industry associate means a non-academic who is an expert in an appropriate field and holds an appropriate and/or corresponding position in industry, business, public sector, professional, clinical or cultural communities. They contribute significantly to the scholarly engagement and either research or learning and teaching culture and activities within the University, and foster partnerships between the University and industry, profession or the wider community. 
  5. Visiting professor or visiting associate professor or visiting senior fellow, or visiting fellow means a member of the academic staff of another educational or research institute, or a member of an industry body who is research active, who is appointed for a limited (specified) time to contribute to the research, learning and teaching, engagement and/or advancement of the University.
  6. Honorary appointee means a person who is conferred an honorary title, established and defined in these Regulations, under the terms and conditions established under the [Honorary Appointments Policy](https://policies.rmit.edu.au/document/view.php?id=101) and procedure.


## Part B - TITLES
#### 4. Appointment
(4)  Subject to the relevant policies and procedures, the University may appoint, on such terms and conditions as it decides:
  1. Emeritus Professors
  2. Honorary Professors
  3. Honorary Associate Professors
  4. Honorary Fellows
  5. Adjunct Professors
  6. Adjunct Associate Professors
  7. Adjunct Senior Fellows
  8. Adjunct Fellows
  9. Adjunct Associates*
  10. Adjunct Professor of Practice
  11. Adjunct Industry Associate Professor
  12. Adjunct Senior Industry Fellow
  13. Adjunct Industry Fellow
  14. Adjunct Industry Associate
  15. Visiting Professors
  16. Visiting Associate Professors
  17. Visiting Senior Fellows
  18. Visiting Fellows


on such terms and conditions as it decides.
* The University may permit ‘Creative’ or ‘Clinical’ to be added in parentheses after the title on such terms and conditions as it decides.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
