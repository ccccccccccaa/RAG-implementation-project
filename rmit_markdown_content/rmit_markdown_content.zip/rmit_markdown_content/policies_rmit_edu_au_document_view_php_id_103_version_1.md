[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=103&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=103&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Sustainability Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=103)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=103&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=103&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=103&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=103&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=103&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=103&version=1)


# Sustainability Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=103&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=103&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=103&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=103&version=1#section4)
  * [Sustainability Principles](https://policies.rmit.edu.au/document/view.php?id=103&version=1#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=103&version=1#major2)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=103&version=1#major3)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=103&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=103&version=1#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  The purpose of this policy is to express RMIT’s commitment to advancing its sustainability ambitions as an organisation that models institution-wide excellence by embedding sustainability principles and practices throughout learning and teaching, research and operational activities.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=1#document-top)
# Section 2 - Overview
(2)  RMIT University is a public institution under Victorian law and stands on Aboriginal Country of the Kulin Nation. RMIT recognises and acknowledges the Bundjil Statement, which helps all RMIT community to respectfully work, live and study on Aboriginal Country through a dhumbali (commitment) to not harm the wurneet (waterways), biik biik (lands) and bubups (children) of Bundjil. RMIT supports the rights and the self-determination of Indigenous peoples and acknowledges the importance of Indigenous knowledge in preserving and protecting place for current and future generations.
(3)  RMIT is a signatory to both the United Nations Global Compact and the Universities Commitment to the Sustainable Development Goals (SDSN Australia/New Zealand 2017). RMIT is committed to addressing modern slavery risks across its sphere of activity.
(4)  RMIT acknowledges that its identity, location and capabilities afford a distinct sphere of influence that predisposes RMIT as a significant force to advance learning, research, governance and collaboration to shape a sustainable future.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=1#document-top)
# Section 3 - Scope
(5)  This policy is applicable to all staff, students, contractors, service providers, clients, customers and visitors when they are engaged in university activities and is applicable at all RMIT locations whether in Australia or overseas.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=1#document-top)
# Section 4 - Policy
### Sustainability Principles
#### Governance
(6)  Make sustainability an organisational priority – embedding sustainability principles into all university activities and ensuring decision making reflects RMIT’s values.
(7)  Behave as a socially responsible organisation and ensure that our activities have a positive impact on individuals and communities.
(8)  Ensure our strategies, processes, supply chains and partnerships meet fundamental responsibilities in the areas of human rights, labour, environment and anti-corruption to achieve a culture of integrity.
(9)  Be transparent in our sustainability journey, regularly monitoring and reporting on our performance and improvement initiatives to stakeholders.
#### Tertiary Education
(10)  Engage students at all levels in learning about relevant sustainability concepts (knowledge, skills and values), identifying issues of importance and taking actions in order to empower them as future leaders in industry and society.
(11)  Embed sustainability capabilities/competencies within disciplinary and professional contexts and encourage interdisciplinary collaboration.
(12)  Support academic and teaching staff to develop high levels of discipline relevant sustainability literacy so that they are able (competent and confident) to facilitate sustainability learning.
(13)  Support our students to drive innovation and sustainable enterprise.
#### Impact
(14)  Adopt a leadership role at a national and international level to shape a sustainable environment and society, contributing to the UN Sustainable Development Goals.
(15)  Support University commitments to reduce inequality for staff, students and the wider community.
(16)  Enhance RMIT’s research contribution to advance the Sustainable Development Goals.
(17)  Make RMIT a living laboratory, encouraging research and learning that engages with internal infrastructure, process and people.
(18)  Proactively engage in partnerships and projects with industry, government, non-government organisations and communities on sustainability.
#### Infrastructure and Operations
(19)  Exceed, wherever possible, all legislative and regulatory requirements for sustainability and aim to achieve exemplary sustainable practice in all university operations.
(20)  Embed reconciliation into planning and decision-making processes in keeping with our dhumbali to working respectfully on Aboriginal country; instil a consciousness of place-specific considerations wherever we are working in the world
(21)  Assess and address the risks of modern slavery in our operations and supply chains through due diligence and remediation processes, as well as implement tools to assess the effectiveness of these actions. 
(22)  Minimise the consumption of resources through sustainable procurement, waste avoidance, good design, reuse and recycling.
(23)  Preserve cultural heritage, enhance biodiversity and promote healthy functioning ecosystems.
(24)  Utilise best-practice sustainable design and innovative technologies to deliver efficient, resilient and adaptable buildings.
(25)  Ensure that RMIT’s greenhouse gas emission reduction targets and actions enable a transition to a low carbon future, whilst adapting the university to the impacts of climate change.
(26)  Provide infrastructure and initiatives which encourage the use of sustainable transport modes.
### Responsibilities
(27)  The RMIT Sustainability Committee is responsible for the oversight and implementation of this policy.
(28)  The performance of this policy is tracked in the Sustainability Annual Report which is prepared in accordance with the Global Reporting Initiative (GRI) Standard.
### Review
(29)  The Sustainability Committee is responsible for the review of this policy and supporting documents.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=1#document-top)
# Section 5 - Procedures and Resources
(30)  Refer to the following documents which are established in accordance with this Policy:
  1. [Corporate Social Responsibility Framework](https://policies.rmit.edu.au/document/view.php?id=104)
  2. [Responsible Investment Principles](https://policies.rmit.edu.au/download.php?id=81&version=2&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=1#document-top)
# Section 6 - Definitions
(31)  As a signatory to both the United Nations Global Compact and the Universities Commitment to the Sustainable Development Goals (SDSN Australia/New Zealand 2017), RMIT defines sustainability as:
  1. development that meets the needs of the present without compromising the ability of future generations to meet their own needs. Building an inclusive, sustainable and resilient future for people and the planet
  2. harmonising three core pillars: economic health, social inclusion and environmental protection, which are interconnected, and crucial for the wellbeing of individuals, societies and ecosystems


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
