[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=162&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=162&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Master Data Management Standard 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=162)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=162&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=162&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=162&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=162&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=162&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=162&version=1)


# Master Data Management Standard
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=162&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=162&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=162&version=1#section3)
  * [Section 4 - Standard](https://policies.rmit.edu.au/document/view.php?id=162&version=1#section4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  Master data management (MDM) is an approach for ensuring the organisation’s master data is captured, maintained and referenced in a consistent, uniform and accurate state, and available across all processes and systems where it is needed.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=162&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=162&version=1#document-top)
# Section 3 - Scope
(3)  This standard applies to all staff of RMIT Group responsible for the management of master data.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=162&version=1#document-top)
# Section 4 - Standard
(4)  The [Master Data Management Standard](https://policies.rmit.edu.au/download.php?id=220&version=3&associated) is available as a PDF.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
