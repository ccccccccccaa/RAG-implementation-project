[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=125&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=125&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Flexible Work Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=125)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=125&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=125&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=125&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=125&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=125&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=125&version=2)


# Flexible Work Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=125&version=2#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=125&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=125&version=2#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=125&version=2#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=125&version=2#major1)
  * [Access to a Flexible Work Arrangement](https://policies.rmit.edu.au/document/view.php?id=125&version=2#major2)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=125&version=2#major3)
  * [Record Keeping](https://policies.rmit.edu.au/document/view.php?id=125&version=2#major4)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=125&version=2#major5)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=125&version=2#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The purpose of this policy is to explain how RMIT can support employees to work more flexibly to balance personal and professional obligations, and to provide people managers with guidance about what to do when employees request flexibility at work.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=125&version=2#document-top)
# Section 2 - Overview
(2)  RMIT recognises the importance of formal and informal flexible working arrangements in maintaining a diverse and adaptable workforce and will assess all employee requests for flexible working arrangements related to any personal attribute, balancing work, life and family needs.
(3)  This policy addresses formal flexibility – for example, moving to part-time arrangement, purchasing additional leave, compressed workdays, altered start and finish times, job-sharing a role, changing or splitting shifts, or working remotely. However, if the need for flexibility arises from an injury or rehabilitation program also see the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=125&version=2#document-top)
# Section 3 - Scope
(4)  This policy applies to all employees of the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=125&version=2#document-top)
# Section 4 - Policy
### Principles
(5)  RMIT recognises the importance of fit for purpose, personalised, flexible working arrangements that foster and encourage a diverse and adaptable workforce. We encourage everyone working at the University to be creative in establishing ways of working that suit their roles and teams as well as balance your life outside RMIT
(6)  RMIT supports flexibility for a range of reasons and does not value or prioritise one reason for requesting flexibility over another, except where the law requires.
(7)  Safety is RMIT’s priority in managing flexible work requests and arrangements.
(8)  RMIT will conduct regular analysis of the take up of flexibility working options and workplace adjustments to identify improvements and promote flexible working options available to staff and managers including by gender diversity of participation and employment type.
### Access to a Flexible Work Arrangement
(9)  Employees covered by an enterprise agreement or awards have the options and any limits around flexibility that exist in that award or agreement. 
(10)  Some employees have a legal right to request flexible work arrangements and to have those requests met in certain circumstances. It’s especially important to seek advice from RMIT People if the request falls into one of the following categories:
  1. parents or carers of children of school age needing flexibility to look after the family needs
  2. carers needing flexibility to fulfil their carer responsibilities
  3. an employee living with a disability
  4. an employee who is aged 55 or older
  5. an employee who is experiencing violence from a family member, or who’s providing care and support for an immediate family member or house-sharer who is experiencing violence from a family member.


(11)  Flexible arrangements are specific to circumstances. If circumstances change then the flexible arrangements may need to be reviewed and modified. A potential change in role should always prompt a discussion to review any flexible arrangement in place before the new role is offered.
### Responsibilities
(12)  Employees looking for flexible work arrangements are required to discuss their request with their manager. Requests can be made in writing, or as requested by the manager.
(13)  Managers are required to ensure direct reports:
  1. are aware of flexible work arrangements, and actively promote the availability of flexible work arrangements, considering how positions in their team can be worked flexibly.
  2. are supported in their request and measure uptake of flexible working arrangements both formal and informal.


(14)  Managers of an employee requesting flexible work arrangements have a responsibility to:
  1. Meet with the employee to discuss their request for a flexible work arrangement
  2. listen carefully to the request
  3. ask questions to understand why flexibility is needed
  4. genuinely consider whether they can agree to the request or meet the need in a different way, including by seeking advice from RMIT People and their management line
  5. have regard to the consequences of the refusal for the employee
  6. discuss alternative working arrangements with the employees if they are considering refusing a request
  7. explain decisions about the request clearly in writing within 21 days of receiving the request.


(15)  Managers are obliged to seriously consider a request for flexibility. In some circumstances, it simply won’t be possible, either because of restrictions contained in the employee’s enterprise agreement, or because of operational requirements or the needs of other employees.
  1. Where a request is refused, managers must have reasonable business grounds for doing so. RMIT People can provide advice on how to test this – sometimes a trial arrangement can help establish whether something is viable.
  2. Where the request is refused, managers may agree upon alternative changes to the employee’s working arrangements and note the agreed changes in their written response


### Record Keeping
(16)  If a request for a flexible work arrangement is approved, this should be clearly documented in writing. The documentation must record the duration of the arrangement, and any trial or review periods that apply.
(17)  If a request for a flexible working arrangement is declined, and there is no ability to offer alternative working arrangements, the refusal must be communicated to the employee in writing and include all of the following:
  1. details of the reasons for the refusal
  2. the particular business grounds for refusing the request
  3. how those grounds apply to the request
  4. any changes that the Manager would be willing to make that would accommodate the employee’s circumstances to any extent, and
  5. a statement that that any unresolved dispute regarding the request may be referred to the Fair Work Commission.


### Review
(18)  This policy will be reviewed every three years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=125&version=2#document-top)
# Section 5 - Procedures and Resources
(19)  Refer to the following documents which are established in accordance with this policy:
  1. [Work Adjustment Procedure](https://policies.rmit.edu.au/document/view.php?id=157)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
