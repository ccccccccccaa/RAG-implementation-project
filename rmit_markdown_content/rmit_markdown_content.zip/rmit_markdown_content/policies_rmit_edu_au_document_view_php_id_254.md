[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=254#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=254#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Submission and Examination Schedule 1 - HDR Examination Recommendations and Classifications 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=254)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=254)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=254)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=254)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=254)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=254)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=254)


# HDR Submission and Examination Schedule 1 - HDR Examination Recommendations and Classifications
Hide Navigation
  * [Table 1 – Examination Recommendations and Classifications](https://policies.rmit.edu.au/document/view.php?id=254#major1)
  * [Table 2 – Outcome and classification of the first examination](https://policies.rmit.edu.au/document/view.php?id=254#major2)
  * [Table 3 – Outcome of the first examination after a third examiner is appointed, due to an initial examiner recommending R4 Revise and Resubmit.](https://policies.rmit.edu.au/document/view.php?id=254#major3)
  * [Table 4 – Outcome of the first examination after a third examiner is appointed, due to an initial examiner recommending R5 Failed.](https://policies.rmit.edu.au/document/view.php?id=254#major4)
  * [Table 5 - Outcome of the second examination following resubmission to two examiners](https://policies.rmit.edu.au/document/view.php?id=254#major5)
  * [Table 6 - Outcome of the second examination following resubmission to three examiners](https://policies.rmit.edu.au/document/view.php?id=254#major6)
  * [Masters by Research Grading](https://policies.rmit.edu.au/document/view.php?id=254#major7)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
### HDR Submission and Examination Schedule 1 - HDR Examination Recommendations and Classifications 
(1)  Authority for this document is established by the [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18).
### Table 1 – Examination Recommendations and Classifications
Classification | Short Description | Detailed Description  
---|---|---  
#### R1/C1
| Passed | The candidate should be awarded the degree with no requirements for amendments other than corrections of an editorial nature. Amendments are to be made within four (4) weeks of classification and certified by an RMIT academic delegate.  
#### R2/C2
| Passed subject to minor amendments | The candidate should be awarded the degree subject to minor amendments. Recommended amendments may include re-writing of small sections of text. Amendments are to be made within six (6) weeks of classification and certified by an RMIT academic delegate.  
#### R3/C3
| Passed subject to major amendments | The candidate should be awarded the degree subject to major amendments. Recommended amendments may involve substantial re-writing of parts of the thesis. Amendments are to be made within six months of classification and certified by an RMIT academic delegate.  
#### R4/C4
| Revise and Resubmit | The candidate should not yet be awarded the degree. Substantial revisions and a re-examination (by non-RMIT certified delegate) are required before a pass can be considered. Resubmission for re-examination to take place within 12 months for PhD candidates and 6 months for Master by Research candidates of initial classification.  
#### R5/C5
| Failed | The research does not meet the criteria for the degree as specified by the University and a significant amount of additional research work and/or major substantive revision will not raise it to an acceptable standard.  
### Table 2 – Outcome and classification of the first examination
|  | Examiner 1 Recommendation  
---|---|---  
| 
#### Passed (R1)
| 
#### Passed subject to minor amendments (R2)
| 
#### Passed subject to major amendments (R3)
| 
#### Revise and resubmit (R4)
| 
#### Failed (R5)  
#### Examiner 2 Recommendation
| 
#### Passed (R1)
| Passed | Passed or passed subject to minor amendments (ADVC RT&D or nominee to determine) | Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Appoint third examiner | Appoint third examiner  
#### Passed subject to minor amendments (R2)
| Passed or passed subject to minor amendments (ADVC RT&D or nominee to determine) | Passed subject to minor amendments | Passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Appoint third examiner | Appoint third examiner  
#### Passed subject to major amendments (R3)
| Passed subject to minor or major amendments (ADVD RT&D or nominee to determine) | Passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Passed subject to major amendments | Appoint third examiner | Appoint third examiner  
#### Revise and resubmit (R4)
| Appoint third examiner | Appoint third examiner | Appoint third examiner | Revise and resubmit | Appoint third examiner  
#### Failed (R5)
| Appoint third examiner | Appoint third examiner | Appoint third examiner | Appoint third examiner | Failed  
### Table 3 – Outcome of the first examination after a third examiner is appointed, due to an initial examiner recommending R4 Revise and Resubmit.
|  | Examiner 1 Recommendation  
---|---|---  
|  | 
#### Passed (R1)
| 
#### Passed subject to minor amendments (R2)
| 
#### Passed subject to major amendments (R3)
| 
#### Failed (R5)  
#### Examiner 2 Recommendation
| 
#### Revise and resubmit (R4)
| Third examiner appointed | Third examiner appointed | Third examiner appointed | Third examiner appointed  
#### Examiner 3 Recommendation
| 
#### Passed (R1)
| Passed | Passed or passed subject to minor amendments (ADVC RT&D or nominee to determine) | Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Revise and resubmit to all examiners  
#### Passed subject to minor amendments (R2)
| Passed or passed subject to minor amendments (ADVC RT&D or nominee to determine) | Passed subject to minor amendments | Passed or passed subject to minor amendments (ADVC RT&D or nominee to determine) | Revise and resubmit to all examiners  
#### Passed subject to major amendments (R3)
| Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Passed subject to major amendments | Revise and resubmit to all examiners  
#### Revise and resubmit (R4)
| Revise and resubmit to all examiners | Revise and resubmit to all examiners | Revise and resubmit to all examiners | Revise and resubmit to all examiners  
#### Failed (R5)
| Revise and resubmit to all examiners | Revise and resubmit to all examiners | Revise and resubmit to all examiners | Failed  
### Table 4 – Outcome of the first examination after a third examiner is appointed, due to an initial examiner recommending R5 Failed.
| Examiner 1 Recommendation  
---|---  
| 
#### Passed (R1)
| 
#### Passed subject to minor amendments (R2)
| 
#### Passed subject to major amendments (R3)
| 
#### Revise and resubmit (R4)  
#### Examiner 2 Recommendation
| 
#### Failed (R5)
| Third examiner appointed | Third examiner appointed | Third examiner appointed | Third examiner appointed  
#### Examiner 3 Recommendation
| 
#### Passed (R1)
| Passed | Passed or passed subject to minor amendments (ADVC RT&D or nominee to determine) | Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Revise and resubmit to all examiners  
#### Passed subject to minor amendments (R2)
| Passed or passed subject to minor amendments (ADVC RT&D or nominee to determine) | Passed subject to minor amendments | Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Revise and resubmit to all examiners  
#### Passed subject to major amendments (R3)
| Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Passed or passed subject to minor or major amendments (ADVC RT&D or nominee to determine) | Passed subject to major amendments | Revise and resubmit to all examiners  
#### Revise and resubmit (R4)
| Revise and resubmit to all examiners | Revise and resubmit to all examiners | Revise and resubmit to all examiners | Revise and resubmit to all examiners  
#### Failed (R5)
| Failed | Failed | Failed | Failed  
### Table 5 - Outcome of the second examination following resubmission to two examiners
| Examiner 1 Recommendation  
---|---  
| 
#### Passed (R1)
| 
#### Failed (R5)  
#### Examiner 2 Recommendation
| 
#### Passed (R1)
| Passed | Appoint third examiner  
#### Failed (R5)
| Appoint third examiner | Failed  
### Table 6 - Outcome of the second examination following resubmission to three examiners
|  | Examiner 1 Recommendation  
---|---|---  
|  | 
#### Passed (R1)  
#### Examiner 2 Recommendation
| 
#### Failed (R5)
|   
#### Examiner 3 Recommendation
| 
#### Passed (R1)
| Passed  
#### Failed (R5)
| Failed  
### Masters by Research Grading
#### Grading Sought from Masters by Research Examiners
(2)  In addition to providing an examination recommendation of R1 to R5, examiners of masters by research submissions are asked to recommend a numerical grade. The grades available to examiners are as follows:
  1. High Distinction (80-100%)
  2. Distinction (70-79%)
  3. Credit (60-69%)
  4. Pass (50-59%)
  5. Fail (<50%)


#### Grading Standards
Grade range | Level | Standard  
---|---|---  
#### 80-100%
| 
#### HD: High Distinction
| Work of exceptional quality showing clear understanding of subject matter and appreciation of issues; well formulated; arguments sustained; figures and diagrams where relevant; appropriate literature referenced; strong evidence of creative ability and originality; high level of intellectual work. Excellent analysis, comprehensive research, sophisticated theoretical or methodological understanding, impeccable presentation. The candidate demonstrates outstanding potential for doctoral level study and warrants strong scholarship support.  
#### 70-79%
| 
#### DI: Distinction
| Work of high quality showing strong grasp of subject matter and appreciation of dominant issues though not necessarily of the finer points; arguments clearly developed; relevant literature referenced; evidence of creative ability and solid intellectual work. Very good work that is very well researched, shows critical analytical skills, is well argued, with scholarly presentation and documentation. The candidate is capable of doctoral level study.  
#### 60-69%
| 
#### CR: Credit
| Work of solid quality showing competent understanding of subject matter and appreciation of main issues though possibly with some lapses and inadequacies and with clearly identifiable deficiencies in logic, presentation or originality. Some evidence of critical analysis and creative ability; well researched, prepared and presented. The candidate may be capable of doctoral level study under close supervision.  
#### 50-59%
| 
#### PA: Pass
| Completion of key tasks at an adequate level of performance with demonstrated understanding of key ideas and some analytical skills. Satisfactory presentation, research and documentation. Adequate report, reasonable quality but showing a minimal understanding of the research area with deficiencies in content or experimental rigour; little evidence of creative ability or original thought. The candidate is unlikely to be capable of doctoral level study.  
#### 0-49%
| 
#### NN: Fail
| The research does not meet the criteria for the degree as specified by the University and a significant amount of additional research work and/or major substantive revision will not raise it to an acceptable standard.  
(3)  Examinations with similar examiner recommendations (R1-R5)
  1. If the examiners’ recommended grades are within 15 percentage points of each other, the SGR Examinations team will derive a grade from the mean of the two recommended grades to recommend to the ADVC RTD.
  2. If the examiners’ grades differ by more than 15 percentage points, the ADVC RTD may refer to a moderator. The moderator must be an RMIT academic staff member who has not been involved in the candidature or the research as this is an internal appointment, and therefore not considered to be wholly independent. For this reason, their grade cannot supersede the examiners’ grades but rather, must consolidate their grades.
  3. A moderator is given two weeks in which to complete their moderation, which must include recommending a grade that: 
    1. agrees with one of the examiners’ grades, in which case this shall become the candidate’s final grade after approval; or
    2. is within the limits set by the examiners’ grades. In this case the SGR Examinations team will derive a grade from the mean of the grades recommended by both examiners and the moderator.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
