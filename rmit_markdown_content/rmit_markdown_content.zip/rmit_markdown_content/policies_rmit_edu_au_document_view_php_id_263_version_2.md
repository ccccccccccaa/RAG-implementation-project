[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=263&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=263&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Name Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=263)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=263&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=263&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=263&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=263&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=263&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=263&version=2)


# Student Name Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=263&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=263&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=263&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=263&version=2#section4)
  * [Conditions applicable to the use of primary and legal name ](https://policies.rmit.edu.au/document/view.php?id=263&version=2#major1)
  * [Conditions applicable to the use of a preferred name ](https://policies.rmit.edu.au/document/view.php?id=263&version=2#major2)
  * [Use of a student identification number ](https://policies.rmit.edu.au/document/view.php?id=263&version=2#major3)
  * [Gender identity and title ](https://policies.rmit.edu.au/document/view.php?id=263&version=2#major4)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=263&version=2#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=263&version=2#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure outlines the use of primary and preferred names by balancing the interests of students to use a preferred name and those for maintaining proof of identity credentials, legal and reporting requirements. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=263&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=263&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to prospective, current and past students of the RMIT Group. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=263&version=2#document-top)
# Section 4 - Procedure
### Conditions applicable to the use of primary and legal name 
(4)  RMIT records and maintains a record of a student’s legal name as their primary name at RMIT. The legal name will continue to appear within university records and systems where required by law. 
(5)  Students provide their legal name at the point of admission. This must be either verified against official identity documents or updated to verify their identity. While an individual may have documentation that reflects different versions of their legal names, RMIT can only maintain one primary name within RMIT records and systems at any given time. 
(6)  The components of the primary name include title, first name, middle name and last name. Due to system limitations, it is not possible to include special characters. 
(7)  Where students change their legal name, they must immediately notify RMIT and provide official documentation to confirm this change on RMIT’s records. 
(8)  Following a change to their legal name, students should ensure their legal name is also updated with other government or external agencies who may verify data from RMIT. 
(9)  The legal name will be used by RMIT as relates to current or former award students for the following activities: 
  1. To verify student identity and citizenship or residency status. 
  2. To report student data for any state and federal reporting and collection requirements. 
  3. To issue official university communication which includes, but is not limited to: 
    1. Student Invoices 
    2. Statements of Enrolment 
    3. Academic transcripts 
    4. Commonwealth Assistance Notices (CAN) 
    5. Electronic Commonwealth Assistance Form (eCAF) 
    6. Australian Higher Education Graduation Statements 
    7. Testamurs 
    8. Statements of Attainment 
    9. Statements of Academic Completion 
    10. Vocational Education qualification statements 
    11. Enrolment verification letters and third-party documents 
    12. Communication regarding scholarships and prizes. 


(10)  A student who legally changes their name must submit the necessary paperwork and supporting identity documentation as outlined in the “Update your personal details” webpage. 
(11)  Students who have legally changed their name to affirm their gender may apply for a replacement testamur as per the [Conferral and Graduation Procedure](https://policies.rmit.edu.au/document/view.php?id=9). 
### Conditions applicable to the use of a preferred name 
(12)  RMIT recognises that students may wish to use a preferred name (also known as a nickname or chosen name) rather than their legal name to identify themselves for a range of university-related activities where the legal name is not required. RMIT supports this choice and as such students may designate a preferred name regardless of whether they have legally changed their name. 
(13)  A student may choose to provide a preferred name in addition to their legal name. A student may add or change a preferred name without the need to provide supporting documentation. 
(14)  In the absence of a student providing a preferred name RMIT records and systems will default to their legal name as their preferred name. 
(15)  A preferred name may be used in RMIT application systems, for student communications, and informational materials, including hard copy communication, except where the legal name is required for legal, compliance and reporting purposes. 
(16)  Not all RMIT application systems use or display preferred name. Where a preferred name is used, these systems may do so in different ways, such as display first name only, or display first name and last name only. When preferred name is displayed, it does not include middle name. 
(17)  Where a student has provided a preferred name, staff should use this name respectfully in all interactions directly with the student, including in person and written communications, as well as when representing them with others. 
(18)  The components of the preferred name include title, first name, middle name and last name. The same system limitations that apply to the legal name also apply to the preferred name, i.e., it is not possible to include special characters. 
(19)  RMIT will monitor preferred names and reserves the right to remove the preferred name if it contains language considered inappropriate or offensive and is not in accordance with RMIT’s core values. Any removal of inappropriate preferred names will default to the student’s legal name. 
(20)  Preferred names may be used provided it is not intended to avoid legal obligations or being used for the purpose of misrepresentation or fraud. 
(21)  Preferred names may not be used for commercial or promotional purposes, therefore may not be a company name, group name, or message. 
(22)  A preferred name will remain in effect until a student changes the name. 
### Use of a student identification number 
(23)  A student identification number is generated and issued to every new student. The student identification number uniquely identifies them in RMIT systems indefinitely. 
(24)  The student identification number is used as the primary value to identify and verify students and is how RMIT staff processes student information for teaching and educational support in RMIT systems. 
### Gender identity and title 
(25)  RMIT maintains a record of a student’s gender and title which appears within some RMIT records and systems where required by law. 
(26)  A student may update their gender and/or title within their student record without the need to provide supporting documentation. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=263&version=2#document-top)
# Section 5 - Resources
(27)  Nil.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=263&version=2#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Legal name  | As registered with the government and commonly displayed on documents such as birth certificate, passport or other officially recognised legal documentation.   
Preferred name  |  Name/s that an individual prefers to be known by or identifies with in the university community that is different from the individual’s legal name.  Is a name other than your legal name which is generally used by individuals who choose to use for example:  - an alternative or shortened first name, and/or middle, and/or last name  - a different name order  - students who want to adopt an English language name  - a name that better represents their gender identity   
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
