[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=217&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=217&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Child Safe Reporting Procedure Vietnam 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=217)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=217&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=217&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=217&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=217&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=217&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=217&version=1)


# Child Safe Reporting Procedure Vietnam
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=217&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=217&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=217&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=217&version=1#section4)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=217&version=1#section5)
  * [Section 6 - Section 6 – Definitions](https://policies.rmit.edu.au/document/view.php?id=217&version=1#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  The [Victorian Child Safe Standards](https://ccyp.vic.gov.au/child-safe-standards/) legislation requires all RMIT staff, students and associates to take all reasonable steps to remove or reduce the risks of harm to children. The legislation sets out how organisations must embed child safety and respond to suspected child abuse, child harm, risk of harm and neglect. 
(2)  RMIT University acknowledges that the Victorian child safety legislation does not apply in the context of Vietnam. This procedure will strive to align with the [National Principles for Child Safe Organisations](https://childsafe.humanrights.gov.au/national-principles) and the [Victorian Child Safe Standards](https://ccyp.vic.gov.au/child-safe-standards/) to contribute to RMIT’s global child safe culture to ensure that young people under 18 years of age are protected from harm. It enables RMIT to detect and respond to child safety concerns and more effectively prevent them from occurring.
(3)  The term child abuse is used throughout the procedure to include an act or omission which endangers a child’s health, wellbeing and/or development. Child abuse can be a single traumatic event or series of events and is rarely limited to one form of abuse. It may take the form of neglect, or physical, emotional or sexual abuse, including grooming and sexual exploitation.
(4)  The term child is used throughout the procedure to include adolescents and young persons, consistent with the legislation which deems a child as a person under 18 years of age. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=217&version=1#document-top)
# Section 2 - Authority
(5)  Authority for this document is established by the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=217&version=1#document-top)
# Section 3 - Scope
(6)  This procedure applies to all students, staff and associates of the RMIT Vietnam campuses. For the purposes of this procedure, students, staff and associates includes:
  1. RMIT University Council members, employees, researchers, representatives and volunteers
  2. contractors, tenants, licensees or lessees, and service providers where there is a connection with RMIT or when attending RMIT premises
  3. customers and visitors when engaged in activities with or for RMIT, or when attending RMIT premises
  4. partner organisations or people acting for or on behalf of RMIT in relation to our students and staff (including clubs and societies, and student representative organisations).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=217&version=1#document-top)
# Section 4 - Procedure
#### Roles and Responsibilities
(7)  RMIT University Council is responsible for: 
  1. ensuring systems and structures are in place within RMIT to implement and monitor the effectiveness of the [Child Safe Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=214)
  2. monitoring the effectiveness of complaints handling processes via reports from the Vice-Chancellor's Executive
  3. overseeing complaints handling where complaints are escalated to Council
  4. responding to and overseeing complaints made about or referring to the Vice-Chancellor
  5. following appropriate reporting processes when a concern, report or disclosure of child abuse arises.


(8)  The Vice-Chancellor and the Vice-Chancellor's Executive are responsible for:
  1. ensuring the Child Safe Reporting Procedure is addressed at the strategic level and implemented across RMIT
  2. ensuring all RMIT staff are aware of their obligations under the [Reportable Conduct Scheme](https://ccyp.vic.gov.au/reportable-conduct-scheme/)
  3. meeting the obligations of the [Reportable Conduct Scheme](https://ccyp.vic.gov.au/reportable-conduct-scheme/) by reporting to relevant child safety authorities within a set period if they become aware of a report of child abuse by an RMIT student, staff or associate
  4. receiving, reviewing, and responding to organisational incidents and outcomes (including summary reports, aggregate recording of reports on a quarterly basis)
  5. reporting complaint trends and information to Council.


(9)  Safer Community/Senior Manager, Wellbeing is responsible for:
  1. maintaining oversight of child safeguarding related complaints
  2. ensuring child and young person friendly complaints mechanisms are in place
  3. receiving and responding to complaints in line with the [Child Safe Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=214)
  4. supporting RMIT staff and children, young people and families who have identified, responded, or reported child harm or neglect by ensuring they are linked in with appropriate community supports
  5. monitoring, manage and continually improve RMIT’s child safe reporting practices
  6. collating, review and respond to organisational incidents and outcomes
  7. ensuring that the [Child Safe Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=214) and pathways to complaints are communicated with RMIT students and families.


(10)  All students, staff and associates are responsible for:
  1. understanding the signs of child abuse and how to respond
  2. following appropriate reporting processes when a concern, report or disclosure of child abuse arises
  3. following the Child Safe Code of Conduct when engaging with children
  4. if the child is at immediate risk, contact the Senior Manager, Wellbeing to advise the next steps. 


(11)  Everyone, regardless of their legal obligations, has a responsibility to report concerns about child abuse, child harm, risk of harm and neglect. 
#### Reporting
(12)  Information on how to identify child abuse and what needs to be reported, who is legally required to report, who is a voluntary reporter and the relevant legislation, can be found in the [Child Safe Reporting Instruction](https://policies.rmit.edu.au/download.php?id=354&version=2&associated).
(13)  When students, staff and associates are concerned about the safety and wellbeing of a child, they must assess that concern to determine if a report should be made to relevant authorities, in consultation with Safer Community/Senior Manager, Wellbeing. This process of considering all relevant information and observations is known as forming ‘reasonable grounds’. Belief on reasonable grounds is formed if a reasonable person in the same position would have formed the belief on the same grounds.
(14)  In the case of emergencies
  1. Remove the child from the harmful situation only if safe to do so.
  2. Immediately contact the Senior Manager, Wellbeing for guidance on next action at safercommunityvn@rmit.edu.vn.


(15)  Where RMIT staff, student on placement, contractor or volunteer forms a belief that a child has suffered abuse/maltreatment, harm or neglect or is at risk of harm, they must notify Senior Manager, Wellbeing within 24 business hours.
(16)  Confidentiality must be maintained when reporting concerns, with any discussions occurring on a need-to-know basis only. Only those directly involved in the management of the child’s situation and responsible for meeting the reporting obligations are to be involved in discussion where the child’s identity or details of the suspected harm is disclosed. An exception is when the child has consented to a secondary disclosure and has capacity to consent.
(17)  If a report is made in good faith, the making of a report is not unprofessional conduct or a breach of professional ethics, and the reporter cannot be held legally liable, regardless of the outcome of the notification. Permission is not required from parents or carers to make a report and they do not need to be informed that a report is being made.
(18)  The types of concerning behaviours that require reporting may include:
  1. suspicions or beliefs that children have suffered or are at risk of suffering abuse
  2. inappropriate relationships developing between a child and a student, staff member or associate
  3. feelings of discomfort about a relationship between a child and a student, staff member or associate
  4. observations of concerning changes in a child’s behaviour.


(19)  In making a report to Senior Manager, Wellbeing, where possible, gather the relevant information necessary to make the report. This should include, wherever possible, the following:
  1. full name, date of birth, and residential address of the child or young person
  2. the details of the concerns and the reasons for those concerns
  3. the individual staff, student on placement, contractor or volunteer involvement with the child and young person
  4. details of any other agencies who may be involved with the child or young person, if known.


(20)  Disclosures of child abuse which, in consultation with the Senior Manager, Wellbeing, be reported to the relevant authorities include any suspected or actual breach of this procedure, [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213), Child Safe Code of Conduct, within the lawful limitations of the Vietnam child protection system. 
#### Protected Disclosures
(21)  Should RMIT students, staff or associates wish to make a protected disclosure, also known as a whistleblowing, they may do so directly to the Vice-Chancellor’s Office. RMIT will ensure that appropriate support is provided to the child of concern, their family, as well as to the discloser/whistle-blower.
#### Record Keeping
(22)  Timely, clear and effective record keeping is important part of managing child safety concerns. The Senior Manager, Wellbeing/Safer Community will manage records of child safety concerns including, but not limited to:
  1. the nature of the child safety concern and how it was managed
  2. any reportable actions or allegations, and which organisations they were reported to
  3. witness details
  4. support persons for those involved in the management of the report
  5. internal and external investigators
  6. outcomes of the reporting process, including any problems that required addressing
  7. support provided, either in the short term or on a continuing basis
  8. actions taken, e.g. escalation, risk assessments and outcomes, policy change, system fault and correction
  9. actions requiring ongoing review and/or follow-up, e.g. ongoing risk assessment, continued support for child or other parties.


#### Responding to Historical Allegations of Abuse
(23)  The Vice-Chancellor or their delegate must be notified of any allegation of historical abuse which pertains to RMIT within 24 hours of a person receiving that information.
(24)  The Vice-Chancellor is responsible for overseeing the handling of any historical allegation, including confirming that it has been referred to the relevant authority, e.g. Police.
(25)  At the conclusion of the Police investigation, the Vice-Chancellor will determine whether it is appropriate to undertake an internal investigation. An internal investigation would generally be warranted where the student, staff or associate implicated in the allegation is still involved with RMIT.
(26)  In all circumstances, RMIT will undertake an internal review to determine if there is a need to amend any policies, procedures or processes. Reviews will focus on the identification and application of learning to minimise future risk.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=217&version=1#document-top)
# Section 5 - Resources
(27)  The following documents are established in accordance with this procedure and are mandatory to comply with:
  1. [Child Safe Reporting Instruction](https://policies.rmit.edu.au/download.php?id=354&version=2&associated)
  2. [Child Safe Image Instruction](https://policies.rmit.edu.au/document/view.php?id=235)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=217&version=1#document-top)
# Section 6 - Section 6 – Definitions
Child abuse | An act or acts which endangers a child’s health, wellbeing and/or development. It can be a single event or a series of events. It includes: - cumulative harm - emotional or physical abuse - exposure to family violence - neglect - grooming - sexual abuse and sexual exploitation (sexual harm) - multi-dimensional harm.  
---|---  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
