[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=111&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=111&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Third-Party Complaints Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=111)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=111&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=111&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=111&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=111&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=111&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=111&version=1)


# Third-Party Complaints Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=111&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=111&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=111&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=111&version=1#section4)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=111&version=1#major1)
  * [Lodging Complaints](https://policies.rmit.edu.au/document/view.php?id=111&version=1#major2)
  * [Privacy and Record Keeping](https://policies.rmit.edu.au/document/view.php?id=111&version=1#major3)
  * [Management and Resolution](https://policies.rmit.edu.au/document/view.php?id=111&version=1#major4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  Any person may make a complaint or raise a concern about any aspect of the operations and business activities of the RMIT Group.
(2)  A third party for the purposes of this procedure is any person not eligible to raise a complaint under the various staff and student policies and procedures
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=111&version=1#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=111&version=1#document-top)
# Section 3 - Scope
(4)  This procedure is governed by the principles and commitments contained in the [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110).
(5)  This procedure applies to any third party wishing to raise a complaint or concern about the RMIT Group.
(6)  A third party may be located anywhere and can include but is not limited to:
  1. the parent or guardian of a prospective or current student of RMIT or its subsidiaries, controlled entities or partner institutions
  2. a member of the public
  3. an industry or work integrated learning partner
  4. non-RMIT staff from a partner institution
  5. staff or students from another university
  6. contractors, including agency staff engaged as contingent labour, associated with the RMIT Group.


(7)  This procedure does not apply where there is an existing contract or agreement in place between a third party and the RMIT Group which prescribes an alternative complaint resolution process.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=111&version=1#document-top)
# Section 4 - Procedure
### Responsibilities
(8)  The Governance, Legal and Strategic Operations function manages third-party complaints.
  1. The Manager, Central Complaints and Investigations has responsibility for the receipt, assessment, investigation and resolution of third-party complaints.


(9)  If the third-party complaint involves or implicates the Manager, Central Complaints and Investigations, it will be managed by the Executive Director, Governance, Legal and Strategic Operations or their delegate.
  1. Similarly, any real or perceived conflict of interest will be avoided by appropriate declaration and reassignment.
  2. If the Executive Director, Governance, Legal and Strategic Operations is the subject of the complaint an appropriate alternative officer will be appointed.


(10)  The complainant is responsible for the provision of information and is personally responsible and liable for the content of their complaint. Complainants must not provide information that they know to be inaccurate or misleading.
(11)  Complaints may be closed at the discretion of the Executive Director, Governance, Legal and Strategic Operations if there are reasonable grounds to believe the complaint is frivolous, misguided, or vexatious or where there is insufficient information to proceed or the matter has been sufficiently dealt with by another area or mechanism.
### Lodging Complaints
(12)  Complaints can be lodged in writing via the [Complaints Portal](https://policies.rmit.edu.au/download.php?id=121&version=1&associated).
(13)  Complaints may also be referred to thirdpartycomplaints@rmit.edu.au.
(14)  Complaints may be received via telephone.
(15)  Complaints may be referred from other business units or areas within RMIT.
### Privacy and Record Keeping
(16)  Staff will not unless otherwise required by law or at the direction of the Executive Director, Governance, Legal and Strategic Operations, discuss details relating to specific individuals with third party complainants to safeguard the privacy of individuals.
(17)  The details of the complaint, the outcome and action taken will be recorded and used for service improvement.
(18)  Complainants will usually receive a written outcome unless to do so would breach legislation, policy, or otherwise have a deleterious effect on any party.
### Management and Resolution
(19)  The nature of the complaint and the parties involved will be assessed before determining the most appropriate method(s) of resolution.
(20)  Any or all parts of the complaint may be transferred for resolution under other processes as deemed necessary.
(21)  The Manager, Central Complaints and Investigations will follow a procedurally fair methodology to investigate third-party complaints.
(22)  Outcomes reached under this procedure will be considered final. Any decision to re-open a complaint after an outcome has been delivered will be at the discretion of the University with explicit approval of the Executive Director, Governance, Legal and Strategic Operations.
(23)  Resolutions available under this procedure include a wide range of non-disciplinary actions including but not limited to an explanation, apology, training, counselling, coaching, or a review of policy, procedure or practice.
(24)  The [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=2&associated) is the appropriate review mechanism for outcomes provided under this procedure.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
