[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=195#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=195#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Honorary Degrees Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=195)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=195)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=195)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=195)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=195)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=195)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=195)


# Honorary Degrees Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=195#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=195#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=195#minor2)
  * [3. Definitions](https://policies.rmit.edu.au/document/view.php?id=195#minor3)
  * [Part B - HONORARY DEGREES](https://policies.rmit.edu.au/document/view.php?id=195#part2)
  * [4. Honorary Degrees](https://policies.rmit.edu.au/document/view.php?id=195#minor4)
  * [5. Confidentiality](https://policies.rmit.edu.au/document/view.php?id=195#minor5)
  * [6. Approval](https://policies.rmit.edu.au/document/view.php?id=195#minor6)
  * [7. Ceremony](https://policies.rmit.edu.au/document/view.php?id=195#minor7)
  * [Part C - TRANSITIONAL PROVISIONS](https://policies.rmit.edu.au/document/view.php?id=195#part3)
  * [8. Transitional Provisions](https://policies.rmit.edu.au/document/view.php?id=195#minor8)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to make further provision relating to the awarding of honorary degrees.
#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
#### 3. Definitions
(3)  In these Regulations:
  1. Nominations, Remuneration and People Committee means the Nominations, Remuneration and People Committee of Council.


## Part B - HONORARY DEGREES
#### 4. Honorary Degrees
(4)  The honorary degrees which may be conferred by Council are:
  1. Doctor of Arts
  2. Doctor of Business
  3. Doctor of Communication
  4. Doctor of Design
  5. Doctor of Engineering
  6. Doctor of Laws
  7. Doctor of Science, and
  8. Doctor of Social Science


(5)  A submission for the conferring of an honorary degree must be made in accordance with the relevant policies and procedures.
(6)  A submission made under clause (5) must be:
  1. made without informing the nominated persons, however, the submission is not invalid only because the nominated person becomes aware of the nomination, and
  2. placed before the Nominations, Remuneration and People Committee.


(7)  No fees are payable for admission to any degree under these Regulations.
#### 5. Confidentiality
(8)  All persons associated with the nominations and approval process in respect of an honorary degree must treat the matter in confidence.
(9)  Without limiting clause (8) the person nominated must not be notified until the award of the honorary degree has been approved.
#### 6. Approval
(10)  A recommendation must be made in accordance with the relevant policies and procedures.
(11)  If the Nominations, Remuneration and People Committee approves the conferring of the honorary degree, the Vice-Chancellor ascertains whether the nominee is willing to receive the award and:
  1. if the nominee is not willing to receive the award then Council approval lapses, or
  2. if the nominee is willing to receive the award then Council may confer the honorary degree.


#### 7. Ceremony
(12)  Subject to the relevant policies and procedures, an honorary degree testamur is presented at an appropriate conferring ceremony by such person as Council appoints.
(13)  Notwithstanding clause (12), in exceptional circumstances an honorary degree may, by Council resolution, be conferred in absentia or posthumously.
## Part C - TRANSITIONAL PROVISIONS
#### 8. Transitional Provisions
(14)  Any honorary degree or award conferred on any person prior to the commencement of these Regulations is treated as having been validly approved and conferred under these Regulations.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
