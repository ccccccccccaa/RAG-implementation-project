[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=170&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=170&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Conduct - Senior Officer Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=170)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=170&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=170&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=170&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=170&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=170&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=170&version=2)


# Student Conduct - Senior Officer Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=170&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=170&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=170&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=170&version=2#section4)
  * [Senior Officer](https://policies.rmit.edu.au/document/view.php?id=170&version=2#major1)
  * [Referral of Potential Student Misconduct](https://policies.rmit.edu.au/document/view.php?id=170&version=2#major2)
  * [Investigations](https://policies.rmit.edu.au/document/view.php?id=170&version=2#major3)
  * [Senior Officer Hearing](https://policies.rmit.edu.au/document/view.php?id=170&version=2#major4)
  * [Senior Officer Determinations](https://policies.rmit.edu.au/document/view.php?id=170&version=2#major5)
  * [Senior Officer Outcome Notification](https://policies.rmit.edu.au/document/view.php?id=170&version=2#major6)
  * [Section 5 - Definitions ](https://policies.rmit.edu.au/document/view.php?id=170&version=2#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets out requirements for Senior Officers that apply to: 
  1. the management of general and academic potential student misconduct reports
  2. internal student conduct investigations, and
  3. the conduct of Senior Officer hearings, determinations and the provision of outcome notifications.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=170&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=170&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to students and staff of RMIT, as set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). It relates to the implementation of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and corresponding procedures regarding student conduct and the management of student misconduct.
(4)  Nothing in this procedure prevents an officer or Senior Officer from taking precautionary measures at any time to address or manage a safety concern.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=170&version=2#document-top)
# Section 4 - Procedure
### Senior Officer
#### Responsibilities
(5)  In determining a student conduct matter, a Senior Officer:
  1. must act in accordance with this procedure and all applicable policies
  2. must act fairly and reasonably in all the circumstances, which may include contacting the respondent student to inform them of the potential student misconduct report, and to explain the nature of their investigation and enquiries
  3. must ensure that all parties, including advocates and support persons are aware of the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedure requirements, including those relating to records, privacy, and confidentiality
  4. is not bound by the rules of evidence, technicalities, or legal forms, including rules which apply in any court or tribunal in Australia, such as those set out in the [Evidence Act 2008 (Vic)](https://content.legislation.vic.gov.au/sites/default/files/2020-06/08-47aa026%20authorised.pdf)
  5. may make such inquiries and communicate with the people they determine to be relevant and necessary to enable them to properly determine the matter
  6. may ask any student to attend a hearing or interview, or to provide information in relation to the matter; however a Senior Officer may not compel or force a student to attend a hearing or interview, or to provide information relating to a student conduct matter, and
  7. must have due regard for the [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56) in the exercise of any authority or discretion granted to them. 


(6)  A Senior Officer may make determinations about all matters relating to the conduct of a hearing, including but not limited to: attendance, scheduling and re-scheduling, any pausing or adjournment of the hearing, any additional material or information required, and the provision of information about the process and the determination. All such determinations are subject to this procedure, the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180).
#### General
(7)  Where a Senior Officer accepts a report of potential academic or general misconduct as referred under this procedure, the Senior Officer has 30 working days from receipt of the referral or report to:
  1. make a determination regarding a student conduct matter based on a student’s written submission, or
  2. convene a hearing.


(8)  Clause (7) does not apply where there are relevant circumstances which impact the ability to act within this time or where the matter has been paused or suspended due to external requirements.
(9)  The Senior Officer is responsible for managing the conduct records including outcomes.
(10)  Any notice or written communication to students is to be provided in accordance with requirements of the [Student Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=106).
### Referral of Potential Student Misconduct
(11)  Referrals to a Senior Officer of matters relating to potential general or academic misconduct must be made in accordance with [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and [Student Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=106).
(12)  If a Senior Officer receives a potential general or academic student misconduct report or referral, or is otherwise aware of information which gives rise to a reasonable belief that a student may have engaged in misconduct under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), the Senior Officer may:
  1. do anything reasonable and proportionate to the circumstances to resolve the report informally without making a determination of misconduct
  2. direct the Course Coordinator (or equivalent) to treat the conduct matter as an assessment issue, which can be addressed as part of the assessment of the student's work in accordance with the [Academic Integrity Policy](https://policies.rmit.edu.au/document/view.php?id=168) and corresponding procedure
  3. redirect the report to another Senior Officer with specialised subject matter expertise such as sexual harm, IT security, academic integrity, or discipline specialisation or to avoid any known or potential conflict of interest
  4. investigate the matter themselves and/or request an internal investigation
  5. accept the report as referred, convene a hearing or determine by written submission, make findings, and apply penalties and/or consequences, where appropriate, in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and this procedure
  6. determine that no further action is required under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and this procedure, provide appropriate notification to the referring officer or reporting person through their preferred method of contact and the respondent student (where appropriate), or
  7. if the matter is considered serious or complex in nature, refer the report to the Student Conduct Board.


(13)  A Senior Officer must refer potential student misconduct reports to the Student Conduct Board when it concerns:
  1. research misconduct
  2. serial academic misconduct
  3. unethical conduct, including but not restricted to the purchase of assessment materials, or the impersonation of a student for an assessment task, or
  4. a student who is also a staff member and the matter could result in an investigation by RMIT’s human resources team.


#### Matters Relating to Sexual Harm
(14)  Where a potential student misconduct report referred to a Senior Officer relates to or may affect or impact the safety of any person, present any increased level of risk, or where it involves sexual harm, the Senior Officer must:
  1. have completed relevant training in relation to sexual harm, and taking a trauma-informed approach, (the matter will otherwise be referred to an appropriately trained Senior Officer), and


  1. consult with Safer Community on the appropriate arrangements for conducting any investigation, hearing or other matters involving the consideration of the reported conduct.


### Investigations
#### Appointment of an Investigator and Responsibilities
(15)  A Senior Officer may determine:
  1. whether an investigation should be conducted in relation to a potential student misconduct report, and
  2. how any such investigation may be carried out subject to the requirements of the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.


(16)  A Senior Officer may decide that an investigation will be conducted by
  1. themselves, or
  2. an officer, group, or Senior Officer of RMIT with appropriate subject-matter expertise.


(17)  Where the reported conduct is serious or complex in nature or may require an external investigation, the investigation must be referred to the Academic Registrar (or delegate) in accordance with the [Student Conduct Board Procedure](https://policies.rmit.edu.au/document/view.php?id=171).
(18)  If an officer is appointed to investigate, the Senior Officer should consider the nature of the reported conduct and the kind of investigation required, as well as any other relevant circumstances. For example:
  1. If the report relates to misuse of RMIT computer or network facilities, it may be appropriate for an investigation to be carried out by a person with sufficiently high IT security access
  2. If the report involves students from within a particular discipline, it may be appropriate to have the investigation carried out by someone from a different discipline or portfolio to ensure impartiality and the absence of actual or perceived bias
  3. If the nature of a discipline’s activities are a particularly relevant context for a report (such as requiring knowledge of a building or a research function or protocols), it may be appropriate for a staff member with knowledge of that discipline or context to carry out the investigation.


(19)  The Senior Officer, or officer may make any necessary enquiries in relation to the reported conduct as part of their investigation, which may include:
  1. reviewing any relevant documents, electronic files, CCTV footage and other evidence
  2. requesting access to any relevant documents, electronic files, CCTV footage, copies of records or material held by other groups within RMIT such as electronic documents or records, emails or other records of communication through RMIT’s computing and network facilities, although such access may be limited and subject to approval by the relevant authority
  3. contact with external parties to confirm authenticity and authorship such as medical practices, health providers, or access to any relevant documents, electronic files, CCTV footage, copies of records or material held by the external party, including but not restricted to placement providers and student residences affiliated with RMIT
  4. seeking to interview persons who may have relevant information (such as witnesses or recipients of communications including staff, students and referring officer).


(20)  Where a Senior Officer determines that an investigation is required by another Senior Officer the investigating officer will be briefed on their involvement including:
  1. conducting their investigation in accordance with this procedure,
  2. determining whether each of the assertions within the potential student misconduct report are able to be substantiated
  3. preparing an investigation report containing findings supported by documentary evidence for the initiating Senior Officer.


(21)  If whilst conducting an investigation a Senior Officer becomes aware of any additional information leading to their reasonable belief that a more serious instance of misconduct may have occurred, the Senior Officer may refer the matter to:
  1. a different Senior Officer who has relevant subject matter expertise or training, or 
  2. the Student Conduct Board.


#### Engagement with Students and Staff
(22)  In carrying out an investigation, the investigating officer will:
  1. seek to apply a trauma-informed approach, with the objective of harm minimisation. This includes minimising the number of times and number of people to whom a reporting person is required to recount their experience
  2. conduct the investigation on a “need to know” only basis, including, to the extent possible, maintaining anonymity over the identity of the person who made any relevant disclosure or report, as well as over the student who is the subject of the investigation
  3. enable flexibility within the process to minimise any risk to wellbeing, such as re-exposure to trauma.


(23)  A student may be accompanied by a support person and/or advocate at any interview that occurs during the conduct investigation.
  1. The student must notify the Chair, Student Conduct Board, Senior Officer or investigating officer as appropriate in advance of the name of the support person or advocate who will attend and advise if this person is a legal practitioner.
  2. An advocate, and not a support person, is permitted to make submissions on the respondent student’s behalf. 
  3. Any person who is under the age of 18 must be accompanied to any meeting by a parent, guardian or caregiver who is responsible for their interaction with the University.


(24)  A student cannot be compelled or required to participate in an investigation.
(25)  Investigations will be conducted such that participants are appropriately informed of timeframes, roles, possible outcomes and any other aspects of the student conduct process relevant to the investigation, including the use of the findings of the investigation in staff as well as student conduct matters.
#### Concluding an Investigation
(26)  Upon concluding an investigation, the Senior Officer must form a preliminary view about the potential student misconduct based on the report, relevant evidence, their enquiries, any internal final investigation reports (where applicable) and may either: 
  1. determine that the conduct may constitute misconduct under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and convene a hearing, or 
  2. determine that no further action is required under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and this procedure where the misconduct is considered not to be substantiated. The Senior Officer (or delegate) will notify the respondent student, referring officer and reporting person by their preferred method of contact (where appropriate) of this determination as quickly as practicable and confirm it in writing.


### Senior Officer Hearing
#### Notification of Hearing
(27)  Where the Senior Officer forms a view that the potential student misconduct may constitute general or academic misconduct, the Senior Officer will advise the Secretary to: 
  1. make arrangements for a hearing in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and this procedure 
  2. notify the respondent student: 
    1. of the opportunity to respond to the potential student misconduct report by the method determined by the Senior Officer with notifications, documentation and timelines provided in accordance with clause (33) 
    2. that they may be accompanied by a support person, a representative from their principal student organisation or other advocate, and their Safer Community case manager in accordance with this procedure (where applicable), and 
    3. details of available student support services.


#### Reporting Party Notification
(28)  Where a matter involves a report from another person, that person will be informed of when and where the Senior Officer hearing is to take place. 
(29)  For matters involving sexual harm or other behaviour that is concerning, threatening or inappropriate, the Senior Officer (or delegate) may invite any person impacted or affected by the respondent student's conduct to make a written submission to the Senior Officer regarding the impact or effect of the respondent student's conduct on them. 
(30)  Where the Senior Officer determines that misconduct has occurred, the Senior Officer will consider reports from persons impacted by the misconduct when determining to apply one or more consequences, or administrative, disciplinary, or academic penalties.
#### Representation and Support
(31)  At the Senior Officer hearing, where invited to participate in person, the respondent student may be accompanied by a support person or advocate as follows:
  1. the support person is not permitted to make submissions on the respondent student's behalf, and
  2. the advocate may make submissions on the respondent student’s behalf.


(32)  Any person who is under the age of 18 must be accompanied to any meeting or hearing by a parent, guardian or caregiver who is responsible for their interaction with the University. 
#### Student Participation
(33)  A student may respond to a potential student misconduct report, the investigation materials and related documentation to be considered via either of the following means (at the discretion of the Senior Officer):
  1. written submission with a due date no earlier than 10 working days from the date of the written notification and provision of the report and related documentation, or
  2. invitation to participate in a hearing in person (which may include by telephone or online video conference) 
    1. with date, time, and location details (and connection information where applicable) scheduled no earlier than 10 working days from the date of the written notification and provision of the report and related documentation, or
    2. if the respondent student does not wish to participate in the hearing, they may provide a written submission no later than two working days before the date of the scheduled hearing.


(34)  Where a respondent student makes a written submission to the Senior Officer and/or elects not to participate in a hearing (where appropriate), the Senior Officer will consider the matter based on the potential student misconduct report and the response provided by the student.
(35)  A respondent student must confirm their attendance and the name of their support person/s and/or any advocate at least two working days before the hearing. 
(36)  The Senior Officer may reschedule a hearing where the respondent student:
  1. provides reasonable evidence that they are unable to attend at the scheduled time, or 
  2. provides written consent to waive the requirement of 10 working days notice. 


(37)  The Senior Officer may request written documentation to support the respondent student’s reasonable cause for not attending, including but not limited to a health practitioner’s report and or a statutory declaration. 
(38)  If the respondent student does not make a written submission or does not attend a hearing within 10 minutes of the scheduled commencement time, and has not provided information about a reasonable cause for their non-submission or non-attendance as the case may be, the Senior Officer may proceed with consideration of the conduct matter and any determination made will be binding.
#### Conduct of a Hearing
(39)  The Senior Officer will ensure that the hearing:
  1. is held confidentially, and in a comfortable venue (if not conducted via telephone or online video conference), and that the safety and wellbeing of the respondent student, their support person/s, and any other persons in attendance including RMIT staff, other students, or witnesses is supported
  2. as far as possible provides the respondent student and their support person/s and/or advocate access to a separate private space for consultation before and after the hearing (if applicable when telephone or online video conference is used)
  3. starts at the scheduled time
  4. proceeds without interruption
  5. is managed to ensure that all parties are treated with respect, and
  6. includes advice to attendees that there must not be audio or video recording of the proceedings, including if they are conducted electronically or via video link.


(40)  The Senior Officer:
  1. must conduct the hearing in accordance with this procedure
  2. must act fairly in all the circumstances
  3. may make such inquiries and communicate with the people they determine to be relevant and necessary to enable them to properly determine the matter
  4. may require any officer to attend the hearing, and
  5. may ask any student to attend a hearing or interview, or to provide information in relation to the matter; however the Senior Officer may not compel or force a student to attend a hearing or interview, or to provide information relating to a student conduct matter.


(41)  The Senior Officer may also make inquiries with any reporting person or persons who were affected or impacted by the reported conduct, taking into account guidance from Safer Community in relation to how this may be done in a trauma-informed and appropriately sensitive manner.
### Senior Officer Determinations
(42)  Once the Senior Officer has considered all relevant materials, and the respondent student's response (where applicable), the Senior Officer must determine: 
  1. what occurred, as a finding of fact, on the balance of probabilities
  2. whether what was found to have occurred constitutes misconduct, and then
  3. to: 
    1. take no further action, or 
    2. apply consequences or penalties or any other steps available to them in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180) and [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). 


### Senior Officer Outcome Notification
#### Notification to Respondent Student
(43)  The Senior Officer (or delegate) must provide written notification of the outcome within 10 working days of the scheduled hearing or deadline for written response advising, where relevant:
  1. the specific provisions of the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) or other policy document that has been reported to have been breached or not complied with 
  2. the reasons for the determination
  3. any consequences, penalties and/or conditions imposed, and why any are appropriate in view of the nature of the established misconduct
  4. that consequences can arise from a failure to comply with outcome determinations in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and that this may lead to further conduct action
  5. any other consequences for, or impacts on, the respondent student and their relationship with RMIT, including any implications there may be in relation to a respondent student’s visa
  6. information about available support services for the respondent student
  7. that a determination to suspend a completing respondent student (where appropriate) will preclude RMIT from issuing them with any award of RMIT until the suspension has concluded, unless this requirement is specifically waived by the Academic Registrar, and
  8. the opportunity to lodge an appeal against the determination and any consequences or penalties in accordance with the [Student Conduct - Appeals Procedure](https://policies.rmit.edu.au/document/view.php?id=172) within 20 working days of the date of the written outcome notification. 


(44)  Senior Officers must promptly notify the Academic Registrar (or delegate) to implement any penalties or consequences that will impact a respondent student’s academic or enrolment record, or where a suspension is to be imposed.
#### Notification to Impacted or Affected Persons
(45)  Where a matter relates to a report from another person, the Senior Officer (or delegate) will advise that person, by their preferred method of contact, the outcome determination. 
(46)  Where a finding of misconduct has resulted in the imposition of consequences or penalties, the specific nature of the consequences or penalties imposed should only be communicated to the reporting person to the extent relevant and appropriate. 
  1. In some cases, for privacy reasons, the details of an outcome and the corresponding consequences or penalties cannot be communicated to anyone other than the respondent student and their representatives.
  2. If a Senior Officer has applied a consequence or penalty, this would not be communicated to the reporting person, unless it was directly relevant to the reporting person because of an impact or repercussion for them as a result of that consequence or penalty. 
    1. For example, if a respondent student has been suspended from RMIT premises, and if this is relevant to a reporting person for the purposes of their attendance at RMIT premises, this would be communicated to the reporting person. 

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=170&version=2#document-top)
# Section 5 - Definitions 
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term  | Definition  
---|---  
advocate | means a member of the principal student organisation, case manager from Safer Community or another person approved by a Senior Officer or Chair of the Student Conduct Board to accompany a student during an investigation or conduct hearing. An advocate may provide advice and is permitted to make submissions or speak on a respondent student's behalf during an investigation or conduct hearing.   
course coordinator | means the academic or teaching staff member who is responsible for the management, conduct, teaching and assessment of a course.  
secretary  | means the secretary appointed by the Academic Registrar to the Student Conduct Board or the Student Conduct Appeals Committee.  
serial academic misconduct  | is academic misconduct, where the student has previously been found to have engaged in academic misconduct at RMIT.  
support person | a support person is someone who may accompany a person and support their wellbeing during a student conduct investigation or conduct hearing but who may not represent or speak on behalf of the student. A support person is usually a family member, friend, fellow student or colleague.  
working day | means days on which the University conducts its business. Working days do not include Saturdays, Sundays and the days set out in clauses 22 and 23 of the [RMIT Enterprise Agreement 2024](https://www.rmit.edu.au/staff/service-connect/benefits-salary/enterprise-agreements-bargaining/rmit-university-agreement-bargaining).  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
