[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=171&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=171&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Conduct Board Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=171)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=171&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=171&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=171&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=171&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=171&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=171&version=1)


# Student Conduct Board Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=171&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=171&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=171&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=171&version=1#section4)
  * [Student Conduct Board](https://policies.rmit.edu.au/document/view.php?id=171&version=1#major1)
  * [Referral of Potential Student Misconduct ](https://policies.rmit.edu.au/document/view.php?id=171&version=1#major2)
  * [Investigations ](https://policies.rmit.edu.au/document/view.php?id=171&version=1#major3)
  * [Concluding an Investigation](https://policies.rmit.edu.au/document/view.php?id=171&version=1#major4)
  * [Student Conduct Board Hearing](https://policies.rmit.edu.au/document/view.php?id=171&version=1#major5)
  * [Student Conduct Board Determinations ](https://policies.rmit.edu.au/document/view.php?id=171&version=1#major6)
  * [Student Conduct Board Outcome Notification ](https://policies.rmit.edu.au/document/view.php?id=171&version=1#major7)
  * [Section 5 - Definitions ](https://policies.rmit.edu.au/document/view.php?id=171&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure sets out requirements for the Student Conduct Board that apply to: 
  1. the management of general, academic, and high risk potential student misconduct reports 
  2. internal and external student conduct investigations, and 
  3. the conduct of Student Conduct Board hearings, determinations and the provision of outcome notifications.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=171&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=171&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to students and staff of RMIT, as set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). It relates to the implementation of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and corresponding procedures regarding student conduct and the management of student misconduct. 
(4)  Nothing in this procedure prevents an officer or Senior Officer from taking any precautionary measures at any time to address or manage a safety concern. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=171&version=1#document-top)
# Section 4 - Procedure
### Student Conduct Board
#### Responsibilities
(5)  In determining a student conduct matter, the Academic Registrar (or delegate) prior to the hearing, and the Chair, Student Conduct Board during proceedings:
  1. must act in accordance with this procedure, and all applicable policies
  2. must act fairly and reasonably in all the circumstances, which may include contacting the respondent student to inform them of the potential student misconduct report, and to explain the nature of their investigation and enquiries
  3. ensure that all parties, including advocates and support persons are aware of the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedure requirements, including those relating to records, privacy, and confidentiality
  4. are not bound by the rules of evidence, technicalities, or legal forms, including rules which apply in any court or tribunal in Australia, such as those set out in the Evidence Act 2008 (Vic)
  5. may make such inquiries and communicate with the people they determine to be relevant and necessary to enable them to properly determine the matter
  6. may ask any student to attend a hearing or interview, or to provide information in relation to the matter; however may not compel or force a student to attend a hearing or interview, or to provide information relating to a student conduct matter, and
  7. must have due regard for the [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56) in the exercise of any authority or discretion granted to them.


(6)  The Chair, Student Conduct Board may make determinations about all matters relating to the conduct of a hearing, including but not limited to: attendance, scheduling and re-scheduling, any pausing or adjournment of the hearing, any additional material or information required, and the provision of information about the process and the determination. All such determinations are subject to this procedure, the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180).
#### General
(7)  A matter referred to the Student Conduct Board and scheduled for hearing will be heard within 30 working days of receiving the referral or the report, except where there are relevant circumstances which impact this time, or where the matter has been paused or suspended because of external requirements. 
(8)  The Secretary is responsible for managing the records of the Student Conduct Board including outcomes. No party may make an audio or video recording of the proceedings, including if they are conducted electronically or via video link. 
(9)  Any notice or written communication to students is to be provided in accordance with the requirements of the Student Conduct Procedure.
### Referral of Potential Student Misconduct 
(10)  Referrals to the Student Conduct Board of matters relating to potential general, academic, or high risk student misconduct must be made in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), Student Conduct Procedure and Student Conduct – Senior Officer Procedure.
(11)  If a potential student misconduct matter or report is referred to the Student Conduct Board, the Academic Registrar (or delegate) may:
  1. do anything reasonable and proportionate to the circumstances to resolve the matter or report informally without making a determination of misconduct
  2. return the matter or report to the referring Senior Officer with appropriate advice, requesting: 
    1. further investigation, information, and development prior to resubmission or
    2. that the matter be addressed in accordance with the Student Conduct – Senior Officer Procedure
  3. redirect the matter or report to a Senior Officer with specialised subject-matter expertise such as sexual harm, IT security, academic integrity, or discipline specialisation or to avoid any known or potential conflict of interest
  4. refer the matter for an internal and/or external investigation
  5. accept the matter or report as referred and advise the Secretary to convene a hearing of the Student Conduct Board for the purpose of making findings, and apply penalties and/or consequences, where appropriate in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and this procedure, or
  6. determine that no further action is required under the Student Conduct Policy and this procedure, providing appropriate notification to the referring Senior Officer, reporting person through their preferred method of contact and the respondent student (where appropriate).


#### Matters relating to sexual harm 
(12)  Where a potential student misconduct report referred to the Student Conduct Board relates to or may affect or impact the safety of any person, present any increased level of risk, or where it involves sexual harm: 
  1. the Chair must consult with Safer Community on the appropriate arrangements for conducting any investigation, hearing or other matters involving the consideration of the report; and 
  2. where relevant and practicable, the Chair and at least one of the other Senior Officer members of the Student Conduct Board, will have undertaken relevant training in relation to sexual harm, and taking a trauma-informed approach. 


### Investigations 
(13)  Investigations may be requested by the Academic Registrar (or delegate) in accordance with clause 11(d), or the Chair, Student Conduct Board during the course of a hearing where the complexities of the matter require additional or specialised investigation. In either case, the Academic Registrar (or delegate), or the Chair, Student Conduct Board (as appropriate) will decide how any such investigation may be carried out, including whether the investigation is appropriately undertaken by an external resource, or by a person or group within RMIT.
(14)  The Academic Registrar (or delegate) or Chair, Student Conduct Board may request that an investigation be conducted by
  1. a Senior Officer
  2. an officer of RMIT with appropriate subject-matter expertise, or
  3. an external organisation or person.


(15)  RMIT may establish a register of external of providers with expertise or skills in relation to the investigation of certain subject matter, including misconduct involving sexual harm.
(16)  Where an investigation is requested the investigating officer will be appropriately briefed in relation to:
  1. conducting their investigation in accordance with this procedure
  2. determining whether each of the assertions within the potential student misconduct report are able to be substantiated
  3. preparing an investigation report supported by documentary evidence.


#### External Investigator 
(17)  Appointment and investigation by an external resource will likely be more appropriate where:
  1. the nature of reported conduct is serious
  2. the availability of any evidence or material relevant to the matter is such that it may require technical expertise to obtain it 
  3. there is a higher level of risk or threat associated with the reported conduct, as determined in accordance with the assessment undertaken by Safer Community
  4. the likely investigation is complex
  5. the subject matter of the reported conduct is sensitive or likely to require a particular skillset to appropriately investigate it 
  6. the persons likely to be involved are vulnerable or have specific needs, and where an external investigation would best facilitate their engagement (including taking into account age, disability, language, social or cultural background or any other relevant characteristics)
  7. there are not appropriate internal resources available to undertake an investigation
  8. the potential outcomes available require it, if a finding of misconduct were to be made (for example if the outcome depended on the need for a specific finding of fact which could only be substantiated through an investigation); or
  9. there are any other relevant factors which support the use of an external investigation resource.


(18)  Where an external investigator is to be appointed, the Academic Registrar (or delegate) will notify the relevant College or Portfolio with whom the respondent student is studying of the appointment and the need to meet investigation costs. 
### Concluding an Investigation
(19)  In the case of matters that have been referred to the Student Conduct Board, the Academic Registrar (or delegate) must form a preliminary view about the potential student misconduct based on the report, relevant evidence, any internal and external final investigation reports (where applicable) and may either:
  1. determine that the conduct may constitute misconduct under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and advise the Secretary to convene a hearing of the Student Conduct Board, or
  2. determine that no further action is required under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and this procedure where the misconduct is considered not to be substantiated. The Academic Registrar (or delegate) will notify the respondent student, referring officer and reporting person by their preferred method of contact (where appropriate) of this determination as quickly as practicable and confirm it in writing.


### Student Conduct Board Hearing
#### Membership
(20)  Where the Student Conduct Board is convened, its membership will accord with quorum requirements set out within the Student Conduct Regulations.
(21)  Before the start of proceedings, members of the Student Conduct Board must declare any actual, potential or perceived conflicts of interest to the Chair of the Student Conduct Board. The Chair will consider whether there is an actual, potential or perceived conflict of interest. The Chair will decide:
  1. whether the member should continue to sit on the relevant Student Conduct Board having regard to the nature of the conflict of interest, and if not, the Chair will request a replacement member be appointed; or
  2. whether the member can remain sitting on the relevant Student Conduct Board, and how to manage the actual, potential or perceived conflict of interest. 


(22)  Membership of the Student Conduct Board will not include:
  1. a Senior Officer who was involved in the investigation, hearing, or referral of the reported misconduct, or
  2. to the extent practicable, a Senior Officer who is from a school responsible for the program in which the respondent student is enrolled.


#### Notification of Hearing 
(23)  Where the Academic Registrar (or delegate) forms a view that the potential student misconduct may constitute general, academic, or high risk misconduct, the secretary will:
  1. convene the Student Conduct Board in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and this procedure
  2. notify the respondent student: 
    1. of the opportunity to respond to the report with notifications, documentation and timelines provided in accordance with clause (33)
    2. that they may be accompanied by a support person and/or advocate in accordance with this procedure (where applicable)
    3. details of student support services.


#### Reporting Party Notification
(24)  Where a matter involves a report from another person, that person will be informed by their preferred method of contact about when and where the hearing of the Student Conduct Board is to take place.
(25)  For matters involving sexual harm or other behaviour that is concerning, threatening or inappropriate, the Academic Registrar (or delegate) may invite any person impacted or affected by the respondent student's conduct to make a written submission to the Student Conduct Board regarding the impact or effect of the respondent student's conduct on them.
(26)  Where the Student Conduct Board makes a finding of misconduct, it will consider reports from persons impacted by the misconduct when determining to apply one or more consequences, or administrative, disciplinary, or academic penalties. 
#### Representation and Support
(27)  At the Student Conduct Board hearing, where invited to participate in person, the respondent student may be accompanied by a support person and/or advocate. 
(28)  An advocate, and not a support person, is permitted to make submissions on the respondent’s student’s behalf.
(29)  Any person who is under the age of 18 must be accompanied to any meeting or hearing by a parent, guardian or caregiver who is responsible for their interaction with RMIT. 
(30)  A student must seek permission from the Chair, Student Conduct Board if they want to be represented by a legal practitioner or to otherwise have a legal practitioner make submissions on their behalf.
(31)  The Chair has discretion not to allow a student to be represented by a legal practitioner or to have a legal practitioner make submissions on their behalf.
(32)  The Student Conduct Board as constituted in a particular matter may be assisted by Counsel, being an external legal practitioner (Counsel Assisting). The role of the Counsel Assisting is to provide legal advice to the Student Conduct Board on how to effectively discharge its obligations under, and comply with, the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180), [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and this and other applicable procedures. Counsel Assisting will not:
  1. undertake advocacy for the Student Conduct Board,
  2. make written or verbal submissions to or for the Student Conduct Board, or the respondent student, or
  3. undertake examinations of any persons on behalf of the respondent student or the Student Conduct Board.


#### Student Participation
(33)  A student may respond to a potential student misconduct report, the investigation materials and related documentation to be considered by the Student Conduct Board by way of participation in a hearing in person (which may include by telephone or online video conference)
  1. with date, time, and location details (and connection information where applicable) scheduled no earlier than 10 working days from the date of the written notification and provision of the report and related documentation, or 
  2. if the respondent student does not wish to participate in the hearing, they may provide a written submission no later than two working days before the date of the scheduled hearing of the Student Conduct Board. 


(34)  Where a respondent student makes a written submission to the Student Conduct Board electing not to participate in a hearing, the Student Conduct Board will consider the matter on the basis of the potential student misconduct report and the response provided by the student.
(35)  A respondent student must confirm their attendance and the name of their support person/s and any advocate at least two working days before the hearing.
(36)  The Chair may re-schedule a hearing where the respondent student:
  1. provides reasonable evidence that they are unable to attend at the scheduled time, or
  2. provides written consent to waive the requirement of 10 working days’ notice.


(37)  The Chair may request written documentation to support the respondent student’s reasonable cause for not attending, including but not limited to a health practitioner’s report and/or a statutory declaration.
(38)  If the respondent student does not make a written submission or does not attend a hearing within 10 minutes of the scheduled commencement time, and has not provided information about a reasonable cause for their non-submission or non-attendance as the case may be, the Student Conduct Board may proceed with consideration of the conduct matter and any determination of the Student Conduct Board will be binding.
#### Conduct of a Hearing
(39)  The Chair will ensure that the Student Conduct Board hearing:
  1. is held confidentially, and in a comfortable venue (if not conducted via telephone or online video conference), and that the safety and wellbeing of the respondent student, their support person/s, members of the Student Conduct Board, and any other persons in attendance including RMIT staff, other students or witnesses is supported
  2. as far as possible provides the respondent student and their support person/s and/or advocate/s access to a separate private space for consultation before and after the hearing (if applicable when telephone/online video conference is used)
  3. starts at the scheduled time
  4. proceeds without interruption, and
  5. is managed to ensure that all parties are treated with respect.


(40)  The Student Conduct Board:
  1. must conduct the hearing in accordance with this procedure
  2. must act fairly in all the circumstances
  3. may make such inquiries and communicate with the people they determine to be relevant and necessary to enable them to properly determine the matter 
  4. may require any officer to attend the hearing
  5. may ask any student to attend a hearing or interview, or to provide information in relation to the matter; however the Student Conduct Board may not compel or force a student to attend a hearing or interview, or to provide information relating to a student conduct matter.


(41)  The Student Conduct Board may make inquiries with any reporting person or persons who were affected or impacted by the potential student misconduct, considering guidance from Safer Community in relation to how this may be done in a trauma-informed and appropriately sensitive manner
### Student Conduct Board Determinations 
(42)  Once the Student Conduct Board has considered all relevant materials, and the respondent student's response (where applicable), the Student Conduct Board must determine:
  1. what occurred, as a finding of fact, on the balance of probabilities;
  2. whether what was found to have occurred constitutes misconduct; and then
  3. to: 
    1. take no further action, or
    2. apply consequences or penalties or any other steps available to them in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180) and [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).


### Student Conduct Board Outcome Notification 
#### Notification to Respondent Student 
(43)  The Secretary must provide written notification of the Student Conduct Board outcome within 10 working days of the scheduled hearing or deadline for written response advising, where relevant:
  1. the specific provisions of the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) or other policy document that has been reported to be breached or not complied with
  2. the reasons for the determination
  3. any consequences, penalties and/or conditions imposed, and why any are appropriate in view of the nature of the established misconduct
  4. that consequences can arise from a failure to comply with outcome determinations in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and that this may lead to further conduct action
  5. any other consequences for, or impacts on, the respondent student and their relationship with RMIT, including any implications there may be in relation to a respondent student’s visa
  6. information about available support services for the respondent student
  7. that a determination to suspend or expel a completing respondent student (where appropriate) will preclude RMIT from issuing them with any award of the University (in the case of a suspension, until the suspension has concluded), unless this requirement is specifically waived by the Student Conduct Board and
  8. the opportunity to lodge an appeal against determination and any consequences or penalties in accordance with the Student Conduct - Appeals Procedure within 20 working days of the date of the written outcome notification. 


#### Notification to Impacted or Affected Persons 
(44)  Where a matter relates to a report from another person, the Academic Registrar (or nominee) will advise that person, by their preferred method of contact, the outcome determination of the Student Conduct Board. 
(45)  Where a finding of misconduct has resulted in the imposition of consequences or penalties, the specific nature of the consequences or penalties imposed should only be communicated to the reporting person to the extent relevant and appropriate. 
  1. In some cases, for privacy reasons, the details of an outcome and the corresponding consequences or penalties cannot be communicated to anyone other than the respondent student and their representatives. For example, if a respondent student has been suspended from RMIT premises, and if this is relevant to a reporting person for the purposes of their attendance at RMIT premises, this would be communicated to the reporting person.
  2. If a Student Conduct Board has applied an academic penalty or another disciplinary measure, this would not be communicated to the reporting person, unless it was directly relevant to the reporting person because of an impact or consequence for them as a result of that penalty or disciplinary measure.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=171&version=1#document-top)
# Section 5 - Definitions 
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy)
Term  | Definition  
---|---  
advocate | means a member of the principal student organisation, case manager from Safer Community or another person approved by a Senior Officer or Chair of the Student Conduct Board to accompany a student during an investigation or conduct hearing. An advocate may provide advice and is permitted to make submissions or speak on a respondent student's behalf during an investigation or conduct hearing.  
secretary  | means the secretary appointed by the Academic Registrar to the Student Conduct Board or the Student Conduct Appeals Committee.  
support person | a support person is someone who may accompany a person and support their wellbeing during a student conduct investigation or conduct hearing but who may not represent or speak on behalf of the student. A support person is usually a family member, friend, fellow student or colleague.  
working day | means days on which the University conducts its business. Working days do not include Saturdays, Sundays and the days set out in clauses 22 and 23 of the RMIT University Enterprise Agreement 2018.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
