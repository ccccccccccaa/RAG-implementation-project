[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=202&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=202&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Design Procedure - Higher Education Coursework 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=202)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=202&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=202&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=202&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=202&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=202&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=202&version=1)


# Program and Course Design Procedure - Higher Education Coursework
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=202&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=202&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=202&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=202&version=1#section4)
  * [Higher Education Coursework Program Design Requirements](https://policies.rmit.edu.au/document/view.php?id=202&version=1#major1)
  * [Higher Education Coursework Program Design and Program Structural Components](https://policies.rmit.edu.au/document/view.php?id=202&version=1#major2)
  * [Higher Education Coursework Program Design for Undergraduate Awards](https://policies.rmit.edu.au/document/view.php?id=202&version=1#major3)
  * [Higher Education Coursework Program Design for Pathways, Nested and Exit Awards](https://policies.rmit.edu.au/document/view.php?id=202&version=1#major4)
  * [Higher Education Coursework Program Design for Double Degrees and Joint Awards](https://policies.rmit.edu.au/document/view.php?id=202&version=1#major5)
  * [Higher Education Coursework Program Design for Postgraduate Awards](https://policies.rmit.edu.au/document/view.php?id=202&version=1#major6)
  * [Higher Education Coursework Program Design Award Titles and Configuration Requirements](https://policies.rmit.edu.au/document/view.php?id=202&version=1#major7)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=202&version=1#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure provides design requirements for development and amendment of new or existing award programs and course offerings aligned to RMIT’s strategic direction and in compliance with legislative requirements. It prescribes a mandatory framework and rules for program and course design intended for all staff involved in program design and delivery.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=202&version=1#document-top)
# Section 2 - Authority
(2)  The authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=202&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all higher education coursework programs and courses offered by the RMIT Group, partners and affiliated third parties. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=202&version=1#document-top)
# Section 4 - Procedure
### Higher Education Coursework Program Design Requirements
#### Higher Education Program Design for Australian Qualification Framework (AQF) Award Level
(4)  Award programs are structured:
  1. incrementally to scaffold learning and provide depth and breadth to students' application of knowledge and skills as they progress through the program
  2. to ensure a positive student learning experience and to maximise student agency through providing flexibility and options in breadth and depth where available
  3. to leverage pathways, exit and entry points and nesting where possible
  4. with constructive alignment to enable achievement of program learning outcomes contextualised to discipline
  5. to embed distinctive RMIT Capabilities
  6. with industry relevance, using Industry Partnered Learning (IPL) for opportunities to connect theory with practice
  7. to ensure the program experience fosters both local and global perspectives and capabilities.


(5)  In addition to the above, undergraduate award programs two years or longer (full-time equivalent) are structured:
  1. to build from a first-year foundation block
  2. with the use of majors and minors where possible
  3. to include inter/trans/cross discipline opportunities for all students.


For further guidance on program design, the RMIT Capabilities and embedding to the award level, refer to the [Centre for Educational Innovation and Development (CEID) Resource Hub](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub).
(6)  Program design must be compliant with the AQF award level specified for the program award title to be conferred.
(7)  The proportion of courses in a program that are required to meet the AQF level of the award may vary but must be sufficient for students to develop their knowledge, skills, and application of knowledge and skills to enable them to achieve the program learning outcomes mapped to the appropriate award level at the point of graduation.
(8)  Courses in a program can be scaffolded through the use of foundation, intermediate or advanced categorisation.
For further guidance on course typology and use of foundation, intermediate, or advanced course categorisation, refer to the [CEID Resource Hub](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub).
(9)  The scaffolding of courses in a program must consider any articulation agreements so that students who have completed a lower-level award are able to seamlessly transition to a further qualification.
(10)  Award programs adhere to the guidance provided by the AQF qualification descriptors. 
(11)  The specified learning outcomes for each program encompass:
  1. specific knowledge and skills and their application that characterise the field(s) of education or disciplines involved
  2. RMIT Capabilities and their application in the context of the fields of education or disciplines involved
  3. knowledge and skills required for employment and further study related to the program, including those required to be eligible to seek registration to practice where applicable, and
  4. skills in independent and critical thinking suitable for life-long learners.


(12)  Programs may have a reduced volume of learning where the entry requirement is a qualification for which students receive a standard amount of credit, or when Recognition of Prior Learning (RPL) or Masters Advanced Standing is granted. Refer to the [Credit Procedure](https://policies.rmit.edu.au/document/view.php?id=37) for further information.
(13)  The maximum time periods for completion of programs by students is specified in the [Enrolment Procedure - Maximum Time to Complete a Coursework Program](https://policies.rmit.edu.au/document/view.php?id=164).
(14)  Program design must include the following:
  1. program learning outcomes mapped to the AQF Level and qualification type for the award level
  2. benchmarking of the program learning outcomes against national and international comparators
  3. course learning outcomes that are scaffolded to meet program learning outcomes
  4. the relationship of each course learning outcome with the assessment method
  5. how the approved set of RMIT Capabilities will be explicitly embedded across the program structure according to award level and program learning outcomes
  6. equivalence of learning outcomes and RMIT Capabilities across all offerings and course combinations (for example, majors and minors) a student may select from to complete their award program
  7. Industry Partnered Learning (IPL) experiences, through Career Development Learning (CDL), Industry Embedded Activities (IEA) and Work Integrated Learning (WIL)
  8. how the program structure and course combinations optimally support student learning and progression in the discipline field of the award
  9. professional accreditation standards and capabilities, where applicable.


(15)  Refer to [Program and Course Approval Procedure - Higher Education Coursework, Short Courses and Micro-Credentials](https://policies.rmit.edu.au/document/view.php?id=244) and the Academic Case Form for detailed requirements on evidencing the elements listed above in the academic case.
(16)  Award programs are designed to ensure:
  1. RMIT’s suite of programs remain sustainable
  2. efficiency of delivery and administration by reducing duplication and sharing courses where possible, and
  3. students are able to enrol online independently.


### Higher Education Coursework Program Design and Program Structural Components
(17)  The structural design of higher education programs and courses is enabled through a combination of:
  1. a unit of learning measured in credit points, which must be a minimum of 1 credit point
  2. a curriculum structure block that is a consistently sized unit of learning with a distinct credit point value to form a program structural component, and
  3. aggregation of curriculum structure blocks to create a coursework program with the required program structural components.


(18)  The program design requirements set out in Table 1 shows:
  1. how the AQF applies to RMIT coursework award programs 
  2. the AQF volume of learning, illustrated as typical years of full-time study (for example, at two semesters a year for Australian campuses)
  3. the AQF volume of learning, in hours, based on the generally accepted length of a full-time year used for student workload as 1200 hours
  4. RMIT credit points normally required to qualify for the respective awards, and
  5. program structural components required for each award type.


#### Table 1 – Higher Education Coursework Program Design Requirements
Award level | Undergraduate certificate | Higher education diploma | Associate degree | Bachelor degree | Bachelor degree | Bachelor honours degree | Bachelor honours | Graduate certificate | Graduate diploma | Masters by coursework | Masters (Extended)  
---|---|---|---|---|---|---|---|---|---|---|---  
AQF award level | 5-7 | 5 | 6 | 7 | 7 | 8 | 8 | 8 | 8 | 9 | 9  
Volume of learning (full-time years) | 0.5 | 1 | 2 | 3 | 4 | 4 | 1 | 0.5 | 1 | 2 | 3  
Volume of learning (hours) | 600 | 1200 | 2400 | 3600 | 4800 | 4800 | 1200 | 600 | 1200 | 2400 | 3600  
Credit points required for each award level | 48 | 96 | 192 | 288 | 384 | 384 | 96 | 48 | 96 | 192 | 288  
Program structural components |   
Award level | Undergraduate certificate | Higher education diploma | Associate degree | Bachelor degree | Bachelor degree | Bachelor honours degree | Bachelor honours | Graduate certificate | Graduate diploma | Masters by coursework | Masters (Extended)  
Core courses | As determined by program team  
Option courses | As determined by program team  
First year block | N/A | 48 | 48 | 48 | 48 | 48 | N/A | N/A | N/A | N/A | N/A  
Majors – 96 credit points minimum requirement | As determined by program team  
Minors – 48 credit points requirement | As determined by program team  
WIL – minimum requirement | N/A | 6 | 12 | 24 | 24 | 24 | N/A | N/A | 12 | 12 | 24  
IPL minimum requirement | N/A | 3 | 6 | 12 | 12 | 12 | N/A | 3 | 3 | 6 | 6  
Research component – minimum | N/A | N/A | N/A | N/A | N/A | 36 | 36 | N/A | N/A | 12 | 12  
Capstone experiences | N/A | N/A | Yes | Yes | Yes | Yes | N/A | N/A | N/A | Yes | Yes  
Elective or disciplinarity minimum credit points requirement | N/A | N/A | 12 | 24 | 24 | 24 | N/A | N/A | N/A | N/A | N/A  
*There is no requirement for programs to include majors and minors, but where these are present in a program structure, they must comprise at least the minimum credit points specified.
(19)  The Deputy Vice-Chancellor Education may approve an exemption from a program structural component in Table 1 where they are satisfied that:
  1. professional accreditation requirements prevent electives, disciplinarity courses and/or disciplinarity minors being offered within the normal program duration
  2. in a double degree program, requirements for meeting prescribed learning outcomes within a reduced volume of learning prevent electives, disciplinarity courses and/or disciplinarity minors being offered, or
  3. where there is a compelling case to create an exit-only award for students who are unable to complete a program with professional accreditation status, where the design of the nested exit-only award prevents all program structural components from being met.


(20)  Programs are made up of consistently sized curriculum structure blocks that may comprise the following components:
  1. first-year block
  2. core courses 
  3. option courses 
  4. University elective courses or disciplinarity courses
  5. majors 
  6. minors
  7. program capstone courses.


#### First Year Block
(21)  First year blocks are comprised of courses that provide the foundational knowledge, skills, and their application as required in the primary discipline or industry field of study.
(22)  Majors and minors are scaffolded from the first year block.
(23)  Courses that form part of a first year block are designed where possible to facilitate breadth by delivering foundational knowledge that enable the maximum number of shared majors and minors for students to select from in the program.
(24)  First-year blocks are designed with flexibility to allow the use of alternative courses to accommodate different educational backgrounds, for example, offering the choice of maths courses to accommodate differing VCE mathematics pre-requisites or to optimise VET pathways credit, without compromising learning outcomes or student progression.
(25)  First-year blocks must be 48 credit points.
(26)  First-year blocks may be offered as a disciplinarity minor in programs of a different primary discipline area.
#### Core Courses
(27)  Core courses are mandatory courses that contain curriculum required to achieve the program learning outcomes at the AQF award level.
(28)  Core courses form program requirements as part of a first-year block, IPL, capstone and/or major/minor sequence. When major and/or minor curriculum structure blocks are present in program design, the identification of courses as core must be determined in relation to those majors and minors.
(29)  Where there are choices for students to complete different majors and/or minors, the major and/or minors are designed so that any combination of core courses allocated within those major and/or minor curriculum structure blocks satisfy the program learning outcomes.
(30)  A core course that is part of a first year block cannot also be part of a major/minor sequence in the same program.
For further guidance on the application of core courses in program design, refer to the [CEID Resource Hub](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub).
#### Option Courses
(31)  Option courses are courses that a student can choose from and are suitably curated for equivalent contribution to the program learning outcomes at the AQF award level.
(32)  Option courses may form part of a major and/or minor sequence.
(33)  Option courses are listed in the program structure, major and/or minor sequence, and require the student to complete a specified number (for example, ‘complete any two from the following list of five courses’).
(34)  The availability of option courses in a major and/or minor is informed by:
  1. suitability in satisfying the curriculum needs of the major and/or minor
  2. the opportunity for enhancing the integration of the major and/or minor into different programs (for example, increased shareability or relevance)
  3. addressing the breadth of learning available within the sequence.


(35)  Equivalent option courses may facilitate contextualisation within a major and/or minor sequence to:
  1. adapt the curriculum to support the needs of different student cohorts
  2. leverage entry pathways and articulation agreements
  3. empower student agency to tailor their learning journey.


#### University Elective or Disciplinarity Courses
(36)  A University elective is a course that a student may choose from those offered across RMIT but is not specifically listed in the program structure.
(37)  University electives are only to be used when a student is required to contribute to the credit point total required for completion of a program.
(38)  A disciplinarity course is identified as a course that is sharable for inclusion outside of its primary discipline:
  1. for use as a core or curated option course in any suitable major or minor sequence, or
  2. for use in creation of disciplinarity minors.


(39)  University electives and disciplinarity courses provide students with the opportunity to obtain breadth of knowledge and skills outside the primary discipline area that is determined through their first-year block. 
(40)  University electives and disciplinarity courses provide inter/trans/cross-disciplinary opportunities for students.
(41)  University electives and disciplinarity courses enable inter/trans/cross-disciplinarity minors that leverage RMIT’s areas of teaching and/or research strength.
#### Majors
(42)  Majors are an integrated set of courses that provide specialisation and/or a discipline/disciplinarity theme to the value of 96 credit points, or more if required by professional accreditation.
(43)  Majors may provide the focus, breadth, depth, and/or specialised knowledge, skills, and their application as required in a discipline or industry field of study.
(44)  When more than one major is offered in a program, the selection offers a complementary discipline, disciplinarity or industry field of study enabling both breadth and depth that considers:
  1. the use of the first year block to ensure a strong disciplinary starting point that supports expansion into cross/inter/trans-disciplinary learning for all students
  2. novel cross-disciplinarity combinations offered as a viable and unique alternative to traditional competitor double degrees.


(45)  Majors may contain both core courses and option courses to enable:
  1. assurance of program and award level learning outcomes
  2. enhanced student experience and choice.


(46)  Majors may culminate in a capstone experience.
(47)  Majors can be designed in tandem with other majors or curriculum structure blocks to incrementally address professional accreditation outcomes or to provide student choice.
For further guidance on types of majors, refer to the [CEID Resource Hub](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub).
#### Minors
(48)  Minors are a related set of two or more curated courses that provide specialisation or generic skills and knowledge on a single discipline, or disciplinarity theme to the value of 48 credit points.
(49)  Minors may provide the focus, breadth, depth, or specialised knowledge, skills and their application as required in a discipline or industry field of study.
(50)  When included alongside a major in a program, the minor offers complementary discipline, disciplinarity or industry field of study to enable breadth.
(51)  The availability of disciplinarity minors (inter/trans/cross-disciplinary) offered across RMIT will be curated and maintained as a defined suite by the colleges.
(52)  Minor pre-requisites are limited to allow for a broad suite of programs to offer the minor to students across disciplines.
(53)  Minors may contain both core courses and option courses to enable:
  1. contribution to program and award level outcomes
  2. enhanced student experience and choice.


(54)  Minors can be stacked together or with other curriculum structure blocks to support professional accreditation outcomes or to maximise student choice.
  1. For further guidance on types of minors, refer to the [](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub)[CEID Resource Hub](https://policies.rmit.edu.au/download.php?id=405&version=1&associated).
  2. Refer to the [Program and Course Configuration Instruction](https://policies.rmit.edu.au/document/view.php?id=41) for detailed structural requirements for majors and minors.


#### Industry Partnered Learning 
(55)  RMIT’s approach to embedding industry and connecting with professional communities in the curriculum structure is referred to as Industry Partnered Learning (IPL).
(56)  IPL experiences are designed in partnership with industry to be authentic and are a critical link between technical knowledge and real-world application. There are three types of IPL experiences:
  1. Work Integrated Learning (WIL)
  2. Career Development Learning (CDL)
  3. Industry Embedded Activities (IEA).


(57)  WIL is an educational approach that uses relevant work-based experiences to allow students to integrate theory with the meaningful practice of work as an intentional and assessed component of curriculum. Defining elements of this educational approach require that students engage in authentic and meaningful work-related tasks and must involve three stakeholders: the student, the University, and the workplace/community.
For requirements of WIL, including arrangements and responsibilities, refer to the [Program and Course Work Integrated Learning Procedure](https://policies.rmit.edu.au/document/view.php?id=119).
(58)  CDL provides students with the knowledge, skills, and capabilities to manage their career development throughout their life. Scaffolded in programs via linkages with other IPL/WIL and/or RMIT Capabilities it contextualises and supports student reflection of their learning and application to career development.
  1. CDL is a developmental process and must be scaffolded across early, mid and the late stages of a program according to the [CDL Framework](https://www.rmit.edu.au/content/dam/rmit/au/en/staff/documents/teaching-and-supporting-students/career-development-learning/career-development-framework-cdl.pdf).
  2. Evidence of scaffolded CDL must be provided in relevant Course Guides and through course learning outcomes and assessment activities.


(59)  IEA incorporate perspectives from industry and community partners in the curriculum through activities that fall outside the scope of WIL, such as guest industry lectures and panels, industry nights and networking events, industry co-designed or guided assessments, mentorships and joint research projects. In their capacity to inform aspects of career planning and management, these activities gain strength when incorporated into CDL-focused assessments.
(60)  In addition to the WIL minimum credit point requirements, award types shown in Table 1 to require IPL experiences may embed CDL, IEA or additional WIL through inclusion of:
  1. one IPL experience in the first year block or first year of a program (equivalent to 3 credit points)
  2. one IPL experience in a minor or second year of a program (equivalent to 3 credit points)
  3. two IPL experiences in a major or final year of program (equivalent to 6 credit points).


(61)  The IPL minimum credit point requirements can be met as part of an existing or new course of greater credit point value, such as an assessment worth 25% and a course learning outcome in a 12 credit point course.
  1. The IPL minimum credit point requirements can be embedded across multiple courses of greater credit point value.


For guidance on scaffolding and types of CLD, what constitutes an IPL experience and relevant credit types, refer to the [CEID Resource Hub](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub) and [CDL staff webpage](https://www.rmit.edu.au/staff/teaching/student-employability/career-development-learning/build-cdl-curriculum).
#### Capstone Experiences and Program Capstones
(62)  Programs at AQF level 6 and above, other than undergraduate certificates, advanced diplomas, one-year honours, graduate diplomas and graduate certificates, have courses that include a capstone experience. 
(63)  Capstones are a culminating course, or several related courses, that integrate all learning outcomes of a program into a coherent assessable experience. Including IPL forms an educational approach that provides the culmination of knowledge, skills and applied work practice into an integrated experience that prepares students for their transition into real world professional practice.
For further guidance on types of capstones, refer to the [CEID Resource Hub](https://rmiteduau.sharepoint.com/sites/CEIDResourceHub).
(64)  Capstone experiences can be embedded as a core requirement in the major sequence/s and/or another core curriculum structure block in the program and must be a minimum of 12 credit points.
  1. Courses with capstone experiences include summative assessment tasks that evidence all program level learning outcomes and RMIT Capabilities.
  2. Capstone experiences may or may not include WIL.
  3. More than one course may contribute to the capstone summative assessment experience requirement of 12 credit points. If this occurs the summative assessment tasks that contribute to the capstone experience must be clearly identified in each course guide.


(65)  Programs with a capstone experience should be sequenced so that the capstone is properly supported by formative learning experiences. This may occur through:
  1. use of a touchstone to provide an introduction and preparatory knowledge, skill, and practice context for the capstone
  2. completion of foundational or preparatory courses as part of the major/s or other core curriculum structure block in the program.


#### Coursework Involving Travel
(66)  Coursework may involve travel away from students’ primary location of study of the course offering, to complete assessment tasks. This travel may be a requirement of the course or course offering, or it may be an option available to some students in the course or course offering. 
For information to be provided to students in such courses, see [Travel Procedure – Student](https://policies.rmit.edu.au/document/view.php?id=108). 
### Higher Education Coursework Program Design for Undergraduate Awards
#### Undergraduate Certificate
(67)  Undergraduate Certificates support community and industry need by providing a short award program that may be used as a standalone qualification, professional upskilling, enablement of lifelong learning and/or as an articulation pathway into a higher-level award program.
(68)  Undergraduate Certificates are normally designed as a nested award comprising courses from:
  1. the first semester of the parent Bachelor Award program, and/or
  2. a 48 credit point set of courses such as from the first-year block, minor or major sequence that is advantageous for supporting a student articulation pathway into a higher award.


(69)  Courses selected as part of the Undergraduate Certificate must not have pre-requisites or assumed knowledge requirements.
(70)  The Undergraduate Certificate will:
  1. lead to outcomes with demonstrated industry demand as a standalone qualification
  2. facilitate articulation or credit transfer between vocational and higher education qualifications as flexible entry/exit points
  3. be designed to provide 48 credit points into undergraduate programs with an articulation agreement
  4. demonstrate program learning outcomes that may meet AQF level 5, 6 or 7 requirements 
  5. equate to 0.5 years full-time study, 48 credit points or approximately 600 hours of student workload.


#### Higher Education Diploma
(71)  Higher Education Diplomas demonstrate understanding and applied knowledge in integrated technical and theoretical concepts in a broad range of contexts.
(72)  Higher Education Diplomas are normally designed using courses from:
  1. the first year of the parent Bachelor and/or Associate Degree Award program, and/or
  2. a 96 credit point set of courses such as from the first-year block, minor or major sequence/s that are advantageous for supporting a student articulation pathway into a higher award. 


(73)  A Higher Education Diploma will:
  1. lead to outcomes with demonstrated industry demand as a standalone qualification
  2. facilitate articulation or credit transfer between vocational and higher education qualifications as flexible entry/exit points
  3. be designed to provide up to 96 credit points into undergraduate programs with an articulation agreement
  4. demonstrate program learning outcomes to meet AQF level 5 requirements 
  5. include at least 6 credit points of WIL and 3 credit points of IPL
  6. equate to 1 year full-time study, 96 credit points or approximately 1200 hours of student workload.


#### Associate Degree
(74)  Associate Degrees demonstrate underpinning technical and theoretical knowledge in a range of contexts for paraprofessional work or as a pathway to further learning.
(75)  Associate Degrees may be designed using courses from the first two years of a related Bachelor Award program, or may be designed to articulate into one or more related Bachelor degrees.
(76)  An Associate Degree will:
  1. lead to outcomes with demonstrated industry demand as a standalone qualification
  2. offer depth of study that is specifically aligned with industry, that may be vocationally focussed, as a first design principle
  3. facilitate articulation or credit transfer between vocational and higher education qualifications as flexible entry/exit points
  4. be designed to provide up to 192 credit points into undergraduate programs with an articulation agreement
  5. map to nationally recognised AQF level 4, 5 and 6 vocational qualifications for pathway, articulation and/or credit transfer and exit/entry points
  6. demonstrate program learning outcomes to meet AQF 6 requirements
  7. include a capstone experience and at least 12 credit points of WIL and 6 credit points of IPL
  8. provide students breadth in learning through offering at least 12 credit points of University elective and/or disciplinarity option courses
  9. equate to 2 years full-time study, 192 credit points or approximately 2400 hours of student workload
  10. where possible, provide students the opportunity of a global mobility experience.


(77)  To meet their intended purpose, Associate Degrees:
  1. closely align with industry needs through industry participation in design and delivery
  2. use relevant national industry and professional standards as reference points for the specification of program learning outcomes.


For the availability of credit from Associate Degrees towards Bachelor Degrees, and from Diplomas and Advanced Diplomas towards Associate Degrees, see the [Credit Procedure](https://policies.rmit.edu.au/document/view.php?id=37).
#### Bachelor Degree
(78)  Bachelor Degrees demonstrate application of a broad and coherent body of knowledge in a range of contexts, or integrate practice in a specialist field, to undertake professional work and as a pathway for lifelong learning.
(79)  Bachelor Degrees are normally designed with consideration of optimal combinations or specialisations with majors and minors that support professional opportunities or further learning.
(80)  Bachelor Degrees are designed to enable articulation and pathways from nested awards and/or from lower level awards in the same or related discipline area/s.
(81)  The Bachelor Degree will:
  1. lead to career outcomes demonstrated through industry demand and co-design
  2. facilitate pathways to further learning by research, industry placement and/or postgraduate study
  3. facilitate articulation opportunities with the maximum available credit transfer from lower level cognate qualifications, and offer flexible exit points for nested awards that meet relevant design requirements to the award level
  4. be designed to provide up to 192 credit points of credit transfer from lower-level undergraduate programs with an articulation agreement
  5. demonstrate program learning outcomes to meet AQF 7 requirements
  6. include a capstone experience and at least 24 credit points of WIL and 12 credit points of IPL
  7. provide students breadth in learning through offering at least 24 credit points of University electives and/or a cross-discipline major/minor
  8. equate to 3 years full-time study, 288 credit points or approximately 3600 hours of student workload
  9. provide students the opportunity of a global mobility experience except where professional accreditation requirements mean that this cannot be accommodated in the program structure. 


#### Bachelor Honours Degrees
(82)  Bachelor Honours Degrees demonstrate the application of knowledge and skills in a specific context. This can include planning and executing a significant research project and/or project work with some independence to undertake professional or highly skilled work and/or as a pathway to research and lifelong learning.
(83)  A Bachelor Honours Degree may be designed:
  1. as a 1-year, 96 credit point Bachelor Honours Degree to be taken after successful completion of the 3-year Bachelor Degree, or
  2. as an embedded 4-year Bachelor Honours Degree where it fulfills requirements as an AQF 7 Bachelor award and an AQF 8 Bachelor Honours award.


(84)  The Bachelor Honours Degree will:
  1. lead to highly skilled outcomes demonstrated through industry demand and co-design
  2. facilitate pathways to further learning by entry to higher degrees by research, industry placement and/or postgraduate coursework study
  3. demonstrate program learning outcomes to meet AQF 8 requirements
  4. include a research component of at least 36 credit points, and
  5. equate to 1-year full-time study, 96 credit points or approximately 1200 hours of student workload as a 1-year Bachelor Honours, or
  6. equate to 4-years full-time study, 384 credit points or approximately 4800 hours of student workload as a 4-year Bachelor Honours.


### Higher Education Coursework Program Design for Pathways, Nested and Exit Awards
(85)  The maximum number of entry and exit points are documented for all programs in the program guide information.
(86)  Where possible, programs are designed to consider the ability to provide non-award study pathways.
(87)  Cognate qualifications at different AQF levels are nested where possible and designed in tandem to ensure that students acquire the skills to succeed in the higher award program.
(88)  Pathways into cognate qualifications within a nested program suite are guaranteed for RMIT graduates, except where professional accreditation restricts entry requirements.
(89)  Where possible, when a lower-level award fulfils a subset of the requirements for a higher award, the lower award is nested within the higher award, and students may opt to exit the program with the lower award. See the [Conferral and Graduation Procedure](https://policies.rmit.edu.au/document/view.php?id=9) for more details.
(90)  The program learning outcomes for any nested or exit awards must be suitably differentiated to map to the AQF Learning Outcome Descriptors conferred by each respective award level.
(91)  For articulation agreements, refer to the [Articulation Agreements Guideline](https://policies.rmit.edu.au/document/view.php?id=129).
#### Integrated Awards
(92)  In program design, consideration is given to opportunities for dual VET/HE integrated awards.
(93)  Where it has been identified as advantageous to students, VET qualifications are incorporated into HE program design and marketed transparently.
#### Recognition of Prior Learning and Credit Transfer
(94)  Program design should consider how recognition of prior learning and credit transfer processes can be provided in a rigorous and generous manner, using the following equivalences for RMIT cognate disciplines as a basis:
  1. Diploma (96 credit points block credit)
  2. Advanced Diploma (192 credit points block credit)
  3. Associate Degree (192 credit points block credit).


Refer to the [Credit Procedure](https://policies.rmit.edu.au/document/view.php?id=37) for further information.
### Higher Education Coursework Program Design for Double Degrees and Joint Awards
#### Double Degrees
(95)  A double degree combines the curriculum of two existing Bachelor programs. 
(96)  Credit points and volume of learning for double degrees are determined when the program learning outcomes of the two programs are delivered in a single structure.
  1. The volume of learning for an AQF 7 Bachelor double degree program is a minimum of 384 credit points and typically a duration of 4-5 years full-time.
  2. The credit points and volume of learning may be higher where one or both single degrees are an AQF 8 Bachelor honours award.


(97)  The curriculum design of a double degree states the program learning outcomes of both component single degrees. 
  1. Where appropriate, a single set of integrated program learning outcomes equivalent to the individual program learning outcomes for the two component single degrees may be used.
  2. The program structure includes all core program requirements of both component single degrees. 
  3. The program structure in a Bachelor double degree offers a minimum of 192 credit points from each component single degree.
  4. The Deputy Vice-Chancellor Education may approve exemptions where all core program requirements of both component single degrees are fulfilled, with a higher number of credit points required to meet professional accreditation requirements and/or a higher AQF level for a component single degree.


(98)  Cross credit in a double degree can be granted for courses where:
  1. the course is a University elective or cross-disciplinary minor option
  2. a core course in one of the component single degrees is assessed as equivalent curriculum content to a core course in the other component single degree that has been included in the double degree structure.


(99)  The program structure of a double degree should not require full-time students to overload by more than one course in any teaching period. It is recommended not to overload students in consecutive teaching periods. 
(100)  A double degree structure may include the first-year block from each component single degree, or a single first-year block where cross credit is available for courses in the first-year blocks of each constituent single degree. 
(101)  A double degree must have at least one capstone experience to meet each set of program learning outcomes, or at least one capstone experience to meet one set of integrated program learning outcomes.
(102)  WIL courses in a double degree provide the course learning outcomes of the designated WIL courses of each component single degree. The designated WIL courses in a double degree must meet the minimum 24 credit point requirement for the single Bachelor degree.
(103)  The IPL experiences in a double degree must meet the minimum 12 credit points requirement for the single Bachelor degree.
(104)  Where one or both of the component single degrees are an AQF 8 award level, the double degree includes a minimum 36 credit point research component.
(105)  The double degree program meets requirements for professional accreditation of the component single degrees where relevant. 
(106)  On successful completion of double degree requirements, students have attained the program learning outcomes of each of the two single Bachelor awards and are eligible to receive two testamurs.
#### Joint and Dual Awards
(107)  RMIT may enter into an agreement with an approved partner institution to deliver an award jointly or as a dual award. 
(108)  RMIT remains accountable for the program of study and must verify continuing compliance of the program of study with RMIT policies, procedures and relevant national standards.
(109)  The agreement with the partner defines operational and management responsibilities such as delivery and issuance of the award.
(110)  The academic standards of joint and dual awards must be evidenced as equivalent to those of awards conferred solely by RMIT.
#### Joint Awards
(111)  A joint award program is designed so that at least half of the required credit points are designed and delivered by RMIT University.
(112)  Upon successful completion of a joint award, students receive a single testamur with the name of both providers that are awarding the single qualification.
#### Dual Awards
(113)  A dual award Bachelor or Bachelor honours program must meet the design requirements of a double degree program.
(114)  Upon successful completion of a dual award, students receive a separate testamur and separate qualification from each provider.
### Higher Education Coursework Program Design for Postgraduate Awards
(115)  The [Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126) provides details for reductions in the volume of learning based on prior completion of AQF awards at level 7 or above. Refer to the [Credit Procedure](https://policies.rmit.edu.au/document/view.php?id=37) for further information on Masters Advanced Standing and cognate entry.
#### Graduate Certificate and Graduate Diploma
(116)  Graduate Certificates and Graduate Diplomas demonstrate focused development of knowledge and skills to advance an area of expertise, or to build foundational knowledge at an advanced skill level in a new discipline. They are designed for graduates to undertake highly skilled work and as a pathway to further postgraduate study and lifelong learning.
(117)  Graduate Certificates and Graduate Diplomas are normally designed as a nested award using courses from the first year of the parent Masters program.
(118)  A Graduate Certificate must:
  1. lead to professional and/or highly skilled career outcomes demonstrated through industry demand and co-design
  2. be designed to provide 48 credit points as advanced standing into the parent Masters program/s
  3. demonstrate program learning outcomes to meet AQF 8 requirements
  4. include at least 3 credit points of IPL
  5. equate to 0.5 year full-time study, 48 credit points or approximately 600 hours of student workload.


(119)  A Graduate Diploma must:
  1. lead to professional and/or highly skilled career outcomes demonstrated through industry demand and co-design
  2. be designed to provide 96 credit points as advanced standing into the parent Masters program/s
  3. demonstrate program learning outcomes to meet AQF 8 requirements
  4. include at least 12 credit points of WIL and 3 credit points of IPL
  5. equate to 1-year full-time study, 96 credit points or approximately 1200 hours of student workload.


#### Masters by Coursework
(120)  A Masters by coursework demonstrates advanced and integrated understanding of a complex body of knowledge in one or more disciplines and skills for research and/or highly skilled professional practice, and offers a pathway to lifelong learning.
(121)  A Masters by coursework equates to 2-years full-time study, 192 credit points or approximately 2400 hours of student workload.
  1. A Masters by coursework program may be designed to allow different entry points based on the [Credit Procedure – Masters Advanced Standing](https://policies.rmit.edu.au/document/view.php?id=127).
  2. The volume of learning may be reduced to suit the program entry requirements, based on the Masters Advanced Standing Credit Point Values defined in the [Credit Procedure – Masters Advanced Standing](https://policies.rmit.edu.au/document/view.php?id=127).


(122)  A Masters by coursework must be designed to include, irrespective of entry point:
  1. progression to advanced professional and/or career outcomes demonstrated through industry demand and co-design
  2. program learning outcomes with at least 96 credit points that meet AQF 9 requirements
  3. a capstone experience and at least 12 credit points of WIL and 6 credit points of IPL
  4. at least 12 credit points of research principles and research methods
  5. at least 12 credit points of independent research, project work, practice-related learning, or an equivalent piece of scholarship.


(123)  To constitute a research pathway, a masters by coursework must provide students with the option of completing a research component comprising at least 24 credit points of courses that meet AQF level 9 requirements. 
#### Masters by Coursework (extended)
(124)  Masters by coursework (extended) demonstrates advanced and integrated understanding of a complex body of knowledge in one or more disciplines, skills for research, a significant proportion of practice-related learning, and offers a pathway to lifelong learning.
(125)  The Masters by coursework (extended) must:
  1. lead to advanced professional outcomes demonstrated through industry demand and co-design
  2. demonstrate program learning outcomes with at least 96 credit points deemed to meet AQF 9 requirements
  3. include a capstone experience and at least 24 credit points of WIL and 6 credit points of IPL
  4. include at least 12 credit points of research principles and research methods
  5. include at least 12 credit points of independent research, project work, practice-related learning, or an equivalent piece of scholarship
  6. equate to 3-years full-time study, 288 credit points or approximately 3600 hours of student workload.


(126)  To constitute a research pathway, a masters by coursework (extended) must provide students with the option of completing a research component comprising at least 24 credit points of courses that meet AQF level 9 requirements. 
#### Research Pathways for Higher Education Disciplines 
(127)  Each discipline that offers programs at Bachelor level or higher will offer an appropriate program with the option of undertaking a research component of at least 24 credit points, as a pathway to higher degree by research study in the discipline. 
### Higher Education Coursework Program Design Award Titles and Configuration Requirements
#### Award Titles
(128)  Award titles are consistent with the requirements of the [AQF Qualifications Issuance Policy](https://policies.rmit.edu.au/download.php?id=407&version=1&associated) and RMIT [Awards Regulations](https://policies.rmit.edu.au/document/view.php?id=191). Refer also to the [Schedule of award title abbreviations](https://www.rmit.edu.au/content/dam/rmit/documents/about/policy/program-course/award-title-abbreviations.pdf). 
#### Configuration
(129)  Refer to the [Program and Course Guide Instruction](https://policies.rmit.edu.au/document/view.php?id=203) for information that must be accurately provided in program and course guides as part of curriculum design requirements.
(130)  Programs are named based on the first-year block with majors in brackets where appropriate.
  1. Consideration is given to naming the specialisation, such as a discipline or sub-discipline, in the program title stem in exceptional cases that are justified by evidence of industry/market demand or operational requirements (for example, professional accreditation requirements).


(131)  Majors are cited on testamurs and transcripts.
(132)  Detailed requirements for configuration of programs, program plans, program titles, awards, majors and minors, courses, course offerings, course requisites and classes are determined by the Academic Registrar's Group and documented in the [Program and Course Configuration Instruction](https://policies.rmit.edu.au/document/view.php?id=41). 
(133)  Courses required to complete a defined program structure and any major sequence offered in the program structure must be scheduled so that students can complete the courses in the appropriate sequence and within the defined standard program duration.
(134)  The same or equivalent core or compulsory curriculum structure blocks are required for a program in any location where the program is offered, except where additional core courses are necessary to satisfy a national registration requirement or local external professional or discipline accreditation requirement. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=202&version=1#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Articulation | A defined pathway that enables a student to progress from a completed course of study to another course of study with admission and/or credit.  
Award | A qualification that is conferred on a student upon successful completion of a program of study. Includes a degree, diploma, certificate, licence, honorary degree or other award.  
Award Program | A program that may lead to an award as defined by the policies and objectives of the Australian Qualifications Framework (AQF).  
Block credit | Credit granted towards whole structural components of a program leading to a qualification.  
Cognate | A closely related discipline or branch of study defined at program level to support the development of pathways in program design and recognition of prior learning.  
Contextualisation | The adaptation of one or more elements in an offering to increase its cultural, personal, professional and global relevance to students.  
Core course | Mandatory courses for students that are identified as containing the curriculum required to achieve the award program and any specified major and/or minor they appear in.  
Coursework course | Any course in a coursework program, or course in a higher degree by research program that is not a research component. Coursework courses lead to the acquisition of skills and knowledge that do not include research skills and knowledge.  
Coursework program | A type of program that is not a higher degree by research program focused on a single research project, but rather comprises a variety of courses each with several assessment tasks. Also, any course in a coursework program that is not a research component of an HDR program.  
Credit points | A measure of student workload represented by a numerical value that is assigned to units of learning, structural components and curriculum structure blocks to help support pedagogical rationale on volume of learning at program level.  
Cross credit | Where a course is able to be credited towards more than one award program.  
Curriculum structure block | Consistently sized units of learning with distinct credit point structures that when combined form a program.  
Discipline | A single defined branch of study in an academic or industry field.  
Disciplinarity | Learning that spans disciplines incorporating but not exclusive of: Cross-disciplinarity: Parallel study undertaken in two or more disciplines (for example, double major from two different disciplines) Interdisciplinarity: Integrated study undertaken in two or more disciplines (for example, combined degree). Transdisciplinarity: Problem based learning that spans two or more disciplines (for example, combined degree with combined IPL).  
Disciplinarity course | A course that is sharable for inclusion outside of its primary discipline in a major and/or minor sequence, such as disciplinarity minors, and must be listed in the program’s structural components.  
Exit award | An award for which the requirements are a subset of the requirements for a higher, parent award; students enrol in the parent award but may choose to exit with the lower award; exit awards are said to be “nested” within the higher program.  
Guaranteed pathway | A pathway for which RMIT publishes a commitment that applicants who successfully complete the program will be offered a place in an RMIT program or programs; applicants may be required to achieve minimum scores.  
Integrated | Purposefully designed award programs that enable explicit articulation pathways and encompass more than one AQF level and/or qualification type and/or education and training sector (i.e. HE/VET).  
Learning outcomes | The set of knowledge, skills and the application of the knowledge and skills a student is expected to have achieved in the courses (referred to as course learning outcomes) and in their program (referred to as program learning outcomes) on successful completion.  
Nested | Awards with articulation arrangements where the lower level award comprises a subset of the requirements for a higher level AQF award. A nested award may also be referred to as an ‘exit award’.  
Non-award course | A course in which a student enrols without being admitted to a program, which does not lead to an award.  
Non-award program | A program that enables students to enrol in courses but which does not lead to a qualification.  
Option course | A course that a student can choose that is listed in the program structure, major and/or minor sequence. Students may be required to complete a specified number from a suitably curated list for equivalent contribution to the award program.  
Pathway | A set of entry requirements that will be predefined by RMIT that will include either: one or more programs at RMIT or another institution; or a set of study or learning outcomes and will allow a student to move to a higher qualification level with or without a standard grant of credit.  
Primary discipline | The main discipline area of a program, identified by the grouping of shared learning or scholarly instruction, knowledge and skills into a single defined branch of study by the owning school or college, or the Australian Standard Classification of Education (ASCED) code of the major and/or minor, or by the first-year block in an award program.  
Sequence | A structured group of courses that share learning or scholarly instruction, knowledge and skills, and is taken across a program in an optimal order to scaffold study and/or address any identified requisites. The optimal order to scaffold study may be identified using foundation, intermediate, and advanced categorisation of courses.  
Structural component | The units of learning, micro-credentials and blocks in the form of first year, capabilities, capstones, minors and/or majors that form a program.  
Student workload | The sum of all supervised (nominal in VET) and unsupervised (learner directed) hours.  
Touchstone | An introductory course that prepares students for their final year capstone. It is an integrated educational approach that provides the foundation and context of knowledge, skills and applied work practice and should include career development learning (CDL).  
Sub-discipline | Further specialisation within a single discipline that relates to the academic or industry field.  
Unbundling | A process in which the structural components (e.g. first year block/major/minor/capstone/IPL/ credentials) of a program are designed in a way that facilitates the option to separate them into their individual components without losing the integrity to measure the outcomes at the relevant AQF level identified in the units of learning.  
Unit of learning | A measurement of learning using credit points and must be at least 1 credit point minimum.  
University elective | A course that is not specifically listed in the program structure that a student may choose from at RMIT to contribute credit points to complete their award program.  
Volume of learning | A measure of learning that is defined by duration represented in equivalent full-time years, depth and breadth of activity in the form of student workload (made up of all teaching, learning and assessment activities to be undertaken by a full-time student), and the required AQF level and award outcomes for the program.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
