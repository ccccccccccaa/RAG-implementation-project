[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=102&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=102&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Honorary Appointments Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=102)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=102&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=102&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=102&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=102&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=102&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=102&version=3)


# Honorary Appointments Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section4)
  * [Eligibility](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major1)
  * [Nomination for Emeritus Professor and honorary, adjunct, visiting and associate appointments](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major2)
  * [Approval of Emeritus Professor appointments](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major3)
  * [Approval of honorary, adjunct, visiting and associate appointments](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major4)
  * [Confidentiality](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major5)
  * [Offer and Acceptance of Offer](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major6)
  * [Visa Requirements for International Visiting Academics](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major7)
  * [Notice of expiring appointments](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major8)
  * [Appointment extension](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major9)
  * [Appointment transition](https://policies.rmit.edu.au/document/view.php?id=102&version=3#major10)
  * [Section 5 - Reporting](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section6)
  * [Section 7 - Related policy](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section7)
  * [Section 8 - Resources](https://policies.rmit.edu.au/document/view.php?id=102&version=3#section8)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure details all requirements and general conditions for honorary appointments at RMIT University. Academic Affiliate is the terminology used in Workday for honorary appointee.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=102&version=3#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Honorary Appointments Policy](https://policies.rmit.edu.au/document/view.php?id=101).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=102&version=3#document-top)
# Section 3 - Scope
(3)  This procedure applies to any individual who may be considered for or conferred an honorary title established under the [Titles Regulations](https://policies.rmit.edu.au/document/view.php?id=197).
(4)  This procedure does not cover:
  1. current employees on a fixed term or continuing contract
  2. academic staff visiting from other national or international institutions who receive payment for their service and are sponsored on a Temporary Skill Shortage (482) visa or subsequent replacement
  3. Vice-Chancellor’s Innovation Professors, who remain subject to the provisions of the [Honorary Appointments Policy](https://policies.rmit.edu.au/document/view.php?id=101) as at the time of their original appointment
  4. recipients of other Honorary Awards conferred by RMIT University Council including Honorary Degrees.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=102&version=3#document-top)
# Section 4 - Procedure
### Eligibility
(5)  Individuals must meet the eligibility criteria as established under the [Honorary Appointments Policy](https://policies.rmit.edu.au/document/view.php?id=101).
### Nomination for Emeritus Professor and honorary, adjunct, visiting and associate appointments
(6)  Nominations must be endorsed by the Dean or Director of Centre or Institute (or equivalent). Nominations must be submitted through the [Service Request](https://rmititsm.service-now.com/sp?id=service_request_portal) form (or equivalent) and be supported by the following information:
  1. An account of the nominee’s area of expertise, how they meet the eligibility criteria for appointment, and a current CV or relevant professional background listing, such as a LinkedIn profile.
  2. A summary of the role and benefit to school, centre, department, college or portfolio and the University. This must include: 
    1. the proposed duties and responsibilities for the nominee (for visiting academics please outline the objective of the proposed visit or details about the research project the visitor will be involved in)
    2. how the appointment will advance the University’s contribution to research, education, engagement or community or the University’s links with industry or government, and
    3. the benefits that will flow through from the appointment to the college, portfolio, school, centre or department.
  3. Details of University facilities and systems to which the appointee will require access.
  4. Details of any financial expenses that will be met by the school, centre, department (if relevant), which may include the required visa and an approximation of associated costs (travel and accommodation support).


(7)  A nomination for a fixed-term appointment must include the period of appointment in the nomination as follows:
  1. Visiting Academics: Not less than three (3) months in duration and not exceeding two (2) years for any one visit, subject to visa requirements
  2. All other fixed-term honorary appointments including honorary, adjunct academic and adjunct industry appointments: an initial period of up to three (3) years, renewed for further period(s) of up to three (3) years.


(8)  The following nominations require additional supporting documentation and endorsements: 
Honorary title | Additional supporting documentation and endorsements required when nomination is submitted  
---|---  
Emeritus Professor | • Endorsement by at least two professors of the University including the relevant Deputy Vice-Chancellor • Where the nominee is a Deputy Vice-Chancellor, endorsement of another Deputy Vice-Chancellor is required.  
Honorary Professor Honorary Associate Professor  Honorary Fellow | • Must normally have three references, one of which must be from a Professor (HE) or Senior Educator (VE) or Director (professional staff) of the University, as relevant. However, if the nominee has been employed on a fixed term or continuing basis by RMIT for the previous three (3) years, no references are required. • In addition, endorsement by a Professor (HE), Senior Educator (VE) or Director (professional staff) of the University, as relevant.  
Adjunct academics: Adjunct Professor Adjunct Associate Professor Adjunct Senior Fellow Adjunct Fellow Adjunct Associate | • Must normally have three external references, including one from a Professor. However, if the nominee has been employed on a fixed-term or continuing basis by RMIT for the previous three years, no references are required • In addition, endorsement by a Professor of the University for nominations for Adjunct Professor or Adjunct Associate Professor, or at least an Associate Professor of the University for nominations for other adjunct academic titles apart from Adjunct Associate.   
Industry adjuncts: Adjunct Industry Associate Professor Adjunct Senior Industry Fellow Adjunct Industry Fellow Adjunct Industry Associate  | • Must normally have three external references from experts in the field • In addition, Professor endorsement for Industry Associate Professor or; Associate Professor endorsement for Senior Industry Fellow and Industry Fellow.   
International Visiting Academic Visiting Professor Visiting Associate Professor Visiting Senior Fellow Visiting Fellow | • Must include a statement to demonstrate a significant record of achievement in their field, which is established if a nominee provides evidence that their research has been published in reputable academic journals or other serial publications. • In addition, the name, relationship and date of birth of any family members who will accompany the nominee during their proposed stay must be provided.   
### Approval of Emeritus Professor appointments
(9)  A committee will be established comprising the Vice-Chancellor (Chair), Deputy Vice-Chancellor or the Chair, Academic Board (or professorial nominee), and a professor with disciplinary expertise. The committee will be guided in its deliberations by the criteria specified in [Schedule 1](https://policies.rmit.edu.au/download.php?id=358&version=2&associated) of the [Honorary Appointments Policy](https://policies.rmit.edu.au/document/view.php?id=101).
(10)  The committee may seek further supporting information about the nominee from the Deputy Vice-Chancellor of the college or portfolio, the Dean or Director of Centre or Institute (or equivalent), or from other persons.
(11)  If the committee determines that the criteria has not been met, it will notify and provide feedback to the nominator. If the committee determines that the criteria has been met, its written decision will be attached as a record in the Workday request.
### Approval of honorary, adjunct, visiting and associate appointments
(12)  The relevant Deputy Vice-Chancellor (or Dean/Director in Vietnam) will consider the nomination and determine if the nomination meets the criteria specified in [Schedule 1 – Honorary Appointments](https://policies.rmit.edu.au/download.php?id=358&version=2&associated). 
(13)  The Deputy Vice-Chancellor may seek further supporting information about the nominee from Dean or Director of Centre or Institute (or equivalent) or from other persons.
(14)  If the Deputy Vice-Chancellor determines that the criteria have not been met, the Academic Partner will be notified. The Academic Partner will be responsible for informing the nominator. 
### Confidentiality
(15)  All nominations must be treated in strictest confidence by all persons involved in the process. The appropriate Security Classification levels in the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53) should be applied to all data.
(16)  In the case of the conferral of titles Emeritus Professor:
  1. Nominations must be submitted to the Committee without the knowledge of the nominated person. The person nominated must not be notified unless the nomination has been approved by the Committee.
  2. If the Committee approves the nomination, the People team must ascertain whether the nominee is willing to receive the award.
  3. If the nominee is willing to receive the award, the People team will prepare written advice to the nominee on behalf of the Committee Chair.
  4. A request for an official certificate should be made by the People team to the Academic Registrar who will prepare an official certificate.
  5. The award of Emeritus Professor will normally be conferred by the Deputy Vice-Chancellor at a ceremony unless alternative arrangements are made by the nominating Dean or Director of Centre or Institute (or equivalent).


### Offer and Acceptance of Offer
(17)  Upon approval from the delegated authority, the People team will confirm the award or appointment in writing. The letter of offer must contain (as appropriate):
• the nature of appointment
• the organisational unit within which the appointee will work
• the duration of the appointment
• the supervisor of the appointee
• the duties of the position
• the support given to appointee
• entitlements and obligations
• the ownership of intellectual property
• any special conditions relating to the appointment (including visa, insurance)
• if a visiting academic is being sponsored, health insurance obligations that the appointee must adhere to.
(18)  The People team must conduct the following verification checks where appropriate:
• Police checks 
• Working with Children checks
• Verification of qualifications and/or certifications 
• Australian Working Rights check 
• Sanctioned country screening and assisting the hiring manager with the sanctions process when relevant
• Any other verification of mandatory requirements. An offer may be subject to the successful completion of these checks.
(19)  An honorary appointee must provide their acceptance of the offer and the conditions of appointment and other relevant paperwork to the People team prior to commencement.
### Visa Requirements for International Visiting Academics
(20)  A minimum appointment length of three (3) months, in line with RMIT Visa Sponsorship requirements applies to International Visiting Academics. Any Visiting Academics that do not meet this minimum appointment time frame can be managed through the Visiting Researcher identity management (IDM) process and do not require a Visa under RMIT sponsorship.
(21)  The People team may provide visa support in obtaining an appropriate visa if required, subject to eligibility and approval. All costs associated with visa processing will be charged back to the local area submitting the request.
(22)  It is a requirement of the [Department of Home Affairs](https://policies.rmit.edu.au/download.php?id=129&version=1&associated) that visa holders must demonstrate at the point of visa application that they have purchased comprehensive health insurance prior to their visa application being submitted.
(23)  Evidence of an international visiting academic’s visa grant notice must be provided to the Talent team prior to the commencement date of the appointment in order to have the appointment and system access finalised.
(24)  International visiting academics on visiting visas may not undertake any form of paid work, without prior application and approval to vary their visa.
### Notice of expiring appointments
(25)  Academic Partners will receive notifications of expiring honorary appointments 90 days, 45 days and 10 days prior to expiration. Where relevant, the Academic Partner will contact the Dean or Director of Centre or Institute (or equivalent) to initiate the extension process. 
(26)  Honorary appointees will receive a notifications 90 days, 45 days and 10 days prior to the expiration of their appointment. Honorary appointments that have a formal end date and are not renewed will expire at the end of the term. 
### Appointment extension
(27)  All fixed term honorary appointments may be extended, except Visiting Academics where the maximum visa period has already been granted.
(28)  Extension of an honorary appointment is by application via the Service Request form (or equivalent) and must be made prior to the expiration of the current term of appointment. The extension should be initiated at least three months prior to the expiration of the current appointment.
(29)  Extension applications are to be provided to the approval authority, with a statement addressing how the school, college, portfolio (or equivalent) has realised the expected benefits from the appointment, and any change to the duties or terms of appointment. 
(30)  If the appointment is approved for extension, the offer and acceptance of offer, as outlined in clauses 15 and 16, will be followed.
(31)  Where an individual previously held an honorary appointment, which was ended due to a transfer to employment, the honorary appointment may be reinstated by request through the Academic Partner. The Academic Partner will update the appointment in Workday. This should be actioned before the end of employment. In these circumstances, no CV, new references and endorsements are required. 
(32)  Renewal of an honorary appointment following a break in service (honorary or employed on a fixed-term or continuing basis) must be made via a new nomination. Where the break in such service is less than three (3) months, no new references are required (where relevant).
### Appointment transition
(33)  For fixed-term honorary appointments, the Dean (or equivalent) may determine that a different honorary title is more appropriate for the individual based on their circumstances, experience and/or scholarship and the definition, purpose and eligibility of the title. Where this occurs, a new nomination form should be submitted for that alternative honorary title. 
(34)  Where the alternative honorary title is at a higher level, the focus of the new nomination will be on achievements since the award of the current honorary title, including evidence of an upward trajectory. 
(35)  Where the alternative honorary title is Emeritus Professor, the nominee’s full contribution to the University will be considered including contributions during periods of employment and as an honorary appointee.
(36)  If the nomination process for the new honorary title requires references, these may be waived if the break between appointments is less than three (3) months.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=102&version=3#document-top)
# Section 5 - Reporting
(37)  The People team collect demographic information for all honorary appointments. On an annual basis, this information will be provided to the school/college/portfolio (or equivalent) to conduct a review of their current and upcoming appointments. The review should consider the diversity of honorary appointments and aim to identify areas of opportunity, if any.
(38)  The Academic Partners will provide quarterly reports to the Dean or Director of Centre or Institute (or equivalent). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=102&version=3#document-top)
# Section 6 - Definitions
Academic Partner |  Academic Partner refers to the planning and resources contact within the college/portfolio who will work with the People team to process the nomination or extension of an honorary or visiting academic affiliate. The Academic Partner will process the requests in Workday. The list of Academic Partners can be found on the [Academic Appointment Nomination Extension form](https://rmititsm.service-now.com/sp?id=sc_cat_item&sys_id=c8aeb092dbb3145093ec42a01496198f).  
---|---  
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=102&version=3#document-top)
# Section 7 - Related policy
(39)  [Honorary Appointments Policy](https://policies.rmit.edu.au/document/view.php?id=101)
(40)  [Schedule 1 – Honorary Appointments](https://policies.rmit.edu.au/download.php?id=358&version=2&associated)
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=102&version=3#document-top)
# Section 8 - Resources
(41)  [Honorary Appointment Nomination/Extension form](https://rmititsm.service-now.com/sp?id=sc_cat_item&sys_id=c8aeb092dbb3145093ec42a01496198f).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
