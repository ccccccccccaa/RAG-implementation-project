[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=110&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=110&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Complaints Governance Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=110)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=110&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=110&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=110&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=110&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=110&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=110&version=2)


# Complaints Governance Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=110&version=2#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=110&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=110&version=2#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=110&version=2#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=110&version=2#major1)
  * [Complaint Handling Commitments](https://policies.rmit.edu.au/document/view.php?id=110&version=2#major2)
  * [Reporting and Governance](https://policies.rmit.edu.au/document/view.php?id=110&version=2#major3)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=110&version=2#major4)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=110&version=2#major5)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=110&version=2#section5)
  * [Section 6 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=110&version=2#section6)
  * [Section 7 - Definitions](https://policies.rmit.edu.au/document/view.php?id=110&version=2#section7)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  To promote a culture where complaints are welcomed as an important component of our commitment to an inclusive, professional and productive work, research and learning environment.
(2)  To establish the principles and governance framework that inform the RMIT Group's approach to complaint handling.
(3)  To ensure complainants are treated with procedural fairness and respect.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=110&version=2#document-top)
# Section 2 - Overview
(4)  A complaint is an expression of dissatisfaction with the RMIT Group’s policies, procedures, decisions, omissions, systems, quality of service or staff behaviour, where a response or resolution is explicitly or implicitly expected or legally required.
(5)  RMIT is committed to providing a safe, supportive and productive work, research and study environment and understands the importance of being accessible, prepared and willing to listen and committed to taking appropriate action where complaints arise.
(6)  RMIT University is a public institution established under Victorian law and stands on the unceded Aboriginal Country of the Kulin Nation. RMIT recognises and acknowledges the [Bundjil Statement](https://policies.rmit.edu.au/download.php?id=127&version=1&associated) that helps all RMIT staff to respectfully work, conduct research, live and study on Aboriginal Country. 
(7)  This policy aims to integrate the [Bundjil Statement](https://policies.rmit.edu.au/download.php?id=127&version=1&associated) into our way of receiving, managing and resolving complaints respectfully with good intent, fairness, transparency and accountability.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=110&version=2#document-top)
# Section 3 - Scope
(8)  The principles contained in this policy will inform complaint policies, procedures and activities across the RMIT Group and take precedence except where to do so may interfere with legislated requirements (see [Schedule 1 – RMIT Complaints Framework](https://policies.rmit.edu.au/download.php?id=122&version=4&associated)) for details on RMIT’s complaints mechanisms).
(9)  Controlled entities and subsidiaries are responsible for ensuring compliance with group policies as required.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=110&version=2#document-top)
# Section 4 - Policy
### Principles
(10)  RMIT is committed to protecting and promoting the welfare and wellbeing of all parties to a complaint throughout the complaints process including access to support services as appropriate.
(11)  RMIT will appropriately educate staff involved in complaints receipt and specifically in which certain complaints and complaint topics should be managed.
(12)  Complaints can be a valuable source of information about RMIT’s performance, service, culture, policies and processes. They may also assist RMIT to identify and address issues that could impact the safety and wellbeing of staff, students, and members of the community. RMIT will welcome complaints, with a focus on achieving a suitable outcome.
(13)  RMIT recognises that an effective complaints management process and a receptive and responsive complaint culture is critical to maintaining the University’s brand, reputation and trust, improving the student experience, research integrity and attracting and retaining quality staff.
(14)  RMIT will ensure that complaints are handled and resolved in a fair, consistent and timely manner for all parties involved.
(15)  RMIT will decide upon the most appropriate way to manage a complaint and will have a range of suitable processes available, and clearly documented for all parties to a complaint process.
### Complaint Handling Commitments
(16)  RMIT will take all reasonable steps in line with legislative requirements and policy to ensure the commitments documented in this policy are demonstrated during the complaints process.
#### Accessibility
(17)  RMIT will publish and publicise details about how to make a complaint for any member of the RMIT community or third party.
#### Conduct of Parties
(18)  All parties to a complaint are expected to act respectfully and with good intent.
(19)  Complainants are personally responsible and liable for the content of their complaints. Complainants must not provide information that they know to be inaccurate or misleading. Doing so may result in disciplinary action or, in extreme circumstances, be reported to the appropriate external regulatory body or the police.
(20)  The University may restrict access to its complaints service for complainants who act unreasonably.
#### Procedural Fairness
(21)  Each individual complaint will be treated on its merits, fairly and without bias or conflict of interest.
(22)  Subjects of a formal complaint investigation will be informed of the substance of any allegations made against them, to the extent it is possible to do so without compromising the health and safety of any known party. 
(23)  All parties will have the opportunity to be heard and respond to the substance of the complaint.
(24)  Complaint handlers and case managers will make all reasonable inquiries before making a decision or recommendation. Evidence and investigative actions, commensurate with the type of complaint, will be documented and stored in a secure manner in accordance with the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
(25)  Complaint outcomes will be clearly communicated to the relevant parties in an appropriate manner taking into consideration relevant legislated requirements and policies.
(26)  Complaints will be addressed without undue delay and where appropriate parties will be regularly updated on progress.
(27)  Complaint outcomes will provide details on any appropriate avenues for review.
#### Providing Protections and Support
(28)  RMIT will address all complaints in a sensitive manner. Where possible and in accordance with any relevant legislation, RMIT will protect the identity of the complainant and use all available measures to ensure documentation, oral representations and all other evidence is confined to appropriate persons on a ‘need to know’ basis.
(29)  Where issues of requested anonymity or limits to confidentiality may impact or impede the investigation process, or where a complainant’s identity may be revealed by the nature of the complaint, this will be discussed with the complainant.
(30)  Support may include, but is not limited to, a support person to attend meetings for reassurance and emotional support, representatives from the staff or student union, Ngarara Willim for Australian Indigenous and Torres Strait Islander staff or students, staff or student counselling services, privately sourced counselling services, Safer Community where appropriate, University Chaplaincy, or Student Legal Service or other support mechanisms as allowed by legislation.
(31)  RMIT will ensure that information obtained throughout the course of the complaint process is handled in accordance with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(32)  Complainants are expected to maintain confidentiality as a matter of fairness and may seek appropriate support from persons outside of RMIT or via professional services offered by RMIT or externally as appropriate. RMIT will take reasonable steps to protect all parties to a complaint from victimisation, unwarranted detrimental action or reprisals. Any RMIT employee or student found to have participated in unwarranted detrimental action may be the subject of disciplinary action.
#### Timeliness
(33)  Complaints will be investigated without undue delay.
(34)  Where a formal investigation or complex enquiry is required, the parties will be kept up to date on the progress of the matter and reasons for any delay where it is appropriate to do so.
#### Safeguarding and Wellbeing
(35)  Where there are concerns about risk or safety of any person related to the complaint, RMIT may take immediate action to remove or isolate individuals from the campus or immediate workspace while an investigation is carried out.
(36)  RMIT may take precautionary action to protect physical or non-physical assets, animals, RMIT’s reputation and the environment, or where required to preserve evidence, or comply with obligations lawfully placed upon RMIT by third parties.
#### Independent Review
(37)  RMIT staff and students who have raised a complaint and feel that the way it has been handled has not been fair, or has breached University policy or procedure, and who have exhausted all other relevant internal avenues, may raise their concerns with the Ombudsman as follows:
  1. For vocational education students, the Victorian Ombudsman
  2. For higher education students, the Victorian Ombudsman or the National Student Ombudsman
  3. For staff, the Victorian Ombudsman.


### Reporting and Governance
(38)  The Executive Director, Governance, Legal and Strategic Operations or delegate will provide a quarterly report on staff, student, and third-party complaints activity, actions and outcomes to Audit and Risk Management Committee. The report will contain:
  1. the number of complaints received in the period across staff, student, third-party and whistleblower categories; and
  2. an analysis of complaint data by type including trends, themes and root causes.


(39)  Where systemic failures are identified, recommendations for action will be made by the Executive Director, Governance, Legal and Strategic Operations (or their delegate) and executive owners will be identified, notified and assigned. Outcomes and actions will be tracked via this reporting mechanism.
(40)  An annual report on complaint activity will be submitted to RMIT University Council (Council).
### Responsibilities
(41)  RMIT’s people leaders and managers will promote a welcoming complaint culture and take action to address systemic issues arising from complaints data analysis.
(42)  The Chief People Officer or delegate will be responsible for ensuring that policies, procedures and resources for staff complaint management align with the principles of this policy.
(43)  The Deputy Vice-Chancellor Education or delegate will be responsible for ensuring that policies, procedures and resources for student and student-related complaint management align with the principles of this policy.
(44)  The Deputy Vice-Chancellor Research and Innovation or delegate will be responsible for ensuring that research-related policies, procedures and resources align with the principles of this policy.
(45)  The Associate Director, Central Complaints and Investigations will be responsible for complaints data gathering, analysis, reporting and training on matters related to compliance with this policy.
(46)  The Executive Director, Governance, Legal and Strategic Operations or delegate will be responsible for ensuring that procedures and resources for third-party complaint management align with the principles of this policy.
### Review
(47)  This policy is to be reviewed every three (3) years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=110&version=2#document-top)
# Section 5 - Schedules
(48)  This policy includes the following schedule(s):
  1. [Schedule 1 - RMIT Complaints Framework](https://policies.rmit.edu.au/download.php?id=122&version=4&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=110&version=2#document-top)
# Section 6 - Procedures and Resources
(49)  Refer to the following documents which are established in accordance with this policy:
  1. [Third-Party Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=111)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=110&version=2#document-top)
# Section 7 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Allegation |  A claim or assertion that someone has done something worthy of a complaint. Allegations are formulated as part of the formal complaints investigations process and are considered assertions until proven on the balance of probabilities.  
---|---  
Anonymity |  Where the identity of a complainant is not revealed to the respondent:
  1. as requested by the complainant; or
  2. in cases where the Executive Director, Governance, Legal and Strategic Operations or Chief People Officer deems it appropriate on the grounds of safety of the complainant or other persons.

In some cases a complainant’s identity may not be revealed to the Associate Director, Central Complaints and Investigations or to RMIT and this may limit the investigative actions that can be taken.  
Confidentiality |  Relative to complaints handling, confidentiality is where only those people who need to be made aware of the complaint for investigative or response purposes are involved. Parties to a complaint are should not discuss the matter with any other person other than appropriate support persons.  
Unreasonable conduct |  Includes but is not limited to:
  1. aggressive, rude or threatening behaviour, including the use of offensive or abusive language in communications;
  2. insisting on unreasonable or unattainable outcomes;
  3. issuing instructions and making demands about how a complaint should be managed;
  4. withholding information, misquoting others or selectively disclosing information, including making serious allegations, then declining to provide further information or evidence about the allegations;
  5. changing the substance of an existing complaint or re-phrasing allegations while the complaint is being managed;
  6. refusing to provide further clarification of issues raised upon request, particularly where large amounts of information are presented as part of the complaint; or
  7. repeatedly emailing or calling the University despite being advised not to do so because the subject matter of their complaint is currently being dealt with or has already been dealt with and resolved.

  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
