[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=189#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=189#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Dress Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=189)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=189)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=189)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=189)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=189)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=189)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=189)


# Academic Dress Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=189#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=189#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=189#minor2)
  * [Part B - ACADEMIC DRESS](https://policies.rmit.edu.au/document/view.php?id=189#part2)
  * [3. Occasions](https://policies.rmit.edu.au/document/view.php?id=189#minor3)
  * [4. Regalia](https://policies.rmit.edu.au/document/view.php?id=189#minor4)
  * [5. Indigenous Stoles](https://policies.rmit.edu.au/document/view.php?id=189#minor5)
  * [6. Specified Colours](https://policies.rmit.edu.au/document/view.php?id=189#minor6)
  * [Part C - REVOCATION OF REGULATIONS](https://policies.rmit.edu.au/document/view.php?id=189#part3)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to prescribe the academic dress to be worn by members of the University, and the occasions on which it is to be worn.
#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
## Part B - ACADEMIC DRESS
#### 3. Occasions
(3)  Academic dress is to be worn by members of the University when attending any of the following occasions:
  1. ceremonies for the conferral and granting of awards of the University
  2. any other formal occasion of the University for which the University specifies academic dress, and
  3. ceremonies of other institutions at which the wearing of academic dress is appropriate or requested.


#### 4. Regalia
(4)  Official Members:
  1. Chancellor Gown of black cloth with trimming of metallic gold lace with finer silver edging cord and bearing the coat of arms on each sleeve, red satin lining and a black velvet bonnet with gold trimming.
  2. Deputy Chancellor Gown of black cloth with trimming of metallic gold lace with finer silver edging, red satin lining and a black velvet bonnet with gold trimming.
  3. Vice-Chancellor Gown of black cloth with trimming of silver lace and bearing the coat of arms on each sleeve, red satin lining and a black velvet bonnet with silver trimming.
  4. President of an RMIT campus outside Australia Black gown with less silver metallic trimmings and a black velvet bonnet trimmed with a silver metallic cord and tassel.
  5. Member of Council The habit of their degree, or a gown of black cloth with fine gold metallic trim, red satin lining and a black trencher with gold trimming.
  6. Staff of the University The habit of their degree, or a gown of black cloth and a black cloth trencher if they are not a graduate of any university.


(5)  Academic Dress, by Award:
  1. Doctoral Degree Festal gown of black cloth similar to that worn by Doctors in the University of Oxford faced with scarlet silk together with a hood of scarlet cloth edged with scarlet silk and a black velvet bonnet with a scarlet tassel.
  2. Degree of Master of Research Festal gown of black cloth similar to that worn by Doctors in the University of Oxford faced with silk the colour of the discipline of the award together with a hood of black cloth edged with the same colour silk as the facing of the gown and a black velvet bonnet with a scarlet tassel.
  3. Higher Doctoral Degree Festal gown of scarlet cloth similar to that worn by Doctors in the University of Oxford faced with silk the colour of the discipline of the award together with a hood of black cloth lined with the same colour silk as the facing of the gown and a black velvet trimmed bonnet with a scarlet tassel.
  4. Masters Degree and Juris Doctor Black gown similar to that worn by Masters of Arts in the University of Oxford with a hood of black silk lined with silk the colour of the discipline of the degree and a black trencher with a black silk tassel.
  5. Bachelors Degree Black gown similar to that worn by Bachelors of Arts of the University of Oxford and a hood of black silk edged with white braid and lined with silk the colour of the discipline of the degree and a black trencher with a black silk tassel.
  6. Associate Degree Black gown similar to that worn by Bachelors of the University of Oxford and a black trencher with a black silk tassel and a square collared silk stole faced with silk the colour of the discipline of the award and edged with black braid.
  7. Graduate Diploma Black gown similar to that worn by Bachelors of the University of Oxford and a black trencher with a black silk tassel and a square collared black silk stole faced with silk the colour of the discipline of the award.
  8. Diploma and Advanced Diploma Black gown similar to that worn by Bachelors of the University of Oxford and a black trencher with a black silk tassel and a square collared silk stole faced with silk the colour of the discipline of the award and edged with white braid.
  9. Associate Diploma Black gown similar to that worn by Bachelors of the University of Oxford and a black trencher with a black silk tassel and an ecclesiastical black stole faced with silk the colour of the discipline of the award edged with white braid.
  10. Fellowship Diploma Black gown similar to that worn by Bachelors of the University of Oxford and a black trencher with a black silk tassel and a square collared black stole faced with coffee silk trimmed with white braid and then black braid.
  11. Associateship Diploma Black gown similar to that worn by Bachelors of the University of Oxford and a black trencher with a black silk tassel and a square collared black stole faced with coffee silk trimmed with white braid centred with black braid.
  12. Undergraduate certificate Black gown similar to that worn by Bachelors of the University of Oxford and a black trencher with a black silk tassel and a square collared black silk stole faced with silk in the colour of the discipline of the award.


(6)  The academic dress for enrolled students other than graduates and diplomates is a plain black gown similar to that worn by graduates of the University of Oxford.
#### 5. Indigenous Stoles
(7)  Indigenous graduands may wear a square collared black stole faced with Aboriginal or Torres Strait Island colours in conjunction with their graduation gowns.
#### 6. Specified Colours
(8)  The colours for disciplines are as approved by the Academic Board from time to time and published by the Academic Registrar.
## Part C - REVOCATION OF REGULATIONS
(9)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 8.1.1 Academic Dress.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
