[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > RMIT Statute No.1 (Amendment No.2) 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=177)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=177)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=177)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=177)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=177)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=177)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=177)


# RMIT Statute No.1 (Amendment No.2)
Hide Navigation
  * [Part 1. Preliminary](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major1)
  * [Part 2. University Governance](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major2)
  * [Part 3. Council](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major3)
  * [Part 4. The Academic Board](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major4)
  * [Part 5. Awards](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major5)
  * [Part 6. Admission, Enrolment, Credit and Assessment](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major6)
  * [Part 7. Student Conduct](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major7)
  * [Part 8. Titles and Honorary Degrees](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major8)
  * [Part 10. Property](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major9)
  * [Part 11. University Premises, Facilities, Services and Activities](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major10)
  * [Part 12. Affiliation](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major11)
  * [Part 13. General](https://policies.rmit.edu.au/document/view.php?id=177&_gl=1*1qhgiab*_gcl_au*MTg0NzE2NTA0OC4xNzI0NjQzMjk2#major12)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
### Part 1. Preliminary
#### 1. Purpose
(1) The purpose of this Statute is to:
  1. provide for the organisation, management and good governance of the University
  2. make provision in respect of the Academic Board
  3. make provision for academic and student matters, and
  4. provide for the making of Regulations.


#### 2. Authorising Provision
(1) This Statute is made under section 28 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
#### 3. Interpretation
(1) The provisions of this Statute apply to all Statutes and Regulations.
(2) Unless the contrary intention appears:
  1. words and terms used in any Statute or Regulation have the same meaning as they have in the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20), and
  2. the [Interpretation of Legislation Act 1984](https://policies.rmit.edu.au/directory/summary.php?legislation=41) applies to the interpretation of all Statutes and Regulations.


(3) A reference in a Statute or Regulation to an Act, Statute, Regulation, policy or procedure unless the contrary intention appears, is a reference to that Act, Statute, Regulation, policy or procedure as amended or re-enacted as the case may be.
(4) Where a Statute or Regulation is revoked, amended or re-enacted the revocation, amendment or re-enactment does not, unless the contrary intention appears, affect:
  1. any right, privilege or liability acquired, accrued or incurred under the revoked or amended Statute or Regulation
  2. any penalty or punishment incurred in respect of any offence committed under the revoked or amended Statute or Regulation, or
  3. any investigation, inquiry, legal proceedings or remedy in respect of any such right, privilege, liability, penalty or punishment and any such investigation, inquiry, legal proceedings or remedy may be instituted, continued or enforced and any such penalty or punishment may be imposed as if the revoking or amending Statute or Regulation had not been made.


(5) Unless the contrary intention appears:
  1. words in the singular include the plural, and words in the plural include the singular
  2. any reference to any person holding an office is a reference to the person who holds or discharges the duties of that office for the time being, and
  3. where any power is conferred or duty imposed on any holder of an office that power may be exercised and the duty performed by the holder for the time being of that office.


#### 4. Definitions
(1) In any Statute or Regulation, unless the contrary intention appears:
Academic Board means the Academic Board established by Council under section 20 of the Act.
Act means the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
administrative error means an administrative error that results in an award being conferred to a person that has not fulfilled the requirements for the award to be conferred.
award includes a degree, diploma, certificate, license, honorary degree or other award.
college means the academic colleges specified by Council from time to time.
common seal means the University common seal referred to in section 7 of the Act.
electoral roll means an electoral roll, established and maintained by the returning officer in accordance with the Elections Regulations.
enrolled or enrolment means enrolled as a student of the University in accordance with the relevant policies and procedures.
fraud, for the purposes of Part 5, Division 2 of this Statute, includes but is not limited to:
  1. a false or misleading statement by a candidate for an award
  2. plagiarism
  3. use of false or fabricated data or material by a candidate in submitting work for examination, or
  4. any other dishonest act on the part of the candidate.


honoris causa means for the sake of the honor.
intellectual property means confidential information or any rights resulting from intellectual activity in the industrial, scientific, literary or artistic fields, including but not limited to rights under the [Patents Act 1990](https://policies.rmit.edu.au/directory/summary.php?legislation=32), [Copyright Act 1968](https://policies.rmit.edu.au/directory/summary.php?legislation=4), Design Act 2003, [Trade Marks Act 1995](https://policies.rmit.edu.au/directory/summary.php?legislation=35), [Plant Breeder's Rights Act 1994](https://policies.rmit.edu.au/directory/summary.php?legislation=34), [Circuit Layouts Act 1989](https://policies.rmit.edu.au/directory/summary.php?legislation=30) and rights under any convention to which Australia is a party and under the common law.
member of the University means a person referred to in subsection 4(3) of the Act, adjunct professors, Honorary University Fellows and such other persons as Council may from time to time determine.
misconduct means general misconduct and/or academic misconduct and/or high risk misconduct.
Official University Holiday means those days as the Vice-Chancellor may declare.
person authorised by the University, for the purposes of Part 11 of this Statute, means:
  1. an employee of the University, or
  2. a person employed or engaged by a contractor of the University to provide security services.


postgraduate student means any student enrolled as a candidate for a graduate certificate, graduate diploma, degree of Master or Doctor or any other course for admission to which completion of a degree is normally required.
Regulations means regulations of the University made under Part 5 of the Act.
returning officer has the meaning given to it in section 29(2) of this Statute.
section means, except when used in reference to the Act, a section of the relevant Statute or Regulations.
Statute means a statute of the University made under Part 5 of the Act.
student means:
  1. any person enrolled at the University, or
  2. for the purposes of Part 7 of this Statute and any associated Regulations, any person who was enrolled at the time when the person is alleged to have committed misconduct, for any award of the University.


This does not include any person who:
  1. has qualified for the award for which they have been enrolled and the period from the end of the examination period to the commencement of the next semester (excluding summer semester where relevant) has expired
  2. has been excluded from the University or had their candidature terminated pursuant to any Statute or Regulation
  3. has not for any academic year or period of study re-enrolled by the date prescribed, or
  4. has given the Academic Registrar notice in writing of discontinuance by the date prescribed.


undergraduate student means any student, whether they are a graduate of the University or of any other tertiary institution enrolled as a candidate for an award of the University not being a postgraduate award of the University.
University activities, for the purposes of Part 11 of this Statute, include:
  1. attendance at or participation in University lectures, seminars, assessments and classes (including online and distance participation)
  2. participating in internships, placements, study tours or student exchanges associated with or organised by the University, and
  3. participating in excursions, trips, functions, events, games or competitions associated with or organised by the University.


University body means Council, its committees and the Academic Board.
University facilities and services include any building, equipment, vehicle, service or amenity provided by the University including University library resources and information technology resources.
University legislation means the Act, Statutes and Regulations.
University premises means premises:
  1. owned by the University
  2. occupied by the University, and/or
  3. under the control of the University.


VET means Vocational Education and Training.
### Part 2. University Governance
#### Division 1 – Chancellor, Deputy Chancellor, Vice-Chancellor and Deputy Vice-Chancellor
#### 5. Chancellor
(1) Council must, at or before the time it appoints a Chancellor, fix the term of office.
(2) The Chancellor holds office for the term, not exceeding five (5) years, fixed by Council, and may, subject to Schedule 1 of the Act, be reappointed.
(3) The Chancellor is, by virtue of the office, a member of all University bodies, except the Audit and Risk Management Committee.
(4) Subject to section 18 of the Act, any matter which in the opinion of the Chancellor requires urgent action may be the subject of a determination by the Chancellor which is as valid and effectual as if it had been passed by a meeting of Council duly called and constituted.
(5) The Chancellor shall report any determination made under section 5(4) to the next meeting of Council and provide reason for the determination.
#### 6. Deputy Chancellor
(1) Council must, at or before the time it appoints one or more Deputy Chancellors, fix the term(s) of office.
(2) The Deputy Chancellor(s) hold office for the term, not exceeding five (5) years, fixed by Council, and may, subject to Schedule 1 of the Act, be reappointed.
#### 7. Vice-Chancellor
(1) Council appoints a Vice-Chancellor for such term and on such conditions as determined by Council.
(2) The Vice-Chancellor:
  1. may be reappointed, and
  2. is, by virtue of the office, a member of all University bodies except the Audit and Risk Management Committee.


(3) An acting Vice-Chancellor appointed by Council under section 27(1) of the Act holds office in the circumstances and for the period stipulated by Council.
#### 8. Vice-Presidents
(1) Council, on the recommendation of the Vice-Chancellor, appoints one or more Vice-Presidents for such term and on such conditions as determined by Council.
(2) A Vice-President:
  1. may be reappointed, and
  2. has the powers, duties and functions conferred on the Vice-President by the Vice-Chancellor.


#### Division 2 – Common Seal
#### 9. Use of the common seal
(1) The common seal must not be used except as authorised by University legislation.
(2) The common seal is in the custody of the University Secretary or nominee.
#### 10. Purposes for which the common seal may be used
(1) The University Secretary or nominee is authorised to affix the common seal to:
  1. testamurs for University awards
  2. Statutes or Regulations approved by Council
  3. other documents which require the affixing of a common seal.


#### 11. Authorisation by the Chancellor, Deputy Chancellor(s) or Vice-Chancellor
(1) The Chancellor, Deputy Chancellor(s) or the Vice-Chancellor may direct that the common seal be affixed to a document if the University Secretary is not available to direct the affixing of the seal.
(2) If the common seal is affixed in accordance with section 11(1), the Chancellor, Deputy Chancellor(s) or Vice-Chancellor must, as soon as practicable, report to Council on the fixing of the common seal and the reason for it.
#### 12. Affixing and attestation
(1) Where the common seal of the University is affixed to a document other than a testamur it is attested by two (2) members of Council or by one (1) member of Council and the University Secretary.
(2) Where the common seal of the University is affixed to a testamur it is attested by the Chancellor, Vice-Chancellor and/or University Secretary (with at least two (2) of the signatories).
(3) The University Secretary maintains a record of all documents to which the common seal of the University has been affixed.
### Part 3. Council
#### 13. Composition of Council
(1) Subject to section 11 of the Act, Council must, from time to time determine the number of members of Council.(Section 76 provides for the composition of the Council until an order in Council is made under section 63)
(2) Council members may be appointed and reappointed, in accordance with Schedule 1 of the Act.
#### 14. Council Meetings
(1) Except as provided by University legislation, Council meetings must be called and conducted as determined by Council.
### Part 4. The Academic Board
#### 15. Membership of the Academic Board
(1) The Academic Board comprises the members prescribed by the Regulations.
#### 16. Functions of the Academic Board
(1) Without limiting the generality of the powers and duties conferred or imposed upon it by the Act, the Academic Board:
  1. approves the requirements for all higher education and vocational education including Higher Education Degrees by Research awards conferred by the University and reports decisions to Council
  2. develops, reviews and approves academic and research policies and procedures and reports decisions to Council
  3. provides advice and reports to Council on academic matters
  4. has such other functions as may be assigned to it by Council from time to time, or conferred on it by Regulation
  5. appoints such committees with such membership and for such terms as it considers appropriate, and
  6. may by resolution delegate any of its powers, authorities, duties and functions (expressly reserving this power of delegation and the powers referred to in section 16(1)a) and b) above) to: 
    1. a committee or board nominated by it
    2. a member of the Academic Board, or
    3. a prescribed officer of the University,


provided that no such delegation will prevent or otherwise limit the Academic Board in the exercise of its powers, authorities, duties or functions.
#### 17. Academic Board Meetings
(1) Academic Board meetings are called and conducted in accordance with the Regulations.
### Part 5. Awards
#### Division 1 – Awards
#### 18. Conferring Awards
(1) Council may confer any award currently approved by the Academic Board.
(2) If Council confers any award, the University may issue a testamur for the degree, diploma, certificate, licence or other award.
#### Division 2 – Revocation of Awards
#### 19. Revocation of awards
(1) Subject to section 19(2) of this Statute, Council may revoke an award if:
  1. the award has been conferred as the result of an administrative error
  2. it is satisfied that the relevant award has been obtained by a person as a result of fraud
  3. in the case of an honorary degree, the recipient of the honorary degree no longer satisfies the criteria referred to in Part 8 Division 2 of this Statute, or
  4. the Student Conduct Board, or other person, after hearing a charge under the Student Conduct Regulations makes a recommendation to Council that an award should be revoked.


(2) Except where a recommendation has been made under section 19(1)d), where Council determines that a prima-facie case exists for revoking an award under section 19(1), Council must establish a committee (the committee) to investigate the facts and to make a recommendation to Council based upon the findings of the committee.
(3) The committee will be constituted and conducted in accordance with the Regulations. Where upon consideration of the findings and recommendation of the committee Council is satisfied that an award has been conferred by fraud, administrative error, or in the case of an honorary degree, the recipient no longer satisfies the criteria referred to in Part 8 Division 2 of this Statute, Council may revoke that award.
(4) Upon an award being revoked by Council, the Academic Registrar (or University Secretary in the case of an honorary degree) notifies the person to whom the award was issued of the decision and that person is required to return to the University the testamur or other document issued in respect of that award.
(5) This Statute applies to awards conferred or granted whether before or after the date of commencement of this Statute and includes awards granted by the Phillip Institute of Technology, Melbourne Institute of Textiles or any other entity which has merged with or is now, or may in the future be, otherwise incorporated in the University.
### Part 6. Admission, Enrolment, Credit and Assessment
#### Division 1 – Admission and Enrolment of Students
#### 20. Admission and Enrolment
(1) The University must conduct admission and enrolment of students in accordance with University legislation and the relevant policies and procedures.
(2) The Academic Board may set admission standards for entry to programs offered by the University.
(3) A person will not be enrolled in any program prescribed for any award unless that person has complied with the enrolment requirements set out in the relevant policies and procedures.
(4) A person will not be enrolled in any program prescribed for any award where for any reason the Academic Board considers it inappropriate that the person be enrolled.
(5) Upon enrolment, a student is bound by University legislation, policies and procedures.
#### Division 2 – Credit
#### 21. Credit Towards Awards
(1) The University may:
  1. credit towards students’ awards
  2. decline applications for credit from students in accordance with University legislation and the relevant policies and procedures.


#### Division 3 – Assessment
#### 22. Forms of Assessment
(1) There are such forms of assessment as determined by the University in accordance with University legislation and the relevant policies and procedures.
### Part 7. Student Conduct
#### 23. Student Misconduct
(1) The University may determine expectations of conduct by students.
(2) A person commits misconduct if the person commits:
  1. general misconduct
  2. academic misconduct, or
  3. high risk misconduct.


(3) A person commits academic misconduct if he or she while a student engages in conduct that is prescribed in the Regulations to be academic misconduct.
(4) A person commits general misconduct if he or she while a student engages in conduct that is prescribed in the Regulations to be general misconduct.
(5) A person commits high risk misconduct if he or she while a student engages in conduct that is prescribed in the Regulations to be high risk misconduct.
#### 24. Penalties for Misconduct
(1) A person who is found to have committed misconduct is liable to the penalties determined under the Regulations.
#### 25. Student Conduct Bodies
(1) There is a Student Conduct Board constituted and conducted in accordance with the Regulations and the relevant policies and procedures.
(2) There is a Student Conduct Appeals Committee constituted and conducted in accordance with the Regulations, and the relevant policies and procedures which, in accordance with the Regulations, may hear appeals against decisions of the Student Conduct Board or a senior officer of the University.
(3) The Student Conduct Board, the Student Conduct Appeals Committee and the officers specified in the Regulations have the power to determine matters of student conduct and where appropriate impose penalties as specified in the Regulations and the relevant policies and procedures.
### Part 8. Titles and Honorary Degrees
#### Division 1 – Titles
#### 26. University May Confer Titles on People Associated With It
(1) The University may, in accordance with the Regulations and the relevant policies and procedures, confer a title on a person who is associated with the University in a significant way, including a person who is not employed or appointed to an established or recurrent position.
#### Division 2 – Honorary Degrees
#### 27. Honorary Degrees
(1) Council may, in accordance with the Regulations and the relevant policies and procedures, admit honoris causa any person to a degree specified in the Honorary Degrees Regulations.
#### 28. Application of This Statute
(1) Part 9 of this Statute applies to elections for membership of bodies which are prescribed by the Regulations for the purposes of Part 9 of this Statute.
#### 29. Conduct of University Elections
(1) Subject to University legislation, elections are conducted by the returning officer.
(2) In any election under this Statute or the Regulations, the University Secretary or their nominee is the returning officer.
#### 30. Electoral Rolls
(1) The electoral roll:
  1. contains information necessary to enable an eligible voter to cast his or her vote, and
  2. is prepared in accordance with the Regulations.


#### 31. Functions and Powers of the Returning Officer
(1) The functions of the returning officer are to:
  1. organise, supervise and conduct University elections
  2. ensure that elections are conducted in accordance with law and good practice
  3. declare the results of elections
  4. make recommendations in relation to the conduct of elections, and
  5. perform the functions and to discharge the duties conferred or imposed on the returning officer by University legislation.


(2) The returning officer has power to carry out the functions and to discharge the duties conferred or imposed on the returning officer by University legislation.
#### 32. Returning Officer May Fill Casual Vacancies
(1) Subject to University legislation, the returning officer may appoint a person to fill a casual vacancy that would otherwise be filled by an election conducted under the Regulations if it appears to the returning officer that there is likely to be a delay in the filling of the vacancy resulting in one or more meetings of the body occurring without that vacancy being filled.
(2) The returning officer, in making the appointment, specifies the duration of the appointment, so that it terminates:
  1. on a specified date, or
  2. on the appointment or election of a person to fill the casual vacancy in accordance with University legislation.


### Part 10. Property
#### Division 1 – Intellectual Property
#### 33. Ownership of Intellectual Property
(1) The University owns intellectual property created by a member of staff in the course of their duties, which may require the member of staff formally to assign to the University their interest in any such intellectual property.
(2) A student of the University owns intellectual property which is created by the student in the course of their studies at the University except where:
  1. the student is involved in a project or specific commission in respect of which the University has provided funds, equipment or facilities, and
  2. the University requires the student, before commencing the same, to formally assign to the University their interest in any intellectual property which the student may create as a result of such involvement.


#### 34. Intellectual Property Committee
(1) An Intellectual Property Committee may be established by Regulations.
#### Division 2 – Other Property
#### 35. Administration of Trusts and other Property
(1) Any purchase, gift, grant, bequest or devise of property whatsoever real or personal or both to the University is administered and applied as determined by Council.
### Part 11. University Premises, Facilities, Services and Activities
#### 36. Restricted Access and Use
(1) A person must not, without the permission of the University or as otherwise authorised by law:
  1. enter University premises
  2. use University facilities and services, or
  3. participate in University activities.


(2) The University may impose conditions or requirements on persons who are:
  1. on University premises
  2. using University facilities and services, or
  3. engaged in University activities.


(3) A person must:
  1. comply with conditions imposed on the person’s: 
    1. presence on University premises
    2. use of University facilities and services, or
    3. engagement in University activities, and
  2. if the relevant permission of the University is withdrawn: 
    1. leave University premises
    2. not use University facilities and services, and
    3. not engage in University activities.


(4) If a person fails to comply with section 36(3), the University or a person authorised by the University may take reasonable steps to bring about the person’s removal from University premises or take reasonable steps to ensure that the person cannot continue to use University facilities and services or engage in University activities.
### Part 12. Affiliation
#### 37. Affiliation
(1) Subject to section 29(1)(y) of the Act, the University may from time to time enter into such agreements for the affiliation to the University of such educational or other institutions as Council considers appropriate.
### Part 13. General
#### Division 1 – Commencement of Statutes and Regulations
#### 38. Commencement of Statutes and Regulations
(1) Upon completion of the relevant approval processes, Statutes and Regulations come into operation on the day on which they are published to the RMIT website.
#### Division 2 – Regulations
#### 39. Power to Make Regulations
(1) Regulations may be made by Council:
  1. for or with respect to any subject matter in relation to which, in accordance with sections 28 and 29 of the Act, university regulations may be made, or
  2. in accordance with this Statute or any other Statute.


#### 40. Making, Amendment and Promulgation of Regulations
(1) Regulations are made by Council resolution and application of the common seal.
(2) Regulations may be amended or revoked by a:
  1. statute
  2. provision of the same Regulations which comes into operation on a later date, or
  3. resolution of Council.


#### Division 3 – Revocation and Transitional Provisions
#### 41. Revocation of Statutes
(1) On the commencement of this Statute the following Statutes are revoked:
  1. Statute 1.1 Interpretation
  2. Statute 1.2 Meetings
  3. Statute 1.3 University Holidays
  4. Statute 1.4 The Seal of the University
  5. Statute 1.5 Members of the University
  6. Statute 2.1 The Council
  7. Statute 2.7 Higher Education Division of the University
  8. Statute 2.8 The Academic Board
  9. Statute 2.9 The Academic Portfolios
  10. Statute 2.10 Technical and Further Education Division of the University
  11. Statute 3.1 The Chancellor
  12. Statute 3.2 The Deputy Chancellor
  13. Statute 3.3 The Vice-Chancellor and President
  14. Statute 3.4 Deputy Vice-Chancellors
  15. Statute 3.5 The Director of Technical and Further Education
  16. Statute 3.6 Deputy Vice-Chancellors
  17. Statute 3.7 The Academic Staff
  18. Statute 3.8 Visiting Professors
  19. Statute 3.8 Vice-President
  20. Statute 3.9 Professors Emeritus
  21. Statute 3.10 Adjunct Professors
  22. Statute 3.11 The General Staff
  23. Statute 4.3 The University Services
  24. Statute 5.1 Awards
  25. Statute 5.2 Enrolment
  26. Statute 5.3 Admission to Advanced Standing 
    1. Statute 5.4 Academic Progress
    2. Statute 5.5 Admission to Honorary Degrees
    3. Statute 5.6 Awards in Conjunction with Other Institutions
    4. Statute 5.7 Revocation of Awards
    5. Statute 6.1 Student Discipline
    6. Statute 7.1 Intellectual Property
    7. Statute 8.1 Academic Dress.
    8. Statute 9.1 Elections
    9. Statute 11.1 Affiliation
    10. Statute 12.1 Administration of Trust and Other Property
    11. Statute 13.1 Student Loan Funds


#### 42. Revocation of Regulations
On the commencement of this Statute the following Regulations are revoked:
  1. Regulation 1.2.1 Notice of Meetings
  2. Regulation 3.1.1 Appointment of the Chancellor
  3. Regulation 3.2.1 Appointment of the Deputy Chancellor
  4. Regulation 4.3.1 The Director University Library
  5. Regulation 4.3.2 The Executive Director of Information Technology Services
  6. Regulation 5.6.1 Awards in Conjunction with Other Institutions.
  7. Regulation 12.1.1 Frances Burke Textile Resource Centre
  8. Regulation 13.1.1 Student Loan Fund Committee.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
