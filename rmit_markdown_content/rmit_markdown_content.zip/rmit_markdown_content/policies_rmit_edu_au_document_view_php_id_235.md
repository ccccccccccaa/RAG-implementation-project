[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=235#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=235#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Child Safe Image Instruction 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=235)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=235)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=235)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=235)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=235)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=235)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=235)


# Child Safe Image Instruction
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=235#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=235#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=235#section3)
  * [Section 4 - Instruction](https://policies.rmit.edu.au/document/view.php?id=235#section4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This Instruction details the conditions under which photographs or video footage of children (persons under 18 years of age) can be used in print or electronic publications, other media or collateral of the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=235#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=235#document-top)
# Section 3 - Scope
(3)  This Instruction applies to any RMIT student, staff, or associate (as defined in the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213)) who is preparing or procuring print or electronic publications, media or other official RMIT collateral or content that contains photography or video footage, hereafter described as an ‘image’.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=235#document-top)
# Section 4 - Instruction
(4)  Any images featuring persons who are 16 or 17 years old can only be taken or recorded with prior written consent from their parent or guardian. The consent needs to be obtained before the recording occurs, and with a full explanation of the proposed use of the image, including purpose and duration. Records of all consents obtained pursuant to this Instruction must be appropriately maintained, so that they can be referred to if necessary.
(5)  Clause 4 does not apply to the recording of classes or other learning activities, such as lectures, tutorials, practicals and workshops, where the recording is intended for educational use by enrolled students. In these instances, consent from a parent or guardian is not required.
(6)  Where persons 15 years of age or younger are participating in an official RMIT activity, such as an Open Day, or as part of a formal marketing campaign which will be photographed or recorded, then there must be written consent from their parent or guardian, plus parent or teacher supervision for the duration of the event and while any recording or images are being taken.
(7)  Where possible, it is preferable that individual faces of persons under 18 years of age are not identifiable. For example, images of large groups with a presenter can be taken from the back of the group, showing the back of the heads of persons under 18 watching a presenter, or can have the children’s faces blurred.
(8)  If the face of a person under the age of 18 is identifiable, the specific image must be approved by the relevant parent or guardian before it is published. This will be in addition to the consent received at the time the image was created as the parent or guardian may withdraw their consent after seeing the finished image.
(9)  Any images of persons under 18 years of age should be respectful. It should show them suitably dressed and in an appropriate circumstance and manner of portrayal to avoid the images being misused or breaching the child’s privacy and dignity.
(10)  Images of persons under 18 years of age must not be in poses or circumstances that could be interpreted as sexually suggestive, unsafe, a criminal offence, or a breach of any other RMIT policy or procedure, for example, a person under 18 to be shown in a lab context without safety equipment.
(11)  Images of persons under 18 years of age must be culturally sensitive.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
