[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=225#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=225#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Travel Procedure Schedule 1 - Class of Travel 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=225)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=225)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=225)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=225)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=225)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=225)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=225)


# Travel Procedure Schedule 1 - Class of Travel
Hide Navigation
This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
(1)  The standard class of travel for RMIT staff is economy, in accordance with the [Travel Procedure - Staff](https://policies.rmit.edu.au/document/view.php?id=81).
(2)  An authorising officer must be a specified college or portfolio head (i.e. Chief Operating Officer, Vice-President, Strategy and Community Impact or Deputy Vice-Chancellor) in relation to travellers from their college or portfolio, or the Vice-Chancellor for senior executive direct reports to the Vice-Chancellor; The authority for approving class of travel cannot be delegated.
(3)  An authorising officer may approve fare classes other than economy if:
  1. The proposed journey is longer than seven hours from the initial flight departure time, and there are circumstances requiring a fare class other than economy, or
  2. The employee health circumstances warrant a seating class other than economy, or
  3. there is evidence that the travel expenditure is permitted by the relevant external funding body.


(4)  Approval for a premium economy or business class fare:
  1. must be received from an authorising officer and obtained through the University’s travel booking systems, and
  2. can only occur if the authorising officer has given due consideration to the purpose and circumstances to justify the cost of the travel.


(5)  Travellers must exercise practical judgment and book the lowest practical fare available for their circumstances, consistent with this policy and the terms of their employment contract.
(6)  When exercising practical judgment, travellers should consider the following guidelines:
  1. travel must be essential and planned to benefit the University and the traveller
  2. travellers should choose travel modes, routes and service providers that minimise climate impact
  3. line managers approving travel must ensure efficient use of resources and give consideration to budgets.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
