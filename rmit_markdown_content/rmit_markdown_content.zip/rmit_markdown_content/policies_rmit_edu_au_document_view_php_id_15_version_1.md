[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=15&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=15&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Progress Management Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=15)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=15&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=15&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=15&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=15&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=15&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=15&version=1)


# HDR Progress Management Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=15&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=15&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=15&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=15&version=1#section4)
  * [Requirement for Regular, Recorded Supervision Meetings](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major1)
  * [Records of Supervision Meetings](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major2)
  * [Candidature Milestone Review Process](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major3)
  * [Convening a Review Panel](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major4)
  * [Scheduling of Milestone Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major5)
  * [Closed Milestone Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major6)
  * [Location](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major7)
  * [Sanctions Assessment and Related Compliance](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major8)
  * [Exemptions from Milestone Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major9)
  * [Written Components of Reviews](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major10)
  * [Convening and Running a Milestone Review](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major11)
  * [Criteria for the Assessment of Candidature Progress at a Milestone Review](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major12)
  * [Assessment of Progress at a Milestone Review](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major13)
  * [Complaints and Appeals](https://policies.rmit.edu.au/document/view.php?id=15&version=1#major14)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=15&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure sets out the rules and processes for supporting HDR academic progress.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=1#document-top)
# Section 3 - Scope
(3)  The procedure applies to all staff responsible for HDR management and supervision and all HDR candidates of the University and its controlled entities (known as the RMIT Group).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=1#document-top)
# Section 4 - Procedure
### Requirement for Regular, Recorded Supervision Meetings
(4)  Supervisors are required to monitor their candidates’ overall academic progress, their preparedness for milestone reviews and submission for examination through regular meetings, and review of work submitted at regular intervals.
(5)  Within the first three months of candidature, candidates and their supervisors must agree on:
  1. an outline of the research project for the duration of candidature with key components of the project detailed (e.g. literature review; whether an ethical review of the proposed research is required)
  2. how the research will be presented for examination according to the norms and standards of the discipline, including where necessary, a plan for recording digitally additional integral elements of work to be examined
  3. any periods, locations, purpose and description of fieldwork, lab work etc.
  4. periods of attendance at a partner institution/organisation (if applicable)
  5. potential ethics and institutional biosafety requirements and timing of ethics approval
  6. an indicative plan for the production of research outputs based on the research
  7. candidate training needs additional to any mandatory coursework to support good progress and successful graduate outcomes (drawing on available offerings through schools, the School of Graduate Research (SGR) and other providers as applicable).


(6)  Supervisors and candidates will agree on a supervision meeting schedule which may be revised depending on the candidate’s study load and stage of candidature. As a guide, meetings should normally occur at least once a fortnight or part-time equivalent.
(7)  At a minimum, all recommendations and actions arising from meetings between supervisor/s and candidates must be documented at least once per research quarter for both full-time and part-time candidates who are not on a leave of absence.
(8)  Candidates and their supervisors are responsible for keeping a record of supervision meetings on file for reference in order to record tasks the candidate must undertake, and the responsibilities of the supervisor, leading up to the next milestone review. It is good practice for candidates to circulate a record of discussion and agreed actions to all members of the supervisory team within 48 hours of a supervisory meeting.
(9)  Records of supervisory meetings must be accessible by the candidate and the supervisory team for future reference. They must also be produced on request by the school HDR delegated authority (HDR DA) or SGR. The most reliable way to achieve this is by storing it on the candidate’s e-file.
### Records of Supervision Meetings
(10)  The following items should be covered:
  1. date of the meeting
  2. name of candidate
  3. name(s) of supervisor(s) present
  4. the next milestone review expected of the candidate: confirmation of candidature; second milestone review; third milestone review
  5. key matters discussed during this meeting
  6. feedback provided by the supervisor on the work presented and directions for moving forward
  7. list of specific tasks the candidate agreed to do prior to the next meeting
  8. list of specific tasks the supervisor/s agreed to do prior to the next meeting
  9. any factors with the potential to impact on the timely and effective achievement of the next milestone
  10. any other matters to be documented
  11. a proposed date for the next meeting
  12. electronic acknowledgement by candidate and supervisor/s.


### Candidature Milestone Review Process
(11)  A candidate’s academic progress is formally assessed through the three candidature milestone reviews: confirmation of candidature; second milestone review; and the third milestone review.
(12)  Timely, successful completion of candidature milestones is a key, lead indicator of successful HDR outcomes.
(13)  Candidates are permitted two attempts to achieve a milestone. A third attempt may be made in exceptional circumstances, subject to approval by the Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D).
### Convening a Review Panel
(14)  The HDR DA will convene the review panel and must ensure there is no potential or actual conflict of interest between the panel members and/or the candidate.
(15)  A review panel normally comprises four members:
  1. a chair, who will be the school HDR DA or another Category 1 supervisor from the school
  2. a minimum of one supervisor who is a senior or a joint senior supervisor
  3. at least one member who is independent of the supervisory team. This member of the panel must be a registered supervisor (or, if external to the university, have a doctoral qualification or equivalent).


(16)  Additional supervisors may be appointed to the panel where appropriate. However, where two or more supervisors are appointed to a panel, they must agree on a single, team position with respect to any decisions the panel may make on the outcome.
### Scheduling of Milestone Reviews
(17)  All candidature milestone reviews must be scheduled within the following milestone windows:
Degree | Timing of confirmation of candidature | Timing of second milestone review | Timing of third milestone review  
---|---|---|---  
PhD | From 0.5 and no later than 1 EFTSL after candidate’s research commencement date | From 1.5 and no later than 2 EFTSL after candidate’s research commencement date | From 2.5 and no later than 3 EFTSL after candidate’s research commencement date  
Masters | From 0.25 and no later than 0.5 EFTSL after candidate’s research commencement date | From 0.75 and no later than 1 EFTSL after candidate’s research commencement | From 1.5 and no later than 1.75 EFTSL after candidate’s research commencement date  
(18)  The milestone review window is adjusted for any approved leave of absence or changes to study load.
(19)  The milestone review involves the candidate presenting their research to a forum of the relevant research community, for example a school or college seminar, or Graduate Research Conference and the candidate is expected to take questions from review panel members and the wider audience.
(20)  Where a candidate is not able to attend a scheduled milestone review due to compassionate or compelling circumstances, they should notify their senior supervisor and HDR DA as early as possible and provide documentary support for their request.
(21)  Provided the senior supervisor supports the request for rescheduling a milestone review, the HDR DA will organise for the milestone review to be rescheduled at an appropriate time.
(22)  Inability to submit work on time for a milestone review does not qualify as grounds for exceptional scheduling. This is an indication that action and support is required (see the HDR Action and Support Procedure).
(23)  All costs associated with milestone reviews, regardless of location, will be borne by the enrolling school.
### Closed Milestone Reviews
(24)  In exceptional circumstances, a candidate may request a milestone review presentation to be made solely to a review panel rather than in a public forum. Candidates make the request by submitting a case and supporting documentation, including evidence of support from their senior supervisor, to their HDR administrator. Candidates are requested to notify the school of the request two months before the scheduled milestone.
(25)  The case is considered for endorsement by the HDR DA, after consultation with the supervisory team. If the request is endorsed, the HDR administrator must submit the documentation for approval by the ADVC RT&D.
(26)  The request will normally be considered on the basis of equitable learning considerations or where intellectual property restrictions apply.
### Location
(27)  If a candidate is unable to attend a milestone review due to location, the HDR DA will organise a modified milestone review presentation.
(28)  The requirements for the review will be the same (see sections 10 and 11) but the presentation may involve use of electronic communication.
(29)  The HDR DA may consult the supervisors, and the SGR candidature management team to ensure that the proposed modified process is acceptable.
### Sanctions Assessment and Related Compliance
(30)  Candidates who are subject to national security compliance assessments must have a new assessment completed by their senior supervisor if the research topic has changed since admission or the last milestone review (further details are provided in the HDR Sanctions Assessment Process).
### Exemptions from Milestone Reviews
(31)  Candidates transferring to RMIT from another institution may apply for an exemption for any milestone review by submitting a request to their senior supervisor, including evidence from their previous institution of successful completion of equivalent milestone(s) for their current research project. Support for the exemption from their senior supervisor is required before the request can be processed. This should be done at the point of application for admission.
(32)  The case is considered, and if deemed appropriate, approved by the HDR DA, after consultation with the supervisory team.
(33)  Candidates who seek re-admission for the purpose of examination may be exempt from completing the third milestone review, providing the school is satisfied that the candidate’s research is ready for examination. 
### Written Components of Reviews
(34)  All review presentations will be accompanied by submission of appropriate written and supporting materials to the review panel as specified in Table 1 and be of an appropriate scholarly standard.
(35)  Candidates are required to produce work of the appropriate quality and length for each milestone after discussion with their supervisory team and/or HDR DA.
#### Table 1: Submission Requirements
Milestone requirements | Confirmation of candidature | Second milestone review | Third milestone review  
---|---|---|---  
A research proposal (confirmation of candidature) or summary (subsequent milestones) document which contains: the HDR submission title the rationale, objectives and research questions an abstract of the research an explanation of how the research is situated in the context of the discipline area/community of practice an up-to-date current outline/summary of progress against a detailed research plan/ timeline | Yes |  |   
How the proposed project will be undertaken (methodology) An initial review of literature and references | Yes |  |   
Evidence of completion of the compulsory online Research Integrity module and Intellectual Property (IP) module, as well as, where appropriate, any relevant online module/s covering human ethics, animal ethics, and institutional biosafety. | Yes |  |   
Evidence of required ethics and institutional biosafety approvals. | Yes | Yes |   
An updated review of literature and references, and Any changes to candidature since the last milestone review |  | Yes – include in summary document | Yes – include in summary document  
Evidence of any pending or completed research outputs, either sole or co-authored | Yes | Yes | Yes  
Evidence of being enrolled in, having successfully completed, or been exempted from, the research methods course listed in the program guide | Yes |  |   
Draft chapters of the thesis, or equivalent in draft or published papers, as deemed appropriate for the discipline, OR |  | Yes – at least two chapters | Yes – at least four chapters  
A portfolio of work, as appropriate to the discipline, which includes a draft of the dissertation. |  | Yes – draft dissertation required | Yes – advanced draft dissertation required  
Any other requirements the school deems necessary. | Yes | Yes | Yes  
### Convening and Running a Milestone Review
(36)  The candidate must submit all documentation to the school HDR administrator at least 15 working days before the scheduled date of the milestone.
(37)  The senior supervisor must ensure that the supervisor section of the relevant milestone review form is completed and provided to the HDR administrator at least 15 working days before the scheduled date of the milestone.
(38)  Candidates must notify their school of any specific technical requirements 10 working days before their presentation. Schools are to make available to candidates any necessary equipment for projection of sound/visual or text-based presentations.
(39)  The HDR administrator must forward the milestone documents to the review panel members at least 10 working days before the scheduled date of the presentation.
(40)  A review panel must check that any necessary human, animal ethics or institutional biosafety approvals, copyright clearances and/or intellectual property arrangements are in place. Where these are not in place, the candidate will work with their supervisors and/or HDR DA to develop and implement a Candidate Action and Support Plan (see the HDR Action and Support Procedure) following the milestone to ensure a swift resolution and to prevent any further impact on progress.
(41)  The duration of the review presentation will normally be an hour, which includes at least 20 minutes for the oral presentation, additional question time and time for the review panel to discuss the candidate’s work and agree on the main points for the milestone report, and the feedback to the candidate.
(42)  Individual disciplines may require longer presentations at some reviews. In these cases, the HDR DA will ensure discipline specific guidance on presentation requirements are communicated to candidates and supervisors.
(43)  Candidates must be provided with informal feedback immediately following their presentation.
(44)  The panel chair must invite candidates to provide confidential feedback on their candidature and supervision after the review presentation, without the supervisory team present. Candidates may also submit feedback on their supervisory experience to SGR. Any record of feedback will remain confidential between the candidate, panel chair and SGR, unless the candidate permits disclosure.
(45)  The review panel must confer in camera, as soon as possible, but not more than 1 week after the presentation. At this meeting the panel reviews whether the candidate’s progress is satisfactory or not satisfactory (refer to section 12) and decides on a recommendation for the outcome of the review (refer to section 13). The chair of the panel has final say in the candidate’s milestone status.
(46)  The Panel must provide detailed, written feedback to the candidate, and include any amendments, necessary or recommended, for the candidate and supervisors.
(47)  The Chair of the Review Panel must finalise and endorse the milestone review report after the meeting. The report is then provided to the HDR DA and HDR administrator within 10 working days of the review presentation.
(48)  The HDR administrator must submit the completed review report and research proposal (Confirmation of Candidature) or summary document (second or third milestone review) to SGR and to the candidate’s e-file within 20 working days of the review.
(49)  Milestone review documentation is subject to regular auditing and moderation, coordinated by SGR.
(50)  Following review of any milestone documentation submitted for approval, the ADVC RT&D (or nominee) may:
  1. block finalisation of a milestone outcome pending provision of further information or documentation;
  2. overrule a milestone outcome;
  3. instruct any remedial action deemed necessary, to uphold academic standards, support HDR progress, and to ensure compliance with University policy.


(51)  SGR notifies candidates formally in writing of the outcome of all milestone reviews. Those who achieve their milestone are regarded as having satisfactory progress.
### Criteria for the Assessment of Candidature Progress at a Milestone Review
(52)  Panel members reviewing candidates will look for the following assessment criteria:
  1. Confirmation of candidature 
    1. a clear summary of the candidate’s aims, methods, theoretical/conceptual framework, as well as the significance, and potential impact of the research
    2. evidence that the candidate has begun to adequately reflect on their research framework, and its relationship to the existing body of knowledge
    3. evidence that the candidate understands the proposed methodology and has the skills needed to undertake the research
    4. evidence of required ethics and institutional biosafety approvals
    5. an indication that the research is original and will produce new knowledge (PhD candidates); or appropriate to the level of a Masters by Research degree in accordance with the Australian Qualifications Framework, including in-candidature research outputs
    6. a clear and viable schema for completing the degree, including a research plan with a specific timeline for the research program from confirmation to completion.
  2. Second milestone review 
    1. presentation of research outcomes of sufficient quality and quantity to support a coherent and critical account of that work
    2. evidence that the candidate has been developing the research and testing their methodology as they progressed
    3. evidence that the candidate has a strong understanding of how their research is situated in the existing knowledge of their discipline and/or community of practice, and its relationship to work by other researchers
    4. evidence of research outputs planned or submitted for the public domain
    5. a clear and viable schema for completing the degree, including a detailed timeline of the research program from the mid-point to completion.
  3. Third milestone review 
    1. evidence of a coherent account of the candidate’s research and the submission of research outcomes which support their aims and answer their research question/s
    2. evidence that the candidate has successfully situated their research within the discipline and/or community of practice and taken account of other research related to their topic
    3. evidence that the research is original and has produced new knowledge (PhD candidates); or appropriate to the level of a Masters by Research degree in accordance with the Australian Qualifications Framework
    4. evidence of research outputs planned or submitted for the public domain
    5. a clear plan and detailed timeline showing how the thesis/project will be completed in the time between the third milestone review and the submission date.


### Assessment of Progress at a Milestone Review
(53)  There are two possible outcomes for candidates at their milestone reviews:
  1. milestone achieved – this outcome can include suggestions or recommendations to a candidate to make amendments to the satisfaction of their senior supervisor, to their milestone documentation; or
  2. milestone not achieved – this outcome leads to the nomination of the candidate for action and support.


(54)  The chair of the review panel may refer milestone reports to the ADVC RT&D prior to determining an outcome where an independent review would be useful. 
(55)  If a candidate is given an outcome of milestone not achieved, SGR instructs a Candidate Action and Support Plan (CASP) to be developed and informs them that they must present their Milestone for a second time, addressing the required amendments. The HDR DA must organise an action and support meeting within 10 working days of the milestone notification being sent to the candidate. A CASP is developed to assist the candidate to regain satisfactory progress. More details on these processes can be found in the HDR Action and Support Procedure.
(56)  Where a candidate is required to complete a milestone for the second time, and the milestone must be presented, the CASP must include the time-frame for resubmitting and presenting the milestone. The process used must be in accordance with section 11. In the case of a second presentation, the panel must assess whether or not the requested amendments were made and complete a Milestone Review – Review of Amendments Report instead of a Milestone Review Report.
### Complaints and Appeals
(57)  Candidates with a current enrolment (including those on an approved period of leave of absence) are entitled to appeal a decision to terminate their candidature on the basis of unsatisfactory performance where they can provide evidence of one or both of the following:
  1. a breach of RMIT legislation, policy or procedure which has had a significant impact on a determination to terminate the candidature or on the examination outcome; and/or
  2. there is significant, new relevant evidence that was not available at the time of the Research Candidate Progress Committee (RCPC) meeting. 


(58)  Appeals must be made in accordance with the Assessment, Academic Progress and Appeals Regulations and the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=15&version=1#document-top)
# Section 5 - Procedures and Resources
(59)  Refer to the:
  1. [HDR Forms](https://policies.rmit.edu.au/download.php?id=68&version=2&associated): 
    1. HDR Candidate Action and Support Plan (CASP) template 
    2. Masters by Research milestone review form 
    3. PhD milestone review form 
    4. Milestone review - review of amendments form


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
