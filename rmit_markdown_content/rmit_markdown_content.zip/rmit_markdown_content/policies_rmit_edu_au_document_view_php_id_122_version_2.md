[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=122&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=122&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Workplace Behaviour Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=122)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=122&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=122&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=122&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=122&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=122&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=122&version=2)


# Workplace Behaviour Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=122&version=2#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=122&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=122&version=2#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=122&version=2#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=122&version=2#major1)
  * [Standards and Expectations](https://policies.rmit.edu.au/document/view.php?id=122&version=2#major2)
  * [Disciplinary Action](https://policies.rmit.edu.au/document/view.php?id=122&version=2#major3)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=122&version=2#major4)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=122&version=2#major5)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=122&version=2#section5)
  * [Section 6 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=122&version=2#section6)
  * [Section 7 - Definitions](https://policies.rmit.edu.au/document/view.php?id=122&version=2#section7)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  The purpose of this policy is to:
  1. make clear RMIT’s position that discrimination, sexual harassment, bullying and victimisation are unacceptable, may be unlawful and will not be tolerated under any circumstances
  2. explain staff obligations in relation to professional and respectful behaviour when interacting with others in the workplace context 
  3. support the maintenance of academic freedom as a principal value of the University, through the description of expectations consistent with the collegial and community nature of a university.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122&version=2#document-top)
# Section 2 - Overview
(2)  RMIT sets standards of behaviour for its staff and associates based on the law, as well as RMIT’s organisational values. RMIT staff and associates are expected to behave in a way that is consistent with the standards set out in this policy.
(3)  Behaviour that is inconsistent with these expectations is unacceptable and may also be unlawful. Staff should be aware that behaviour may breach this policy even if there is no intention to do so. One of the key concerns of RMIT’s policies on behaviour is how affected parties experience unacceptable or unlawful behaviour in the workplace.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122&version=2#document-top)
# Section 3 - Scope
(4)  This policy applies to all staff and associates of the RMIT Group, which is RMIT University and its controlled entities (e.g. RMIT Europe, RMIT Online, RMIT UP, RMIT Vietnam).
(5)  Staff and associates of the RMIT Group include RMIT Council members, employees, researchers, contractors and volunteers, both in Australia and overseas (subject to the relevant legislation).
(6)  Maintenance of academic freedom is a principal value of the University, as supported by the [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56). The provisions in this [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122) do not seek in any way to limit academic freedom. This policy establishes behavioural expectations consistent with the collegial and community nature of a University which is itself the foundation of academic freedom.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122&version=2#document-top)
# Section 4 - Policy
### Principles
(7)  RMIT is committed to creating a culture where all people can participate in a workplace free from harassment (including sexual harassment), discrimination, bullying, and victimisation. Behaviour of this kind is unacceptable and may be unlawful.
(8)  RMIT values and commits to encouraging positive values-based behaviour. RMIT will not tolerate unacceptable or unlawful behaviour by staff, or directed at staff, or behaviour that undermines the right of all people to feel safe, respected and valued.
(9)  Standards and expectations of professional and respectful workplace behaviour apply to all interactions between staff, students and third parties where there is a connection with the workplace.
(10)  RMIT recognises the existence of a connection with the workplace where the behaviour has some link to the workplace. This includes:
  1. when staff are in the workplace physically or operating in the online work environment
  2. when staff are performing work even though not physically in the workplace (such as at home or at a conference or in a hotel whilst travelling for work)
  3. when staff are attending functions or events related to work (even if they are purely social and informal, like after work drinks)
  4. outside of work behaviour if the behaviour can negatively impact on RMIT or its reputation (such as involvement with criminal activity)
  5. where the conduct creates issues within the workplace (for example stalking an employee or student outside of work). 


(11)  Conduct permitted under the [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56) does not constitute a breach of this policy.
### Standards and Expectations
(12)  Staff must not unlawfully discriminate against anyone in a workplace context because that person has, may have or had one or more of the protected attributes as defined in the [Inclusion, Diversity and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93), including but not limited to:
  1. indigeneity, or identity as an Aboriginal or Torres Strait Islander person
  2. age
  3. physical features
  4. race (including colour, nationality, ethnicity, ethnic or social origin)
  5. gender identity or expression
  6. pregnancy or potential pregnancy
  7. breastfeeding
  8. impairment, disability, or mental health condition
  9. employment activity, profession, trade or occupation
  10. industrial activity or membership of a union
  11. sex or intersex status
  12. political belief or activity
  13. marital and relationship status
  14. parental status, status as a carer (family responsibilities)
  15. sexual orientation
  16. lawful sexual activity
  17. religious belief or activity
  18. expunged homosexual conviction
  19. spent conviction
  20. personal association (as a relative or otherwise) with a person who is identified by reference to any of the above attributes
  21. any other protected attribute defined by law. 


(13)  If there is a conflict between the protected attributes in RMIT Group policy and Vietnamese law, the Chief People Officer will determine the appropriate response, on a case by case basis, taking into account to RMIT’s organisational values and local requirements and authorities.
(14)  Staff must not sexually harass anyone they have contact with in connection with RMIT, or in the workplace context. Sexual harassment under the Fair Work Regulations 2009 is considered serious misconduct. In Australia where an RMIT employee is found to have engaged in serious misconduct their employment may be terminated summarily (without notice).
(15)  Sexual harassment under the [Fair Work Act 2009](https://policies.rmit.edu.au/directory/summary.php?legislation=6) (Cth) where it is found to have occurred within the workplace is a valid reason for dismissal.
(16)  Staff must not bully anyone they have contact with in connection with the workplace. Reasonable performance management, and the setting and management of reasonable performance goals, does not constitute bullying.
(17)  Staff must not victimise anyone they have contact with in connection with their employment or engagement with RMIT.
(18)  There are other types of staff or associate behaviour in connection with RMIT which do not meet the definitions of discrimination, sexual harassment, bullying, or victimisation but still amount to unprofessional or disrespectful conduct and are inappropriate and unacceptable. This includes:
  1. unreasonable behaviour that creates a risk to health and safety or causes another person to feel unsafe
  2. behaviour that takes improper advantage of a power imbalance or relationship which exists between individuals
  3. behaviour that involves deceit, fraud, theft or malicious damage to RMIT property.


### Disciplinary Action
(19)  RMIT will usually address concerns, complaints or reports involving discrimination, sexual harassment, bullying, victimisation and other forms of unacceptable workplace behaviour by applying any relevant enterprise agreement and the procedures under this policy. The related policies set out below, as well as any other relevant policies, may also be applied where appropriate.
(20)  RMIT Vietnam will address concerns, complaints or reports involving discrimination, sexual harassment, bullying, victimisation and other forms of unacceptable workplace behaviour by applying its Internal Labour Rules and any other applicable procedures under this policy. 
(21)  Behaviour which breaches this policy will be treated as misconduct or serious misconduct.
(22)  Staff or associates who breach this policy may be subject to disciplinary action, including summary termination of employment. Staff who engage in unlawful behaviour may also be subject to criminal or civil liability. For RMIT Vietnam, a breach of this policy by any Employee may result in disciplinary action being taken against such Employee as detailed in the Internal Labour Rules.
(23)  Staff should also refer to the following related policy documents:
  1. [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56)
  2. [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52)
  3. [Staff-Student Personal Relationships Procedure](https://policies.rmit.edu.au/document/view.php?id=258)
  4. [Health Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
  5. [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218)
  6. [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91)
  7. [Anti-Corruption and Fraud Prevention Policy](https://policies.rmit.edu.au/document/view.php?id=47)
  8. [Information Technology - Acceptable Use Standard](https://policies.rmit.edu.au/document/view.php?id=76)
  9. [Managing Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=153)
  10. [Staff Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=156)
  11. [Inclusion, Diversity and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93).


### Responsibilities
(24)  All staff who work for, or with, the RMIT Group:
  1. must be aware of their obligations under this policy
  2. must ensure their behaviour complies with this policy
  3. should identify and report unacceptable workplace behaviour to a manager or a member of the People team, or through other designated complaints or disclosure avenues.


(25)  RMIT managers have a leadership role and are responsible for taking prompt action if suspected or actual breaches of this policy occur.
(26)  Policy and Workplace Relations, on behalf of the Chief People Officer, will manage conduct matters arising from alleged breaches in the University unless determined otherwise.
(27)  HR Directors of RMIT entities will investigate and refer to Policy and Workplace Relations for investigation of conduct matters arising from alleged breaches by entity employees.
### Review
(28)  This policy will be reviewed every three years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122&version=2#document-top)
# Section 5 - Schedules
(29)  [Schedule 1](https://policies.rmit.edu.au/download.php?id=175&version=2&associated) provides some non-exhaustive examples of sexual harassment, discrimination, behaviours that (if repeated) may constitute bullying and other forms of unacceptable workplace behaviour under this policy which may be updated by the Chief People Officer from time to time.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122&version=2#document-top)
# Section 6 - Procedures and Resources
(30)  Refer to the following documents which are established in accordance with this policy:
  1. [Managing Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=153)
  2. [Staff Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=156)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122&version=2#document-top)
# Section 7 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Definitions or examples which are specific to this policy are set out in [Schedule 1](https://policies.rmit.edu.au/download.php?id=175&version=2&associated)).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
