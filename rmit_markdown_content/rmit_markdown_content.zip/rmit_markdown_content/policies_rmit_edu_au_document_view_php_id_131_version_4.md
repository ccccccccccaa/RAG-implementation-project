[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=131&version=4#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=131&version=4#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > English Language Proficiency Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=131)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=131&version=4)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=131&version=4)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=131&version=4)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=131&version=4)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=131&version=4)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=131&version=4)


# English Language Proficiency Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=131&version=4#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=131&version=4#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=131&version=4#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=131&version=4#section4)
  * [General](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major1)
  * [Meeting Minimum English Language Proficiency Requirements](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major2)
  * [Meeting Requirements for Undergraduate and Postgraduate Coursework Programs ](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major3)
  * [Meeting Requirements for Vocational Education Programs ](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major4)
  * [Meeting Requirements for Foundation Studies Programs](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major5)
  * [Meeting Requirements for Non-Award Study ](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major6)
  * [Meeting Requirements for Higher Degree by Research (HDR) Programs ](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major7)
  * [Time Limitations for Previous Study and Proficiency Tests](https://policies.rmit.edu.au/document/view.php?id=131&version=4#major8)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=131&version=4#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure documents the minimum English language requirements for admission into programs at RMIT University to ensure admitted students have the English proficiency needed to participate successfully in their intended study.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=131&version=4#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=131&version=4#document-top)
# Section 3 - Scope
(3)  This procedure applies to admission into all programs, courses and non-award study offered by the RMIT Group and RMIT partner institutions.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=131&version=4#document-top)
# Section 4 - Procedure
### General
(4)  On recommendation by the Admissions Governance Steering Committee, the Programs Committee may approve a higher English language entry requirement than the University minimum for a coursework program.
(5)  The Deputy Vice-Chancellor Research and Innovation may approve a higher English language entry requirement than the University minimum for a higher degree by research (HDR) program.
(6)  International Admissions maintains the following lists, with changes approved by the Programs Committee: 
  1. qualifications that satisfy the minimum University English language entry requirements, and
  2. approved English language proficiency tests and required scores.


### Meeting Minimum English Language Proficiency Requirements
(7)  Applicants to RMIT may demonstrate they meet the minimum English language requirements for entry into a program via one of the following: 
  1. an approved English language proficiency test
  2. completion of an English language preparatory program from an approved provider, or
  3. approved prior study taught and assessed entirely in English in an RMIT recognised English speaking country. 
  4. approved prior preparatory study taught and assessed entirely in English in an RMIT recognised English speaking country.


(8)  A list of recognised English speaking countries is published online and maintained by the Assistant Director, Pathways and Operation with changes noted by the Programs Committee.
(9)  Where an applicant’s completed qualification or studies have been taught and assessed entirely in English from a country not recognised as being an English speaking country (except for recognised secondary qualifications), English proficiency will be assessed on an individual basis. 
(10)  Additional requirements for demonstrating the required English language proficiency for different student cohorts and award levels are detailed in this procedure. 
### Meeting Requirements for Undergraduate and Postgraduate Coursework Programs 
#### VCE or equivalent
(11)  Applicants using a VCE or equivalent qualification as the basis of meeting minimum English language requirements must have achieved the following: 
  1. for entry to bachelor and postgraduate coursework programs, a study score of at least 30 in Units 3 & 4 English as an Additional Language (EAL) or at least 25 in Units 3 & 4 English, Literature or English Language 
  2. for entry to associate degrees, a study score of at least 25 in Units 3 & 4 English as an Additional Language (EAL) or at least 20 in Units 3 & 4 English, Literature or English Language 
  3. for entry via the Schools Network Access Program (SNAP) or Indigenous Access Program, the required English study score is five points lower than the published study score for entry to bachelor degree programs. 


#### Tertiary studies 
(12)  Domestic applicants using a tertiary qualification as the basis of meeting minimum English language requirements must either have: 
  1. successfully completed at least two courses (subjects) or 24 RMIT credit points at Australian undergraduate level (or overseas equivalent), or 
  2. an Australian Qualifications Framework (AQF) accredited award at certificate IV or higher (or overseas equivalent) or equivalent volume of learning. 


(13)  International applicants applying for admission must either have: 
  1. at least six years of primary and/or secondary education taught and assessed entirely in English in a recognised English-speaking country with at least two years of this education at secondary or senior secondary level (or overseas equivalent), and 
    1. at least two courses (subjects) or 24 RMIT credit points at Australian undergraduate level (or overseas equivalent), or
    2. an Australian Qualifications Framework (AQF) accredited award at certificate IV or higher (or overseas equivalent), or 
    3. the circumstances described in (14) for applications for postgraduate coursework programs only.
  2. a minimum of one-year full-time study in an award equivalent to an Australian diploma, advanced diploma, associate degree, bachelor degree, or 
  3. one semester full-time of a postgraduate qualification (equivalent to an Australian graduate certificate or higher).


#### Professional Work Experience – Postgraduate Coursework Program Applications
(14)  Applicants who are applying for postgraduate coursework programs may demonstrate they meet English language proficiency requirements with evidence of two years professional work experience in an occupation requiring English language proficiency.
### Meeting Requirements for Vocational Education Programs 
#### Domestic Applicants
(15)  There are no set minimum English language requirements for entry into vocational education programs. 
(16)  Applicants who are admitted to any vocational education program may be required to undertake a language, literacy and numeracy (LLN) assessment prior to enrolment. 
  1. The results of the LLN are used to determine the appropriateness and academic suitability of the offered program, any educational support requirements and the student’s eligibility for a VET student loan. 
  2. RMIT uses the BKSB tool to test LLN where an assessment is required. 
    1. Results of the BKSB test are made available directly to the student via the BKSB tool immediately after the test is taken.
    2. Results are also recorded in RMIT’s Student Management System. 
  3. RMIT will provide LLN results to authorised officers of the state and federal governments if requested.
  4. Offers may be rescinded if it is determined that the program is not appropriate. 


#### International Applicants
(17)  Applicants who have completed the VCE or equivalent must achieve a study score of at least 20 in Units 3 & 4 English as an Additional Language (EAL) or at least 15 in Units 3 & 4 English, Literature or English Language. 
### Meeting Requirements for Foundation Studies Programs
(18)  Applicants may demonstrate English language proficiency requirements for Foundation Studies programs by meeting (17), or:
  1. having successfully completed VCE units 1 & 2 English as an Additional Language (EAL), English, English Language or Literature(or equivalents at another Australian senior secondary institution) and achieved a minimum 50% average grade.


### Meeting Requirements for Non-Award Study 
(19)  Applicants for the following non-award programs may demonstrate they meet English language proficiency requirements as follows: 
  1. For study at RMIT via an approved RMIT exchange agreement, applicants may supply formal confirmation from their home institution that their level of English language proficiency meets RMIT requirements. 
  2. Incoming study abroad students must demonstrate they have successfully completed one year or the equivalent of 60 European credit Transfer and Accumulation System tertiary level courses where English is the language of instruction for the completed courses. 


### Meeting Requirements for Higher Degree by Research (HDR) Programs 
(20)  Applicants from recognised English speaking countries meet minimum English language entry requirements when they meet program academic entry requirements based on a qualification that was taught and assessed entirely in English. 
(21)  Applicants for HDR programs who are not from an English speaking country can demonstrate English language proficiency by the following: 
  1. A postgraduate qualification from an accredited university or institution where: 
    1. English was the medium of instruction and assessment of study, and 
    2. the final year of university study was completed during the five years immediately prior to the commencement of study at RMIT University. 
  2. Successful completion of at least two years of full-time (or part-time equivalent) university study from an accredited university or institution where: 
    1. English was the medium of instruction and assessment of study, and 
    2. the final year of university study was undertaken during the two years immediately prior to commencement at RMIT. 
  3. Evidence of professional experience and/or academic publications in English, such as: 
    1. sustained work for two years immediately prior to commencement at RMIT in a country where English is an official language 
    2. authorship or co-authorship of at least two English language peer-reviewed journal articles or a book chapter written and published in English within the three years prior to commencement at RMIT. 


### Time Limitations for Previous Study and Proficiency Tests
(22)  The following time limitations apply to the eligibility of previous study and proficiency tests for international applicants excluding those who meet the eligibility requirements of (13)a. for entry into coursework study:
Measure |  Time Limitation  
---|---  
Foundation Studies  | 2 years  
Secondary school studies |  2 years   
Bachelor or associate degree (completion of 1 year full-time or part-time equivalent) |  2 years   
Bachelor degree or higher (completion of award) |  5 years   
Postgraduate qualification (completion of 1 semester full-time or part-time equivalent) |  2 years   
Diploma or Advanced Diploma (completion of award 1 year full-time or part-time equivalent) |  2 years   
English language proficiency tests and approved English language programs |  2 years   
Satisfactory completion of an equivalent English subject from Denmark, Finland, Germany, Netherlands, Norway and Sweden (for students who have completed all schooling in one of these countries) |  5 years   
Satisfactory completion of an equivalent English subject from Denmark, Finland, Germany, Netherlands, Norway and Sweden (for students who haven’t completed all schooling in one of these countries) | 2 years  
Other completed qualifications |  2 years   
(23)  Time limitations for prior study and proficiency tests do not apply to applicants who have resided in a recognised English speaking country for at least five years since completing their secondary studies, bachelor degree or master degree in an English speaking country and can demonstrate having maintained their level of English proficiency through professional and/or academic achievements. 
(24)  Where an applicant for whom time limits apply presents with more than one measure of English language proficiency over a period of time, and where these are more than three months apart only the most recent will be considered. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=131&version=4#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Recognised English speaking countries  |  Countries formally recognised by RMIT as being English language speaking countries and where at least all secondary education is undertaken in English.   
---|---  
Secondary  |  Equivalent to years 7 to 10 in the Australian school system.   
Senior Secondary  |  Equivalent to years 11 and 12 in the Australian school system.   
Primary  |  Equivalent to Preparatory to year 6 in the Australian school system.   
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
