[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=160&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=160&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Information Management Standard 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=160)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=160&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=160&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=160&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=160&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=160&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=160&version=1)


# Information Management Standard
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=160&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=160&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=160&version=1#section3)
  * [Section 4 - Standard](https://policies.rmit.edu.au/document/view.php?id=160&version=1#section4)
  * [Overview](https://policies.rmit.edu.au/document/view.php?id=160&version=1#major1)
  * [Application Guidance](https://policies.rmit.edu.au/document/view.php?id=160&version=1#major2)
  * [Requirements](https://policies.rmit.edu.au/document/view.php?id=160&version=1#major3)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=160&version=1#major4)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=160&version=1#major5)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=160&version=1#major6)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Purpose
(1)  This standard foregrounds RMIT’s commitment to information management and its approach to the compliant handling of information in digital form, in compliance with relevant legislation. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=160&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=160&version=1#document-top)
# Section 3 - Scope
(3)  This standard applies globally to any person or entity of the RMIT Group, including staff, students, temporary employees, contractors, visitors and third parties who manage RMIT information; with the exception of research data as defined by the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=160&version=1#document-top)
# Section 4 - Standard
### Overview
(4)  RMIT must comply with standards issued under the [Public Records Act 1973 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=38) by the [Public Record Office Victoria (PROV)](https://policies.rmit.edu.au/download.php?id=219&version=1&associated). These standards specify how the information we create as part of our work – or records - must be managed. 
(5)  The [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53) establishes a framework for effective information governance. This standard supports the policy by providing clear information management requirements for information in digital form that underpin the embedding of information management into day-to-day practices by default, so that information is complete, authentic and reliable evidence of RMIT’s actions and decision making. 
(6)  These requirements apply to information, also known as unstructured data, wherever it is received, created or managed including (but not limited to) email systems, productivity tools, business or applications in digital form. This compliance by design approach enables RMIT to build compliance into its systems and processes so that we can: 
  1. gain visibility over current risks 
  2. mitigate risks where possible 
  3. accept residual risks where necessary .


### Application Guidance
(7)  These requirements should be implemented using a risk and value-based approach. Measures taken to ensure compliance should be reasonable and commensurate with the risk presented by the information; they should be followed more closely for high-value information or information needed to mitigate high business risk. 
(8)  Indicators of high-value business information include that it: 
  1. is critical to business continuity and/or accountability 
  2. affects the rights and entitlements of students, staff, or the broader community 
  3. significantly affects workplace health and safety 
  4. is subject to a high level of scrutiny (i.e., audits and freedom of information requests) or has a high likelihood for legal action 
  5. involves large sums of funding. 


### Requirements
(9)  Information is created and managed digitally throughout its life.
  1. Information should be created and managed in hardcopy only by exception. Exceptions may include where a document must be created and maintained in hardcopy for legal reasons. 
  2. Information must be maintained in a format that is expected to survive and be readable for the required life of the information, as defined in the [Retention and Disposal Authority Standard (RDA Standard)](https://policies.rmit.edu.au/document/view.php?id=55). 


(10)  Information must be retained according to legal and business requirements and disposed of lawfully when their retention period ends. 
  1. Information must be retained in accordance with the [RDA Standard](https://policies.rmit.edu.au/document/view.php?id=55) for as long as required. 
  2. Information must be disposed of – either destroyed/deleted or transferred – in accordance with the [Destruction of Information Procedure](https://policies.rmit.edu.au/document/view.php?id=136). 


(11)  Information is to be shared. Access to information held by RMIT must not be restricted, unless required by legislation or in accordance with policy or authorised criteria. 
  1. RMIT must support openness and transparency by only restricting access to information when required by legislation, regulation or policy. These may include freedom of information exemptions or privacy principles for personal information. 
  2. Unauthorised access and unlawful deletion must be prevented. 


(12)  Controls must be designed and implemented to ensure information is only accessed, amended, used, released, or disposed of as authorised. 
  1. Evidence of the integrity, authenticity and reliability of information must be captured and retained for its lifetime. 
  2. This may be demonstrated by capturing appropriate audit trails and version control (i.e. who performed which action on what information at what time, major amendments must be documented). 
  3. Business continuity and disaster recovery planning must ensure information can be retrieved in the event of disaster. 


(13)  Information must have sufficient description to allow access and management over time. 
  1. The minimum will include the following metadata elements: title, creator, date created, and a unique identifier. 


(14)  Information must be managed to facilitate migration or relocation over time to ensure required retention. 
  1. This may include managing information and data beyond the life of the system (e.g., the reasonable likelihood of the need for migration to systems must be assessed) . 
  2. Considerations should include (but not be limited to) the export capabilities of tools and applications used, the formats in which information can be extracted and the ability to extract information in a timely manner – either by RMIT or vendor. 


### Responsibilities
(15)  Managing information compliantly is everyone’s responsibility and all staff, students, researchers and affiliates have an obligation to manage the information they receive, create, collect, manage, use or re-use during their engagement with RMIT in accordance with this standard, the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53) and relevant information security, information privacy and data governance policies.
(16)  Managers are required to ensure that information management principles and practices are implemented locally, and suspected or actual breaches of this standard are reported in accordance with the [Compliance Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=50). 
(17)  Information Trustees as owners of information must review any risks to information within their remit caused by non-compliance with these principles. If residual risk remains, they must take further mitigating steps or accept the risk/s. 
(18)  Information Stewards provide support and advice for information management activities within their area. 
(19)  The Chief Information Security Officer oversees information security controls and responses to enable RMIT to deliver effective protection of data held by RMIT consistent with privacy and corporate management obligations across all its operations. 
(20)  The Chief Data and Analytics Officer (CDAO) is accountable for leading the information governance framework across RMIT and the CDAO team is responsible for enterprise information management standards in accordance with applicable legislation, under the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53). 
(21)  The Information Governance Board provides advice and recommendations for the strategy, policy and risk in relation to RMIT’s information and data.
### Compliance
(22)  Breaches of this standard will be managed in accordance with the [Compliance Breach Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=50). 
### Review
(23)  The Chief Data and Analytics Officer will review this standard at least every three years in accordance with the [Policy Governance Framework](https://policies.rmit.edu.au/document/view.php?id=57). 
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
