[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=222#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=222#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Procurement Quotation Procedure (Australia) 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=222)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=222)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=222)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=222)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=222)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=222)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=222)


# Procurement Quotation Procedure (Australia)
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=222#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=222#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=222#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=222#section4)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=222#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets out how to obtain quotations for expenditure by RMIT in relation to the acquisition of goods or services.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=222#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Procurement and Expenditure Policy](https://policies.rmit.edu.au/document/view.php?id=221).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=222#document-top)
# Section 3 - Scope
(3)  This procedure applies to expenditure on goods or services, which is below the Strategic Sourcing threshold, as set out in the Procurement Schedule 1 – Purchasing Threshold (Australia and Vietnam).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=222#document-top)
# Section 4 - Procedure
(4)  Seeking quotations provides a way to engage the supply market in order to obtain a competitive price from one or more suppliers for a defined supply of goods, or scope of works or services.
(5)  Goods or services must be obtained from an existing RMIT supplier (including from a panel provider, or through an RMIT Catalogue) in the first instance. RMIT staff should only seek to engage a new supplier on an exceptional basis.
(6)  Any high-risk expenditure, and expenditure which is at or above the Strategic Sourcing Threshold, must be referred to the RMIT Procurement team.
(7)  For non high-risk expenditure, the Purchasing Threshold table sets out how many quotations are required to enable appropriate price competition for different amounts of expenditure.
(8)  A policy waiver must be completed for any expenditure that cannot be conducted in a way which is consistent with the relevant minimum requirements.
(9)  For the avoidance of doubt, the requirement to obtain multiple quotations under the Purchasing Threshold table applies even when the proposed suppliers are all RMIT Contracted Suppliers, or from a Vendor Catalogue or a Panel.
(10)  It is the responsibility of the person requesting a quotation to ensure their specification of goods, or scope of works or services are clear, unambiguous and comprehensive to allow the supplier to provide an accurate quote.
(11)  Records of quotes received must be kept for audit purposes.
(12)  It is the responsibility of the person requesting the quotes to ensure that the goods or services sought comply with RMIT’s specifications and requirements and that they are fit for purpose.
(13)  Acceptance of a supplier’s quote or price offer must not be communicated to the supplier prior to approval by an RMIT staff member with appropriate financial delegation under the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51). RMIT staff must not make commitments to suppliers without obtaining the required approval under the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=222#document-top)
# Section 5 - Resources
(14)  See also:
  1. [Procurement and Expenditure Policy](https://policies.rmit.edu.au/document/view.php?id=221)
  2. [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51)
  3. [Procurement Strategic Sourcing Procedure (Australia)](https://policies.rmit.edu.au/document/view.php?id=224)
  4. [Procurement Schedule 1 – Purchasing Threshold (Australia and Vietnam)](https://policies.rmit.edu.au/document/view.php?id=223)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
