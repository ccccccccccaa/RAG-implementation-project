[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=133&version=5#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=133&version=5#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Entry Requirements Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=133)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=133&version=5)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=133&version=5)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=133&version=5)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=133&version=5)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=133&version=5)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=133&version=5)


# Academic Entry Requirements Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=133&version=5#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=133&version=5#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=133&version=5#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=133&version=5#section4)
  * [General](https://policies.rmit.edu.au/document/view.php?id=133&version=5#major1)
  * [Preparatory Programs ](https://policies.rmit.edu.au/document/view.php?id=133&version=5#major2)
  * [Vocational Education Programs](https://policies.rmit.edu.au/document/view.php?id=133&version=5#major3)
  * [Undergraduate Programs](https://policies.rmit.edu.au/document/view.php?id=133&version=5#major4)
  * [Postgraduate by Coursework](https://policies.rmit.edu.au/document/view.php?id=133&version=5#major5)
  * [Higher Degree by Research](https://policies.rmit.edu.au/document/view.php?id=133&version=5#major6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure documents the minimum academic entry requirements for admission into programs and courses at RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=133&version=5#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=133&version=5#document-top)
# Section 3 - Scope
(3)  This procedure applies to all programs, courses and non-award study offered by the RMIT Group and RMIT partner institutions.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=133&version=5#document-top)
# Section 4 - Procedure
### General
(4)  International Admissions, in collaboration with colleges/schools/industry clusters as required, maintains the list of overseas qualifications equivalent to the [Australian Qualifications Framework (AQF)](https://policies.rmit.edu.au/download.php?id=18&version=2&associated) that satisfy University academic entry requirements for coursework programs. 
  1. The list is determined in accordance with Australian Government or other RMIT recognised databases. 
  2. College Admission teams assess equivalence of overseas qualifications to the AQF for applications made direct to RMIT. 
  3. The Programs Committee approves changes to this list.


(5)  Where a qualification is stated to meet a minimum entry requirement, the following also meet the requirement except for entry to a one-year honours program: 
  1. a qualification (or equivalent volume of learning) at a higher AQF level, or
  2. an equivalent overseas qualification. 


(6)  The following qualifications are considered by RMIT to be equivalent to the Victorian Certificate of Education (VCE): 
  1. Senior Certificate of Education in other Australian states or territories, as deemed by the Victorian Curriculum and Assessment Authority
  2. New Zealand National Certificate of Educational Achievement (NCEA) Level 3 
  3. the International Baccalaureate Diploma Programme, or 
  4. a recognised equivalent overseas high school qualification. 


### Preparatory Programs 
(7)  Admission to the VCE is subject to the requirements stated in the publications of the Victorian Curriculum and Assessment Authority.
(8)  All selected into programs funded by the Victorian Government must complete an approved language, literacy and numeracy test before enrolment.
(9)  Foundation Studies programs for students studying on a student visa are designed according to the Foundation Program Standards 2021. 
  1. International Admissions advise on the comparability of standard for non-award and overseas preparatory programs with reference to Australian Government and other recognised databases.
  2. Programs Committee approves alternative non-award and overseas studies, including but not limited to, Australian Foundation programs (which comply with Foundation programs Standards 2021) and other overseas foundation programs.


### Vocational Education Programs
#### Certificate I, II, III and IV, Diploma and Advanced Diploma Programs
(10)  There are no University academic entry requirements for domestic applicants.
(11)  All applicants (except international applicants) must complete an approved language, literacy and numeracy test before enrolment.
(12)  All applicants selected into programs funded by the Victorian government must complete an approved language, literacy and numeracy test before enrolment.
(13)  Apprenticeship and traineeship applicants must present a current, signed and valid Australian Apprenticeship Support Network Training Agreement.
### Undergraduate Programs
#### Associate Degree and Bachelor Degree Programs (Including Four-Year Bachelor Honours Degree Programs)
(14)  Applicants must have a Victorian Certificate of Education (VCE) or one of the equivalent qualifications or approved studies in Table 1 below.
  1. Alternatively, an applicant may satisfy the requirement if they achieve an acceptable result in an approved aptitude test.


Table 1: Completion of Minimum Academic Requirement by Qualification and approved studies to meet RMIT’s minimum academic requirements.
Qualifications and Approved Studies Type |  Minimum Academic Requirement  
---|---  
Victorian Senior Secondary Qualification | Victorian Certificate of Education Vocational Major.  
Victorian Senior Secondary Qualification | Senior Victorian Certificate of Applied Learning (Senior VCAL).  
Australian Year 12 (other states) |  An Australian Senior Certificate of Education for the State.  
New Zealand Level 3 |  The National Certificate of Educational Achievement.  
International Baccalaureate Diploma |  The International Baccalaureate Diploma.  
Foundation Studies |  A Foundation Studies program offered by a registered TAFE, university or private provider that is accredited as a Certificate IV or compliant with the Foundation Programs Standards 2021 or deemed acceptable for entry.  
International secondary schooling |  A qualification recognised by RMIT as detailed under the Country or region equivalence webpage for recognised qualifications that are frequently presented by applicants.  
Australian higher education studies |  Satisfactory completion, on an award or non-award basis at any university (including Open Universities Australia), of at least two courses (subjects) at undergraduate level equivalent in volume of learning to at least 24 RMIT University credit points.  
International tertiary studies |  Satisfactory completion of study equivalent to at least six months full time in a program assessed as equivalent to an AQF qualification of at least level 5.  
Australian vocational education studies |  Satisfactory completion of an AQF accredited award at Certificate IV or above.  
#### Double Degree
(15)  The level of achievement required for admission to a double degree will not be lower than the requirement for admission to either of the two component single degrees.
#### One-Year Bachelor Honours Programs
(16)  Applicants for one-year bachelor honours programs must hold an equivalent Australian bachelor degree in a relevant discipline with an RMIT-equivalent GPA of at least 2.0. The published entry requirements of the program will specify which courses contribute to this GPA.
### Postgraduate by Coursework
(17)  Applicants for graduate certificate, graduate diploma and master by coursework programs must hold:
  1. a bachelor degree; or
  2. an appropriate level of advanced professional experience relevant to the discipline area.


(18)  Applicants for extended master programs must hold a bachelor degree.
### Higher Degree by Research
#### Masters by Research
(19)  The minimum requirements for admission to a masters by research program are:
  1. a bachelor's degree requiring at least four years of full-time study in a relevant discipline awarded with honours. The degree should include a research component comprised of a thesis, other research projects or research methodology subjects that constitute at least 25% of a full time (or part time equivalent) academic year. The applicant must have achieved at least a credit average in the final year; or
  2. evidence of appropriate academic qualifications and/or experience that satisfies the Associate Deputy Vice-Chancellor Research Training and Development or nominee that the applicant has developed knowledge of the field of study or cognate field and the potential for research sufficient to undertake the proposed program.


(20)  At RMIT a grade of Credit represents academic achievement of 60% or higher.
#### Doctor of Philosophy
(21)  The minimum requirements for admission to a Doctor of Philosophy (PhD) program are:
  1. a bachelor's degree requiring at least four (4) years of full-time study in a relevant discipline awarded with honours. The degree should include a research component comprised of a thesis, other research projects or research methodology subjects that constitute at least 25% of a full time (or part time equivalent) academic year. The applicant must have achieved at least a distinction average in the final year; or
  2. a master's degree that includes a research component comprised of at least 25% of a full time (or part time equivalent) academic year with an overall distinction average or a master's degree without a research component with at least a high distinction average; or
  3. evidence of appropriate academic qualifications and/or experience that satisfies the Associate Deputy Vice-Chancellor Research Training and Development or nominee that the applicant has developed knowledge of the field of study or cognate field and the potential for research sufficient to undertake the proposed program.


(22)  At RMIT a grade of Distinction represents academic achievement of 70% or higher and a High Distinction is 80% or higher.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
