[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=248&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=248&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Sexual Harm Response Procedure - Vietnam 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=248)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=248&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=248&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=248&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=248&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=248&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=248&version=2)


# Sexual Harm Response Procedure - Vietnam
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=248&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=248&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=248&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=248&version=2#section4)
  * [Disclosures](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major1)
  * [Ways to make a disclosure](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major2)
  * [Ways to make a formal report](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major3)
  * [Reports or notifications to Police](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major4)
  * [Precautionary measures](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major5)
  * [Informal or formal processes](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major6)
  * [Ongoing support and assistance](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major7)
  * [False reports](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major8)
  * [Privacy, confidentiality and record keeping](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major9)
  * [Internal reporting and continuous improvement](https://policies.rmit.edu.au/document/view.php?id=248&version=2#major10)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=248&version=2#section5)
  * [Section 6 - Associated information](https://policies.rmit.edu.au/document/view.php?id=248&version=2#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This Procedure documents how RMIT will support and respond to matters involving sexual harm in Vietnam.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Sexual Harm Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to:
  1. all students studying in RMIT Vietnam campuses
  2. all staff and associates of the RMIT Group, with the same scope as the [Sexual Harm Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).


(4)  Other policies and procedures at RMIT apply directly to student conduct, staff misconduct, third party, anonymous or whistleblower reports. However,
  1. where a disclosure or report made pursuant to those other procedures involves sexual harm, this procedure also applies, unless there are specific overriding factors or circumstances (e.g. if the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) applies).
  2. those policies and procedures should be applied in a manner to enable the [Sexual Harm Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218) and this procedure to have full effect in supporting the person reported to have been sexually harmed.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248&version=2#document-top)
# Section 4 - Procedure
### Disclosures
(5)  A disclosure of sexual harm is when a person first makes known an incident of sexual harm. Staff and students can choose to make a disclosure of sexual harm to anyone they trust, including a staff member of RMIT. A person who makes a disclosure is not required to make a formal report of sexual harm.
(6)  Where a staff member receives a disclosure of sexual harm, or becomes aware of a disclosure, the staff member must provide advice to the discloser that they can seek support from Safer Community, (which is part of the Wellbeing Department) in relation to formal reporting options.
(7)  All RMIT Vietnam staff members are under an obligation to notify Safer Community when they receive a disclosure of sexual harm, in order to inform RMIT’s ongoing prevention and support strategies and enable better responses.
  1. The staff member must inform the discloser of this obligation to notify and ask the discloser about what information they consent to being shared with Safer Community, including if the discloser would like to remain anonymous.
  2. If the discloser does not want their identity disclosed (or the identity of the person they are reporting about), the staff member will ensure the information they provide to Safer Community does not identify the discloser (or the person they are reporting about).


(8)  Safer Community will provide support for persons who make a disclosure of sexual harm and seek to resolve a disclosure where it is safe, reasonable and appropriate to do so.
### Ways to make a disclosure
(9)  All persons who have experienced sexual harm can contact Safer Community (via the online [Student Connect](https://policies.rmit.edu.au/download.php?id=130&version=2&associated) portal [students only]; email safercommunityvn@rmit.edu.vn or in person at the Saigon South campus) for support and advice, regardless of where or when the harm occurred or whether they want only to make a disclosure of harm, or to make a formal report about it. Specialist support and advice services external to RMIT are also listed on the Safer Community webpage.
(10)  In an emergency or in circumstances of immediate danger call RMIT security on 028 3776 1368 (SGS) and 942 347 108 (Hanoi) or International SOS 24/7 Assist on 028 3824 0555.
(11)  RMIT Vietnam staff members can contact People Connect for support and advice.
### Ways to make a formal report
(12)  After, or while making a disclosure regarding sexual harm, a person may choose to make a formal report – but they are not required to; it is their choice. A report is where a person provides a statement or account about sexual harm, and where a formal response or resolution is sought or expected by them.
(13)  RMIT encourages persons who want to make a formal report to contact Safer Community for advice and support. Safer Community can provide information on how to report under the applicable policy or policies, which may be different depending on whether the person making the report is a current student or a staff member, and whether the person who is reported to have caused the sexual harm (the respondent) is a student or a staff member. For example, Safer Community can support a student to make a formal report. With the student’s permission, the report may then be referred to Academic Registrar's Group, Student Conduct to be addressed via the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). Similarly, Safer Community can support a staff member to make a formal report. With the staff member’s permission, the report may then be referred to the Human Resource Department to be addressed via the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122).
(14)  The channels for providing a safe and confidential report of sexual harm include:
  1. [Student Connect](https://policies.rmit.edu.au/download.php?id=130&version=2&associated) online, for current students
  2. People Connect or the [RMIT Complaints portal](https://www.rmit.edu.au/utilities/complaints), for current staff
  3. the Complaints portal, for former RMIT students and staff
  4. the Complaints portal, for third parties (within Australia and internationally), if the harm occurred while they were engaged in RMIT activities or if it involved a member of the RMIT community.


### Reports or notifications to Police
(15)  If a person who has experienced sexual harm wants to make a report to Police, Safer Community can support a person to make a police report but cannot make a police report on that person’s behalf. Safer Community support could include support of a non-Vietnamese speaking person via the assistance from a certified translator.
(16)  However, in certain circumstances, RMIT may have a duty to notify the Police, and/or the [Australian Department of Foreign Affairs and Trade (DFAT)](https://www.dfat.gov.au/) for matters relating to Australian expatriate staff in its own name. This includes where the incident involves a risk to students, or staff; or where the person who is the subject of the disclosure or report presents a risk to themselves.
  1. RMIT may have this obligation to notify the Police or DFAT even if the discloser does not want to make their own report to the Police or DFAT.
  2. A notification to the Police by RMIT in its own name in translator-approved Vietnamese and English must be approved by the Chief Operating Officer (if the respondent is a staff member) and Academic Registrar (AUS) or delegate authority in VN (if the respondent is a student) taking into account: 
    1. evidence of an unacceptable risk to RMIT’s community, or the public
    2. multiple disclosures, reports, or complaints about the same person
    3. advice from the Critical Incident Management Team, and other relevant groups including Policy and Workplace Relations, Risk, Compliance and the Academic Registrar's Group
    4. advice from Safer Community
    5. the wishes of the person who has experienced the sexual harm or who made the disclosure or report initially.


(17)  Safer Community will advise the person who has disclosed or reported the sexual harm about RMIT’s decision to notify the Police and (to the extent possible) will keep the person informed of any actions that result from that notification.
### Precautionary measures
(18)  Safer Community may recommend certain temporary or permanent precautionary measures in response to a report of sexual harm, to protect the wellbeing and safety of all students, staff, and third parties, and where there may be an ongoing risk to the broader RMIT community. Safer Community will consult with the relevant areas of RMIT in implementing appropriate precautionary measures including Health, Safety and Wellbeing, Risk, [Compliance](https://policies.rmit.edu.au/download.php?id=147&version=1&associated), the Academic Registrar's Group, Legal Services, Student Experience and Success and Policy and Workplace Relations.
(19)  In managing a response to a critical incident, the Safer Community team will provide expert advice and guidance to the Critical Incident Management Team VN to inform the management of risks and issues associated with sexual harm.
(20)  Where one or more of the persons involved in a report of sexual harm is a student, precautionary measures that can be implemented by the Safer Community team under the direction of the Executive Dean of Students may include but are not limited to:
  1. changes to class timetables
  2. temporary remote learning arrangements
  3. temporary restriction of access to campus
  4. academic adjustments
  5. no contact directives
  6. a recommendation regarding an executive suspension, in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).


(21)  Where one of the persons involved in a report of sexual harm is a staff member, precautionary measures which can be implemented through the Human Resource team may include adjustments to working arrangements.
(22)  Precautionary measures are not a punitive measure and do not indicate that RMIT has concluded that a breach of the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), Internal Labour Rules or [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) has occurred.
### Informal or formal processes
(23)  Where a disclosing or reporting person wishes to resolve a matter informally, RMIT may utilise processes that focus on the resolution of the issue rather than the substantiation of the report through a full investigation, such as restorative engagement processes.
(24)  Where a report of sexual harm is repeated conduct, or where the harm or conduct is of a more serious nature, it will be more appropriate to use formal procedures which are directed at establishing whether a report is substantiated. However, RMIT may be required to pause or temporarily suspend certain investigation activities, if required to do so by Police or other external regulators or authorities.
(25)  RMIT will ensure that persons who carry out investigations have been properly trained in taking a trauma-informed approach regarding instances of reported sexual harm.
(26)  RMIT will offer support to all persons who are affected by a disclosure or report of sexual harm, including persons who make disclosures or reports, as well as the person about whom a report is made. Support may include:
  1. providing a referral for a support person to attend meetings for reassurance and emotional support
  2. staff or student counselling services, privately sourced counselling services, Safer Community, and
  3. other support mechanisms or facilities as appropriate.


(27)  Persons who make a report, as well as persons who are the subject of a report, will be provided with information about the steps involved for any formal or informal resolution process; and they will be kept appropriately informed about the progress and outcome of those steps in accordance with the relevant policy and procedure.
### Ongoing support and assistance
(28)  RMIT will continue to provide appropriate and reasonable assistance and support to protect the safety and wellbeing of all parties after the conclusion of any investigative or disciplinary action, including the recovery of any person who has been found through the RMIT process to have been sexually harmed.
### False reports
(29)  Any person who knowingly makes a false report of sexual harm may be subject to disciplinary action in accordance with RMIT regulations, policies and procedures.
### Privacy, confidentiality and record keeping
(30)  Disclosures and reports of sexual harm will be treated confidentially and in accordance with RMIT's [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59). This means that disclosures and reports of sexual harm may be shared confidentially with appropriate officers of RMIT or external authorities on a strict need-to-know basis, as part of RMIT's duty of care obligations or as required by law.
(31)  Safer Community maintain a confidential register of disclosures about sexual harm. Human Resources and Academic Registrar's Group will maintain confidential register of reports about sexual harm. All information will be collected, stored, and accessed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59), and any applicable laws.
(32)  A person who provides information to Safer Community or via the anonymous reporting portal about an incident of sexual harm may remain anonymous, however this may prevent RMIT from taking further steps in relation to the disclosure or report in view of procedural fairness requirements. RMIT will provide support and take all reasonable steps to ensure there are no repercussions for a person who has made a disclosure or report of sexual harm.
(33)  RMIT will use de-identified data about disclosures and reports relating to sexual harm to inform preventative strategies, identify trends and develop targeted responses to sexual harm in the RMIT community.
(34)  There are some limited circumstances in which RMIT may be required to disclose identifying information about a person, for the safety and wellbeing of the members of the RMIT community, including the person identified (such as where RMIT is required by law to report an incident to the Police or a regulator).
### Internal reporting and continuous improvement
(35)  De-identified data will be reported by Health, Safety and Wellbeing AUS every six months, or as required, to the Vice Chancellor’s Executive, the Vice-Chancellor’s Prevention of Gender-based Violence Advisory Group, RMIT Council, the Pro Vice-Chancellor Vietnam, the Vietnam Leadership Team and other areas of RMIT as required to identify trends and systemic issues, contribute to evaluation of prevention programs, and aid RMIT to identify opportunities for improvements, and preventative actions. Access to this information will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(36)  RMIT may provide information to a third party for investigation purposes in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and Procedures. Where a requirement to make a report to a third party exists and this information is not able to be provided in a de-identified format, the individual will be consulted prior to the report being made and every effort taken to respect privacy and minimise trauma.
(37)  RMIT will also provide de-identified data to external agencies or bodies, where required, to ensure compliance with legislated reporting requirements including, but not limited to, those detailed under the [Gender Equality Act 2020 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/gender-equality-act-2020/) and the [Workplace Gender Equality Act 2012 (Cth)](https://www.legislation.gov.au/Details/C2016C00895). Access to this information will be managed in accordance with the RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(38)  If disclosed or reported incidents indicate material breaches in safety or preventative controls, including recurring incidents of sexual harm, Safer Community will notify the Director, Academic Governance and Standards, who will determine if it is appropriate to notify the [Tertiary Education Quality and Standards Agency (TEQSA)](https://www.teqsa.gov.au/). If deemed appropriate, a recommendation will be made to the Deputy Vice-Chancellor Education that TEQSA be notified.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248&version=2#document-top)
# Section 5 - Resources
(39)  Refer to the following documents established in accordance with this procedure:
  1. [Sexual Harm Response Procedure](https://policies.rmit.edu.au/document/view.php?id=219)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=248&version=2#document-top)
# Section 6 - Associated information
(40)  [Sexual Harm Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218)
(41)  [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52)
(42)  [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)
(43)  [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
(44)  [Complaints Governance Policy](https://policies.rmit.edu.au/document/view.php?id=110)
(45)  [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122)
(46)  [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59)
(47)  [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14)
(48)  Internal Labour Rules
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
