[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=25&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=25&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Distribution of Commercialisation Income Process 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=25)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=25&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=25&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=25&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=25&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=25&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=25&version=1)


# Distribution of Commercialisation Income Process
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=25&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=25&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=25&version=1#section3)
  * [Section 4 - Process](https://policies.rmit.edu.au/document/view.php?id=25&version=1#section4)
  * [More information](https://policies.rmit.edu.au/document/view.php?id=25&version=1#major1)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Purpose
(1)  This resource describes how income from commercialisation activities is distributed by the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=25&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=25&version=1#document-top)
# Section 3 - Scope
(3)  This process applies to all University staff and students who are creators of intellectual property.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=25&version=1#document-top)
# Section 4 - Process
(4)  Following successful commercialisation of University-owned Intellectual Property, the Intellectual Property and Commercialisation Team (IPC Team) will distribute royalties in accordance with Schedule 2 of the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23).
(5)  On an annual basis, the IPC Team will contact each of the Creators to advise on the royalty amount payable and period for which the royalties relate.
(6)  Creators will provide details on how they would like to receive their royalty payment by competing the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated). Creators will also note that depending on how royalties are to be paid, there may be tax implications that apply. The options are:
  1. Payments to personal bank accounts
  2. Payments to a separate entity with an ABN
  3. Payments to internal research accounts
  4. A combination of the above


(7)  Depending on how Creators wish to receive their royalty payments the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated) requires approval from various delegates at RMIT:
  1. For payment to personal bank accounts, the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated) requires approval from an appropriate RMIT delegate within R&I (DVC R&I). 
    1. In addition to the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated), Creators choosing this option need to also fill, sign and submit a [Statement by a Supplier Fact Sheet-Form](https://policies.rmit.edu.au/download.php?id=15&version=1&associated) from the Australian Tax Office.
    2. Creators should select the sixth option – “not entitled to an ABN”, sign and submit the form to the IPC Team.
  2. For payment to a separate entity with ABN, the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated) requires approval from an appropriate RMIT delegate within R&I (DVC R&I). In addition, Creators should also provide an invoice (or if registered for GST, a tax invoice) noting the ABN to the IPC Team.
  3. For payment to internal research accounts, the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated) requires approval from an appropriate RMIT delegate within R&I (DVC R&I). In addition, the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated) also requires the Creator/s to sign a declaration on the form to state that they will forgo payment. The Creators then request the appropriate delegate in their School/College with the authority to request that the forgone royalties are then distributed to the research account nominated by the Creator/s for use in on-going research.


(8)  For 7(a)or (b) above, the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated) approved by the appropriate R&I delegate and other relevant documentation noted above is forwarded to the appropriate Financial Delegate for payment independently of payroll.
(9)  For 7(c) above, the [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated) approved by the appropriate R&I delegate and by the appropriate delegate in the Creator/s’ School/College is forwarded to R& I Finance Team for allocation into nominated internal research account.
### More information
(10)  For more information, please contact the Intellectual Property and Commercialisation Team at ip.commercialisation@rmit.edu.au.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
