[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=253#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=253#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Supervision Arrangements Schedule 1 - Supervision Registration Requirements 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=253)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=253)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=253)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=253)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=253)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=253)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=253)


# HDR Supervision Arrangements Schedule 1 - Supervision Registration Requirements
Hide Navigation
  * [HDR Supervision Arrangements Schedule 1 – Supervisor Registration Requirements](https://policies.rmit.edu.au/document/view.php?id=253#major1)
  * [Internal Supervisors](https://policies.rmit.edu.au/document/view.php?id=253#major2)
  * [External Supervisors](https://policies.rmit.edu.au/document/view.php?id=253#major3)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
### HDR Supervision Arrangements Schedule 1 – Supervisor Registration Requirements
(1)  Authority for this document is established by the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14).
### Internal Supervisors
Internal Supervisors  
---  
Definition |  Fixed-term and continuing RMIT salaried staff RMIT Emeritus Professors  
Roles available | Senior Supervisor (not available to fixed-term staff) Joint Senior Supervisor Associate Supervisor  
Academic qualifications | PhD (or formally deemed equivalent)  
*Supervisory load is the sum of all proportions of supervision provided by an individual supervisor. It is not adjusted for candidate load. **Applications to exempt prospective supervisors from the research active requirements detailed in [Schedule 1](https://policies.rmit.edu.au/download.php?id=290&version=1&associated) must be recommended by the Dean of School based on evidence of research and supervisory performance and/or capability, and approved by the ADVC RT&D or nominee. Exemptions would apply to achievements relative to opportunity and industry fellowship appointments. 
Categories | Maximum supervisory load Teaching and research staff* | Maximum supervisory load Research only staff* | Research active requirements ** | Professional development requirements  
---|---|---|---|---  
Associate Supervisor | 8 | 10 | None | As per [Schedule 3 -Supervisor Professional Development](https://policies.rmit.edu.au/document/view.php?id=256)  
Senior or Joint Senior Supervisor | - At least one HDR supervision to completion (as Senior or Associate) And within the last 3 years, either: - An ERA recognisable research output (including publications and creative works) and external research income or - A minimum of three ERA recognisable research outputs, two of which must be Q1 (or equivalent).  
### External Supervisors
External Supervisors  
---  
Definition | Anyone not employed by RMIT  
Roles available | Joint Senior Supervisor Associate Supervisor  
Academic qualifications | None required for associate supervision. PhD (or formally deemed equivalence) for Joint Senior Supervisor  
Categories | Maximum number of candidates (by FTE) | Research active requirements | Professional development requirements  
---|---|---|---  
Associate supervisor | None | None | None  
Joint senior supervisor | None | None | None  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
