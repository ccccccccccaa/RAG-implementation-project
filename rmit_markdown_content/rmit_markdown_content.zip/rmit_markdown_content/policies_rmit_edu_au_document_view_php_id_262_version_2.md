[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=262&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=262&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Smoke-free RMIT Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=262)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=262&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=262&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=262&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=262&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=262&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=262&version=2)


# Smoke-free RMIT Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=262&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=262&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=262&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=262&version=2#section4)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=262&version=2#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure outlines RMIT’s commitment to providing a smoke-free work and learning environment for the benefit of all students, staff, contractors, service providers, clients, customers and visitors. Providing a smoke-free environment:
  1. reduces the risk of smoking-related illnesses in RMIT’s staff and students
  2. reduces fire related risks with RMIT facilities
  3. raises awareness of the health risks associated with smoking
  4. provides a cleaner environment for the wellbeing of staff, students and others
  5. promotes a community that actively encourages and welcomes a smoke-free environment.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=262&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Health Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=262&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all:
  1. RMIT-controlled buildings, grounds and property
  2. RMIT-owned or controlled vehicles, and
  3. RMIT income and investment streams, including venue hire.


(4)  This procedure is applicable to all students, staff, contractors, service providers, clients, customers and visitors (defined as ‘persons’) when they are engaged in RMIT activities.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=262&version=2#document-top)
# Section 4 - Procedure
(5)  RMIT is committed to providing a safe and healthy campus environment free of passive smoking risk for staff, students, contractors, honorary appointees and visitors.
(6)  While RMIT recognises an individual's right to smoke and consume tobacco products, RMIT is committed to minimising the smoking-related and tobacco-related harm to all persons who attend RMIT’s campuses.
(7)  Smoking is prohibited:
  1. in RMIT vehicles
  2. in RMIT-controlled buildings, and
  3. on RMIT-controlled grounds and property, except for those areas established as designated smoking areas.


(8)  Smoking and tobacco advertising, promotion and sales are prohibited in or on RMIT-controlled property and buildings.
(9)  The Executive Director, Property Services may establish designated smoking areas at each RMIT campus. When doing so, the following requirements must be met:
  1. minimum distance of four metres from any building entrance, operable window or air intake
  2. minimum distance of 10 metres from any dangerous goods storage or delivery area
  3. reasonable protection for non-smokers from environmental tobacco smoke likely to emanate from the designated smoking area
  4. reasonable access for smokers located on the campus, and
  5. adequate signage.


(10)  The person responsible for approving new leases, licences and other permission to use RMIT space must include provisions restricting the occupants of the space from smoking and/or selling tobacco products.
(11)  The Executive Director, Governance, Legal and Strategic Operations must ensure the Smoke-Free Procedure is publicly available for suppliers on RMIT's policy website.
(12)  The Director, Health Safety and Wellbeing must ensure smoking cessation information and resources are available to support staff and students.
#### Compliance
(13)  Students persistently breaching the Smoke-Free Procedure may be subject to action under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
(14)  Staff persistently breaching the Smoke-Free Procedure may be subject to action under the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122).
(15)  Contractors persistently breaching the Smoke-Free Procedure may be required to leave RMIT or may be subject to an action for breach of contract.
(16)  Visitors continuing to breach the Smoke-Free RMIT Procedure after being asked by RMIT Security to desist, may be required to leave RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=262&version=2#document-top)
# Section 5 - Definitions
Term | Definition  
---|---  
Smoking | The inhalation and exhalation of the smoke of burning tobacco. For the purposes of this procedure, smoking also refers to: (a) any method of consuming by combustion/smoking of plant material, herbs, or drugs (licit or illicit) using any utensil or apparatus including cigarettes, pipes or cigars (b) the use of e-cigarettes and vaping, and (c) the use of chewing tobacco.   
Facilities | A physical location or building, a teaching or research site or locations, a teaching or research entity of any kind, air space, ground space and rights or items of any nature or description owned, operated or administered by RMIT University.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
