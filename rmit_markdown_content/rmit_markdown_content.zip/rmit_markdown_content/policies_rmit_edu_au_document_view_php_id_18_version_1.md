[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=18&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=18&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Submission and Examination Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=18)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=18&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=18&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=18&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=18&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=18&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=18&version=1)


# HDR Submission and Examination Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=18&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=18&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=18&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=18&version=1#section4)
  * [Part A - Submission](https://policies.rmit.edu.au/document/view.php?id=18&version=1#part1)
  * [Eligibility to Submit](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major1)
  * [Appointment of Examiners](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major2)
  * [Submission Requirements](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major3)
  * [Format of Submission for Examination](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major4)
  * [Submission of Artefacts Produced as Part of the Research](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major5)
  * [Doctoral Citation](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major6)
  * [Readmission for the Purpose of Examination](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major7)
  * [Part B - Examination](https://policies.rmit.edu.au/document/view.php?id=18&version=1#part2)
  * [Examination Processes](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major8)
  * [Concerns About Research Integrity in the Examined Work](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major9)
  * [Requirements for Presentation for Examination – Practice-based Research](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major10)
  * [Review of Examination Recommendations](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major11)
  * [Appointment of an Adjudicator on Receipt of Diverging Examiners Recommendations](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major12)
  * [Examination Results](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major13)
  * [Re-examination Process – Following a Classification of C4 (Doctoral or Masters by Research)](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major14)
  * [Potential for Masters Examination – Following a Classification of C5 on a Doctoral Submission](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major15)
  * [Request for Extension of time To Submit Amendments](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major16)
  * [Appeal Against Final Examination Results](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major17)
  * [Lodgement of the Final Archival and Completion of the Degree](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major18)
  * [Research Embargo](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major19)
  * [Application Outcome](https://policies.rmit.edu.au/document/view.php?id=18&version=1#major20)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=18&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure provides the rules for submission and examination of research towards a higher degree by research at RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all staff responsible for higher degrees by research (HDR) management and supervision, and all HDR candidates of the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=1#document-top)
# Section 4 - Procedure
## Part A - Submission
### Eligibility to Submit
(4)  To be eligible to submit their research for examination, candidates must have:
  1. been enrolled for at least the minimum duration of candidature as prescribed by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12)
  2. successfully completed all prescribed coursework components of the program, or received an exemption from the component
  3. successfully completed all compulsory milestone reviews, or received an exemption from the milestone
  4. a current enrolment.


(5)  Should a candidate wish to submit earlier than the minimum duration of candidature:
  1. no exemptions will be granted for completion of the third milestone
  2. the senior supervisor must submit a statement to SGR confirming that: 
    1. the candidate’s research is of an examinable standard
    2. the candidate has achieved all the learning outcomes of the degree
    3. in their opinion, the candidate may submit for examination without prejudice
  3. permission to submit earlier than the minimum duration of candidature is subject to review by the ADVC RT&D.


### Appointment of Examiners
(6)  Appointment of examiners must be conducted in accordance with the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and the Australian Council for Graduate Research Conflict of Interest in the Appointment of Examiners Guidelines.
(7)  Supervisors must begin the process of identifying and approaching examiners before the third milestone review.
(8)  Recommended Panel of Examiners forms must be submitted to SGR with a full CV for each examiner proposed.
(9)  All panels of examiners must be approved by the time the candidate submits for examination. SGR expects to receive a recommended panel of examiners for approval at least two months ahead of the candidate’s intended submission date.
(10)  Candidates should notify the HDR Delegated Authority (HDR DA) if they intend to submit and they identify that no examiners have been approved for their research.
(11)  Candidates may request the exclusion of specific individuals as their examiners
  1. the request including broad justification, should be provided to the senior supervisor and SGR at least three months prior to submission.
  2. candidates must not be told the names of their examiners.


(12)  The senior supervisor must approach potential examiners who will be recommended for the examination of research for a higher degree. Each potential examiner will be provided with:
  1. the candidate’s name
  2. an abstract of the research
  3. likely submission date for the research
  4. relevant RMIT Guidelines to HDR examiners.


(13)  Before completing the Recommended Panel of Examiners form, supervisors should satisfy themselves that:
  1. examiners will be available at the necessary time
  2. where a confidentiality agreement is required, that examiners are willing to sign such an agreement in principle
  3. examiners have the necessary knowledge and experience to examine the topic
  4. no perceived or actual conflict of interest exists between the examiner and the candidate or members of the supervisory team.


(14)  Where a perceived conflict of interest exists, supervisors must declare this at the time of proposal. SGR will provide advice on how this can be managed.
(15)  Supervisors must inform potential examiners that:
  1. they will be provided with access to an electronic copy of the examinable outputs for examination; and
  2. they must complete and submit a final recommendation and report within six (6) weeks of receiving notification from SGR; and
  3. they are required to attend the examination when any presentation (e.g. oral presentation, exhibition, performance or demonstration) is involved; or
  4. their identity shall remain undisclosed during the examination process but may elect to have their name revealed to the candidate at the conclusion of the examination.


(16)  If a proposed examiner is not in the same/related discipline or field as the candidate, the senior supervisor must include justification of the recommendation with the Recommended Panel of Examiners form.
(17)  The school HDR DA must review the recommended panel of examiners for any conflicts of interest before forwarding to the SGR for approval.
(18)  SGR will check examiners’ credentials for suitability and the results will be presented to the ADVC RT&D who approves the examination panel.
(19)  The ADVC RT&D will not approve a panel of examiners consisting only of RMIT graduates.
(20)  In cases where a confidentiality agreement is required, SGR will prepare and arrange execution of an examiner’s confidentiality agreement prior to formal appointment.
### Submission Requirements
(21)  Examination submissions must include a thesis or dissertation which provides the:
  1. purpose
  2. scholarly or practical context for the research
  3. process and methodology
  4. presentation of the results, analysis and conclusions of the research.


(22)  Examination submissions may also include components such as research outputs and artefacts, for example: published articles, creative works, software and professional reports or policy documents.
(23)  The candidate must declare that the published research outputs included in their submission:
  1. are by the candidate
  2. have appropriate attribution and authorship recorded
  3. have been generated by the candidate during the course of candidature.


(24)  Candidates are required to upload and submit their thesis or dissertation to SGR at least two weeks ahead of the next census date to avoid future fee liability should the submission be returned due to not meeting the submission requirements.
(25)  Candidates and senior supervisors must confirm that the research complies with the [Australian Code for the Responsible Conduct of Research, 2018](https://policies.rmit.edu.au/directory/summary.php?code=1) and has been prepared in accordance with legislative copyright and privacy requirements.
(26)  Where two or more candidates collaborate on a project which will form the content of their submission for examination:
  1. the contributions of each candidate must have sufficient individual value to the discipline or practice to be worthy of separate examination
  2. each collaborator’s contributions to the overall research outcomes must be declared in each of the uniquely titled research submissions.


(27)  The senior supervisor and school HDR DA must approve the candidate to submit via the prescribed process. These approvals certify that the School believes the candidate’s work to be of an examinable standard.
(28)  Candidates who meet the eligibility criteria to submit may choose to submit without school approval, by:
  1. contacting SGR for advice, to ensure they are aware of the implications of submitting without school approval
  2. completing and lodging an Intention to Submit Without Approval form to SGR.


(29)  Candidates’ submissions must adhere to the prescribed RMIT format as well as the standards and conventions for scholarly work which apply in the relevant discipline or field, such that they may be assessed without prejudice by leading experts of that discipline or field.
(30)  Supervisors must ensure that candidates understand the normal standards of research submission for their field and have taken account of these standards in the original research project design.
(31)  Following submission, providing all submission requirements are fulfilled, SGR will approve the thesis or dissertation for examination.
(32)  The submission date is the date that the thesis or dissertation is uploaded via the digital repository, provided it is approved for examination by the ADVC RT&D.
### Format of Submission for Examination
(33)  An electronic copy of the thesis or dissertation must be uploaded to the HDR digital repository in PDF format.
(34)  Attachments in other formats may also be permitted subject to approval by SGR.
(35)  The thesis or dissertation must contain the following in the order outlined below:
  1. a title page in the prescribed RMIT format (no page number)
  2. a declaration by the candidate on authorship and, where relevant, sponsorship and editorial assistance received
  3. acknowledgements, if any (for example, where the candidate’s research has been supported by the Research Training Program, or other grant, contract or sponsor)
  4. a table of contents and, where applicable, lists of diagrams, tables, images etc. contained in the submission
  5. a summary (abstract) of the research in not more than 1,000 words
  6. the main text of the thesis or dissertation
  7. a list of all references cited in the preparation of the research in a format appropriate to the discipline
  8. appendices, as required.


(36)  The thesis or dissertation shall be in English and be formatted in clearly readable font (no smaller than ten point).
(37)  Figures, tables, images, etc. must carry a number and a caption and be placed as close to the relevant text as possible. Usually they should be either immediately after or opposite the text.
(38)  The pages of the thesis or dissertation following the title page, up to and including the table of contents, must be numbered in Roman numerals.
(39)  From the summary (abstract) onwards, Arabic numerals must be used.
(40)  The letter of approval from an authorised RMIT committee for any research with humans or animals, involving genetic modification or any other activity relating to institutional biosafety, must be included as an appendix in the work.
(41)  Published material, or material prepared in anticipation for publication, may be included in the written thesis or dissertation. This material must be appropriately cited and the candidate’s contribution to the publication must be made clear.
### Submission of Artefacts Produced as Part of the Research
(42)  Examination submissions that include one or more artefact(s) and/or presentation of the research to examiners in a venue should include a detailed description of the artefact(s) that complements the outcome of the research question.
(43)  A digital record of the artefact or presentation may be examined along with the thesis; in cases where it would disadvantage the candidate if the physical artefact were not examined, the artefact may be provided to the examiners along with the thesis.
(44)  The candidate and their supervisors should decide by the third milestone review on the inclusion of artefacts or a presentation at an RMIT campus. The paperwork submitted for the milestone review must contain details about the supporting outputs that are planned to include in the examination submission.
(45)  In this case, the milestone paperwork should include:
  1. a description of the artefacts including dimensions and approximate weight
  2. the likely value of the artefacts, as any items greater value than A$100 will need additional insurance coverage provided by the candidate’s school
  3. an explanation of why the items must be sent rather than providing a digital record for the examiners.


(46)  Any changes to the proposed submission for examination after the second milestone review must be detailed in the paperwork submitted to SGR for the third milestone review.
(47)  Schools and the ADVC RT&D may determine that they will not support submission of artefacts directly to examiners, due to the potential risk involved if the items:
  1. go astray or are lost
  2. cannot be reproduced for any possible re-examination
  3. are of considerable value and could be misconstrued as a bribe by an examiner.


(48)  The candidate must be informed of the University’s decision as soon as possible after stating their intention to submit one or more artefacts as components for examination.
### Doctoral Citation
(49)  PhD candidates must provide a doctoral citation to SGR to be eligible to graduate. The citation is included in the graduation program and the Australian Higher Education Graduate Statement (AHEGS).
(50)  Candidates must submit a citation with their initial submission to prevent delay at the point of completion. If necessary, candidates may amend their doctoral citation at the point of archival.
(51)  The citation must be written in a manner such that the nature of the research, its significance or potential for impact may be understood and appreciated by those with no specialist knowledge of the field or its technical terms.
(52)  It is the responsibility of the senior/joint senior supervisor to ensure the citation meets the stipulated criteria.
### Readmission for the Purpose of Examination
(53)  Individuals may be readmitted for the purpose of examination within three years of their cancellation date, if their HDR candidature has been cancelled for any reason.
(54)  Individuals must submit a completed, examinable draft of their thesis or dissertation, along with any associated artefact(s) where relevant, to their former senior supervisor or HDR DA if the senior supervisor is no longer available.
(55)  The HDR DA must ensure that candidates meet the eligibility criteria for submission.
(56)  Following a candidate’s readmission, the senior supervisor or HDR DA overseeing the submission is responsible for:
  1. nominating examiners
  2. providing a statement attesting that the research topic is current and has not been superseded by subsequent research in the field
  3. recommending that the work is ready for examination to the Dean or HDR DA.


(57)  The candidate is required to submit their thesis or dissertation via the digital repository within 10 working days of re-enrolment.
## Part B - Examination
### Examination Processes
(58)  Research for examination is uploaded, submitted and provided to examiners via the prescribed digital repository.
(59)  Artefacts included as part of the examination must be submitted in accordance with the Instructions for submission of practice-based artefacts for examination.
(60)  SGR must provide all examiners with the relevant RMIT Guidelines to HDR Examiners and any relevant supplementary guidelines or advice for the examination.
(61)  Only the ADVC RT&D (or nominee) may communicate with examiners on behalf of RMIT while the research is under examination.
(62)  Except for contact during a presentation forming part of the examination process:
  1. supervisors and candidates must attempt no contact with examiners during the examination process.
  2. no contact is permitted between examiners while the research is under examination.
  3. the examiners’ identity must not be disclosed to the candidate until after the final classification has been given, and only with permission of the examiner.


(63)  The examination period extends from the date examiners are provided with the research submission to the date they provide their reports.
(64)  Examiners who are sent one or more artefacts will be asked to provide email confirmation of the safe arrival of the artefact/s and will be given six weeks from that date to finalise the examination.
(65)  Examiners must provide their reports within six (6) weeks of receipt of the submission.
(66)  Where a presentation of the research in a venue is required, examiners will be provided with the digital submission four weeks prior to the presentation event and must provide their final reports within two weeks following the event.
(67)  Examiners must prepare independent and individual, written reports of their assessment and submit these directly to the SGR examinations team, accompanied by the Examiner’s Report Form indicating a recommended classification.
(68)  If at any time during the preparation of the examiner’s report, an examiner identifies a significant query on any aspect of the submission, they should contact the SGR examinations team who will coordinate a response.
(69)  If any examiner is unable to complete and submit the examination reports within the allotted time period, including any agreed extensions, SGR will provide a written request to the senior supervisor and HDR DA seeking recommendations for the appointment of a replacement examiner.
(70)  Candidates will be informed of a delay to the examination outcome if the examination duration exceeds 12 weeks of their submission being provided to examiners.
### Concerns About Research Integrity in the Examined Work
(71)  In the event of an examiner or any other relevant party raising concerns about the integrity of the research during the examination process, the SGR examinations team will immediately refer the matter to the ADVC RT&D.
  1. SGR will suspend the examination and notify the examiners, school and the candidate
  2. a Designated Person will investigate in accordance with the Management of Breaches of Research Integrity Procedure
  3. recommendations arising from the investigation may include application of the Student Conduct Regulations
  4. in all cases, all parties will be notified of the outcome.


### Requirements for Presentation for Examination – Practice-based Research
(72)  The examination must be in an appropriate venue at a time and date arranged by the School and approved by the ADVC RT&D.
(73)  Examiners may attend the presentation in person or by use of communication technology, which will be arranged by the school.
(74)  Examination must be convened by a person appointed as Convenor by the ADVC RT&D. Persons who have acted in a supervisory or consultative capacity must not be appointed as the Convenor.
(75)  Presentations of research for examination must not occur without the appointed Convenor being present.
(76)  It is the responsibility of the Convenor to explain the process for examination including any oral presentation, to examiners, including the amount of time they have to review the work, and ensure the examination is conducted in accordance with the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and this procedure.
(77)  In the case of an oral presentation by the candidate, the time allowed is:
  1. PhD candidates – one-hour oral presentation plus half- to one-hour discussion with the examiners;
  2. Masters by research candidates – half-hour oral presentation plus up to half hour discussion with the examiners.


(78)  Examiners may consult the Convenor if they have questions during the presentation but must refrain from expressing evaluative judgements which may influence another examiner’s evaluation at any time.
(79)  The examination panel may meet in camera, with the Convenor present, to obtain further clarification if required.
(80)  The Convenor is not permitted to comment on the content of the research and is responsible for ensuring that each examiner is uncompromised in their ability to make an independent evaluation of the research.
(81)  Discussion and questions from the public, if allowed by the School, must be directed through the Convenor to the candidate only after examiners have indicated they have no further comments for the candidate.
(82)  The presentation of the research will be recorded digitally to enable electronic archival.
### Review of Examination Recommendations
(83)  Both examiners’ reports will be reviewed, and the examination will be classified by the ADVC RT&D in accordance with Schedules 1-3.
(84)  Masters candidates commencing on or after 1 January 2016 will receive a numeric grading for a successfully completed masters by research degree at RMIT. Refer to the Masters by Research Grading Procedure.
(85)  In a first examination, the examination may be referred to a College HDR Examinations Advisory Committee (CHEAC) by the ADVC RT&D where examiners’ recommendations differ on whether:
  1. the work should receive a pass classification, or
  2. the candidate should be afforded the opportunity to revise and resubmit.


(86)  The CHEAC will recommend to the ADVC RT&D whether the candidate should be given the interim classification, Revise and Resubmit (C4) or whether the examination should be referred to an external adjudicator for review.
(87)  In convening a CHEAC, the committee terms of reference must be followed, and the committee recommendation must be in accordance with Schedule 2.
### Appointment of an Adjudicator on Receipt of Diverging Examiners Recommendations
(88)  Where a CHEAC recommends the appointment of an adjudicator, the ADVC RT&D must approve the recommendation before commencement of the process.
(89)  A notification of the decision of the ADVC RT&D must be provided to the Dean, HDR DA, supervisors and candidate.
(90)  The candidate’s senior supervisor is responsible for approaching a potential adjudicator and providing them with the following information to enable them to decide whether to agree to the adjudication:
  1. name of the candidate
  2. an abstract of the research
  3. a copy of the relevant RMIT Advice for HDR examination adjudicators
  4. the proposed timeline for the adjudication process.


(91)  The supervisory team must support the candidate to prepare a response to the examiner’s reports.
(92)  The candidate must prepare a response to the examiners’ remarks that provides a list of the amendments undertaken or provides evidence in defence of their research that refutes the requested amendments, as appropriate.
(93)  The candidate must submit their response to the SGR Examinations team within eight (8) weeks of receipt of the initial notification.
(94)  The senior supervisor must submit the Adjudicator Appointment Form to the HDR DA for authorisation and submission to SGR for ADVC RT&D approval. The form should be received by SGR within eight (8) weeks of receipt of the initial notification
(95)  The appointment of the adjudicator must be in accordance with the requirements for appointment of examiners.
(96)  Adjudicators’ identities must not be disclosed to the candidate until after the conclusion of the examination, subject to their consent.
(97)  Adjudicators are required to use Schedule 3 and submit their recommendations for final classification for the examination outcome directly to the SGR examinations team within four (4) weeks of receipt of the examined work.
(98)  The SGR examinations team will provide the adjudicator’s recommendations to the ADVC RT&D for approval.
### Examination Results
(99)  After the examination outcome has been classified in accordance with the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and Schedules to this procedure, SGR must send a notification to the candidate, their supervisors, the HDR DA, and the Dean of School and the examiners, to advise them of the examination classification.
(100)  SGR must forward the examiners’ reports to the candidate’s senior supervisor to enable them to provide academic guidance on any necessary amendments.
(101)  In the event of one or both examiners recommending an R5 ‘Failed’ after re-examination of a doctoral or masters HDR submission, the SGR examinations team will recommend that the ADVC RT&D convene a meeting of the Graduate Research Committee Executive to review and ratify a final classification of the HDR submission.
(102)  The GRC Executive may refer the work to an external adjudicator where appropriate. A record of the Graduate Research Committee Executive’s decisions in respect of the examination will be transmitted to the candidate and their supervisor(s) following classification.
(103)  For research classified as C5 (Failed):
  1. the candidate will not be awarded the degree for which they were enrolled and will not be permitted to revise and resubmit their research for re-examination for the same degree
  2. one copy of the examined thesis or dissertation becomes the property of RMIT and shall be filed with the candidate’s official records
  3. (except for section 14 of this procedure) a record of the fail will be placed on the RMIT student system.


### Re-examination Process – Following a Classification of C4 (Doctoral or Masters by Research)
(104)  Where a candidate is given the interim classification C4 Revise and Resubmit for re-examination:
  1. a re-examination is undertaken with the original examiners, if they are willing and available to re-examine the revised submission, or with replacement examiners such that the revised work still receives assessment from two independent, external experts.
  2. all material submitted and recommendations made in the context of a re-examination supersedes all previous material and recommendations, with the exception of the candidate’s response to the examiners’ remarks provided in the initial examination.


(105)  When arranging for the re-examination of research classified as C4, SGR will:
  1. notify the candidate’s supervisors of the interim classification and supply de-identified examiners’ reports to enable them to provide guidance on the candidate’s response and revisions; SGR will not supply examiners’ reports direct to the candidate
  2. notify the candidate of the interim classification and instruct them to contact their supervisors to begin revising their research and preparing a response to the examiners’ remarks, which may acknowledge the need for amendment or present evidence in defence of their research as appropriate
  3. invite the original examiners to re-examine the revised work at the end of the one-year revision period; if one or both examiners are not available, SGR will contact the senior supervisor to initiate replacement examiner(s).
  4. contact the candidate and supervisors at regular intervals during the revise and resubmit period to obtain an update on the progress towards re-submission, to enable a swifter conclusion to the re-submission process.


(106)  Candidates are given 12 months to revise and resubmit their research.
(107)  International candidates who receive a C4 classification may complete revisions and be re-examined in a way that does not require them to be in Australia.
(108)  Resubmission of a revised thesis or dissertation follows the same process as initial submission with the addition of a document from the candidate listing the amendments made to address the initial examiners’ requirements and justification for any amendments not made at the request of those examiners.
(109)  If any of the original examiners re-examine the research, they must be provided with their original examiner’s report.
### Potential for Masters Examination – Following a Classification of C5 on a Doctoral Submission
(110)  In the event of one or both examiners recommending an R5 ‘Failed’ for an examination or re-examination of a doctoral submission, the examiner(s) are required to confirm whether they consider the research to be suitable for examination at the level of a masters by research.
(111)  Advice received from examiners on the suitability for the doctoral research to be examined at a masters by research level will be provided to:
  1. the school HDR DA to consider whether the school will support further examination
  2. the ADVC RT&D in the case of a first examination
  3. the GRC Executive for review and ratification of the final classification in the case of a re-examination.


(112)  A record of the final classification decisions in respect of the examination will be transmitted to the candidate and their supervisor(s) following classification. The examiner(s) will also provide advice on whether the work is suitable for re-examination at a masters level.
(113)  On receiving a ‘Failed’ outcome for a doctoral examination, candidates may, within two (2) months of receiving the classification, apply to have their HDR submission examined for the award of the related masters by research program. In these circumstances, candidates:
  1. must be enrolled in a masters by research degree program to submit for this examination
  2. may choose to revise their submission over a period of two months, or submit the same version with a new cover page and references to the correct degree
  3. are entitled to supervision of up to two months’ or part-time equivalent.


(114)  By pursuing a masters by research award for work originally submitted for a doctoral degree, candidates acknowledge that any assessment and commentary previously made on their HDR submission will be superseded by those made in the process of the masters by research examination.
(115)  The examiners appointed to review the work for a masters by research may not have been involved in the previous doctoral examination, except in exceptional circumstances approved by the ADVC RT&D and must not be informed that the work has been previously examined.
### Request for Extension of time To Submit Amendments
(116)  A candidate may apply with their senior/joint senior supervisor to the ADVC RT&D for approval of an extension to the resubmission or archival date, where the candidate cannot meet the:
  1. nominated date for resubmission of their research for re-examination; or
  2. lodgement date for the archival of their research.


(117)  The candidate must submit the Request for Extension of Time to Submit Amendments Form to SGR before the nominated resubmission or lodgement date passes.
(118)  Failure to re-submit or lodge a thesis by the date specified by SGR may lead to the examination being classified as “Failed”. Candidates will be notified if this process is being initiated.
### Appeal Against Final Examination Results
(119)  Candidates whose examination has been completed and who have a result of ‘Failed’ may appeal against any perceived procedural irregularities in the conduct of their HDR examination. They must use the form for Appeal against the outcome of an examination by a student in a research program – University Appeals Committee.
(120)  Candidates must ensure their appeal form is received by the Secretary of the University Appeals Committee within 20 working days of the date of the formal notification from SGR of their final examination outcome. Late appeal applications cannot be accepted.
### Lodgement of the Final Archival and Completion of the Degree
(121)  After a candidate’s research has been classified by the ADVC RT&D, any amendments requested by the examiner/s must be completed by the candidate, or a defence presented as to why they do not need to be undertaken.
(122)  Candidates must provide a list of amendments/points of defence for uploading with their final archival submission.
(123)  Submission of the archival research must follow the requirements for initial submission.
(124)  Candidates whose research includes artefacts and/or presentation in a venue in addition to their dissertation must provide a digital record of these for archival storage.
(125)  Completion and graduation processes require that:
  1. the final electronic archival submission of the thesis and any related digital records are uploaded to the digital repository within the timeline specified by the University and after completion of any appropriately supervised amendments deemed necessary by the University
  2. the candidate is not indebted to the University
  3. the candidate has fulfilled the academic and administrative requirements for the award of the degree.


(126)  Candidates may apply for an embargo in accordance with this procedure.
(127)  When the final archival submission has been approved for lodgement by the senior supervisor and the Dean (or HDR DA):
  1. a record of the completion is provided to the ADVC RT&D, who will approve the research for archival and recommend the candidate for award
  2. the final archival is uploaded into the RMIT Research Repository after which the research will be publicly available
  3. the result for the research component of the program will be entered on the student system
  4. SGR will provide written notification of the satisfactory completion of the degree to the Academic Registrar, candidate, their supervisors, the Dean and HDR DA, and any sponsor(s) of international onshore candidates.


### Research Embargo
(128)  Candidates who wish to apply for an embargo on the publication of their research in the RMIT Research Repository must meet the requirements for embargo detailed in Table 1.
#### Table 1: Grounds for Embargo
Requirement | Maximum duration | Level of approval  
---|---|---  
The candidate has signed a publishing agreement or is planning to publish their work which requires some restriction on the availability of the submission. | Up to two years | ADVC RT&D  
Option for extension of embargo for one year | ADVC RT&D  
The candidate provides evidence that they have permanently re-assigned copyright of their submission to a third party and this assignment explicitly disallows the publication of the submission in the research repository. | Permanent | ADVC RT&D  
There is an existing formal agreement, or the candidate is involved in the development of a formal agreement that commercially or otherwise sensitive material will not be publicly disclosed. This includes patents, research produced under a funded contract (e.g. Student Participation Agreement or confidentiality agreement). | Duration as per agreement or up to two years | ADVC RT&D  
Option for extension of embargo for one year | ADVC RT&D  
The research contains material that must be kept confidential due to legal, cultural, ethical or national security reasons. | Permanent | GRC Executive  
(129)  Candidates can request an embargo on any submitted component of their research whilst allowing other components to be published in the RMIT Research Repository.
(130)  Candidates whose research meets the grounds for embargo must:
  1. lodge a completed Request for a Confidentiality Deed or Embargo form with the SGR examinations team
  2. include relevant documentary evidence, if the request relates to any existing commercial or publication agreement
  3. ensure their embargo applications are submitted prior to their archival submission
  4. ensure any application for an extension to the embargo is submitted at least two months prior to the embargo’s expiry.


### Application Outcome
(131)  The outcome of an application will be determined by the ADVC RT&D.
(132)  In exceptional circumstances and on production of compelling evidence, the GRC Executive may grant:
  1. an embargo that does not meet the prescribed criteria
  2. further extension to an embargo.


(133)  Notification of the outcome is provided to the candidate, their Senior Supervisor and the School HDR DA.
(134)  An embargo approved prior to archival submission is effective from the archival date of the research until the expiry date of the embargo.
(135)  An approved extension to an embargo is effective from the expiry date of the previous embargo until the extension expiry date.
(136)  Archival research which has been approved for embargo is stored in a restricted repository until the embargo expiration date, when it is published.
(137)  In cases where an embargo has been approved but no longer required, the candidate or their supervisor should inform the SGR examinations team to enable the candidate’s submission to be published in the public domain.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=18&version=1#document-top)
# Section 5 - Schedules
(138)  This procedure includes the following schedule(s):
  1. [Schedule 1 – HDR Examination Recommendations and Classifications](https://policies.rmit.edu.au/download.php?id=223&version=3&associated)
  2. [Schedule 2 – Classification Options Available to a CHEAC](https://policies.rmit.edu.au/download.php?id=224&version=1&associated)
  3. [Schedule 3 – Classification Options Available to an Adjudicator](https://policies.rmit.edu.au/download.php?id=225&version=1&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
