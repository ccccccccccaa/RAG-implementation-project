[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=154#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=154#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Managing Performance Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=154)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=154)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=154)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=154)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=154)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=154)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=154)


# Managing Performance Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=154#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=154#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=154#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=154#section4)
  * [Concerns About Unsatisfactory Performance](https://policies.rmit.edu.au/document/view.php?id=154#major1)
  * [First Stage](https://policies.rmit.edu.au/document/view.php?id=154#major2)
  * [Second Stage](https://policies.rmit.edu.au/document/view.php?id=154#major3)
  * [Final Stage](https://policies.rmit.edu.au/document/view.php?id=154#major4)
  * [Recommencing Performance Support](https://policies.rmit.edu.au/document/view.php?id=154#major5)
  * [The Role of a Support Person](https://policies.rmit.edu.au/document/view.php?id=154#major6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure details how RMIT will manage concerns relating to consistent or significant unsatisfactory performance, with the intent of helping staff improve performance to the expected level. Performance standards and measures will be fair, equitable and transparent.
(2)  Matters that are more appropriately classified as conduct issues (such as wilfully refusing to comply with a manager’s instructions about how to perform a task) will ordinarily be dealt with under the Managing Conduct Procedure.
(3)  For the purposes of this procedure, the term “manager” refers to an employee’s immediate line manager.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=154#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Employee Lifecycle Policy](https://policies.rmit.edu.au/document/view.php?id=123).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=154#document-top)
# Section 3 - Scope
(5)  This procedure applies to all employees of RMIT University.
(6)  This procedure does not relate to the provision of feedback and coaching to improve minor performance issues.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=154#document-top)
# Section 4 - Procedure
### Concerns About Unsatisfactory Performance
(7)  Where an enterprise agreement (agreement) mandates how RMIT will deal with any unsatisfactory performance, the process specified in that agreement will be applied.
(8)  Where there is no applicable agreement-based process, or RMIT has exercised its right under an agreement not to apply a process that would otherwise apply, the procedures set out below will be applied.
(9)  RMIT retains the right to vary or not apply this procedure at manager discretion, having regard to employee seniority, the nature of the performance issue/s, the nature or length of the employee’s employment, any feedback previously provided to the employee about their performance, or organisational needs. 
### First Stage
(10)  Where a manager considers an employee is consistently or significantly failing to meet the expected level of performance, they will work with the individual to correct performance using non-disciplinary interventions. Examples include, but are not limited to:
  1. discussion/advice
  2. training
  3. observation of good practice
  4. regular catch-ups and review
  5. mentoring
  6. goal setting
  7. coaching
  8. guidance
  9. feedback
  10. counselling
  11. professional development
  12. work allocation changes.


### Second Stage
(11)  If performance does not improve to the expected level, managers may implement a Performance Improvement Plan (PIP).
(12)  The purpose of the PIP is to:
  1. identify where performance is lacking
  2. identify where and how performance needs to improve
  3. provide mechanisms (including timeframes) for reviewing performance.


(13)  Where meetings to discuss the PIP are conducted in person, the employee may have a support person present.
(14)  The PIP must allow the employee a reasonable time to improve performance to an acceptable standard, having regard to the issues identified, the steps taken to support the employee and their commitment to improving performance.
### Final Stage
(15)  Where a PIP has been implemented, reasonable time has been provided to improve performance, and performance continues to fall below the required standard as communicated, managers will:
  1. inform the employee of their findings
  2. propose a disciplinary outcome
  3. provide the employee an opportunity to respond to the findings and proposed disciplinary outcome.


(16)  Where meetings to discuss these matters are conducted in person, the employee may have a support person present.
(17)  Having considered the employee’s response, the line manager may then impose a disciplinary outcome, including but not limited to:
  1. formal warning
  2. demotion
  3. termination of employment (either via the provision of notice or payment in lieu).


(18)  Any decision to undertake disciplinary action will be explained in writing.
(19)  ‘Stepped’ outcomes are not necessary. For example:
  1. termination of employment might occur as an outcome even if there have been no prior formal warnings
  2. a final written warning may be issued even if there has been no previous written warning.


(20)  Managers may decide to extend the PIP process to enable employees further time to improve. For example, following a warning or final written warning, the manager may extend the PIP process to give the employee more time to improve before determining whether termination of employment is appropriate.
### Recommencing Performance Support
(21)  Managers may commence performance support again at the second stage where:
  1. an employee has been on a PIP which ended after an acceptable improvement in performance; and
  2. the manager then determines that performance in the same role is once again unsatisfactory.


### The Role of a Support Person
(22)  Where employees choose to have a support person present, it may be a union representative, another employee, or someone outside the organisation such as a friend or relative.
(23)  Employees may be asked to choose a different support person if the presence of a chosen support person is considered inappropriate – for example, the support person is already involved in the matter in some way.
(24)  The role of the nominated support person is to provide advice and support the wellbeing of the employee.
(25)  The support person must not:
  1. unduly delay or disrupt the process
  2. act as a representative or advocate on the employee’s behalf.


(26)  An inability to find a suitable support person will not be an acceptable reason to delay the process.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
