[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=180#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=180#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Conduct Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=180)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=180)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=180)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=180)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=180)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=180)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=180)


# Student Conduct Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=180#part1)
  * [Part B - GENERAL](https://policies.rmit.edu.au/document/view.php?id=180#part2)
  * [Part C - GENERAL AND HIGH RISK MISCONDUCT](https://policies.rmit.edu.au/document/view.php?id=180#part3)
  * [Part D - ACADEMIC MISCONDUCT](https://policies.rmit.edu.au/document/view.php?id=180#part4)
  * [Part E - REPORTING AND RESPONDING TO POTENTIAL MISCONDUCT](https://policies.rmit.edu.au/document/view.php?id=180#part5)
  * [Officers and Senior Officers](https://policies.rmit.edu.au/document/view.php?id=180#major1)
  * [Part F - APPEALS](https://policies.rmit.edu.au/document/view.php?id=180#part6)
  * [Part G - CONSEQUENCES OF MISCONDUCT](https://policies.rmit.edu.au/document/view.php?id=180#part7)
  * [Part H - MISCELLANEOUS](https://policies.rmit.edu.au/document/view.php?id=180#part8)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
## Part A - PRELIMINARY
#### Purpose
(1)  The purpose of these Regulations is to:
  1. maintain and protect academic integrity at RMIT;
  2. regulate the conduct of students in connection with RMIT;
  3. facilitate the proper functioning of RMIT; and
  4. enable RMIT to fulfil its duty to foster the wellbeing of staff and students.


#### Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No. 1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20) (Vic).
#### Scope
(3)  These Regulations apply to RMIT Group students as defined in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
#### Definitions
(4)  In these Regulations:
  1. Academic freedom means, in relation to students: 
    1. the freedom of students to engage in intellectual enquiry, to express opinions and beliefs, and to contribute to public debate in relation to their subjects of study and research; 
    2. the freedom of students to express their opinions in relation to RMIT, inclusive of operations, management and governance, and higher education issues generally; and
    3. the freedom of students to participate in student societies and associations.
  2. academic misconduct means conduct or behaviours as defined in Part D of these Regulations. A non-exhaustive list of behaviour or conduct which is academic misconduct is contained in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
  3. Chair means the chair of the Student Conduct Board or the Student Conduct Appeals Committee appointed by the Vice-Chancellor (or delegate).
  4. Course Coordinator means the academic or teaching staff member who is responsible for the management, conduct, teaching and assessment of a course.
  5. the duty to foster the wellbeing of staff and students: 
    1. involves reasonable and proportionate measures to prevent or proscribe any person from using lawful speech which a reasonable person would regard, in the circumstances, both as likely to humiliate, or intimidate, harass or bully other persons; and as being intended to have any of those effects; 
    2. includes the duty to ensure that no member of staff and no student is subject to threatening or intimidating behaviour by another person or persons on account of anything they have said or proposed to say in exercising their intellectual freedom; 
    3. does not extend a protection from feeling shocked, insulted or offended by the lawful speech of another. 
  6. general misconduct means conduct or behaviour as defined in Part C of these Regulations. A non-exhaustive list of behaviours or conduct which is general misconduct is contained in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).
  7. high risk misconduct means conduct or behaviour as defined in Part C of these Regulations.
  8. lawful speech means lawful public comment by students on any issue in their personal capacity. This includes all forms of expressive conduct, including oral and written speech, creative works and activity, whether communicated in person or online.
  9. misconduct includes general misconduct, academic misconduct, and high risk misconduct.
  10. officer means any person employed or engaged as staff within the RMIT Group.
  11. principal student organisation means the main body representing students at the relevant campus of RMIT.
  12. Senior Officer means the role of Senior Officer as established under these Regulations, and referenced within the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.
  13. Student Conduct Appeals Committee means the Student Conduct Appeals Committee, RMIT University as established under these Regulations, and referenced within the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.
  14. Student Conduct Board means the Student Conduct Board, RMIT as established under these Regulations, and referenced within the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), and corresponding procedures.
  15. Regulations means these Student Conduct Regulations.


## Part B - GENERAL
#### Student Conduct
(5)  Student conduct may be subject to prohibitions, restrictions or conditions imposed by:
  1. law; or
  2. the reasonable and proportionate regulation of conduct necessary to enable RMIT to discharge its obligations in relation to its: 
    1. teaching and research activities;
    2. duty to foster the wellbeing of students and staff;
    3. legal duties; or
    4. reasonable requirements as to programs and courses to be delivered and the means of their delivery.
  3. Academic, disciplinary, and professional standards that apply to the production of academic work and assessment.


(6)  Subject to the limitations and regulation of conduct allowable under the [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56):
  1. the exercise of academic freedom by a student will not constitute misconduct nor attract any penalty or adverse action; and 
  2. a student’s lawful speech on RMIT property or in connection with a University activity will not constitute misconduct or attract a penalty or adverse action by reference only to its content.


## Part C - GENERAL AND HIGH RISK MISCONDUCT
#### General Misconduct
(7)  General misconduct is conduct by a student:
  1. that is prohibited by a University Statute, regulation, policy, procedure, rule, guideline, principle, code, charter or similar instrument; or
  2. that is or is likely to be detrimental to: 
    1. RMIT’s ability to fulfil its learning, teaching, research and service obligations;
    2. RMIT staff, students (including the student themselves), or the public;
    3. RMIT property or the property of any person or the public.


(8)  General misconduct does not include high risk misconduct. 
#### High Risk Misconduct
(9)  High risk misconduct is conduct by a student that gives rise to a significant or substantial risk to, or that has consequences that are potentially major, severe or extreme for:
  1. the physical or psychological safety of RMIT staff, students (including the student themselves) or the public; or 
  2. RMIT property or the property of any person or the public, 


regardless of whether the risk or consequences have eventuated.
## Part D - ACADEMIC MISCONDUCT
#### Academic Misconduct
(10)  Academic misconduct is conduct by a student that is intended or is likely to have the effect of obtaining, for that student or any other person, an advantage in the performance of assessment by unauthorised, dishonest, unethical or unfair means whether or not the advantage was obtained.
## Part E - REPORTING AND RESPONDING TO POTENTIAL MISCONDUCT
### Officers and Senior Officers
#### Reporting and responding to potential student misconduct
(11)  Where an officer:
  1. receives a report concerning potential student misconduct, or
  2. has reasonable grounds to believe that a student has engaged in misconduct,


they must inform a Course Coordinator or Senior Officer (where appropriate) and act in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and any corresponding procedures.
(12)  The role of Senior Officer is constituted under these Regulations. 
(13)  Senior Officers are appointed:
  1. in RMIT University and RMIT Vietnam, by the Deputy Vice-Chancellor Education
  2. in RMIT Europe, by the Executive Director,
  3. in RMIT University Pathways (RMIT UP), by the Chief Executive Officer, and
  4. in RMIT Online, by the Chief Executive Officer.


(14)  Senior Officers may: 
  1. consider reports of potential general and academic misconduct;
  2. make and direct internal investigations;
  3. refer complex or serious conduct matters to the Student Conduct Board; 
  4. make determinations: 
    1. regarding findings of fact concerning reported potential student misconduct; 
    2. as to whether the reported conduct constitutes student misconduct; and 
    3. on any actions, consequences or penalties to be applied, following those determinations.


in accordance with these Regulations, the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures
(15)  Where a Senior Officer:
  1. receives a report concerning potential student misconduct, or
  2. has reasonable grounds to believe that a student has engaged in misconduct,


they must comply with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and any corresponding procedures in relation to the potential misconduct.
#### Student Conduct Board
(16)  The Student Conduct Board is constituted under these Regulations.
(17)  The powers and functions of the Student Conduct Board are set out in these Regulations, and in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.
(18)  The Student Conduct Board may: 
  1. consider reports of potential general, high risk and academic misconduct; 
  2. make and direct internal and external investigations;
  3. make determinations: 
    1. regarding findings of fact concerning reported potential student misconduct,
    2. as to whether the reported conduct constitutes student misconduct, and
    3. on any actions, consequences, or penalties to be applied, following those determinations,


in accordance with these Regulations, the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.
(19)  Subject to Regulaton (21), membership of the Student Conduct Board comprises:
  1. a Chair,
  2. two Senior Officers, and
  3. an enrolled student nominated by the principal student organisation.


(20)  Where possible, membership of the Student Conduct Board will represent gender diversity.
(21)  A quorum of the Student Conduct Board is the Chair and two members.
(22)  The Chair may make procedural determinations on behalf of the Student Conduct Board, including but not limited to determinations in relation to:
  1. the attendance of parties, representatives, and support persons at the hearing,
  2. requests for adjournments, and
  3. release of information about the process and the determination.


#### Executive Suspension
(23)  The Vice-Chancellor (or delegate) may determine that a student is immediately subject to executive suspension.
(24)  The powers conferred by Regulation 23 may not be exercised unless the Vice-Chancellor (or delegate) has determined that an executive suspension is reasonably necessary to prevent or reduce the likelihood of further high risk misconduct.
(25)  The Vice-Chancellor (or delegate):
  1. is not required to hold a hearing before making the decision,
  2. may inform themselves in any way in relation to any matter, and
  3. may impose terms, conditions and directions on the executive suspension.


(26)  The Vice-Chancellor's (or delegate’s) decision to impose an executive suspension is final and cannot be appealed. 
(27)  An executive suspension continues to operate until it is revoked, by the Vice-Chancellor (or delegate), however it may not exceed a period of 12 months from the date of imposition. The Vice-Chancellor (or delegate) will review the executive suspension after it has been in place for 6 months.
(28)  The Vice-Chancellor (or delegate) must within 24 hours of the decision to executively suspend the student provide written notice to the student:
  1. of the decision, any terms and conditions of the decision, and a summary of the reasons for the decision, and
  2. the provisions of these Regulations.


(29)  An executive suspension takes effect when the student is notified of the decision via their university email account.
(30)  The Vice-Chancellor (or delegate) may vary an executive suspension including any of the terms, conditions or directions initially imposed at any time.
(31)  The Vice-Chancellor (or delegate) will revoke an executive suspension when the student demonstrates to the satisfaction of the Vice-Chancellor (or delegate) that they are fit to return to study or otherwise engage with RMIT without further risk.
(32)  If the student cannot demonstrate within 12 months of the executive suspension that they are fit to return to study or otherwise engage with RMIT without further risk, the student’s enrolment will be cancelled. Any future application for admission will be referred for a decision to the Vice-Chancellor (or delegate).
## Part F - APPEALS
#### Eligibility Criteria
(33)  Subject to satisfying any eligibility criteria set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) or corresponding procedures, a student may apply to appeal to the Student Conduct Appeals Committee against the determinations of a Senior Officer or the Student Conduct Board.
(34)  Any application to appeal must be based on one or more of the grounds of appeal set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) or corresponding procedure.
(35)  The Academic Registrar (or delegate) will decide whether the relevant application to appeal satisfies the grounds for appeal set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) or corresponding procedure in determining whether the application to appeal can proceed to a hearing of the Student Conduct Appeals Committee.
#### Student Conduct Appeals Committee
(36)  The Student Conduct Appeals Committee is constituted under these Regulations.
(37)  The powers and functions of the Student Conduct Appeals Committee are set out in this Regulation, the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.
(38)  The Student Conduct Appeals Committee may consider and make determinations in relation to eligible applications concerning determinations of:
  1. Senior Officers, and
  2. the Student Conduct Board.


(39)  Subject to Regulation (41), membership of the Student Conduct Appeals Committee comprises:
  1. a Chair
  2. one Senior Officer, and
  3. an enrolled student nominated by the principal student organisation.


(40)  Where possible, membership of the Student Conduct Appeals Committee will represent gender diversity.
(41)  A quorum of the Student Conduct Appeals Committee for determining the appeal is the Chair and one member.
(42)  The Chair may make procedural determinations on behalf of the Student Conduct Appeals Committee, including but not limited to determinations in relation to:
  1. the attendance of parties, representatives, and support persons at the hearing
  2. requests for adjournments, and
  3. release of information about the process and the determination.


## Part G - CONSEQUENCES OF MISCONDUCT
#### Senior Officers
(43)  A Senior Officer may apply the following consequences or penalties in finding that a student has engaged in misconduct: 
  1. a reprimand;
  2. suspend the student’s enrolment for a period not exceeding one compulsory semester or nominated teaching period;
  3. require the student to repeat all or any part of an assessment task;
  4. record a failure or capped result for a course;
  5. record a failure for all or any part of an assessment task;
  6. require the student to pay the cost of any damage to RMIT property (including the cost of repair or replacement) up to a maximum of $AUD200 in total. Property damage in excess of this amount is referred to the Student Conduct Board;
  7. provide the student with a verbal or a written warning taking steps to record the warning on the relevant student record or file;
  8. require that the student undertake or participate in any educative, learning, mediation or resolution focussed activity;
  9. impose a combination of the above; or
  10. subject to Regulation 44 below, any other actions which the Senior Officer considers appropriate, including as may be set out in more detail in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.


(44)  A Senior Officer may not: 
  1. cancel any or all final results;
  2. impose a financial penalty on the student who has engaged in misconduct;
  3. revoke the student’s licence to attend campus or any RMIT premises;
  4. exclude the student from using any of RMIT’s computing and network facilities for a period, either partially or fully;
  5. refer to Council a recommendation to revoke an award; or 
  6. expel the respondent student.


#### Student Conduct Board
(45)  The Student Conduct Board may apply the following consequences or penalties in finding that a student has engaged in misconduct: 
  1. any of the outcomes available to Senior Officers in Regulation 43 above;
  2. record a failure for a course or a capped result for a course, including the research component of a research program;
  3. cancel any or all final results;
  4. impose a financial penalty or fine on the student who has engaged in misconduct, in accordance with the RMIT’s schedule of fees and charges;
  5. require the student to pay the cost of any damage to RMIT property;
  6. make an order that the student has forfeited their fees associated with undertaking a course or program; 
  7. revoke the student's licence to attend campus or RMIT premises;
  8. exclude the student from using any of the RMIT’s computing and network facilities for a period either partially or fully;
  9. suspend the student's enrolment for a period not exceeding two compulsory semesters or nominated teaching periods;
  10. refer to Council a recommendation to revoke an award;
  11. expel the student; 
  12. any combination of the above consequences or penalties; 
  13. any other action the Student Conduct Board considers appropriate, including as may be set out in the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and corresponding procedures.


## Part H - MISCELLANEOUS
#### External Review of Determination
(46)  Nothing in these Regulations is intended to preclude a student from exercising any right to external review of any determination.
(47)  RMIT may pause any internal process under these Regulations where the student exercises the right to external review of a determination involving the same or similar subject matter, or where the matter is otherwise subject to legal proceedings.
#### Regulation of Proceedings
(48)  Subject to RMIT legislation, a Senior Officer, the Student Conduct Board, and the Student Conduct Appeals Committee constituted under the Student Conduct Regulations:
  1. regulates its own proceedings and may make determinations as to procedure
  2. in hearing any matter and making any determination: 
    1. is not bound by the rules or practices as to evidence or procedure applicable in courts of law or other tribunals, including the Evidence Act 2008 (Vic) or the Civil Procedure Act 2010 (Vic) as updated or replaced from time to time
    2. may inform themselves or itself in relation to any matter as they or it consider appropriate, and
    3. will apply the principles of procedural fairness.


#### Delegations 
(49)  The Vice-Chancellor may delegate to a Senior Officer in writing any of their functions or powers under these Regulations other than this power of delegation.
(50)  A Senior Officer may delegate to a Deputy Dean or Deputy Head of School in writing any of their functions or powers under these Regulations other than:
  1. a function or power delegated under Regulation 49, and
  2. this power of delegation.


#### Transitional Provisions
(51)  In this Regulation:
  1. commencement date means the date on which these Regulations come into operation.
  2. old regulations mean the Student Conduct Regulations in respect of which the seal was affixed by the authority of Council on 11 November 2013, and which were in force up until the commencement date of these Regulations.


(52)  Any report of potential student misconduct reported to a Senior Officer in accordance with these Regulations, on and from the commencement date, is to be dealt with under these Regulations.
(53)  Any report of potential student misconduct reported to a Senior Officer in accordance with the old regulations, prior to the commencement date, is to be dealt with under the old regulations.
#### Revocation of Regulations
(54)  On the commencement of these Regulations the following regulations are revoked: the Student Conduct Regulations in respect of which the seal was affixed by the authority of Council on 11 November 2013, and which were in force up until the commencement date of these Regulations.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
