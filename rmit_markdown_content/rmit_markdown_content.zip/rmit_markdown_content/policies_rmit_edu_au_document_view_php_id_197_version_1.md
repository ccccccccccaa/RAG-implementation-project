[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=197&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=197&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Titles Regulations 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=197)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=197&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=197&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=197&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=197&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=197&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=197&version=1)


# Titles Regulations
Hide Navigation
  * [Part A - PRELIMINARY](https://policies.rmit.edu.au/document/view.php?id=197&version=1#part1)
  * [1. Purpose](https://policies.rmit.edu.au/document/view.php?id=197&version=1#minor1)
  * [2. Authorising Provision](https://policies.rmit.edu.au/document/view.php?id=197&version=1#minor2)
  * [3. Definitions](https://policies.rmit.edu.au/document/view.php?id=197&version=1#minor3)
  * [Part B - TITLES](https://policies.rmit.edu.au/document/view.php?id=197&version=1#part2)
  * [4. Appointment](https://policies.rmit.edu.au/document/view.php?id=197&version=1#minor4)
  * [Part C - REVOCATION OF REGULATIONS](https://policies.rmit.edu.au/document/view.php?id=197&version=1#part3)
  * [5. Revocation of Regulations](https://policies.rmit.edu.au/document/view.php?id=197&version=1#minor5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
## Part A - PRELIMINARY
#### 1. Purpose
(1)  The purpose of these Regulations is to make provision for conferral of titles on persons who are associated with the University in a substantial way, including persons who are not employed or appointed to established or recurrent positions.
#### 2. Authorising Provision
(2)  These Regulations are made under the [RMIT Statute No.1](https://policies.rmit.edu.au/document/view.php?id=177) and sections 28, 29 and 30 of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20).
#### 3. Definitions
(3)  In these Regulations:
  1. Emeritus professor means a retired or former professor of the University in recognition of significant academic service to the University.
  2. Adjunct professor, or adjunct associate professor, or adjunct senior fellow, or adjunct fellow means a person with suitable levels of experience and expertise in a profession or industry whose appointment will assist in developing and strengthening engagement with industry and the professions, or for the enhancement of research and/or learning and teaching activities within the University.
  3. Visiting professor, or visiting associate professor, or visiting senior fellow, or visiting fellow means a member of the teaching or research staff of another educational or research institute, or a member of an industry body who is research active, who is appointed for a limited (specified) time to contribute to the research, learning and teaching, and/or advancement of the University.
  4. Vice-Chancellor’s innovation professor means a person with national or international eminence whose appointment will make a distinctive contribution to the research, learning and teaching, and/or advancement activities of the University.


## Part B - TITLES
#### 4. Appointment
(4)  Subject to the relevant policies and procedures, the University may appoint:
  1. Emeritus Professors
  2. Adjunct Professors
  3. Adjunct Associate Professors
  4. Adjunct Senior Fellows
  5. Adjunct Fellows
  6. Visiting Professors
  7. Visiting Associate Professors
  8. Visiting Senior Fellows
  9. Visiting Fellows
  10. Vice-Chancellor's Innovation Professor


on such terms and conditions as it decides.
## Part C - REVOCATION OF REGULATIONS
#### 5. Revocation of Regulations
(5)  On the commencement of these Regulations the following Regulations are revoked:
  1. Regulation 3.9.1 Professors Emeritus
  2. Regulation 3.10.1 Adjunct Professors.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
