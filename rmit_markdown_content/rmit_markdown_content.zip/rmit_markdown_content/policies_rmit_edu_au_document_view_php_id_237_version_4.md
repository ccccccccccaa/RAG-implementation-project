[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=237&version=4#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=237&version=4#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Progress Management and Support Schedule 1 - Milestone Submission Requirements, Assessment Criteria and Outcomes 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=237)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=237&version=4)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=237&version=4)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=237&version=4)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=237&version=4)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=237&version=4)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=237&version=4)


# HDR Progress Management and Support Schedule 1 - Milestone Submission Requirements, Assessment Criteria and Outcomes
Hide Navigation
  * [HDR Progress Management and Support Schedule 1 – Milestone Submission Requirements, Assessment Criteria and Outcomes](https://policies.rmit.edu.au/document/view.php?id=237&version=4#major1)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
### HDR Progress Management and Support Schedule 1 – Milestone Submission Requirements, Assessment Criteria and Outcomes
Authority for this document is established by the [HDR Progress Management and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=15).
Milestone requirements | Confirmation of candidature | Second milestone review | Third milestone review  
---|---|---|---  
A research proposal (confirmation of candidature) or summary document (subsequent milestones)  | Yes | Yes | Yes  
Details on how the proposed project will be undertaken (methodology) and an initial review of literature and references | Yes |  |   
Evidence of being enrolled in, having successfully completed, or been exempted from, the relevant research methods course | Yes |  |   
Evidence of completion of compulsory training (Respectful Research Training: HDR Candidates, and Research Integrity, required for the completion of Doing Research). | Yes |  |   
Evidence of completion of optional training including Intellectual Property – An Introduction, Intellectual Property Commercialisation, Human Ethics, Animal Ethics, Institutional Biosafety.  | Yes – if optional training is to be completed on the recommendation of the supervisory team |  |   
A research data management plan | Yes | Yes | Yes  
Evidence of required ethics and institutional biosafety approvals; or approved exemption, where applicable (confirmation of candidature) OR Evidence of maintaining required ethics and biosafety approvals (subsequent milestones) | Yes | Yes | Yes  
Evidence of consideration of the likely and actual impact, positive and negative, of the proposed research engagement of stakeholders, where appropriate | Yes | Yes | Yes  
A publication plan including evidence of any pending or completed research outputs and timelines | Yes | Yes | Yes  
An updated review of literature and references, and any changes to candidature since the last milestone review |  | Yes – include in summary document | Yes – include in summary document  
Draft chapters of the thesis, or equivalent in draft or published papers, as deemed appropriate for the discipline OR A portfolio of work, as appropriate to the discipline, which includes a draft of the dissertation  |  | Yes – at least two chapters OR Yes – draft dissertation required | Yes – at least two chapters OR Yes – draft dissertation required  
Any other requirements the school deems necessary.  | Yes | Yes | Yes  
The following criteria must be assessed during each milestone review:
Confirmation of Candidature | 
  1. A clear summary of the candidate’s aims, methods, theoretical/conceptual framework, as well as the significance, and potential impact of the research.
  2. Evidence that the candidate has begun to adequately reflect on their research framework, and its relationship to the existing body of knowledge.
  3. Evidence that the candidate understands the proposed methodology and has the skills and knowledge needed to undertake the research.
  4. Evidence that the candidate has addressed research integrity requirements, such as a data storage plan, and has obtained ethics and institutional biosafety approvals, if required; or approved exemption, where applicable.
  5. Evidence that the candidate has begun to consider the likely and actual impact, positive and negative, of the proposed research and has engaged with stakeholders, where appropriate.
  6. An indication that the research is original and will produce new knowledge (PhD candidates) OR appropriate to the level of a Master by Research degree in accordance with the Australian Qualifications Framework, including in-candidature research outputs.
  7. A clear and viable schema for completing the degree, including a research plan with a specific timeline for the research program from confirmation to completion. 

  
---|---  
Second milestone review | 
  1. Presentation of research outcomes of sufficient quality and quantity to support a coherent and critical account of that work.
  2. Evidence that the candidate has been developing the research and testing their methodology as they progressed.
  3. Evidence that the candidate has addressed research integrity requirements, such as a data storage plan, and has maintained ethics and institutional biosafety approvals, if required; or approved exemption, where applicable.
  4. Evidence that the candidate has a strong understanding of how their research is situated in the existing knowledge of their discipline and/or community of practice, and its relationship to work by the other researchers.
  5. Evidence of the research outputs planned or submitted for the public domain.
  6. A clear and viable schema for completing the degree, including a detailed timeline of the research program from the mid-point to completion.

  
Third milestone review | 
  1. Evidence of a coherent account of the candidate’s research and the submission of research outcomes which support their aims and answer their research question/s including potential or likely beneficial impacts arising from the research, such as for stakeholders and/or end-users.
  2. Evidence that the candidate has successfully situated their research within the discipline and/or community of practice and has taken account of other research related to their topic.
  3. Evidence that the candidate has addressed research integrity requirements, such as a data storage plan, and has maintained ethics and institutional biosafety approvals, if required; or approved exemption, where applicable.
  4. Evidence that the research is original and has produced new knowledge (PhD candidates) OR appropriate to the level of a Master by Research degree in accordance with the Australian Qualifications Framework.
  5. Evidence of research outputs planned or submitted for the public domain including communication of results with key stakeholders and end-users.
  6. A clear path and detailed timeline showing how the thesis/project will be completed in the time between the third milestone review and the submission date.

  
The following table provides information on the outcomes of the milestone reviews:
Milestone achieved  | No amendments required or minor amendment required to a candidate’s milestone documentation, made to the satisfaction of the senior supervisor.  
---|---  
Major amendments required | This outcome leads to the nomination of the candidate for a period of action and support. The candidate must re-present their milestone within the timeframe of the CASP. This outcome can include major changes to the milestone presentation and/or documentation. Where a candidate successfully presents their milestone for a second time, the milestone outcome will be changed to achieved. Where a candidate presents their milestone for a second time and the milestone is not achieved, the outcome ‘major amendments, not achieved’ is selected.  
Major amendments not achieved | This outcome is for candidates presenting their milestone for a second time where the amendments are not to the satisfaction of the milestone panel. The candidate will be referred to the college review for academic progress in accordance with the [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174).  
Ethics pending | This outcome means the candidate has achieved the milestone in all other respects except for ethics and/or biosafety approvals; or approved exemption, where applicable. It leads to the milestone being marked as ‘ethics pending’. If the candidate has not made an ethics application prior to their CoC, they will be nominated for a period of action and support. A CASP may be recommended if there are delays during the ethics application and/or revisions are required to the ethics application. Once the ethics approval or exemption has been obtained and the CASP (if required) is marked complete, the milestone outcome can be changed to achieved.  
Transfer to PhD | Recommends the candidate to transfer to a PhD (Master by Research candidates) in accordance with the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16). Where a candidate fails an attempt at a program transfer and the milestone is not achieved, SGR or the HDR DA may nominate the candidate for a period of action and support if the application for transfer has caused the candidate to be significantly delayed in their current program. The candidate needs to have requested to upgrade before attempting the milestone.  
Achieved, transfer to Masters by Research | Recommends the candidate to transfer to a Master by Research program (PhD candidates) in accordance with the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16). The candidate needs to have requested the downgrade before attempting the milestone.  
Not achieved, transfer to Masters by Research | This outcome means the candidate has not achieved their PhD milestone and the panel feels the candidate does not meet the requirements of a PhD. They recommend that the candidate considers a transfer to a Master by Research program (PhD candidates) in accordance with the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16). If the candidate does not want to downgrade, the outcome should be changed to ‘Major Amendments Required’ and the candidate nominated for a period of action and support.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
