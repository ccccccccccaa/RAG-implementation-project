[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=260#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=260#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Health, Safety and Wellbeing Policy Schedule 1 - Responsibilities and Accountabilities 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=260)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=260)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=260)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=260)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=260)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=260)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=260)


# Health, Safety and Wellbeing Policy Schedule 1 - Responsibilities and Accountabilities
Hide Navigation
  * [Section 1 - Schedule](https://policies.rmit.edu.au/document/view.php?id=260#section1)
  * [Overall responsibility](https://policies.rmit.edu.au/document/view.php?id=260#major1)
  * [Individual responsibilities](https://policies.rmit.edu.au/document/view.php?id=260#major2)
  * [Delegation of Health and Safety Responsibilities](https://policies.rmit.edu.au/document/view.php?id=260#major3)
  * [Authority](https://policies.rmit.edu.au/document/view.php?id=260#major4)
  * [Accountability](https://policies.rmit.edu.au/document/view.php?id=260#major5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Schedule
### Overall responsibility
(1)  RMIT has responsibility for providing a healthy and safe environment for all staff, students, researchers, visitors, third parties and members of the public who may take part in, or be affected by, RMIT’s activities.
### Individual responsibilities
#### Vice-Chancellor
(2)  The Vice-Chancellor has the responsibility and authority for the development, resourcing, implementation, review and continuous improvement of health, safety and wellbeing at RMIT. The Vice-Chancellor is accountable to the RMIT University Council for health, safety and wellbeing performance and ensuring the commitments within RMIT’s [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97) are delivered.
(3)  The Vice-Chancellor must ensure that:
  1. there is a clear and robust health, safety and wellbeing strategy and policy
  2. there is adequate resourcing for health, safety, and wellbeing within the organisation, enabling the objectives of the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97) and Strategy to be met
  3. systems are in place and resourced to monitor and remedy workplace conditions and the health of the RMIT community
  4. regular reports of activity against the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97) and Strategy are submitted to Council and other relevant forums.


#### Executive Leaders
(4)  Executive leaders and CEOs of RMIT controlled entities must:
  1. promote the principles of health, safety, and wellbeing throughout all levels of the organisation
  2. contribute to the evolution of the organisation’s health, safety, and wellbeing culture
  3. participate, where required, in matters relating to health, safety and wellbeing
  4. provide adequate resourcing for health, safety, and wellbeing within the organisation, enabling the objectives of the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97) and Strategy to be met
  5. provide mechanisms for effective and meaningful consultation and rectification regarding matters relating to the health, safety, and wellbeing of RMIT staff and students
  6. plan and implement the [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated) (Safety Management System) and ensure health, safety and wellbeing matters are addressed in relation to all new development, tendering, research and program opportunities
  7. monitor compliance with Occupational Health and Safety legislation and RMIT’s [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated) (GSM) requirements
  8. participate in the ongoing monitoring and review of the organisation’s performance in health and safety, including the formal Health, Safety and Wellbeing Management Review process
  9. provide adequate facilities and safe systems of work.


#### Senior Leaders
(5)  Senior leaders must:
  1. ensure adequate and timely resourcing of all areas of health, safety and wellbeing within their area of responsibility to ensure adequate safe systems of work can be effectively implemented.
  2. promote and support the roles of Health and Safety Representatives, first aiders and wardens
  3. implement the [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated) (Safety Management System) and ensure health, safety and wellbeing matters are addressed in relation to all new development, tendering, research, and program opportunities
  4. monitor and review of health, safety and wellbeing performance and risks across their area of responsibility and ensure all hazards, incidents and near misses are managed in accordance with [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated)
  5. maintain adequate facilities and safe systems of work across their area of responsibility
  6. provide staff and students, and third parties with necessary information, instruction, supervision and training.


#### Operational Leaders and Supervisors
(6)  Operational Leaders and Supervisors must:
  1. ensure staff, students, researchers and third parties are aware of and understand their health and safety responsibility
  2. implement the [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated), which provides safe systems of work for employees, students and third parties to safely undertake their work, study, and research
  3. monitor resourcing of all areas of health, safety, and wellbeing within the area of responsibility to ensure adequate safe systems of work are effectively implemented
  4. consult and communicate effectively and meaningfully on matters relating to the health, safety, and wellbeing of RMIT staff, students and researchers
  5. provide staff, students, researchers and third parties with necessary information, instruction, and training
  6. provide staff, students, researchers and third parties with adequate supervision based on the level of risk and competency
  7. participate in the risk management processes for health, safety and wellbeing matters and engage subject matter experts as required within their area of responsibility
  8. report all health and safety incidents, near misses, hazards and risks, and investigate and action in accordance with the [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated)
  9. ensure staff, students, researchers and third parties are aware of RMIT’s Incident and Hazard Reporting process
  10. monitor and review health, safety and wellbeing performance across their area of responsibility to ensure all hazards, incidents and near misses are managed in accordance with [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated).


#### Staff, Students and Researchers
(7)  Staff, students and researchers must, as applicable:
  1. take reasonable care for their own health and safety and ensure their acts or omissions do not adversely affect the health and safety of other persons
  2. comply with policies and procedures and any reasonable instruction given by RMIT relating to health, safety and wellbeing
  3. comply with lawfully issued instructions from Wardens or other members of the Emergency Control Organisation during emergency situations
  4. participate in risk management processes and engage subject matter experts as required
  5. promptly report to their manager/supervisor if they believe there is a risk to the health, safety and wellbeing of themselves or others
  6. participate in meetings, training and other health safety and wellbeing activities
  7. pass on relevant information to peers to protect themselves or others from risk of injury or illness.


#### Health and Safety Representatives (HSR) and Deputy Health and Safety Representatives (DHSR)
(8)  HSRs and DHSRs are encouraged to:
  1. represent their Designated Work Group (DWG) on occupational health and safety issues, concerns and interests, as detailed in the Health and Safety Representatives process document in the [Global Safety Model](https://policies.rmit.edu.au/download.php?id=78&version=3&associated) (HSW-PR08)
  2. facilitate communication and consultation and provide a crucial link between RMIT management and those in their DWG.


#### Third Parties
(9)  Third Parties must:
  1. take reasonable care for their own health and safety whilst on RMIT premises or performing work for RMIT
  2. take reasonable care to ensure their acts or omissions do not adversely affect the health and safety of other persons
  3. comply with policies and procedures and any reasonable instruction given by RMIT
  4. promptly report to their manager/supervisor if they believe there is a risk to the health, safety and wellbeing of themselves or others
  5. pass on any information to others to protect themselves or others from risk of injury or illness on RMIT premises or performing work for RMIT.


#### Visitors
(10)  Visitors must:
  1. take reasonable care for their own health and safety
  2. take reasonable care to ensure their acts or omissions do not adversely affect the health and safety of other persons
  3. comply with policies and procedures and any reasonable instruction given by RMIT staff.


#### Director, Health Safety and Wellbeing
(11)  The Director, Health Safety and Wellbeing must:
  1. develop and implement the RMIT Health, Safety and Wellbeing Strategy
  2. review, develop, consult on, implement, and monitor the Global Safety Model in meeting the requirements of the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
  3. ensure Executive Reporting on RMIT Health, Safety and Wellbeing performance is completed
  4. assist with the development of RMIT Health, Safety and Wellbeing KPIs
  5. facilitate continuous improvement of safety performance in RMIT’s operations
  6. implement the [Health, Safety and Wellbeing](https://policies.rmit.edu.au/document/view.php?id=97), [Child Safe](https://policies.rmit.edu.au/document/view.php?id=213) and [Gender-Based Violence Prevention and Response](https://policies.rmit.edu.au/document/view.php?id=218) policies and associated procedures, including providing relevant directions to staff, students and third parties.


#### Health, Safety and Wellbeing Team
(12)  The Health, Safety and Wellbeing team must:
  1. promote the principles of health, safety and wellbeing across RMIT
  2. provide specialist advice on health, safety and wellbeing matters
  3. contribute to the evolution of the organisation’s health, safety and wellbeing culture
  4. monitor and assist (where required) with the fulfilment of health, safety and wellbeing responsibilities throughout RMIT
  5. maintain RMIT’s Global Safety Management system
  6. report on the performance of RMIT’s Global Safety Management system and specific elements as required
  7. maintain current knowledge of Occupational Health and Safety legislation and standards as they apply to RMIT’s operations and delivery of service
  8. report to regulators as required by Occupational Health and Safety legislation.


#### Property Services Group (Property Services)
(13)  Property Services Group (PSG) manages, maintains and optimises the use of RMIT owned infrastructure. PSG operates under an Integrated Management System and are certified for ISO9001, 45001, 14001, 55001 and 41001.
(14)  PSG must:
  1. provide strategic advice to support the RMIT Health, Safety and Wellbeing Strategy and operationalise the strategy with relation to maintenance of RMIT built infrastructure and third-party maintenance and construction works
  2. oversee safety, environment and hazardous materials activities for the maintenance and construction undertaken by Property Services
  3. ensure compliance with applicable Acts and Regulations for activities undertaken by Property Services
  4. oversee and manage relationships with Property Services third parties, including improving safety culture
  5. identify and manage risks and report in relation to maintenance and construction, including risk and reporting for Property Services third parties’ consultants/contractors
  6. respond to imminent or immediate risks in relation to health, safety and wellbeing (including physical and psychological) of staff, students and visitors on RMIT’s premises


### Delegation of Health and Safety Responsibilities
(15)  Health and safety responsibilities cannot be transferred to another person. Specific tasks, however, can be delegated to competent persons. This should follow the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51) process as detailed in RMIT [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51) policy. Where specific health and safety tasks are delegated, these must be documented and communicated to the responsible person/s. This may be documented through job descriptions and/or workplans.
(16)  More than one person can have the same responsibilities at the same time.
### Authority
(17)  The level of health, safety and wellbeing authority is commensurate with the level of responsibility within a role. This will depend on the level of control a role has to influence outcomes.
(18)  These are outlined in position descriptions, namely:
  1. Vice-Chancellor for all RMIT
  2. CEOs of RMIT controlled entities
  3. Executive Leaders for their respective college or portfolio
  4. Operational Leaders for their respective school or department
  5. Supervisor for their respective area, project, laboratory or workshop.


(19)  Director, Health Safety and Wellbeing
  1. The Director, Health Safety and Wellbeing has authority to revoke a person’s implied licence to be on RMIT’s campus where that person is not an RMIT staff member or student and the Director, Health Safety and Wellbeing reasonably believes that the person: 
    1. presents an ongoing risk to the health, safety or wellbeing (including physical and psychological) of staff, students or visitors; or
    2. has engaged, and is likely to reengage, in theft, damage or destruction of RMIT’s facilities, buildings, infrastructure, equipment or other property. This section 19(a) does not in any way limit section (36)(4) of the [RMIT Statute No 1 (Amendment No.2)](https://policies.rmit.edu.au/document/view.php?id=177).
  2. Where revoking a person’s implied licence to be on campus under section (19(a)), the Director, Health Safety and Wellbeing must consider: 
    1. whether such a revocation would inhibit the person’s freedom of speech and freedom to protest under the [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56); and
    2. the [Charter of Human Rights and Responsibilities Act 2006 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=46), and must be made after consultation with relevant RMIT experts or advisors, including but not limited to, where relevant, Safer Community, Legal Services and Security.
  3. All revocations of a person’s implied licence under section (19)(a) must be: 
    1. documented in writing;
    2. include reasons for the decision; and
    3. be signed by the Director, Health Safety and Wellbeing.
  4. All such documents must be stored securely in RMIT’s records management system with access provided to RMIT Senior Manager, Campus Security Operations and any other RMIT staff required to enforce the decision.
  5. A summary of revocations must be provided through the regular health, safety and wellbeing (HSW) reporting including but not limited to: HSW Steering Committee, University Executive and Nominations, Remuneration and People Committee (NRPC).


(20)  Property Services Groups staff, such as Security, Grounds and Facility Managers (PSG), have authority to:
  1. stop an activity and evacuate an area where there is an imminent and significant risk of harm or damage, for example: 
    1. in relation to events on RMIT premises; or
    2. failure of building or facilities infrastructure or essential services such as gas, water, electricity;
  2. require a person to produce their RMIT staff or student identification card upon request; 
  3. make enquiries and take reasonable action to regulate the access and behaviour of persons while they are on RMIT’s premises in order to maintain a safe and secure environment;
  4. take reasonable steps to bring about a person’s removal from RMIT’s premises where: 
    1. the person presents an imminent risk to health, safety or wellbeing (including physical and psychological) of persons on RMIT’s premises;
    2. the person fails to comply with a request to produce their RMIT staff or security identification card and the person does not demonstrate a reason authorised by RMIT to remain on RMIT’s premises;
    3. the person is undertaking an unauthorised Specified Activity (as defined under the [Property Management Procedure](https://policies.rmit.edu.au/document/view.php?id=78)) and does not cease undertaking the Specified Activity upon request by PSG staff;
    4. the Director, Health Safety and Wellbeing has revoked the person’s implied licence to be on RMIT’s campus or locations under section (19)(a); or
    5. as otherwise authorised under the RMIT Statute No.1 (Amendment No.2).


(21)  Property Services must report any exercise of any powers under section (20)(d) to the Executive Director, Property Services Group within 24 hours of that exercise. The Executive Director, Property Services must report any exercise of powers under section (20)(d) at the next Audit and Risk Management Committee.
(22)  All members of the RMIT community have authority to initiate action to stop a hazardous activity. The appropriate action will vary depending on the circumstances and may include, for example:
  1. a direct request to the person causing the hazard or their supervisor
  2. calling Security in case of emergency
  3. calling Facilities Management for building or contractor hazards
  4. completing a hazard report, or
  5. notifying their Health and Safety Representative or Health, Safety and Wellbeing Team Advisor.


### Accountability
(23)  Accountability for health, safety and wellbeing responsibilities is monitored through:
  1. Executive Leaders’ meetings
  2. Council meetings
  3. Positive Performance Targets and/or staff performance reviews
  4. Periodic health, safety and wellbeing statistics and reports
  5. Internal or external audits
  6. Corrective Actions
  7. Occupational Health and Safety committees


(24)  Documented evidence of accountability monitoring can be demonstrated by completed audit reports, periodic and annual review reports and minutes of committee meetings.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
