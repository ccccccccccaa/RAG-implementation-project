[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=103&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=103&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Sustainability Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=103)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=103&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=103&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=103&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=103&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=103&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=103&version=3)


# Sustainability Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=103&version=3#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=103&version=3#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=103&version=3#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=103&version=3#section4)
  * [Governance](https://policies.rmit.edu.au/document/view.php?id=103&version=3#major1)
  * [Tertiary education](https://policies.rmit.edu.au/document/view.php?id=103&version=3#major2)
  * [Impact](https://policies.rmit.edu.au/document/view.php?id=103&version=3#major3)
  * [Infrastructure and Operations](https://policies.rmit.edu.au/document/view.php?id=103&version=3#major4)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=103&version=3#major5)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=103&version=3#major6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This policy articulates RMIT’s commitment to advancing its sustainability ambitions as an organisation that models institution-wide excellence. RMIT aims to embed sustainability principles and practices throughout governance, learning and teaching, research and operational activities.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=3#document-top)
# Section 2 - Overview
(2)  As a signatory to both the United Nations Global Compact and the Universities Commitment to the Sustainable Development Goals (SDSN Australia/New Zealand 2017), RMIT defines sustainability as: • development that meets the needs of the present without compromising the ability of future generations to meet their own needs. Building an inclusive, sustainable and resilient future for people and the planet • harmonising three core pillars: economic health, social inclusion and environmental protection, which are interconnected, and crucial for the wellbeing of individuals, societies and ecosystems.
(3)  RMIT University acknowledges the people of the Woi wurrung and Boon wurrung language groups of the eastern Kulin Nation on whose unceded lands we conduct the business of the University. RMIT University respectfully acknowledges their Ancestors and Elders, past and present. RMIT also acknowledges the Traditional Custodians and their Ancestors of the lands and waters across Australia where we conduct our business and their unique rights to participate in all aspects of RMIT under the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20). 
(4)  RMIT recognises and acknowledges the [Bundjil Statement](https://policies.rmit.edu.au/download.php?id=127&version=1&associated), which helps all RMIT community to respectfully work, live and study on Aboriginal Country through a dhumbali (commitment) to not harm the wurneet (waterways), biik biik (lands) and bubups (children) of Bundjil. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=3#document-top)
# Section 3 - Scope
(5)  This policy is applicable to all staff, students, contractors, service providers, clients, customers and visitors when they are engaged in RMIT activities and is applicable to the RMIT Group which includes the University and the controlled entities (RMIT Vietnam, RMIT Europe, RMIT Online, RMIT University Pathways (RMIT UP)).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=103&version=3#document-top)
# Section 4 - Policy
(6)  RMIT is guided by the following sustainability principles across all aspects of its education, research, governance and operations:
### Governance
(7)  Ensure sustainability remains an organisational priority – embedding sustainability principles into all RMIT activities and ensuring decision-making reflects RMIT’s values.
(8)  Behave as a socially responsible organisation – considering whole of lifecycle impacts and prioritising overall sustainability merit where it outweighs minor, short term impacts or higher upfront costs to drive positive impacts for communities and the environment. 
(9)  Support the rights of Aboriginal and Torres Strait Islander peoples informed by the United Nations Declaration on the Rights of Indigenous Peoples through our commitment to responsible practice and the Indigenous strategic commitments.
(10)  Ensure our strategies, processes, supply chains and partnerships meet fundamental responsibilities in the areas of human rights, labour, environment and anti-corruption to achieve a culture of integrity.
(11)  Continue to model participatory governance and engagement with our students, staff and communities, ensuring everyone contributes to sustainability and is accountable for driving positive change.
(12)  Ensure that our staff, partners, suppliers and wider supply chain act ethically and align with RMIT values.
(13)  Be transparent in our sustainability journey, regularly monitoring, reporting and improving on our performance to stakeholders. 
### Tertiary education
(14)  Support academic and teaching staff to develop high levels of discipline-relevant sustainability literacy so that they are able (competent and confident) to facilitate sustainability learning.
(15)  Embed sustainability capabilities and competencies within disciplinary and professional contexts and encourage interdisciplinary collaboration.
(16)  Engage students at all levels in learning about relevant sustainability concepts (knowledge, skills and values), identifying issues of importance and taking actions to empower them as ethical global citizens.
(17)  Support our students to drive innovation and sustainable enterprise as future leaders in industry and society. 
### Impact
(18)  Adopt a leadership role at a national and international level to shape a sustainable environment and society, contributing to the UN Sustainable Development Goals.
(19)  Support RMIT’s commitments to reduce inequality and promote diversity, inclusion and equity for staff, students and the wider community.
(20)  Ensure RMIT’s research contributes to the advancement of the Sustainable Development Goals.
(21)  Make RMIT a living laboratory, encouraging research and learning that engages with internal infrastructure, process and people. 
(22)  Proactively engage in partnerships and projects with industry, government, non-government organisations and communities on sustainability.
### Infrastructure and Operations
(23)  Exceed, wherever possible, all legislative and regulatory requirements for sustainability and aim to achieve exemplary sustainable practice in all its operations.
(24)  Embed responsible practice into planning and decision-making processes in keeping with our dhumbali to work respectfully on Aboriginal country; and instil a consciousness of place-specific considerations wherever we are working in the world.
(25)  Assess and address the risks of modern slavery in our operations and supply chains through due diligence and remediation processes, as well as implementing tools to assess the effectiveness of these actions.
(26)  Minimise the consumption of resources through sustainable procurement, waste avoidance, good design, reuse, recycling and community engagement to drive a circular economy.
(27)  Prioritise water and energy efficiency, conservation and education.
(28)  Preserve and enhance the architectural, social, creative and natural value of place and promote healthy functioning ecosystems.
(29)  Utilise best-practice sustainable design and innovative technologies to deliver efficient, resilient and adaptable buildings, which are accessible and inclusive by design.
(30)  Ensure that RMIT’s greenhouse gas emission reduction targets and actions enable a transition to a low-carbon future, whilst ensuring our places and people are resilient to the impacts of climate change.
(31)  Provide infrastructure and initiatives that encourage the use of sustainable transport modes.
### Responsibilities
(32)  The RMIT Sustainability Committee is responsible for the oversight and implementation of this policy.
(33)  The performance of this policy is tracked in the Sustainability Annual Report which is prepared in accordance with the Global Reporting Initiative (GRI) Standard.
### Review
(34)  The Sustainability Committee is responsible for the review of this policy and supporting documents.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
