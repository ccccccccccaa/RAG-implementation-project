[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=100&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=100&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Sexual Harassment Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=100)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=100&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=100&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=100&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=100&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=100&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=100&version=1)


# Sexual Harassment Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=100&version=1#section1)
  * [Section 2 - Scope](https://policies.rmit.edu.au/document/view.php?id=100&version=1#section2)
  * [Section 3 - Policy](https://policies.rmit.edu.au/document/view.php?id=100&version=1#section3)
  * [Sexual Harassment](https://policies.rmit.edu.au/document/view.php?id=100&version=1#major1)
  * [Disclosure and Support](https://policies.rmit.edu.au/document/view.php?id=100&version=1#major2)
  * [Responsibilities of Management, Staff and Students](https://policies.rmit.edu.au/document/view.php?id=100&version=1#major3)
  * [Education and Training](https://policies.rmit.edu.au/document/view.php?id=100&version=1#major4)
  * [Consequences](https://policies.rmit.edu.au/document/view.php?id=100&version=1#major5)
  * [Section 4 - Definitions](https://policies.rmit.edu.au/document/view.php?id=100&version=1#section4)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Purpose
(1)  The University is committed to providing a safe, respectful study and workplace and this means one that is free from sexual harassment.
(2)  The University aims to ensure that all staff and students understand their responsibilities and:
(3)  are aware of the behaviours that may constitute sexual harassment; are informed in the prevention of sexual harassment; know where to get support for themselves or others; know where to report sexual harassment.
(4)  RMIT encourages the reporting of behaviour that is harmful and disrespectful so it can be addressed to ensure RMIT is a safe and respectful work and study environment for all members of the university community.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=100&version=1#document-top)
# Section 2 - Scope
(5)  This policy is applicable to all students and staff members. It also applies to contractors, service providers, clients, customers and visitors when they are engaged in University activities, and is applicable to all RMIT locations whether in Australia or overseas.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=100&version=1#document-top)
# Section 3 - Policy
### Sexual Harassment
(6)  Sexual harassment is unacceptable and has no place at RMIT. No person at RMIT must ever engage in behaviour which could be regarded as sexual harassment.
(7)  Sexual harassment can impact anyone regardless of their sex, gender identity or sexual orientation.
(8)  Sexual harassment can take various forms. It can involve conduct such as:
  1. unwelcome touching, hugging or kissing
  2. staring or leering
  3. suggestive comments or jokes
  4. sexually explicit pictures, screen savers or posters
  5. unwanted invitations to go out on dates or requests for sex
  6. intrusive questions about someone’s private life or body
  7. unnecessary familiarity, such as deliberately brushing up against someone
  8. insults or taunts of a sexual nature
  9. sexually explicit emails, SMS messages or social media
  10. accessing sexually explicit internet sites
  11. inappropriate advances on social networking sites


(9)  Sexual harassment also includes offences and crimes which are associated with unwelcome conduct of a sexual nature such as sexual assault, indecent exposure, stalking, obscene communications etc.
(10)  Sexual harassment does not have to be repeated or continuous, it can be a one-off incident.
(11)  Sexual harassment is not sexual interaction, flirtation, attraction or friendship which is invited, mutual, consensual or reciprocated but can occur where consent has been withdrawn or if a person continues with behaviour after being put on notice that the behaviour is no longer welcome.
### Disclosure and Support
(12)  Care and consideration for a person’s wellbeing is the primary focus of the University in responding to any Disclosure of sexual harassment and in addressing any report or complaint of sexual harassment.
(13)  In considering the wellbeing of a person involved in a Disclosure of sexual harassment the University must take into account all implications with regards to that person participating in potential complaints and/or misconduct processes and investigations. These implications will be balanced against the University’s obligations to address the possible misconduct and to provide a safe workplace. A Disclosure will not automatically require a person to participate in a Concern or Complaint process.
(14)  Support will be offered in response to any disclosure of sexual harassment, regardless of location of the incident, whether or not it occurred in connection with the University and whether or not a Concern or Complaint has been lodged.
(15)  The University recognises that the person making a Disclosure of sexual harassment has the choice to report a Concern or make a Complaint to the University or the Police and is entitled to be fully informed of their available options and the possible outcomes.
(16)  The University will take steps to make staff and students aware of how to make a disclosure of sexual harassment.
(17)  Disclosures of sexual harassment by students should be referred to Safer Community (safercommunity@rmit.edu.au) in the first instance.
(18)  Disclosures of sexual harassment by staff should be referred to the Health, Safety and Wellbeing (HSW) team in the first instance (contact HR Assist and ask for the HSW team).
(19)  Concerns and complaints of sexual sarassment will be managed in accordance with the Complaints Resolution Policy with a complainant and respondent being made aware of all allegations and counter-allegations under consideration and being given the opportunity to rebut information relied upon by decision makers.
(20)  Where students experience sexual harassment on placement, the local procedures at the site of the placement should be used. The University will ensure that the relevant University personnel are informed and that appropriate action is taken to ensure the safety of students.
(21)  The University will comply will all mandatory reporting obligations. For example, possible offences regarding students under the age of 18.
### Responsibilities of Management, Staff and Students
(22)  All members of the RMIT community are responsible for their behaviour and actions.
(23)  All managers/supervisors will be informed of their responsibility for ensuring the maintenance of proper standards of conduct within the University context.
(24)  All persons covered by the scope of this policy are required to:
  1. Comply with this policy
  2. Behave appropriately
  3. Promote a climate of mutual respect
  4. Maintain confidentiality concerning any disclosure, report, complaint or investigation


(25)  Where inappropriate behaviour is witnessed or known to have occurred appropriate action must be taken. It is the responsibility of everyone to take action to eradicate sexual harassment.
(26)  Staff members with managerial/ supervisory responsibility are required to:
  1. Promote a respectful culture and practices within their sphere of influence and take steps to prevent a sexual harassment culture from developing at RMIT.
  2. Take steps to inform staff and students that sexual harassment is unacceptable and has no place at RMIT.
  3. Take steps to ensure that acceptable standards of conduct are maintained and take action when unacceptable conduct is observed.
  4. Take steps to make students and staff aware of RMIT’s commitment to assist them should they experience sexual harassment regardless of where this occurs.
  5. Ensure that students and staff on placement have access to the policies and practices in place at that site.
  6. Encourage staff members to use the services of the University’s Employee Assistance Program (EAP) where appropriate.
  7. Encourage students to use the student support and counselling services of the University where appropriate.
  8. Manage Disclosures, Concerns or Complaints of sexual harassment in a timely, confidential and fair manner ensuring due process to all parties.


### Education and Training
(27)  Staff and students will be informed of this policy and have access to the information and training needed to both prevent and respond to incidents of sexual harassment.
(28)  Training will be provided to staff at induction and at regular intervals.
(29)  Staff will be required to complete any mandated training within the prescribed timelines.
(30)  Students will be offered training opportunities around the issues of sexual misconduct and informed consent.
### Consequences
(31)  Conduct which breaches this policy may result in disciplinary action.
(32)  The remedies for action will be taken by the University in line with the relevant service contract or agreement where the behaviour involves a customer, contractor or service provider.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=100&version=1#document-top)
# Section 4 - Definitions
Sexual harassment | A person sexually harasses another person if he or she— 
  1. makes an unwelcome sexual advance, or an unwelcome request for sexual favours, to the other person; or
  2. engages in any other unwelcome conduct of a sexual nature in relation to the other person—

in circumstances in which a reasonable person, having regard to all the circumstances, would have anticipated that the other person would be offended, humiliated or intimidated.  
---|---  
Disclosure | Where a person first makes known an incident of sexual harassment with the University. This may or may not lead to a concern or complaint being made via the Complaints Governance Policy. The wellbeing of the person making the Disclosure is the primary objective of the staff member receiving the Disclosure.  
Concern | An expression of dissatisfaction with a decision, action or lack of these by RMIT, or the behaviour of a student or staff member, where no formal response or resolution is requested or implicitly expected.  
Complaint | An expression of dissatisfaction with a decision, action or lack of these by RMIT, or the behaviour of a student or staff member, where a response or resolution is explicitly or implicitly expected.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
