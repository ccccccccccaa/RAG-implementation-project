[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=249#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=249#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Child Safe Code of Conduct 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=249)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=249)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=249)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=249)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=249)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=249)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=249)


# Child Safe Code of Conduct
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=249#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=249#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=249#section3)
  * [Section 4 - Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249#section4)
  * [Behaviours](https://policies.rmit.edu.au/document/view.php?id=249#major1)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=249#major2)
  * [Understanding and Acceptance](https://policies.rmit.edu.au/document/view.php?id=249#major3)
  * [Section 5 - Related Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=249#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The RMIT Child Safe Code of Conduct will provide guidelines about professional behaviours, expectations, obligations, outline appropriate and inappropriate behaviours when interacting with children, and the consequences of inappropriate conduct.
  1. for the purposes of this Child Safe Code of Conduct, a child is any person under the age of 18. Younger person, young person and children are other terms used to refer to anyone under the age of 18.


(2)  RMIT University is committed to fostering the empowerment and engagement of children and young people. RMIT seeks, at all times, to create an environment that supports children and young people to participate in decisions that affect them and to have confidence that adults in the RMIT community will always act on their concerns. RMIT is committed to ensuring that young people are aware of their rights and provided with age-appropriate child safety information.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=249#document-top)
# Section 2 - Overview
(3)  The Child Safe Code is about how we work as a community to uphold our commitment to child safety.
(4)  As a public University that conducts its business across the biik biik (lands) and wurneet (water ways) of the Eastern Kulin Nations, the Child Safe Code acknowledges our dhumbali (commitment) to place, explained in the [Bundjil Statement](https://policies.rmit.edu.au/download.php?id=127&version=1&associated).
(5)  RMIT is a values-based organisation, and all staff are expected to practice our RMIT core values. Our values inspire us and help us to make RMIT a positive force for social, cultural and environmental change, and guide how we live and work together, wherever we are in the world.
(6)  The Child Safe Code is maintained as an information resource for RMIT Group staff and the public.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=249#document-top)
# Section 3 - Scope
(7)  All staff, students, contractors, visitors and volunteers across all campuses in all regions are required to comply with the Child Safe Code of Conduct, irrespective of whether their role includes interaction with children. It also applies to students when completing a placement.
(8)  Any breach of this Child Safe Code of Conduct must be reported to RMIT Safer Community.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=249#document-top)
# Section 4 - Code of Conduct
### Behaviours
#### Expected behaviours
(9)  All staff are responsible for:
  1. adhering to all relevant Australian and Victorian legislation, RMIT University [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213), this Child Safe Code of Conduct, and other organisational policies
  2. conducting yourself in a manner consistent with RMIT values 
  3. promoting the safety and wellbeing of children and young people
  4. establishing and maintaining a child safe environment in the course of your work
  5. treating children, young people and their families with respect, fairness, professionalism and courtesy
  6. actively promoting cultural safety, participation and inclusion to ensure all children and their families are welcomed by being inclusive
  7. upholding the principles of equity in working with children and young people
  8. treating all children and young people with respect, regardless of race, colour, sex, gender identity, sexual orientation, language, religion, political or other opinion, national, ethnic, or social origin, culture, property, disability, or other status
  9. providing Aboriginal children and young people with a safe, respectful, positive environment where they are empowered to express their culture and belief systems
  10. respecting and protecting the cultural rights of Aboriginal children and young people, ensuring that each child is supported in their identity
  11. promoting the safety, participation and empowerment of children and young people with a disability, culturally and linguistically diverse, LGBTIQ+ children and young people and those who cannot live at home
  12. understanding and complying with reporting obligations
  13. raising concerns with the University if risks to child safety are identified in any of the activities, facilities, structures, procedures, or adult behaviour
  14. making a report if you believe or suspect a child is being harmed, is at risk of harm, or an allegation or disclosure has been made, taking all reasonable steps to protect children from abuse
  15. reporting and act on any behavioural complaints, concerns or observed breaches regarding this Child Safe Code of Conduct
  16. reporting any concern, allegation, disclosure, or observation of child abuse to the relevant person or authority as outlined in RMIT University’s reporting procedure and in line with mandatory reporting requirements, including the Reportable Conduct Scheme
  17. respecting the privacy of children and their families by keeping all information regarding child protection concerns confidential, only discussing information with the relevant people to follow the reporting procedure
  18. listening to and valuing children and young people’s ideas and opinions, ensuring they are listened to and responded to appropriately
  19. working with children in an open and transparent way – other adults should always know about the work being done with a child/young person
  20. maintaining appropriate boundaries and ensuring a professional and appropriate tone in all social media interactions, especially with a child/young person
  21. always maintaining professional boundaries with a child/young person, including when seeing a child from RMIT outside the workplace
  22. ensuring any physical contact with a child/young person is appropriate to the delivery of learning and programs or activities, and based on the needs of children and young people (such as to assist or comfort a distressed child)
  23. participating in child safety training.


(10)  Expected behaviours in an online environment:
  1. only authorised contact with a child/young person using RMIT email addresses and/or RMIT social media accounts
  2. any other interaction with a child/young person online must be for the purposes of their safety or education and must take place on University endorsed channels, such as RMIT email systems
  3. if an online class has students who are under 18, they must ensure that the content is suitable for all participants.


(11)  Unacceptable behaviours are:
  1. engaging in any activity with a child or young person that is likely to cause harm, including participating in any behaviour that would constitute abuse, harm, neglect, exploitation, harassment, discrimination, or victimisation
  2. condoning or participating in behaviour with a child/young person that is illegal, unsafe, or abusive
  3. seeking to use a child/young person in any way to meet the needs of adults
  4. ignoring or disregarding any concerns, suspicions, or disclosures of child abuse
  5. exaggerating or trivialising child abuse issues
  6. using hurtful, discriminatory, or offensive behaviour or language with a child/young person
  7. initiating unnecessary physical contact (including cuddling, physical restraint, or personal hygiene practices (such as patient care while on placement)
  8. engaging in sexual misconduct, which includes any sexual activity (touching, fondling, oral, anal, or vaginal penetration, voyeurism, exhibitionism), exploitation, inappropriate conversations of a sexual nature. Sexual misconduct can occur face to face or online.
  9. engaging in any behaviours which could be seen as grooming, such as developing ‘special’ relationships with a child/young person, showing favouritism through the provision of gifts or inappropriate attention, or developing friendships with a child/young person and/or their families outside learning/program hours. Grooming can occur face to face or online.
  10. discriminating on the basis of age, sex, gender identity, race, culture, or sexual orientation
  11. being in a one-to-one situation with a child/young person unless required by your role
  12. supply of alcohol or drugs to a child/young person
  13. communicating directly with a child through personal or private contact channels (including but not limited to social media, email, instant messaging, chat rooms, gaming sites and texting) outside of learning/program requirements, your position description or without oversight
  14. exchanging personal contact details such as phone numbers, social media details or email addresses with a child/young person outside of learning/program requirements, your position description or without oversight
  15. having unauthorised contact with a child/young person online, on social media, email or by phone 
  16. using any device including computer, mobile phone, or video or digital camera to exploit or harass a child/young person
  17. offering to transport a child/young person alone in your car or inviting them to your home (except in cases of an organised car-pooling arrangement for transport for course related or club trips, with the consent of a parent or guardian).


(12)  Camping and/or overnight stays. Throughout their engagement with RMIT, enrolled students aged 16 or 17 years old may participate in camps and overnight trips either as part of their education or their membership of an RMIT club or society. Elements to be considered include, but are not limited to:
  1. parental/guardian approval must be obtained in writing prior to the trip
  2. supervision - if no RMIT staff member will be present, leaders of the group must be aware of their responsibilities regarding child safety and consider a ‘buddy’ support system where a trip leader and/or responsible adult helps to support the participation of a child/young person
  3. emergency contacts – ensure the trip leaders have the emergency contact of every child/young person 
    1. ensuring that the child/young person and trip organiser have the details for escalated support, such as Safer Community.
  4. sleeping arrangements – consider if the arrangements will be safe and appropriate for a child/young person, such as age and gender
  5. consumption of alcohol – ensure the young person is aware that they are not allowed to consume alcohol on the trip and ensure the trip leaders of aware of this.


### Compliance
(13)  If a member of the RMIT community breaches the RMIT Child Safe Code of Conduct, they will face an internal and/or external investigation which may result in any of the disciplinary action listed below. Disciplinary actions may include, but are not limited to:
  1. additional training and support
  2. verbal warning
  3. formal written warning
  4. report to police/Sexual Offences and Child-abuse Investigation Team (SOCIT)/Reportable Conduct Scheme
  5. stood down with pay
  6. stood down without pay
  7. termination of employment/engagement.


(14)  Alleged or actual breaches of the Code will be handled in accordance with the applicable RMIT policy or procedure, enterprise agreement, applicable country law, industrial instrument, or contract. Where an alleged breach is not covered by an RMIT policy document, enterprise agreement, industrial instrument, or contract, RMIT will apply the principles of natural justice when investigating such a complaint.
(15)  In serious cases staff may have their employment and/or affiliation terminated where an allegation is proven.
###  Review
(16)  This policy will be reviewed at least once every five (5) years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
### Understanding and Acceptance
(17)  RMIT University requires all staff to read and acknowledge this Child Safe Code of Conduct prior to commencement of employment.
(18)  All contractors, students and volunteers must read and acknowledge this Child Safe Code of Conduct as part of their onboarding compliance with the University.
(19)  All RMIT staff must complete the mandatory e-learning compliance module - Child Safety at RMIT. This module is completed at the beginning of employment and then every two years thereafter.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=249#document-top)
# Section 5 - Related Procedures and Resources
  1. [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213)
  2. [Child Safe Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=214)
  3. [Child Safe Reporting Procedure (Vietnam)](https://policies.rmit.edu.au/document/view.php?id=217)
  4. Child Safe Statement of Commitment
  5. [Child Safe Reporting Instructions](https://policies.rmit.edu.au/download.php?id=354&version=2&associated)
  6. [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
  7. [Children on Campus and At Work Guideline](https://policies.rmit.edu.au/document/view.php?id=99)
  8. [Inclusion, Diversity and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
