[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=120&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=120&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > COVID-19 Assessment Flexibility Approach 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=120)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=120&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=120&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=120&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=120&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=120&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=120&version=1)


# COVID-19 Assessment Flexibility Approach
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=120&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=120&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=120&version=1#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=120&version=1#section4)
  * [Assessment Flexibility](https://policies.rmit.edu.au/document/view.php?id=120&version=1#major1)
  * [Assessment Policy Waivers/Adjustments and Alternative Assessments](https://policies.rmit.edu.au/document/view.php?id=120&version=1#major2)


This is not a current document. It has been repealed and is no longer in force.
This advice will be updated as required and will remain in effect until otherwise approved by the Academic Registrar.
# Section 1 - Purpose
(1)  This document outlines assessment support measures in place for students impacted by COVID-19 including associated travel restrictions.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=120&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=120&version=1#document-top)
# Section 3 - Scope
(3)  This document applies to RMIT students affected by COVID-19.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=120&version=1#document-top)
# Section 4 - Guideline
### Assessment Flexibility
(4)  Students affected by COVID-19 will be provided with a range of support and flexibility including alternative equivalent assessments (see policy waivers below). Alternative study options are also being progressively provided to impacted students.
Further information is available to students via the [RMIT coronavirus webpages](https://policies.rmit.edu.au/download.php?id=168&version=5&associated).
#### Alternative Study Options
(5)  Where students are unable to study on campus, alternative study options are being made available for both Higher Education and Vocational Education students across each of the Colleges.
Further information is available via the [RMIT coronavirus webpages](https://policies.rmit.edu.au/download.php?id=168&version=5&associated) (see specifically [programs and courses](https://policies.rmit.edu.au/download.php?id=169&version=2&associated)).
#### Special Consideration (Time Extensions)
(6)  Existing rules around assessment extensions have been relaxed for students impacted by COVID-19 (see policy waivers below); this will alleviate pressure on special consideration operations and streamline support processes for those impacted.
(7)  Schools are able to approve assessment extension up to 21 days (previously only 7 days) for students impacted by COVID-19. Extension applications for periods greater than 21 days will require a special consideration application. The special consideration team will consult directly with course coordinators about the assessment flexibility options appropriate/available.
Further information is available via [special consideration](https://policies.rmit.edu.au/download.php?id=170&version=1&associated) (see specifically [extensions of time](https://policies.rmit.edu.au/download.php?id=171&version=1&associated)).
#### Results
(8)  In view of delayed semester start dates to support students impacted by COVID-19, results release dates have needed to be amended. RMIT Vietnam and some of our global partners have been impacted by these changes and are being supported by the Assessment Support and Exams team in Academic Registrar's Group (ARG).
### Assessment Policy Waivers/Adjustments and Alternative Assessments
(9)  On 26 February 2020 the Academic Registrar endorsed interim waivers to specific provisions within various assessment policies and processes in order to provide flexibility to students who have been impacted by COVID-19. 
(10)  A communication will be available on the Policy Register, and within the FAQs on the student facing COVID-19 page, advising that specific policy provisions have been adjusted to assist students impacted by COVID-19. ARG will maintain (with oversight from Internal Audit, Compliance Risk and Regulation (IACRR)) a central register of alternative assessments for regulator assurance.
#### Assessment Policy Waivers/Adjustments Overview 
(11)  The following table provides an overview of policy adjustments necessary to assessment policy provisions as endorsed by the Academic Registrar. It should be noted that:
  1. The policy adjustments described only apply to students affected by COVID-19.
  2. Amendments to assessment tasks will be equivalent and assess the same learning outcomes. 
  3. Start dates and assessment arrangements are likely to be impacted.

Policy/process |  Reference |  Current provision |  Adjustment/waiver |  Rationale  
---|---|---|---|---  
[Program and Course Approval Processes](https://policies.rmit.edu.au/document/view.php?id=40) |  6.18 |  Courses for the first year of coursework programs must offer an early assessment task (formative or summative). |  Relax this requirement in the common core UG and in the enabling courses PG to facilitate a rescheduling (delay) of assessment by two (2) weeks to account for COVID-19 isolation. |  Latest day to start for UG students is Monday March 23rd. Common core subjects have assessment due in weeks three and four (week ending March 27th). Provision to waive requirement on a case by case basis to allow for rescheduling of in-class tests if required.   
6.18.1 |  In the first four weeks of teaching (where the course is offered over a standard 12 to 16 week teaching period).  
6.18.2 |  In the first third of the teaching period (where the course is delivered in intensive mode).  
[Assessment Processes](https://policies.rmit.edu.au/document/view.php?id=38) |  2.2.2 |  Development of examination papers must be carried out in liason with the course management team, normally no later than the expiry of 50% of the teaching period (see note 3 below). |  Relax this requirement by 14 days. |  A two (2) week extension be granted in recognition of other significant work that is ongoing.  
[Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7) |  (36) |  Extensions can be approved for up to one week (seven calendar days) after the due date for an assessment. (Where students need an extension exceeding one week they must instead apply for special consideration.) |  Allow schools to grant extensions for up to 21 days (the normal 7 days plus 14 days for cases involving COVID-19 isolation). See note 4 below. |  With appropriate evidence, this provision will ease the burden on the special considerations team and allow for local level adjustments to be made on a case by case basis.  
(21) |  Changes to assessment tasks after commencement of the teaching period can only be made following consultation with affected students and must be approved by the Dean/Head of School. Any such changes must be reflected in the course guide. |  See note 5 below. |  To speed up approval of adjustments to assessment whilst maintaining quality and transparency.  
#### Notes
1. All waivers for Semester 1, 2020 only and will be reviewed for application in Semester 2, as required.
2. Changes to assessment dates for UG and PG introductory courses are submitted to Director, Programs for review and approval. Decisions are recorded on decisions register.
3. Changes to exam preparation date deadlines are accounted for in the College’s Automated Exam Preparation and Approval process. The process provides an end to end view of exam production key steps including deadlines (as per Assessment Processes) which is auditable. This process relies on central Exam timetabling to be completed and exam header and coversheet process to be available (~ four week ‘gap’ available between final deadline to central exams and mid-semester deadline).
4. Schools to centrally record which extensions are granted as per section 5.2.6 of the Assessment and Assessment Flexibility Policy: “5.2.6. Applications are approved by the responsible staff member in the school as determined by the Dean/Head of School.” Opportunity to impose central digital extension of time process across all schools/courses.
5. Change to assessment during semester (if required) 
  1. Course coordinator identifies need to change assessment; 
  2. Discusses with Program Manager who ensures change doesn't impact program integrity – with support of checklist;
  3. Program Manager endorses and approaches Deputy Dean Learning and Teaching or an Associate Dean of a discipline (DSC only) for approval;
  4. Decision recorded on school-based spreadsheet (standard across schools) and submitted to next available relevant sub-committee meeting of Academic Board for formal noting and inclusion in minutes. Rationale for changed assessment to be entered into a central spreadsheet created and managed by ARG and IACRR to oversee the rationale for amended assessment and its equivalence.


6. Student Progression: non-standard enrolment processes are mature and can be used to support student progression to ensure students have the opportunity to complete. Students and Programs team have well-documented processes in place.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
