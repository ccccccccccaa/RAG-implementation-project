[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=258&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=258&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Staff-Student Personal Relationships Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=258)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=258&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=258&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=258&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=258&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=258&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=258&version=1)


# Staff-Student Personal Relationships Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=258&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=258&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=258&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=258&version=1#section4)
  * [Key concepts](https://policies.rmit.edu.au/document/view.php?id=258&version=1#major1)
  * [Obligations of Staff](https://policies.rmit.edu.au/document/view.php?id=258&version=1#major2)
  * [Other Obligations of Staff](https://policies.rmit.edu.au/document/view.php?id=258&version=1#major3)
  * [Consequences of non-compliance](https://policies.rmit.edu.au/document/view.php?id=258&version=1#major4)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure explains RMIT’s expectations and staff obligations with respect to staff personal relationships with students (including vocational, undergraduate or post-graduate higher education students, and Higher Degree by Research candidates).
(2)  RMIT prioritises the welfare of students and their entitlement to learn and undertake research in a safe and respectful environment. RMIT has legal and ethical obligations to take steps to ensure that all students, regardless of gender, can undertake learning and research without being exposed to risks to their health or safety, and for all students to have equal access to power, resources and opportunities and to be treated with dignity, fairness and respect.
(3)  RMIT acknowledges that:
  1. staff members hold positions of power in relation to students through their status within the University and ability to affect a student’s academic, research and other social outcomes at the University. This power imbalance applies irrespective of the ages of the student or the staff member, though is likely to be greater with younger students, and applies irrespective of the work area of the staff member, though is likely to be greater when the staff member has influence over or contact with staff within the student’s area of study.
  2. if a staff member takes advantage of, or exploits a power imbalance between them and a student, this can cause harm to the student with respect to their psychological and physical health and safety, and that this affects female students disproportionately to other students.
  3. power imbalances are inherent in staff-student relationships, and as a consequence, free consent cannot be assumed on the part of the student. It is the obligation of staff members to maintain and enforce professional boundaries at all times.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=258&version=1#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=258&version=1#document-top)
# Section 3 - Scope
(5)  This procedure applies to all RMIT University Council members, staff, researchers, contractors, volunteers, and visitors (including research fellows) of the RMIT Group both in Australia and overseas. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=258&version=1#document-top)
# Section 4 - Procedure
(6)  RMIT staff are expected to:
  1. act in the best interests of students and not use their position of power and trust to exploit or take advantage of students, whether physically, sexually, emotionally, psychologically, financially or any other way
  2. act with integrity and without bias, to avoid or otherwise manage any conflicts of interest, and ensure that they do not use their positions to unduly benefit themselves or another person.


(7)  All staff members are responsible for setting the tone in the workplace and the teaching, learning and research environment. RMIT seeks to avoid a culture of ‘complicity by silence’ in relation to the serious harm that can result from the exploitation of the power imbalance between students and staff through inappropriate relationships.
### Key concepts
(8)  ‘Position of Authority’ is any position in the University where a person has a relationship with the student where they have oversight, influence, power, management, or leadership over students, whether that role has actual decision-making responsibilities over that student or not. This may include, but is not limited to:
  1. a teacher, lecturer, tutor, educational assistant or other student-facing role in a student’s class, degree, school or college
  2. a person employed in a central RMIT role
  3. a student’s academic or research supervisor
  4. a staff member who holds a leadership position in a University club, union, or society in which the student participates
  5. a professional staff member within a student’s school or college, such as a WIL coordinator.


(9)  ‘Close personal relationships’ are relationships which meaningfully exceed that of a purely professional relationship or acquaintanceship, and include (but are not limited to) any of the following:
  1. former intimate relationships, including de facto partners or spouses
  2. close friendships
  3. family or familial-like relationships, including culturally significant relationships
  4. relationships which involve financial dependency or joint financial interests. 


(10)  ‘Intimate relationships’ are romantic or sexual relationships which are more than close personal relationships.
(11)  ‘Exploitative relationship’ is a relationship in which a person uses their position to exploit another for personal gain or benefit. Forms of exploitation that can occur in the context of a staff-student relationship include:
  1. denying a student access to fair recompense for work (including unpaid research work)
  2. denying a student access to breaks or other entitlements for the staff member’s or University’s gain
  3. exposing a student to unsafe work conditions
  4. requiring the student to carry out tasks outside of the student’s responsibilities, such as performing secretarial duties, domestic labour, childcare, or personal administrative tasks for their supervisor when they are not employed to do so
  5. requiring students to live in a rental property owned by the staff member.


(12)  ‘Coercive controlling relationship’ is one where there is a systematic pattern of behaviour used by one person to dominate and control another person.
  1. Coercive control can involve physical or sexual violence, but it can also include non-physical behaviours, including emotional and psychological abuse, financial abuse, technology-facilitated abuse, stalking and intimidation.
  2. Coercive controlling behaviour can include using a physical body to invade personal space or the removal of physical property, deception, manipulation, isolation, humiliation or gaslighting.


### Obligations of Staff
#### Disclose close personal relationships
(13)  Staff at RMIT are required to disclose any close personal relationships with a student at the point that staff member holds, or is likely to hold in the near future, a position of authority in relation to that student. Staff must make this disclosure in accordance with RMIT’s [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91).
#### Intimate Relationships with students
(14)  Staff must not develop or engage in, or seek to develop or engage in, an intimate relationship with a student while the staff member is, or in the future is likely to be, in a position of authority in relation to that student. To do so would be considered a breach of this procedure and may also be a breach of RMIT’s [Sexual Harm Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218), [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122), [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52) or [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91).
(15)  Should staff be, or have formerly been, in an intimate relationship with someone who is currently a student, they are required to disclose this at the point where a staff member holds a position of authority in relation to that student or is likely to hold it in the near future. Staff must make this disclosure in accordance with RMIT’s [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91).
(16)  Staff must not engage in sexual activity or engage in conduct which might reasonably be perceived to be building towards a sexual relationship, with any person under the age of 18 years of age, including a student. Such conduct is a breach of the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213) and the [Child Safe Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249) and may also amount to criminal conduct and be reported to the Police.
#### Coercive controlling or exploitative relationships
(17)  Staff must not start or develop, or engage in, or attempt to develop or engage in, an exploitative relationship or a coercive controlling relationship with any students. Such conduct is a breach of this policy, and may also be a breach of other policies, including the staff [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), the [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122) and the [Sexual Harm Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218). In certain circumstances it may also amount to criminal conduct and be reported to the Police. 
#### Maintain Professional Relationship
(18)  Staff must ensure that all their interactions and relationships with students are professional and appropriate. Staff who engage in any behaviour which is inconsistent with reasonably understood appropriate professional boundaries between staff and students may be in breach of this procedure, the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122) and other University policies.
(19)  By way of guidance, behaviour which may be inconsistent with the reasonably understood appropriate professional boundaries between staff and students include (but are not limited to) a staff member:
  1. not maintaining an appropriate physical or emotional distance from students
  2. failing to perform University duties in the best interests of RMIT without favour towards any individual student over another student
  3. having one-on-one meetings or interactions with a student other than through University-approved communication channels (e.g. a private chat message platform) instead of having meetings and discussions with students in public venues during operating hours where practicable, such as libraries or cafés
  4. sharing personal contact details, such as their home address, personal phone numbers and personal email addresses where the details are not necessary to support the teaching or supervisory relationship between them; staff should only use their RMIT user profile on official RMIT channels and platforms when communicating with students, such as RMIT email, the learning management system or online communication channels, such as Teams or Webex
  5. contacting students about personal matters which are not related to University conduct or teaching or learning, or in an inappropriate manner, or communications outside of the normal operating hours of the University
  6. seeking personal information from a student which is not relevant to a University process (e.g. medical information for special consideration or as part of academic progress process) or obtaining personal information about a student from University records for purposes unrelated to the staff member’s role
  7. withholding details of a support facility, or failing to refer a student with a need for support to a facility, in order to create a dependency or closer relationship between the staff member and the student
  8. encouraging comments from students that are suggestive, overly flattering, overly personal or otherwise inappropriate
  9. failing to actively remove themselves from a situation where a student attempts to form an intimate relationship with the staff member and where the staff member does not put the student on notice that the conduct must stop.


### Other Obligations of Staff
#### Staff who are also students 
(20)  This procedure applies to staff who are also students. The requirements of this procedure are not lessened or mitigated in any way because either or both parties to the relationship are concurrently both a staff member and a student.
#### Obligation to report suspected breaches of this procedure
(21)  All staff must report a breach of this procedure, or where they have grounds to reasonably consider there has been a breach of this procedure, as soon as practicable after becoming aware of it, to Safer Community and People Connect, or otherwise through RMIT’s anonymous reporting or whistleblower channels.
#### Obligation to report inappropriate student behaviour
(22)  Where a staff member becomes aware that a student has engaged in behaviour which is inappropriate or is inconsistent with the boundaries of a professional relationship with students (such as when a student makes a sexual advance towards a staff member), this behaviour must be reported to the relevant staff member’s Dean or immediate supervisor. Even if the staff member has not reciprocated the advance, or rejected it, it may still give rise to an actual, potential or perceived conflict of interest for the staff member, and it may be appropriate to manage it through the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91).
(23)  Staff can contact Safer Community for advice and support where a student initiates inappropriate behaviour towards them that is inconsistent with professional student-staff relationships as outlined in this procedure.
(24)  Any person can make a disclosure, report or complaint in relation to a student via the [Student Connect](https://policies.rmit.edu.au/download.php?id=130&version=2&associated) portal or the RMIT [Complaints portal](https://policies.rmit.edu.au/download.php?id=121&version=1&associated).
### Consequences of non-compliance
(25)  Breaches of this procedure may amount to staff misconduct which are managed in accordance with the [Managing Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=153). Other policies and procedures may also apply, such as the [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91), the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213), the [Sexual Harm Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218).
(26)  In responding to incidents of non-compliance, RMIT will seek to ensure that students are not unfairly disadvantaged or adversely treated as a result of being in an inappropriate relationship with a staff member or because of making a disclosure or report regarding a possible breach of this procedure.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
