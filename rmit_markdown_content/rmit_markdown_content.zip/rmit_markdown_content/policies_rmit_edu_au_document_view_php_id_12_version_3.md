[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=12&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=12&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Higher Degrees by Research Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=12)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=12&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=12&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=12&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=12&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=12&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=12&version=3)


# Higher Degrees by Research Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=12&version=3#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=12&version=3#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=12&version=3#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=12&version=3#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=12&version=3#major1)
  * [Candidature](https://policies.rmit.edu.au/document/view.php?id=12&version=3#major2)
  * [Complaints and Appeals](https://policies.rmit.edu.au/document/view.php?id=12&version=3#major3)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=12&version=3#major4)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=12&version=3#major5)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=12&version=3#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=12&version=3#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This policy provides a framework for the effective delivery of research training and the management of Higher Degrees by Research (HDR) at RMIT.
(2)  Higher Doctorates are governed by the Higher Doctorate Procedure.
(3)  This policy should be read in conjunction with the RMIT [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28) suite.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=3#document-top)
# Section 2 - Overview
(4)  Candidates admitted for enrolment in a Higher Degree by Research at RMIT undertake a research project under academic supervision with the objectives of:
  1. engaging in critical reflection, synthesis and evaluation
  2. generating original knowledge and producing research for examination
  3. developing demonstrable researcher and professional development capabilities
  4. disseminating the findings of their research in high-quality research outputs. 


(5)  The objectives of this policy are to:
  1. promote high-quality research training experiences and outcomes
  2. identify and define the roles and responsibilities of all parties involved in research training
  3. ensure compliance with national regulation and quality standards.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=3#document-top)
# Section 3 - Scope
(6)  The policy applies to all staff, candidates and supervisors involved with HDR programs in the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=3#document-top)
# Section 4 - Policy
### Principles
(7)  RMIT will offer research training that:
  1. is developed, delivered, examined and awarded in accordance with the [Australian Qualifications Framework](https://policies.rmit.edu.au/download.php?id=18&version=1&associated), [Higher Education Standards Framework](https://policies.rmit.edu.au/directory/summary.php?legislation=44), and the [Australian Code for the Responsible Conduct of Research, 2018](https://policies.rmit.edu.au/directory/summary.php?code=1),
  2. is impact-driven and promotes a research culture of excellence, integrity, respect, cultural safety and professionalism, 
  3. provides high-quality supervision, support and resources to all candidates,
  4. provides candidates with opportunities to undertake professional and researcher development activity to support successful and timely completion,
  5. contributes to the University’s research strategy.


(8)  RMIT is committed to supporting diversity. RMIT recognises, respects, and values the unique contributions of Aboriginal and Torres Strait Islander HDR candidates. 
(9)  HDR candidates may be provided with a global experience through joint supervision and mobility with international partners and via Collaborative Research Training Agreements. In those cases, additional conditions and requirements may apply.
### Candidature
(10)  Procedures and processes related to admission, enrolment, progression and examination will be consistent, fair, and transparent. 
(11)  Admission to an HDR program is conducted in accordance with the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6), the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11) and the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16), which document the minimum criteria for admission and selection of students into programs, and the minimum and maximum candidature duration. 
(12)  Higher Degrees by Research will be conducted in an environment of research activity. 
(13)  The University will provide each candidate with high-quality and dedicated supervision for the duration of their candidature. 
(14)  Supervision of candidates will be conducted in accordance with the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14).
### Complaints and Appeals
(15)  The University will provide fair complaints and appeals processes to address concerns or grievances that may arise during candidature.
  1. Complaints and grievances relating to HDR are managed in accordance with the [Student and Student-Related Complaints Policy](https://policies.rmit.edu.au/document/view.php?id=33).
  2. Complaints about the integrity of research undertaken as part of HDR will be considered according to the RMIT [Research Integrity Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=30)
  3. Candidates are entitled to appeal a decision to terminate their candidature or the outcome of an examination in accordance with the [Assessment, Academic Progress and Appeals Regulations](https://policies.rmit.edu.au/document/view.php?id=190).


### Responsibilities
(16)  Academic Board is responsible for monitoring and overseeing the quality enhancement and review of research training.
(17)  Research Committee is responsible for monitoring and overseeing the HDR quality and performance against University key performance indicators. 
(18)  Graduate Research Committee is responsible for providing academic leadership pursuant to quality enhancement, and the avoidance of conflict of interest and institutional and academic risk in the delivery of research training. The Graduate Research Committee Executive group is responsible for:
  1. reviewing and approving variations to candidature as the nominee of the Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D),
  2. reviewing and ratifying final examination classifications in the case of one or two Fail recommendations being made by examiners on re-examination of an HDR submission,
  3. reviewing exceptional applications for thesis/dissertation embargo, and
  4. approving requests for posthumous submission and examination.


(19)  The ADVC RT&D or nominee, with the support of the School of Graduate Research, is responsible for:
  1. ensuring compliance with relevant legislative and regulatory obligations, including quality assurance and identifying any areas of concern,
  2. managing the HDR policy framework and developing and approving all associated procedures and supporting documents to this policy,
  3. approving variations to candidature, milestone outcomes, and panels of examiners, and
  4. determining examination classifications, and
  5. monitoring the award of Higher Doctorates.


(20)  College Associate Deputy Vice-Chancellor, Research and Innovation (ADVC R&I), or equivalent, are responsible for:
  1. providing strategic leadership to ensure that HDR profile and areas of research in which supervision and scholarship are supported are aligned to University strategy,
  2. approving sanction assessments and other legislative and regulatory obligations (this responsibility can be delegated), 
  3. managing and resolving any quality issues,
  4. convening Research Candidate Progress Committees, and
  5. ensuring resourcing and support for quality assurance is available.


(21)  Deans/Heads of School are responsible for:
  1. delivering research training in line with the [Higher Education Standards Framework](https://policies.rmit.edu.au/directory/summary.php?legislation=44), the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28), the [Inclusion, Diversity and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93), the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97), and any other relevant policies,
  2. ensuring supervision and resources required to complete a Higher Degree by Research are available to and accessible by HDR candidates as per the project’s needs and the [Infrastructure and Asset Security Policy](https://policies.rmit.edu.au/document/view.php?id=77),
  3. providing school-specific orientation and induction to newly enrolled candidates,
  4. monitoring the general progress and welfare of HDR candidates, and approving variations to candidature where appropriate, 
  5. declaring and managing any potential, perceived, or real conflicts of interest with candidates, other members of the supervisory team, or examiners, as per the [Conflict of Interest Declaration and Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90), and 
  6. monitoring compliance with this policy and the quality assurance of programs and supervision, and managing or escalating any issues to the College ADVC R&I or the ADVC RT&D. 


(22)  Supervisors are responsible for:
  1. designing projects that are achievable within the relevant expected program duration,
  2. discharging their responsibilities in accordance with the Supervision Code of Practice,
  3. declaring and managing any potential, perceived, or real conflicts of interest with candidates, other members of the supervisory team, or examiners, as per the [Conflict of Interest Declaration and Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90). 
  4. in collaboration with their candidates, setting expectations and establishing ways of working,
  5. monitoring and supporting the progress and welfare of candidates,
  6. ensuring that the academic and professional development activity undertaken within candidature duration supports candidates’ successful and timely completion, and
  7. guiding candidate conduct in accordance with the [Australian Code for the Responsible Conduct of Research, 2018](https://policies.rmit.edu.au/directory/summary.php?code=1) and supporting opportunities for: 
    1. the production of high-quality research outputs based on their research
    2. professional development, and 
    3. end-user engagement. 


(23)  Candidates are responsible for:
  1. maintaining good academic progress,
  2. completing training in responsible research conduct, health and safety, and other relevant areas, and 
  3. complying with University policies, procedures, including the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), the [Australian Code for the Responsible Conduct of Research, 2018](https://policies.rmit.edu.au/directory/summary.php?code=1), and the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated) and any other regulatory requirements. 


### Review
(24)  The ADVC RT&D is responsible for review of this policy and supporting documents.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=3#document-top)
# Section 5 - Procedures and Resources
(25)  Refer to the following documents which are established in accordance with this Policy:
  1. [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16)
  2. [HDR Progress Management and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=15)
  3. [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14)
  4. [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18)
  5. [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174)
  6. [Higher Doctorate Procedure](https://policies.rmit.edu.au/document/view.php?id=192)
  7. [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated)
  8. [HDR and RTP Scholarships Policy](https://policies.rmit.edu.au/document/view.php?id=22)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=12&version=3#document-top)
# Section 6 - Definitions
Adjudicator | An academic, external to RMIT, appointed to adjudicate on examiners' recommendations.  
---|---  
AHEGS | Australian Higher Education Graduation Statement. All graduates from Australian higher education providers receive an AHEGS.  
ARG | Academic Registrar's Group. ARG's role in relation to Higher Degrees by Research is to support the administrative configuration of programs, to review compliance with academic policy, manage complaints and appeals processes, and to handle the conferral of degrees on behalf of the University.  
Associate supervisor | A member of the supervisory team who contributes in particular areas of disciplinary or methodological expertise. See also HDR supervisor; senior supervisor.  
Candidate | Student enrolled in an HDR degree from the research commencement date until the completion date.  
CASP | Candidate Action and Support Plan. A plan for focused support and monitoring with the goal of returning a candidate to satisfactory academic progress.  
College CASP review | Review by College Graduate Research Committee representative or nominee, to review the action and support provided to a candidate.  
Completion date | The date the candidate submits the final archival version of their HDR submission.  
Confirmation of candidature | The first milestone review which assesses candidate academic progress specifically to determine whether the candidature may transition from probationary candidature to confirmed status. See also milestone review.  
Consumed load | Amount of EFTSL that has been consumed since the research commencement date of a Higher Degree by Research candidate.  
Convenor  | A person appointed to oversee practice-based research examinations and ensure the examination is conducted in accordance with the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and associated procedures.   
Designated Officer | The person performing the role of the Designated Officer as defined in the [Australian Code for the Responsible Conduct of Research, 2018](https://policies.rmit.edu.au/directory/summary.php?code=1). The Delegated Officer for RMIT staff is the Deputy Vice-Chancellor Research and Innovation, and the Delegated Officer for RMIT Higher Degree by Research candidates is the ADVC RT&D or nominee.   
Development activity | Activity, training, internship or work placement which supports the development of HDR candidates as professionals and/or researchers.  
Dissertation | Written component of an HDR submission where other components exist, such as experiential presentation or artefact of the research.  
Domestic candidate | A person enrolled in a Higher Degree by Research who is a citizen or permanent resident of Australia or a citizen of New Zealand.   
EFTSL | Equivalent Full Time Student Load (1 EFTSL = 1 full-time year).  
Examination classification | The result of assessment of an HDR candidate’s submission for examination.   
Experiential presentation | An element of the examination which may include: oral presentation; exhibition; demonstration; performance or similar. The requirement to prepare for such a presentation will be identified in the research project design in accordance with School advice. A digital record of this element must be made available for archival.  
Extension beyond maximum duration of candidature | Time granted to a candidate after their maximum duration of candidature has been reached to allow for HDR submission.   
Final archival | The process by which a candidate lodges the final version of their HDR submission, following successful examination and any required amendments.   
First enrolment date | The date that will make the first enrolment in a course by a candidate for their program. This should be on or before the research commencement date on the candidate’s offer letter. Enrolment prior to commencement may be helpful to establish ‘student’ status for administrative and regulatory purposes. See also research commencement date.  
GRC | Graduate Research Committee. Committee which oversees the development and implementation of HDR policy, quality assurance of HDR programs, and which makes recommendations to Research Committee on matters of quality and strategy relating to graduate research.  
GRC Executive | The Executive group of the Graduate Research Committee, comprising College GRC representatives, and the Associate Deputy Vice-Chancellor Research Training and Development.  
Graduate research internship | A short-term, (3-6 month) research contract undertaken by an HDR candidate with a partner organisation external to the University, under the academic supervision of the candidate’s RMIT supervisory team and an industry supervisor.  
Higher Degrees by Research | A postgraduate degree that will involve a student load comprising of two-thirds or more research and will either be a Master by Research (AQF level 9), or a Doctoral Degree (AQF level 10), or a Higher Doctorate degree.  
HDR Delegated Authority (HDR DA) | Member of academic staff who has the delegated authority of the Dean/Head of School to provide academic leadership and support for Higher Degrees by Research programs. Schools allocate different titles for HDR DA's, such as Associate Deans/Heads Higher Degrees by Research, HDR Directors, HDR Coordinators.  
HDR Sanctions and Defence Trade Controls assessment | Process used to identify whether the proposed research of an applicant for HDR admission, or the current research of a candidate, is subject to sanctions arising from the [Autonomous Sanctions Act 2011](https://policies.rmit.edu.au/directory/summary.php?legislation=29) or the [Charter of the United Nations Act 1945](https://policies.rmit.edu.au/directory/summary.php?legislation=31) or controls under the [Defence Trade Controls Act 2012](https://policies.rmit.edu.au/directory/summary.php?legislation=23).  
HDR submission | The candidate’s submission for examination which comprises a thesis or dissertation and may also include published research outputs, artefacts or experiential presentations of the research conducted during candidature.  
HDR supervisor | An appropriately experienced and qualified individual responsible for advising and guiding a candidate on the conduct of their research. See also associate supervisor; senior supervisor; joint senior supervisor.  
HDR supervisor register | A register that will contain a list of HDR supervisors eligbile to undertake HDR supervision at RMIT.   
International candidate | A person enrolled in a Higher Degree by Research who is not a citizen or permanent resident of Australia or a citizen of New Zealand.   
Joint senior supervisor | A member of an HDR supervisory team who will jointly supervise an HDR candidate and may be from an external organisation.   
Milestone review | A formal event to review the academic progress of an HDR candidate; see also confirmation of candidature.  
Moderator | An RMIT academic staff member (HDR DA or nominee) who is appointed to review examination reports and recommended grades for a Master by Research when the examiners’ grades differ by more than 15 percentage points.  
Normal location of study | The place where an enrolled candidate will undertake the bulk of their study and research towards their degree.  
Offshore candidate | A candidate who is located outside of Australia for the majority of their candidature whether domestic or international.   
RCPC | Research Candidate Progress Committee. The committee which reviews unsatisfactory academic progress of a candidate and determines whether a candidature should be terminated.   
Research artefact | A component of a candidate’s research submitted for examination that is not the written component.   
Research commencement date | The date appearing on the candidate’s offer letter from which duration of HDR candidature is calculated. See also first enrolment date.  
Research output | Public dissemination of research outcomes in the form of a book, book chapter, commissioned report, conference paper, creative work, journal article, patent, or performance, or other form appropriate to the discipline or field.  
Research project | In relation to HDR candidates, the work planned to fulfil the requirements of the degree.  
Research Training Program (RTP) | The Australian Federal Government block grant provided to Australian higher education providers (universities) to support the research training of domestic and international HDR candidates.  
Research Training Services (RTS) | A team in the School of Graduate Research (SGR) who supports the administration of HDR candidates.   
Scholarship | A financial allowance or benefit (to help with living expenses and/or a tuition fee) provided to a student to support their study. See also Stipend.  
Senior supervisor | A member of the HDR supervisory team who provides overall academic leadership to the candidate on their research project. See also Associate supervisor.  
SGR | School of Graduate Research. The unit within the Research & Innovation Portfolio which provides support for strategic development in research training and manages the policy, procedures, and business processes associated with research training at RMIT.  
Stipend | A financial allowance paid directly to the candidate to support living costs while enrolled in their program of study. See also Scholarship.  
Study away | A period of time when an enrolled candidate is undertaking research and study away from their normal location of study, for example, conference attendance or fieldwork.   
Study load | Study load denotes the time fraction allocated to a candidate’s study and is either 'full-time' or 'part-time'.  
Submitted status | The enrolment status of a candidate who has submitted their research for examination.  
Termination of candidature | Cancellation of the enrolment of a candidate in their HDR program; a result of unacceptable lack of academic progress.  
Thesis | Independent written work submitted for examination.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
