[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=161#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=161#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Source Data Extract Controls Standard 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=161)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=161)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=161)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=161)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=161)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=161)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=161)


# Source Data Extract Controls Standard
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=161#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=161#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=161#section3)
  * [Section 4 - Standard](https://policies.rmit.edu.au/document/view.php?id=161#section4)
  * [Introduction](https://policies.rmit.edu.au/document/view.php?id=161#major1)
  * [Data Extraction Standards](https://policies.rmit.edu.au/document/view.php?id=161#major2)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This document provides requirements on how data is to be extracted from an operational source system. It outlines the need for data to be taken from the system without adjustment and outlines the controls that need to be in place to ensure down-stream data is replicated correctly, in a timely manner, and remains synchronised with the master source.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=161#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=161#document-top)
# Section 3 - Scope
(3)  This standard applies:
  1. to all staff requesting or providing data from source systems
  2. regardless of the integration style used, such as batch files or APIs.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=161#document-top)
# Section 4 - Standard
### Introduction
(4)  RMIT has many systems capturing and generating a significant amount of data. This data is often needed by systems or processes across the organisation and externally, outside of the system from which it originates.
(5)  Requests for the data have created numerous extracts from the sources systems, most bespoke to meet the consumers’ needs. This leads to significant processing load, as well as entanglement of systems, inhibiting updates of both producers and consumers.
(6)  This set of standards and guidelines for source system owners intends to point towards providing a reduced, base set of ‘raw’ data extracts, allowing focus on the original primary intent of the system.
### Data Extraction Standards
#### Data Extract Set
(7)  Data extract set design must:
  1. be based on the source system’s data structure, not a consumer’s data requirements (accurate);
  2. ensure all of the system’s business data is included (complete);
  3. ensure there are no overlaps between extracts (efficient); and
  4. not extract data that did not originate in the system (original).


#### Data Extract
(8)  Data extract design must:
  1. be based on the source system’s data structure, not a consumer’s data requirements (accurate);
  2. include all data that naturally fits in the extract at hand, and does not omit data if it adds value (complete);
  3. include all records (unfiltered); and
  4. be natural, not enriched using business rules foreign to the system (not enriched).


#### Data Movement Controls
(9)  All batch data extracts must have the following data movement controls:
  1. extraction process end date-time
  2. data batch record count
  3. file checksum
  4. data batch sequence number or business scheduled date
  5. source system unique identifier
  6. data set time zone identifier.


(10)  Delta batch data extracts must also have the following data movement controls:
  1. delta batch data point start date-time
  2. delta batch data point end date-time.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
