[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=256&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=256&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Supervision Arrangements Schedule 3 - Supervisor Professional Development 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=256)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=256&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=256&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=256&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=256&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=256&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=256&version=1)


# HDR Supervision Arrangements Schedule 3 - Supervisor Professional Development
Hide Navigation
This is not a current document. To view the current version, click the link in the document's navigation bar.
### HDR Supervision Arrangements Schedule 3 - Supervisor Professional Development 
(1)  Authority for this document is established by the [HDR Supervision Arrangements Procedure](https://policies.rmit.edu.au/document/view.php?id=14). The requirements listed in this schedule are specific to maintaining eligibility as an HDR supervisor. Professional development requirements apply to internal supervisors only. Academic staff will have additional professional development requirements not listed here (e.g. research integrity and reconciliation capability). Refer to Workday Learning for registration and further information.
Offering | Description | Mode | Requirement | Timeframe  
---|---|---|---|---  
#### HDR Supervisor Registration module
| An overview of the RMIT HDR policy suite. | Self-directed e-module | Required for all internal supervisors. | To be completed when applying for supervisor registration. The e-module must be completed biennially.  
#### Respectful Research Training – module
| A culture-change program aimed at achieving a mutually respectful and safe research training environment | Self-directed e-module | Required for all internal supervisors | To be completed when applying for supervisor registration  
#### HDR Supervisor Induction
| An intensive introduction to supervision and research training at RMIT | Seminar/webinar | Required for all internal supervisors | Within 3 months of supervisor registration  
#### Respectful Research Training – webinar
| A culture-change program aimed at achieving a mutually respectful and safe research training environment | Seminar/webinar | Required for all internal supervisors | Within 3 months of supervisor registration  
#### Introduction to HDR supervision
| An introduction to good supervisory practice and candidature management. | Moderated online short course | Required for all internal supervisors Exemptions apply for supervisors with more than three completions as senior supervisor | Within 6 months of supervisor registration  
#### HDR Supervisor seminars
| A range of collegial seminars and other activities designed to extend networks and promote good practice in supervision and research education | Seminar/webinar delivered by the School of Graduate Research | Required for all internal supervisors | Once annually  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
