[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=122#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=122#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Workplace Behaviour Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=122)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=122)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=122)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=122)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=122)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=122)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=122)


# Workplace Behaviour Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=122#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=122#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=122#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=122#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=122#major1)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=122#major2)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=122#major3)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=122#major4)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=122#section5)
  * [Section 6 - Procedures and Standard](https://policies.rmit.edu.au/document/view.php?id=122#section6)
  * [Section 7 - Related Policies](https://policies.rmit.edu.au/document/view.php?id=122#section7)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The purpose of this policy is to:
  1. describe the behaviours that are unacceptable, may be unlawful, and will not be tolerated under any circumstances at RMIT
  2. explain staff obligations in relation to professional and respectful behaviour when interacting with others in a workplace context, and
  3. support the maintenance of academic freedom as a principal value of the RMIT, through the description of expectations consistent with the collegial and community nature of a university.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122#document-top)
# Section 2 - Overview
(2)  RMIT sets standards of behaviour for its staff and associates based on the law, as well as its organisational values. RMIT staff and associates are expected to behave in a way that is consistent with the standards set out in this policy.
(3)  Behaviour that is inconsistent with these expectations is unacceptable and may also be unlawful. Behaviour may breach this policy even if there is no intention to do so. 
(4)  The policy and associated procedure also address how RMIT supports affected parties who experience unacceptable or unlawful behaviour in the workplace.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122#document-top)
# Section 3 - Scope
(5)  This policy applies to the RMIT Group, which is RMIT University and its controlled entities (RMIT Europe, RMIT Online, RMIT University Pathways (RMIT UP), RMIT Vietnam).
(6)  This policy applies to RMIT University Council members, Council committee members, controlled entity board members, employees (including employees who are also students), researchers, contractors and volunteers of the RMIT Groups, both in Australia and overseas, subject to any relevant legislation (collectively referred to in this policy as staff). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122#document-top)
# Section 4 - Policy
### Principles
(7)  RMIT is committed to creating a culture where all people can participate in a workplace free from harassment (including sexual harassment), discrimination, bullying, victimisation, fraud, corruption and theft. Behaviour of this kind is unacceptable and may be unlawful.
(8)  RMIT is committed to encouraging positive values-based behaviour. RMIT will not tolerate unacceptable or unlawful behaviour by staff, or directed at staff, or behaviour that undermines the right of all people to feel safe, respected and valued.
(9)  Standards and expectations of professional and respectful workplace behaviour, as outlined in the [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52) and Workplace Behaviour Standard, apply to all interactions between staff, students and third parties where there is a connection with the workplace.
(10)  RMIT recognises the existence of a connection with the workplace where the behaviour has some link to the workplace. This includes:
  1. when staff are in the workplace physically (face to face) or operating in the online work environment
  2. when staff are performing work even though not physically in the workplace
  3. when staff are attending functions, workshops or events related to work
  4. outside of work behaviour if the behaviour can negatively impact on RMIT or its reputation
  5. where the conduct occurs outside of work but creates issues within the workplace (for example, stalking an employee or student outside of work).


(11)  Maintenance of academic freedom is a principal value of RMIT.
  1. The provisions in this [Workplace Behaviour Policy](https://policies.rmit.edu.au/document/view.php?id=122) do not seek to limit academic freedom but clarify behavioural expectations consistent with the collegial and community nature of a university which is itself the foundation of academic freedom.
  2. Conduct permitted under the [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56) does not constitute a breach of this policy.


(12)  RMIT promptly addresses concerns, complaints or reports about unacceptable workplace behaviour by applying any relevant enterprise agreement, policies, and the procedures under this policy as appropriate.
(13)  RMIT Vietnam addresses concerns, complaints or reports about unacceptable workplace behaviour by applying its Internal Labour Rules and any other applicable procedures under this policy or other relevant RMIT policies. 
### Compliance
(14)  Behaviour which breaches this policy will be treated as misconduct or serious misconduct.
(15)  Staff who breach this policy may be subject to disciplinary action, including summary termination of employment. Staff who engage in unlawful behaviour may also be subject to criminal or civil liability. For RMIT Vietnam, a breach of this policy by any employee may result in disciplinary action being taken against them as detailed in the Internal Labour Rules.
### Responsibilities
(16)  All staff who work for, or with, the RMIT Groups:
  1. must be aware of their obligations under this policy
  2. must ensure their behaviour complies with this policy
  3. should identify and report unacceptable workplace behaviour to a manager or other senior staff member, a member of the People team, or through other designated complaints or disclosure avenues including the RMIT [Complaints Portal](https://policies.rmit.edu.au/download.php?id=121&version=1&associated).


(17)  RMIT managers are responsible for taking prompt action if suspected or actual breaches of this policy occur and have a duty of care to implement corrective actions, where necessary. Some non-exhaustive examples of disciplinary and non-disciplinary actions are set out in [Schedule 1](https://policies.rmit.edu.au/download.php?id=175&version=2&associated) to the [Managing Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=153). 
(18)  The Chief People Officer is responsible for ensuring:
  1. the effective implementation of this policy, including the provision of training and awareness-raising on appropriate workplace behaviour and managing misconduct
  2. compliance monitoring and reporting to governance bodies
  3. continuous improvement processes exist for managing misconduct
  4. ensuring the appropriate delegated authority is exercised when determining an outcome of a staff misconduct investigation.


### Review
(19)  This policy will be reviewed every five years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122#document-top)
# Section 5 - Schedules
(20)  [Schedule 1](https://policies.rmit.edu.au/download.php?id=175&version=2&associated) – Unacceptable Workplace Behaviour provides some non-exhaustive examples of sexual harassment, discrimination, victimisation, behaviours that (if repeated) may constitute bullying and other forms of unacceptable workplace behaviour under this policy which may be updated by the Chief People Officer from time to time.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122#document-top)
# Section 6 - Procedures and Standard
(21)  Refer to the following documents which are established in accordance with this policy:
  1. [Workplace Behaviour Standard](https://policies.rmit.edu.au/document/view.php?id=324)
  2. [Managing Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=153)
  3. [Staff Complaints Procedure](https://policies.rmit.edu.au/document/view.php?id=156).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=122#document-top)
# Section 7 - Related Policies
(22)  Staff should also refer to the following related policy documents:
  1. [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56)
  2. [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52)
  3. [Staff-Student Personal Relationships Procedure](https://policies.rmit.edu.au/document/view.php?id=258)
  4. [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213)
  5. [Health Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97)
  6. [Gender-Based Violence Prevention and Response Policy](https://policies.rmit.edu.au/document/view.php?id=218)
  7. [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91)
  8. [Anti-Corruption and Fraud Prevention Policy](https://policies.rmit.edu.au/document/view.php?id=47)
  9. [Information Technology - Acceptable Use Standard](https://policies.rmit.edu.au/document/view.php?id=76)
  10. [Managing Conduct Procedure](https://policies.rmit.edu.au/document/view.php?id=153)
  11. [Inclusion, Diversity and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93)
  12. Internal Labour Regulations (Vietnam).


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
