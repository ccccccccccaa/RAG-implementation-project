[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=173#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=173#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Safety Measures Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=173)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=173)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=173)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=173)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=173)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=173)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=173)


# Student Safety Measures Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=173#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=173#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=173#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=173#section4)
  * [Identifying behaviours representing grounds for concern](https://policies.rmit.edu.au/document/view.php?id=173#major1)
  * [Behaviours covered by other procedures](https://policies.rmit.edu.au/document/view.php?id=173#major2)
  * [Reporting and Initial Action](https://policies.rmit.edu.au/document/view.php?id=173#major3)
  * [Student Safety Case Management](https://policies.rmit.edu.au/document/view.php?id=173#major4)
  * [Reports to the Police](https://policies.rmit.edu.au/document/view.php?id=173#major5)
  * [Safety Measures and Directions](https://policies.rmit.edu.au/document/view.php?id=173#major6)
  * [Safety Directions](https://policies.rmit.edu.au/document/view.php?id=173#major7)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=173#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  The purpose of this procedure is to identify and support students whose actions or behaviour may present a risk to the health and safety of themselves, other students, staff, or other members of the public or the broader RMIT community, as well as the safety or property functioning of RMIT facilities or property. It provides a framework for the effective, safe, consistent, and timely identification and management of fitness-for-study concerns and protects the student, staff, other students, placement providers and the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=173#document-top)
# Section 2 - Authority
(2)  Authority for this procedure is established by the [Health Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=173#document-top)
# Section 3 - Scope
(3)  This procedure applies to all students within the RMIT Group, including:
  1. students on approved leave of absence and students who have allowed their enrolment to lapse
  2. students studying through Open Universities Australia (OUA) or other third-party providers of RMIT courses and programs
  3. students studying RMIT programs at global partner institutions
  4. higher degree by research students, including those who have submitted work for examination
  5. graduands or past students
  6. students who are undertaking placement or work integrated learning activities with a partner organisation, and
  7. students in single courses, short courses, or non-accredited courses, and students studying online or face-to-face.


(4)  This procedure applies to students who are also staff of RMIT.
(5)  Where a person who is the subject of a safety review under this procedure is a student as well as an RMIT staff member, their fitness for work may also be considered under the relevant staff policy or procedure.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=173#document-top)
# Section 4 - Procedure
### Identifying behaviours representing grounds for concern
(6)  RMIT is required to take reasonably practical steps to reduce or eliminate risk where it becomes aware that a student’s behaviour or a student’s circumstances give rise to a likelihood of physical or psychological harm to themselves or to another student, staff or a member of RMIT’s broader community, or the public. Examples of behaviours or circumstances that might require RMIT to take action to reduce or eliminate risk include:
  1. reported behaviour or circumstances involving risk of harm that is likely to occur or recur, or where multiple reports involving risk of harm or actual harm have been received about the same student.
  2. behaviour or circumstances that may give rise to a risk to the student’s own health, safety or wellbeing.
  3. behaviour or circumstances that may give rise to a risk to other students or staff, or other members of the RMIT community, such as placement providers, or the public.
  4. behaviour or circumstances that may give rise to harm to or damage of property, facilities, resources, assets or infrastructure.


### Behaviours covered by other procedures
(7)  Certain behaviours may be more appropriately managed through the Student Conduct Framework or under a combination of RMIT policies. Such behaviours may include:
  1. gender-based harm
  2. child safety concerns
  3. violence or aggression towards people or property
  4. deliberate disregard of safety procedures in practical learning or research spaces
  5. non-compliance with directions provided by a Senior Officer, or actions or behaviour which may constitute high risk misconduct under the Student Conduct Framework
  6. behaviours that may have criminal implications or in relation to which the Police are involved.


(8)  Where the behaviour of a student is within the application of this procedure as well as the Student Conduct Framework, the Executive Director, Health, Safety and Risk and/or Senior Manager Safer Community (Senior Manager) and the Academic Registrar will consult and determine how each procedure will apply, including if both procedures will apply, or if one procedure will take precedence or be applied first, based on the on-going risk that may need to be managed, as well any other relevant circumstances. 
### Reporting and Initial Action
(9)  Where there is an emergency or an immediate risk of harm, staff should seek urgent assistance via:
  1. emergency services and RMIT Security, for RMIT Australia. RMIT Security will assist in coordinating the personal safety of staff and students, responding to property damage or theft, notifying Police and may make a referral to a Critical Incident Management Team.
  2. the relevant local authority, for offshore campuses and partners.


(10)  RMIT staff, students, supervisors or other members of the University community, with the exception of staff in Counselling and Psychological Services, who consider that a student’s behaviour or circumstances represents grounds for concern about risk to their or others’ safety must make a report to:
  1. the Health, Safety and Risk team via [SafetyNow](https://policies.rmit.edu.au/download.php?id=464&version=1&associated) which may be reported on a confidential basis, or
  2. directly to Safer Community.


(11)  The responding person or team will triage the response and take other initial steps including:
  1. notifying the Executive Director, Health, Safety and Risk and the relevant Senior Officer under the Student Conduct Framework
  2. coordinating timely and adequate support to the student and any other students or staff impacted
  3. conducting a risk assessment to determine the level or type of investigation or action required, which may include: 
    1. a Health, Safety and Risk (HSR) investigation
    2. a Sexual Assault or Sexual Harm (SASH) investigation
    3. a referral to a Senior Officer or Student Conduct Board
    4. a recommendation to the Academic Registrar that an Executive Suspension be implemented
  4. initiating the case management process
  5. determining whether it is safe for the student to continue to have access to RMIT campus, facilities or other online systems, or safely engage with RMIT activities, while investigations or other risk management steps are being undertaken.
  6. determining whether a Critical Incident Management Team notification needs to be made in consultation with the Executive Director, Health, Safety and Risk.


### Student Safety Case Management
(12)  The objective of case management is to support the student in their pathway back to health or to a safe situation, ultimately in order to continue their study or research in a manner that is safe, for them and those who interact with them.
(13)  Cases managed under this procedure will be coordinated by a suitably qualified staff member, nominated by the Executive Director, Health, Safety and Risk. The case manager will lead a team that may include:
  1. representative from Safer Community 
  2. student wellbeing specialist from the Students Group
  3. representatives fromAcademic Registrar's Group
  4. staff wellbeing specialist from the Staff Wellbeing team
  5. People Business Partner for the relevant School or RMIT entity
  6. Senior Officer from the relevant School or entity.


(14)  Depending on the circumstances of the student, the team may also include representatives from:
  1. School of Graduate Research (for HDR students)
  2. Child Safety advisor where the matter involves a person who is under 18 years of age
  3. Ngarara Willim Centre (for Aboriginal and Torres Strait Islander students)
  4. any other team which may be appropriate for the purposes of scoping and managing the relevant risks.


(15)  Once a case manager has been appointed to the case the case manager must:
  1. at the earliest appropriate opportunity discuss or communicate the concern with the relevant student. The student may wish to have a support person attend with them.
  2. consider the student’s perception and understanding of their behaviour or circumstances, and the response of the student to any steps taken by the University to manage the situation.
  3. identify short term or immediate supports or adjustments that may be provided to the student in order to address the relevant risks. 
  4. identify any short term or immediate support or adjustments required for staff or other students
  5. notify the key stakeholders as required, which may include: 
    1. [Equitable Learning Services](https://policies.rmit.edu.au/download.php?id=52&version=2&associated)
    2. Director Research Training Services, School of Graduate Research
    3. Academic Registrar's Group
    4. Security
    5. Relevant People Business Partners


(16)  The case manager will work with the student to develop an action and support plan that will set out the steps required of both the student and RMIT in relation to any return to study or research by the student (if required).
### Reports to the Police
(17)  In an emergency situation where the safety of the student or others is at immediate risk, RMIT Security can alert the Police directly.
(18)  If a person who has experienced harm wants to make a report to the Police, Safer Community can support a person to make a police report but RMIT cannot make a police report on that person’s behalf.
(19)  In certain circumstances, RMIT may have a duty to make a report to the Police, in its own name. This includes where the incident involves a risk to students, or staff; or where the person who is the subject of the disclosure or report to presents a risk to themselves.
  1. RMIT may have this obligation to notify the Police even if the discloser or person making a report to RMIT does not want to make their own report to the Police.
  2. A notification to the Police by RMIT in its own name must be approved by the COO or the Academic Registrar where the person who is the subject of the report is a student. When deciding to make a report to the Police, RMIT will take into account: 
    1. the nature of the evidence of the risk to RMIT staff or students, to the broader RMIT community, or the public, or to RMIT property or facilities (eg original or direct evidence, or reported or second hand evidence)
    2. multiple disclosures, reports, concerns or complaints about the same student
    3. advice from any Critical Incident Management Team, and other relevant subject matter expert groups including Policy and Workplace Relations, Risk, Compliance and the Academic Registrar's Group
    4. advice from Safer Community
    5. the wishes of the person who has experienced the harm or who made the disclosure or report initially.


(20)  Safer Community will advise the person who has disclosed or reported the harm about RMIT’s decision to notify the Police and (to the extent possible) will keep the person informed of any actions that result from that notification.
#### Health, Safety and Risk(HSR) Investigation
(21)  RMIT may conduct a Health, Safety and Risk(HSR) investigation to better understand the relevant risks associated with and causes of a student’s behaviour or circumstances, and to assist in developing recommendations for appropriate actions in response to those risks (HSW Investigation). 
(22)  A HSR Investigation may utilise whatever methodology is considered most appropriate in the circumstances. As an example, an ICAM (Incident Cause Analysis Method) investigation may be used to identify causative factors, or failures within organisations, systems or communications and to provide recommendations directed at preventing recurrence. 
(23)  The HSR Investigation should include a consideration of the specific student behaviours or circumstances, the risk and the impact or potential impact on the physical or psychological safety of the student, other students, staff, the broader RMIT community, and RMIT’s property and facilities.
(24)  The HSR Investigation should include recommendations arising from its conclusions. Recommendations may include suggested actions at both an individual and an organisational level. Recommendations could include but are not limited to:
  1. requiring an external threat assessment to inform risk management actions for cases involving complex mental illness and behaviours which pose risk to psychological or physical safety of the student themselves or others
  2. commencing a referral under the Student Conduct Framework for potential misconduct
  3. making a recommendation to the Academic Registrar that an executive suspension be implemented under sections 23-32 of the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180)
  4. taking steps to prepare and make a report to Police
  5. making a recommendation to the Academic Registrar that adjustments are required to a student’s enrolment including applying for a leave of absence on the student’s behalf, with their consent
  6. making a recommendation to the Academic Registrar that the student’s enrolment be cancelled under the [Enrolment Procedure Discontinuation of Student Program](https://policies.rmit.edu.au/document/view.php?id=116) on the basis that their continued enrolment gives rise to a serious concern or risk in relation to the health, safety or wellbeing of any members of the RMIT Community
  7. making a recommendation to the Executive Director, Health, Safety and Risk to issue safety Directions with respect to the student, under clause 29 below. 


### Safety Measures and Directions
#### Interim Safety Measures
(25)  The Senior Manager Safer Community may approve certain measures either on their own initiative, or in response to a report of potential or actual harm to a student, staff member of member of the public to mitigate or eliminate risks to their health and safety, as far as reasonably practical (Interim Safety Measures). Interim Safety Measures are measures which may alter, but not obstruct, a student’s engagement in education at RMIT University, on a temporary basis, where reasonably required to protect the health and safety of students, staff, and members of the public and/or RMIT Community. The case manager will consult with the relevant school and program stakeholder areas of RMIT in implementing appropriate precautionary safety measures. Additionally, the case manager may consult with other relevant stakeholders including:
  1. [Equitable Learning Services](https://policies.rmit.edu.au/download.php?id=52&version=2&associated)
  2. Director Research Training Services, School of Graduate Research
  3. Academic Registrar's Group
  4. Security
  5. Relevant People Business Partners


(26)  Interim Safety Measures that can be implemented include but are not limited to:
  1. changes to class timetables or tutorial allocation 
  2. temporary remote learning arrangements, such as requiring a student to learn online in one or more classes for a period of time
  3. a temporary redirection, block or monitoring of emails, to be reviewed internally every 10 business days from the date the measure is implemented
  4. directing that a Behaviour Support Plan (BSP) be put in place in relation to a student, including their participation in study, research, or other RMIT-related activities
  5. no contact directives, such as directing a student not to approach, engage with, make contact or communicate with certain other members of the RMIT Community
  6. a restriction to the mode of contact with RMIT by the student
  7. a recommendation regarding a further direction by the Executive Director, Health, Safety and Risk or Executive Suspension in accordance with the Student Conduct Framework.


(27)  Where a student is subject to an Interim Safety Measure, they must receive a written copy of the Interim Safety Measure in plain, accessible language, including a description of why the Senior Manager, Safer Community has implemented the Interim Safety Measures.
### Safety Directions
(28)  The Executive Director, Health, Safety and Risk may at any time issue safety directions to, or in relation to, a student in circumstances where they are satisfied that the Directions are reasonably necessary for the health, safety and wellbeing of the student themselves, other students, staff, RMIT property, or members of the broader RMIT community, the public, or RMIT property or facilities (a Direction). The Executive Director will consult with the relevant school and program stakeholder areas of RMIT in implementing appropriate precautionary safety measures. Additionally, the Executive Director may consult with other relevant stakeholders including:
  1. [Equitable Learning Services](https://policies.rmit.edu.au/download.php?id=52&version=2&associated)
  2. Director Research Training Services, School of Graduate Research
  3. Academic Registrar's Group
  4. Security
  5. Relevant People Business Partners.


(29)  The Directions may include, but are not limited to:
  1. the measures outlined in section 26 of this procedure
  2. directing that a student be required to provide medical evidence from a suitably qualified specialist to determine their capacity or fitness to study, engage in research, or participate in other RMIT-related activities, including placements or attendance at campus or otherwise having access to any RMIT facilities, without relevant risk to themselves, other students, staff, or any other members of the RMIT community
  3. directing a student to attend an Independent Medical Examination (IME) to determine their capacity or fitness to study, engage in research, or participate in other RMIT-related activities, including placements or attendance at campus or otherwise having access to any RMIT facilities, without relevant risk to themselves, other students, staff, or any other members of the RMIT community
  4. directing a student not to attend campus for a period of time, or withdrawing a student’s implied licence to be present on all or any part of RMIT property, or otherwise using or having access to any of RMIT’s facilities, including online systems for: 
    1. a period of initially no more than 14 days
    2. a further period of 14 days where required, such as to complete a HSR Investigation and/or refer the matter to another process under an RMIT policy, regulation or procedure to be dealt with
    3. a further period, to a maximum of one compulsory semester or nominated teaching period, where required for another relevant RMIT or external process relating to the student’s conduct or behaviours to be concluded, such as a student conduct process or an Executive Suspension to be considered under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).


(30)  The Directions must be proportionate to the identified risks to health, safety and wellbeing of any persons and to RMIT property and must have regard to:
  1. the outcomes and any recommendations of a HSR Investigation, where one has been undertaken
  2. the rights of the student under the [Charter of Human Rights and Responsibilities (Vic)](https://www.humanrights.vic.gov.au/legal-and-policy/victorias-human-rights-laws/the-charter/) and to engage in their education
  3. the rights of the other students to engage in education, learning, research and work in a manner that is safe and without risks to health, safety and wellbeing, including physical and psychosocial health and safety
  4. the rights of staff to have a work environment that is safe and without risks to health, safety and wellbeing, including physical and psychosocial health and safety
  5. any other relevant RMIT policies and procedures.


(31)  Where a student is subject to a Direction, they must receive a written copy of the Directions in plain, accessible language, including a description of why the Executive Director, Health, Safety and Risk has made the Directions, the information considered in making the Directions and the avenues for appeal under this procedure below.
(32)  Where a student is subject to a Direction, the case manager will work with the student to develop an action and support plan that will set out the steps required of both the student and RMIT in relation to any return to study or research by the student (if required). 
(33)  Where the student identifies additional information after the Directions have been made which was not considered by the Executive Director, Health, Safety and Risk, and which may be relevant to the Directions, the student may provide the information in writing to the Executive Director (Further Information Application). Once the Further Information Application is received, the Executive Director must consider that information and either: 
  1. confirm their original decision and applicable Directions
  2. vary the original decision and apply different Directions, or
  3. revoke the original decision and applicable Directions.


(34)  The student must receive the outcome of the Further Information Application within 7 working days of providing it to the Director.
(35)  The Executive Director, Health, Safety and Risk may determine that a student’s conduct, behaviour or circumstances present a serious concern or risk in relation to the health, safety or wellbeing of the student, other students, staff, RMIT property, or the broader RMIT Community, and refer the matter to the Academic Registrar to consider and make a decision in relation to the cancellation of the student’s enrolment under the [Enrolment Procedure Discontinuation of Student Program](https://policies.rmit.edu.au/document/view.php?id=116).
(36)  The Executive Director, Health, Safety and Risk may at any time issue safety directions to, or in relation to, a person who is not a member of the RMIT Community in circumstances where they are satisfied that the Directions are reasonably necessary for the health, safety and wellbeing of the person themselves, RMIT students, staff, RMIT property, members of the public or broader RMIT community, or RMIT property or facilities (a Direction).
#### Appeal Process
(37)  Only a student who has been the subject of an Interim Safety Measures or a Direction under this procedure (the Decision) may apply to appeal the Decision (the Appeal).
(38)  The grounds on which a student may seek to appeal the Decision are limited to one or more of the following (the Appeal Criteria):
  1. that the Decision was made based on unreasonable bias
  2. that there has been a breach of RMIT legislation, regulation, policy or procedure in the course of the Decision, which has substantially affected or been determinative of the outcome of the Decision
  3. that the measures applied through the Decision are unreasonable, excessive, or inappropriate
  4. that there is new supporting material or evidence that would have substantially affected the measures applied through the Decision if the material or evidence had been available to the Senior Manager Safer Community or Executive Director, Health, Safety and Risk at the time the Decision was made.


(39)  The Appeal application must be provided in the following form: 
  1. applications must be in writing and address the relevant Appeal Criteria
  2. applications must include the evidence on which the student relies to support the Appeal Criteria
  3. applications must be lodged within 10 working days from the date the Director provides notification of the Interim Safety Measures or Directions.


(40)  The Interim Safety Measures or Directions will remain in place while the application to appeal is being assessed.
(41)  The Chief Operating Officer (COO), in consultation with the Academic Registrar, will assess the Appeal against the Appeal Criteria. Where none of the Appeal Criteria have been reasonably proven, no further decision may be made by the COO and the Appeal will be rejected.
(42)  If the COO is satisfied that one or more of the Appeal Criteria has been reasonably proven, having regard to the Interim Safety Measures or Directions as a whole, the COO may determine to:
  1. confirm the Decision and the Interim Safety Measures or Directions
  2. determine that there was an error in the Decision and remit the Decision to the Executive Director, Health, Safety and Risk for reconsideration and determination
  3. vary the Decision and the Interim Safety Measures or Directions, or
  4. set aside the Decision and void the Interim Safety Measures or Directions. 


(43)  The COO must provide their decision with respect to the Appeal within 10 working days of having received the Appeal application. The applicant student will be provided with written reasons for the determination and, where the Appeal has not been successful, advised of their right to seek external review of the COO's decision by the [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=2&associated).
#### Records, Privacy and Confidentiality
(44)  All persons involved in Student Safety Measure matters initiated under the [Health Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97) and corresponding procedures must maintain confidentiality in order to ensure the integrity of the proceedings and outcomes, and the privacy of all persons involved. This requirement does not limit the exercise of student academic freedoms associated with university operations upon the formal conclusion of safety review proceedings. Further, RMIT staff may make relevant and appropriate disclosures of matters under this procedure where reasonably necessary to give effect to it, including, for example where a BMP has been applied in relation to a student, or the other contents of a safety Direction, such as redirection of emails.
(45)  Advocates and support persons are bound by the same confidentiality requirements as all other persons involved in student or staff conduct proceedings.
(46)  Where personal medical information of the student is presented it must be managed in accordance with the [Health Records Act 2001 (Vic)](https://policies.rmit.edu.au/directory/summary.php?legislation=10). Access to this information will be limited to those people who require it to make a decision about the case.
(47)  RMIT recognises the importance of maintaining confidentiality to ensure safety and will seek to balance this with procedural fairness. This may mean that the identities of persons who are witnesses are not disclosed to a student where it might give rise to a risk to safety or wellbeing. Different approaches to confidentiality may also apply where a matter involves persons who are under 18 years of age, in accordance with the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213).
(48)  Records and information regarding student safety matters will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and the information management policies and procedures.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=173#document-top)
# Section 5 - Definitions
Chief Operating Officer | Means the Chief Operating Officer of RMIT University, or their delegate.  
---|---  
Executive Director | Means the Executive Director, Health, Safety and Risk of RMIT University  
Senior Officer | Means a Senior Officer under the Student Conduct Framework  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
