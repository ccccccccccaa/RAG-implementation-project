[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=22&version=5#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=22&version=5#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR and RTP Scholarships Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=22)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=22&version=5)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=22&version=5)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=22&version=5)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=22&version=5)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=22&version=5)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=22&version=5)


# HDR and RTP Scholarships Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=22&version=5#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=22&version=5#section2)
  * [Section 3 - Status](https://policies.rmit.edu.au/document/view.php?id=22&version=5#section3)
  * [Section 4 - Scope](https://policies.rmit.edu.au/document/view.php?id=22&version=5#section4)
  * [Section 5 - Policy](https://policies.rmit.edu.au/document/view.php?id=22&version=5#section5)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=22&version=5#major1)
  * [Application, Selection and Award](https://policies.rmit.edu.au/document/view.php?id=22&version=5#major2)
  * [Scholarship Administration](https://policies.rmit.edu.au/document/view.php?id=22&version=5#major3)
  * [Research Training Program Scholarships](https://policies.rmit.edu.au/document/view.php?id=22&version=5#major4)
  * [Section 6 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=22&version=5#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This policy provides the framework for establishing and managing Research Training Program (RTP) scholarships and University-funded scholarships for candidates undertaking Higher Degree by Research (HDR) programs at RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=5#document-top)
# Section 2 - Overview
(2)  This policy sets out the guiding principles which underpin the provisions and criteria required to administer and manage RTP scholarships and University-funded scholarships. This policy should be read in conjunction with the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=5#document-top)
# Section 3 - Status
(3)  Divisional policy to the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=5#document-top)
# Section 4 - Scope
(4)  This policy applies to all RTP and University-funded Higher Degrees by Research scholarships awarded and managed by the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=5#document-top)
# Section 5 - Policy
### Principles
(5)  The School of Graduate Research (SGR) will ensure a consistent approach to establishing, awarding, managing and reviewing RTP scholarships and University-funded scholarships. 
(6)  The terms and conditions of research scholarships will align with RTP guidelines, where possible. 
### Application, Selection and Award
(7)  SGR is responsible for the management of HDR scholarships paid in Australia. RMIT Vietnam is responsible for the management of HDR scholarships in Vietnam.
(8)  All scholarships for HDR candidates must be awarded through a competitive selection process that assesses applicants on academic achievement, relevant research experience, research outputs relative to opportunity, and alignment with University research priorities. 
(9)  Applicants may only be awarded a scholarship if they meet the eligibility requirements prescribed in the RMIT [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
(10)  The Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) or nominee approves the allocation of HDR fee scholarships funded by the University. 
(11)  All RTP, RMIT and Vice Chancellor’s PhD scholarships and scholarships funded by private donation to the University are awarded by the HDR Scholarships Committee. 
(12)  Research scholarships funded by the University’s colleges or schools or by industry partners are awarded by the academic staff making the scholarship available. 
(13)  Research scholarships funded by the University’s colleges or schools or by industry partners must comply with the [HDR scholarship principles](https://policies.rmit.edu.au/download.php?id=284&version=1&associated).
### Scholarship Administration
(14)  All scholarships are managed in accordance with the RMIT [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated) and the [HDR scholarship principles](https://policies.rmit.edu.au/download.php?id=284&version=1&associated). 
### Research Training Program Scholarships
(15)  RMIT will, at its discretion, use Research Training Programs funds to provide:
  1. Fees offsets for eligible candidates
  2. Stipends
  3. Allowances to assist candidates with costs associated with completing an HDR degree including but not limited to: 
    1. for overseas candidates, an Overseas Student Health Cover policy approved by the Commonwealth Department of Health,
    2. relocation costs to undertake an HDR program, and
    3. HDR thesis printing and academic publication costs.


(16)  To be eligible for an RTP stipend a candidate must not be receiving income from another source to support that candidate’s general living costs while undertaking their course of study if that income is greater than 75 percent of that candidate's RTP stipend rate. Income unrelated to the candidate’s course of study or income received for the candidate’s course of study but not for the purposes of supporting general living costs is not to be taken into account. 
(17)  RMIT will provide an RTP stipend at a rate published annually in the RMIT [Research Scholarships Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated). The RMIT RTP stipend rate will be no less than the base value and no more than the maximum value specified in the [Commonwealth Scholarship Guidelines (Research) 2017](https://policies.rmit.edu.au/directory/summary.php?legislation=45). 
(18)  The duration of RTP support is as follows:
  1. For domestic candidates the RTP Fees Offset may be provided up to the maximum duration of candidature. 
  2. For all RTP support provided to international candidates, and for domestic RTP stipend recipients, RTP support is for the full time equivalent (FTE) of up to three years for doctoral study (six-month extension may be applied for); and for Master by Research study, a maximum of two years (FTE). 


(19)  The candidate’s period of support will be adjusted to account for any periods of leave approved by RMIT. 
(20)  Extensions to candidature duration are considered in accordance with the [HDR Admissions and Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=16) and any other applicable [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated). 
(21)  By approving any program transfer to, or within, RMIT by an RTP Scholarship recipient, RMIT commits to providing the equivalent RTP Scholarships at the standard RMIT rates for the remaining duration of candidature in the new program (less any scholarship already received in-candidature). Requests for any exceptions may be considered for approval by the ADVC RT&D or nominee.
(22)  Where an RMIT-enrolled RTP Scholarship recipients transfers to another university, RTP scholarship support provided through RMIT will cease on cancellation or enrolment at RMIT. RMIT will supply details of the RTP support already provided to the candidate to the new university, with the candidate’s consent. 
(23)  Leave provisions for all RTP and University-funded scholarships are set out in the RMIT [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated). 
(24)  Where a candidate engages in a graduate research internship, work placement or other professional development activity during candidature:
  1. there will be no impact on the duration or level or support provided through an RTP fees offset scholarship, however,
  2. RTP Stipend Scholarship (RSS) conditions apply if the candidate receives an income associated with the activity.


(25)  Additional provisions relating to employment while in receipt of a RTP stipend or other type of stipend are set out in the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated).
(26)  RMIT can terminate an RTP fees offset based on a candidate having established unsatisfactory academic progress, in accordance with the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and associated procedures. 
(27)  RMIT can terminate an RTP Stipend in accordance with the [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated). 
(28)  If a research stipend is terminated, it cannot be re-activated unless the termination occurred in error. 
(29)  All aspects of candidature and supervision aside from the scholarship are managed through HDR procedures. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=22&version=5#document-top)
# Section 6 - Procedures and Resources
(30)  Refer to the following documents which are established in accordance with this Policy:
  1. [Research Scholarship Terms and Conditions](https://policies.rmit.edu.au/download.php?id=112&version=1&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
