[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=119&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=119&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Work Integrated Learning Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=119)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=119&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=119&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=119&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=119&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=119&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=119&version=1)


# Work Integrated Learning Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=119&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=119&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=119&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=119&version=1#section4)
  * [Overview](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major1)
  * [Types of WIL](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major2)
  * [Program and Course Requirements](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major3)
  * [Program and Course Guides](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major4)
  * [WIL Agreements](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major5)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major6)
  * [Changes or Cancellation of WIL Activities in Designated WIL Courses](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major7)
  * [Unsatisfactory Academic Progress (Poor Performance) or Student Misconduct During WIL Activities](https://policies.rmit.edu.au/document/view.php?id=119&version=1#major8)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=119&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  Work integrated learning (WIL) is an educational approach that uses relevant work-based experiences to allow students to integrate theory with the meaningful practice of work as an intentional and assessed component of the curriculum. Defining elements of this educational approach require that students engage in authentic and meaningful work-related tasks and must involve three stakeholders: the student, the university, and the workplace/community.
(2)  WIL may encompass a range of models and approaches to learning and assessment with discipline theory, knowledge, and skills as an integral part of program and course design. 
(3)  WIL provides the opportunity for students to gain professional and/or vocational experience in their chosen field by completing approved activities that, when successfully completed, count towards their program of study.
(4)  The Program and Course requirements duplicate [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27) content, with minor editorial changes. Details are subject to review 12 months from the effective date of this procedure.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119&version=1#document-top)
# Section 2 - Authority
(5)  Authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119&version=1#document-top)
# Section 3 - Scope
(6)  This procedure applies to all work integrated learning courses offered by RMIT Group institutions.
(7)  WIL does not include:
  1. higher degrees by research
  2. apprenticeships and traineeships
  3. guest lecturers from industry, government, or community
  4. work experience as co-curricular activities, or
  5. any other non-assessed activities. 

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119&version=1#document-top)
# Section 4 - Procedure
### Overview
(8)  WIL activities must: 
  1. integrate theoretical learning with practical application in professional contexts that engage students in meaningful and consequential learning activities 
  2. be integrated throughout the program to enable students to achieve course and program learning outcomes, graduate attributes, and vocational education employability skills as they progress through the program 
  3. include student preparation, supervision and monitoring of progress, and reflective practice/debriefing 
  4. be aligned to the requirements of professional registration, accrediting bodies, and training package rules (where applicable) 
  5. be authentically assessed in line with the University’s assessment policy
  6. comply with relevant government legislation and regulations, University policies, procedures, and resources.
  7. be undertaken in a safe workplace context whether on campus, off campus, or online. 


(9)  Industry engagement in WIL activities is expected to
  1. involve students interacting with organisations (industry, government, and community) through discipline relevant projects and work placements.
  2. be inclusive of continuous feedback from all stakeholders to ensure ongoing evaluation and quality improvements
  3. be negotiated with partner organisations (where relevant) and designed to be safe, accessible, equitable and mutually beneficial for stakeholders 
  4. be authentic, including simulated workplace environments, with current practitioners/partners actively working in industry, community, or government organisations able to provide a registered business name or ABN.


(10)  WIL activities will not cause unnecessary or unreasonable hardship for students or partner organisations.
### Types of WIL
(11)  WIL activities can be offered face-to-face, online or in a blended approach and may fall under one or more of the broad categories described in this section.
#### Placements
(12)  These activities are generally on-site placements in a workplace or community setting, can be onshore, offshore, or online and may be paid or unpaid.
(13)  Common terminology for WIL placement activities include practical placement, practicum, cooperative education, clinical placements, fieldwork, and internship.
#### Projects
(14)  WIL projects are co-designed with industry and/or community partners. Industry engaged projects commonly require teams or individual students to undertake a real project that is based on real problems or address needs of industry or community. Industry partners are engaged in the project and provide feedback to students.
(15)  Industry engaged WIL projects may be paid or unpaid. They may take place on campus, off campus, offshore or online. 
#### Simulated Workplace Environments
(16)  WIL activities in simulated workplace environments may be necessary for ethical, safety or professional reasons or when other forms of industry engaged WIL are unavailable.
(17)  These environments are designed to simulate real workplaces in their function, equipment and mode of operation so that students can experience a variety of scenarios and inter-related activities similar to real work experience in the industry or profession to which the program leads.
(18)  This type of WIL can occur face-to-face or online, on campus or off campus, and is usually unpaid.
(19)  Partner organisations are involved in the design of the simulated workplace environment and provide feedback to students. 
### Program and Course Requirements
(20)  Programs offering WIL must comprise the following minimum number of WIL units, courses, or credit points in core courses: 
  1. certificate III, certificate IV, diploma, or advanced diploma programs other than apprenticeships, traineeships or that specified within the training package rules: one unit of competency or cluster of units
  2. undergraduate diploma, associate degree, graduate diploma, masters by coursework: 12 credit points.
  3. bachelor degree, bachelor honours degree other than one-year bachelor honours degree: 24 credit points.
  4. double degree comprising bachelor degrees and/or bachelor honours degrees: 24 credit points. The WIL courses in double degrees must, however, provide the learning outcomes of the core WIL courses of both component single degrees.


(21)  In higher education, designated WIL courses must be core and comprise WIL activities that align with at least 50% of the assessment. WIL in elective or optional courses does not need to meet the 50% assessment requirement. 
(22)  For vocational education programs where WIL activities are spread across more than the minimum of units of competency or cluster of units, WIL activities must be appropriately incorporated into the assessment requirements in alignment with the training package rules.
(23)  Designated WIL courses may offer different types of WIL at different locations and with different cohorts if these are deemed to be equivalent and to meet course learning outcomes. 
(24)  The Deputy Vice-Chancellor Education can approve exemptions from the above requirements of WIL components in programs where:
  1. professional accreditation requirements prevent WIL being offered within the normal program duration or
  2. the program is primarily intended as a credit pathway to a higher program that meets the WIL requirements in the previous section or
  3. the program is designed to provide a specific skill such as a language rather than an employability outcome or
  4. progressive learning of professional skills requires that WIL placements be distributed as an assessment component weighted at less than 50% in numerous courses or
  5. in a dual or double degree, requirements for meeting prescribed learning outcomes within a reduced volume of learning prevent WIL experiences being offered.


### Program and Course Guides
(25)  Program and course guides must comply with the requirements prescribed by the [Program and Course Approval Processes](https://policies.rmit.edu.au/document/view.php?id=40) and the requirements prescribed in clauses (26) and (27).
(26)  Program guides must include:
  1. the name of the designated WIL courses by course code and title 
  2. a list the mode of activities that will be offered in designated WIL courses as either WIL Placement, WIL Project, or WIL in a Simulated Workplace Environment, or as a blended approach 
  3. the eligibility requirements both academic prerequisites and non-academic requirements (which may include but are not limited to immunisations, visas, Working with Children Checks, Police Checks and responsibilities for associated costs) including those aligned to the requirements of professional registration and accrediting bodies (where applicable).


(27)  Course guides for designated WIL courses must include: 
  1. the eligibility requirements both academic prerequisites and non-academic requirements (which may include but are not limited to immunisations, visas, Working with Children Checks, Police Checks and responsibilities for associated costs) including those aligned to the requirements of professional registration and accrediting bodies (where applicable)
  2. a list of the mode of activities that will be offered as either WIL Placement, WIL Project, or WIL in a Simulated Workplace Environment, or as a blended approach 
  3. details which stipulate the minimum and maximum range of duration as either hours or days
  4. a WIL-specific statement addressing inclusivity, health, safety, and well-being, cultural safety, accessibility, equity, and adjustments 
  5. a statement which advises if the student, School or a nominated area is responsible for sourcing the WIL placement/ activity 
  6. advice on student registration with Global Mobility if WIL activity is overseas 
  7. a statement that WIL agreements, schedules and relevant insurance documentation must be fully approved, and the WIL Preparation module for students and/or WIL Ready Cred for students must be successfully completed before the WIL activity commences.


### WIL Agreements
#### Agreement Requirements
(28)  WIL Agreements must be used for all WIL activities (including paid) involving partner organisations (including RMIT), regardless of whether the activity is on campus, off campus or online and must have the appropriate RMIT sign-off as set out in the [Delegations of Authority](https://policies.rmit.edu.au/document/view.php?id=51). 
(29)  WIL agreements, schedules, insurance, and other relevant documentation such as roles, rights and responsibilities of all stakeholders are to be completed before commencement of a WIL activity. 
(30)  Agreements and schedule information between students, RMIT and partner organisations may vary according to higher education or vocational education contexts, specific discipline requirements, location (local, interstate, international or national regulatory requirements) and whether the WIL activity is paid or not. 
(31)  All parties must be adequately prepared and informed of their duties, roles, rights, and responsibilities for participating in WIL activities in a timely manner. 
(32)  WIL arrangements must be consistent with the guidance available from Fair Work Commission on work experience and internships. For students on overseas placements, workplace arrangements must conform with local employment and workplace legislation, including safety. 
(33)  Ownership of any new Intellectual Property created by the WIL activity must be agreed between the student, RMIT and the Partner before an activity starts. Use the relevant template agreement, depending on whether a student will retain ownership of the IP, or if the Partner will own the student’s IP. 
(34)  Any WIL Agreements requiring translation must be undertaken by a translation service accredited by the National Accreditation Authority for Translators and Interpreters. The cost of the translation and interpreting services are charged to the relevant school or nominated area.
(35)  Partner organisations may request that RMIT use their organisation’s WIL agreement. Any such agreement must be reviewed by the Legal Services Group prior to signing. 
#### Authorisation and Signatories
(36)  All stakeholders engaged in WIL activities with a partner organisation must sign a WIL agreement prior to the commencement of a WIL activity. Sign-off must be in accordance with the [Delegations of Authority](https://policies.rmit.edu.au/document/view.php?id=51). 
(37)  RMIT staff shall not commit RMIT to any additional legal or other obligations or costs without seeking appropriate legal or commercial advice. 
(38)  In situations where an overarching relationship WIL agreement is in place (between a partner organisation and RMIT), students must sign a student declaration/deed (also known as a Schedule - Student Undertaking) that acknowledges their acceptance and understanding of their roles, rights and responsibilities during WIL activities with that partner organisation. 
#### Record Management
(39)  RMIT WIL agreement templates, change annexures, schedules and information sheets must be accessed from the RMIT staff WIL website to ensure the most up-to-date version is used. 
(40)  WIL agreements, change annexures, associated information sheets and schedules are to be managed by the WIL practitioner (or nominee). 
(41)  Electronic copies of the WIL Agreement/Schedule/Change Annexure/insurance documents/WIL Risk Assessment Checklist must be filed in:
  1. TRIM, for RMIT Vietnam
  2. InPlace, which is the designated WIL data collection system for RMIT Australia and for any other global WIL experiences. 
  3. A copy must also be provided to the student and the partner organisation as appropriate. Original (i.e. physically signed) hard copies of these documents must be stored in accordance with the School's regular records management practice or sent to RMIT Archives. 


### Responsibilities
#### Eligibility
(42)  Schools (or nominated area) will assess a student’s eligibility to undertake WIL activities against the requirements prescribed in the course guide for designated WIL courses. Students must meet these requirements to participate in WIL activities. 
(43)  Before any student who is 17 or younger is sent out on placement, supervising staff of the partner organisation (the provider of the placement) must have clearance to work with children. 
  1. RMIT must ask the provider to supply proof that supervising staff have clearance to work with children before the placement begins. 


(44)  Where a partner organisation or professional body requires students to submit a satisfactory police check and/or Working With Children Check before commencing the WIL activity, and the student does not do this by the timeline specified by the WIL practitioner, the student will not be approved to commence the WIL activity. 
(45)  Where WIL activities are to be completed overseas, students must be registered and processed through the appropriate organisational department.
#### Provision of Information
(46)  The WIL practitioner (or nominee) has a responsibility to ensure students are informed:
  1. of their roles, rights, and responsibilities throughout the WIL activity as documented in the WIL Agreement and Schedule
  2. of required conduct and safety policies and procedures both on campus, online and at partner organisation workplaces
  3. in the event of the student decides to end a placement or project early, to contact the WIL practitioner (or nominee) as soon as practicable
  4. of how they will be supported by the WIL practitioner and school if they are concerned about behaviour experienced on placement including but not limited to discrimination, sexual harm, or workplace bullying, and
  5. that RMIT student wellbeing, student support and safer community services remain available if the student experiences unreasonable or unsafe workplace behaviour or sexual harm during the WIL activity


(47)  Where applicable, the WIL practitioner (or nominee) must also ensure:
  1. students are assigned to, and / or are approved for, appropriate WIL activities
  2. reasonable adjustments to WIL activities will be considered for students living with a disability, long-term illness or a mental health condition 


(48)  The WIL practitioner (or nominee) has a responsibility to inform partner organisations:
  1. of their roles, responsibilities, and obligations to supervise and monitor student progress
  2. to induct students to required safety policies and procedures in their workplaces
  3. to immediately notify RMIT of any health, safety or well-being concerns relating to the student. 


#### Monitoring and Supervision
(49)  The WIL practitioner is responsible for ensuring the ongoing processes for monitoring and supervising student progress throughout the WIL activity are determined before commencement of the activity and documented in the schedule.
(50)  The schedule must make clear to the student how supervision of their progress will contribute to assessment and what will occur if their progress is deemed to be unsatisfactory during the activity. 
(51)  Monitoring and supervising student learning and progress is the responsibility of both the University and the partner organisation.
#### Occupational Health and Safety
(52)  The WIL practitioner and partner organisation must ensure potential risk management issues such as hazards are identified before commencement of the WIL activity using the appropriate risk assessment document and risk mitigations are put in place. 
(53)  In line with RMIT Occupational Health and Safety (OHS) processes, WIL practitioners must report all WIL emergencies, critical incidents or identified hazards to the partner organisation supervisor, RMIT OHS through PRIME and the program manager. 
(54)  Risk assessment must consider travel arrangements where students are undertaking WIL activities interstate or overseas.
#### Students Studying in Australia on a Student Visa (International Students)
(55)  It is the responsibility of international students studying in Australia to remain aware of their visa conditions in terms of paid/unpaid/volunteer work and any impact an offshore WIL activity may have on future visa applications.
(56)  International students studying in Australia are only permitted to work (this includes paid/unpaid WIL hours) a maximum of 40 hours per fortnight while classes are in session unless it is an approved WIL course in a CRICOS registered program. 
### Changes or Cancellation of WIL Activities in Designated WIL Courses
(57)  In situations where WIL activities are no longer available and must be withdrawn, alternative WIL activities must be organised by schools where appropriate.
(58)  In the case of placement cancellation by a partner organisation, the student should be prioritised for a new placement by the school, where possible, to minimise any impact on the student’s progression in the program.
(59)  For WIL activities that are still able to continue but have significant changes to mode of delivery, activities, assessment, or any other significant change, a change annexure form must be completed. 
### Unsatisfactory Academic Progress (Poor Performance) or Student Misconduct During WIL Activities
(60)  A partner organisation and/or school may decide that a student must leave a WIL activity prior to the official end date due to the student's conduct and/or unsatisfactory academic progress (poor performance) during the WIL activity.
(61)  Early termination of a student’s participation in a WIL activity due to:
  1. unsatisfactory academic progress (poor performance) and feedback on assessment must be managed in accordance with the Assessment and Assessment Flexibility Policy.
  2. inappropriate actions or behaviours must be addressed in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=119&version=1#document-top)
# Section 5 - Resources
(62)  Refer to the following documents which are established in accordance with this procedure:
  1. [Work Integrated Learning](https://policies.rmit.edu.au/download.php?id=164&version=3&associated) for staff including InPlace and online resources for WIL practitioners
  2. [WIL Ready For Staff](https://policies.rmit.edu.au/download.php?id=165&version=1&associated) learning module


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
