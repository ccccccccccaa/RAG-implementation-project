[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=10&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=10&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Dress Guideline 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=10)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=10&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=10&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=10&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=10&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=10&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=10&version=1)


# Academic Dress Guideline
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=10&version=1#section1)
  * [Section 2 - Scope](https://policies.rmit.edu.au/document/view.php?id=10&version=1#section2)
  * [Section 3 - Authority](https://policies.rmit.edu.au/document/view.php?id=10&version=1#section3)
  * [Section 4 - Guideline](https://policies.rmit.edu.au/document/view.php?id=10&version=1#section4)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This guideline defines the use of academic dress when participating in official RMIT ceremonies and processions, and when representing RMIT at other approved events.
(2)  These guidelines support the RMIT Academic Dress Regulations and the [Conferral and Graduation Policy](https://policies.rmit.edu.au/document/view.php?id=8) and [Conferral and Graduation Procedure](https://policies.rmit.edu.au/document/view.php?id=9).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=10&version=1#document-top)
# Section 2 - Scope
(3)  These guidelines apply to RMIT staff, alumni and graduands participating in official occasions that require academic dress.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=10&version=1#document-top)
# Section 3 - Authority
(4)  Authority for this document is established by the [Conferral and Graduation Policy](https://policies.rmit.edu.au/document/view.php?id=8).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=10&version=1#document-top)
# Section 4 - Guideline
(5)  Academic dress, as determined by discipline, will be worn by participants at official RMIT ceremonies and processions and approved external events as determined by RMIT University Council (Council).
(6)  When participating in official RMIT ceremonies and processions, academic dress shall be worn by:
  1. the Chancellor and Members of Council
  2. staff and graduands
  3. alumni of RMIT
  4. official representatives of other institutions or external bodies who are formally invited to participate.


(7)  Participants of academic ceremonies who do not have a higher education or VE qualification will wear plain black gowns and black cloth trencher caps.
(8)  Academic dress will be supplied without charge to the following participants who do not have their own academic dress:
  1. Members of Council, staff and alumni who are participating in official RMIT ceremonies
  2. Representatives of RMIT Student Union (RUSU), Student Union Council, and the RMIT Postgraduate Association members who are participating in official RMIT ceremonies
  3. Council and staff who are required to represent RMIT at approved external occasions.


(9)  Academic dress may be hired from ARG, Completions, Awards and Graduations by:
  1. graduands attending and receiving awards at conferring ceremonies
  2. graduands, alumni, staff and members of Council attending approved external ceremonies
  3. external bodies who require the use of common items of dress to augment their own stocks for specific ceremonial purposes.


(10)  The fees for hiring academic dress are prescribed in the Schedule of Fees, advised to participants with ceremony details, and published online.
(11)  Applications for the use of academic dress by external bodies should be made in writing to the ARG, Completions, Awards and Graduations.
(12)  Academic dress of other institutions may be worn by alumni of those institutions. Individuals will be responsible for providing their own academic dress appropriate to their award; or may hire the RMIT academic dress which corresponds most closely to their award.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
