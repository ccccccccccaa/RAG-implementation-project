[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=16&version=4#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=16&version=4#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Admissions and Enrolment Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=16)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=16&version=4)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=16&version=4)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=16&version=4)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=16&version=4)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=16&version=4)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=16&version=4)


# HDR Admissions and Enrolment Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=16&version=4#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=16&version=4#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=16&version=4#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=16&version=4#section4)
  * [Admission](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major1)
  * [Duration of Candidature and Research Commencement Date](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major2)
  * [Variations to Candidature](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major3)
  * [Study Load](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major4)
  * [Leave](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major5)
  * [Study Away and Change of Location](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major6)
  * [Program Transfer](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major7)
  * [Readmission Within Maximum Duration](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major8)
  * [Extension Beyond Maximum Duration](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major9)
  * [Cancellation Due to Exceeding Maximum Duration](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major10)
  * [Cancellation Due to Unresponsive Candidate](https://policies.rmit.edu.au/document/view.php?id=16&version=4#major11)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=16&version=4#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure sets out the rules and processes relating to Higher Degree by Research (HDR) admissions and enrolment, including candidature duration and enrolment variation.
(2)  This procedure should be read in conjunction with the RMIT [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6), [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11), [Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126) and associated procedures. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=16&version=4#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=16&version=4#document-top)
# Section 3 - Scope
(4)  This procedure applies to all staff responsible for monitoring and managing HDR admissions and enrolment and all HDR candidates in the RMIT group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=16&version=4#document-top)
# Section 4 - Procedure
### Admission
(5)  Selection and admission to Higher Degrees by Research are managed in accordance with the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6) and RMIT [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11) and associated procedures.
(6)  RMIT admits applicants on the basis of their demonstrated capacity or potential to conduct independent research, and on the capacity of the school to provide expert supervision. All applicants for research programs must meet the minimum entry requirements. 
(7)  By recommending an offer of admission to be made to an applicant, the enrolling school confirms that it has: 
  1. the appropriate discipline expertise to house the research,
  2. the necessary space, facilities, equipment, technical and resource staff and funding for the applicant, for the duration of the program, and
  3. the capacity to provide high-quality and dedicated supervision for the duration of the program. 


(8)  Candidates may apply for credit towards coursework components of the program to which they are admitted in accordance with the [Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126). 
(9)  Export Controls, Foreign Relations, Autonomous and United Nations Sanctions, and other security considerations will be managed in accordance with relevant legislation, the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28), and any other necessary processes.
(10)  All applicants from a sanctioned country (excluding applicants who hold Australian permanent residency or an Australian humanitarian visa) seeking to study an HDR program at RMIT are assessed against the relevant legislation and policies. 
(11)  Existing HDR candidates who elect to change their research and supervision arrangements will undergo a further assessment of their research. 
(12)  In assessing applications, RMIT may refuse to progress applications to an offer of admission based on the outcome of sanctions or security assessment. Outcomes of these assessments are final.
### Duration of Candidature and Research Commencement Date
(13)  Permitted HDR candidature duration is calculated using Equivalent Full-Time Student Load (EFTSL) as follows:
  1. PhD: minimum 3.0 EFTSL and maximum 4.0 EFTSL.
  2. Master by Research: minimum 1.0 EFTSL and maximum 2.0 EFTSL.


(14)  The commencement date is the first date of enrolment. Commencement dates cannot be backdated.
(15)  Candidates unable to enrol by the research commencement date on their offer of admission must notify the School of Graduate Research (SGR) immediately and may need to seek a deferment to ensure that their candidature duration is correctly calculated. Deferments are subject to rules set out in this procedure and the RMIT [Admission Procedure](https://policies.rmit.edu.au/document/view.php?id=36).
  1. SGR will process deferments on receipt of email confirmation by the senior supervisor of the new, agreed research commencement date.
  2. Failure to seek a deferment within one month of the candidate’s research commencement date will result in the offer of admission lapsing, which may also affect visa and scholarship status. 


(16)  Candidates must remain enrolled for the duration of their candidature unless on an approved leave of absence.
  1. Candidates may be enrolled by SGR in training and development activities (such as research internships) after their thesis or dissertation submission. Candidates may not enrol themselves in classes for this purpose.


### Variations to Candidature
(17)  Variations to candidature are subject to approval by the Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) or nominee (unless otherwise specified in this procedure) on provision of supporting evidence and subject to any applicable scholarship terms and conditions.
(18)  Variations to candidature cannot be backdated.
(19)  A candidate may request a review of a decision to alter or reject their application for an enrolment variation in accordance with the [Enrolment Procedure](https://policies.rmit.edu.au/document/view.php?id=113) and [Enrolment Procedure – Leave of Absence](https://policies.rmit.edu.au/document/view.php?id=115).
### Study Load
(20)  Candidate enrolment shall be either full-time (1.0 EFTSL per 12 months), or part-time (0.5 EFTSL per 12 months).
(21)  Full-time commitment will average at least four days per week over the course of a year. Part-time commitment will average at least two days per week over the course of a year. Any work, paid or otherwise, undertaken by the candidate outside of their research project must not affect their ability to maintain this commitment.
(22)  International candidates studying in Australia on a student visa who wish to reduce their study load must submit a Recommendation to Reduce Enrolment Load Form and supporting documentation (e.g., Candidate Action and Support Plan, medical certificates, etc.) to their HDR Delegated Authority (HDR DA). If the recommendation is endorsed, the Research Training Services (RTS) team in SGR will submit the documentation for approval by the ADVC RT&D or nominee, subject to any terms and conditions of their scholarship or sponsorship.
(23)  All other candidates can request changes between full- and part-time study load for an enrolment period by submitting a request to their senior supervisor and notifying SGR, subject to any terms and conditions of their scholarship or sponsorship. 
(24)  Changes to study load cannot be made retrospectively, except in extenuating circumstances.
### Leave
(25)  Candidates are entitled to a total of 20 working days’ annual leave per year. 
(26)  Candidates must discuss any proposed leave period with their senior supervisor prior to applying for any type of leave.
(27)  Candidates are entitled to a total of twelve (12) months’ leave of absence (LOA) per candidature (including part time students) to cover medical, compassionate or compelling circumstances which prevent the candidate carrying out research, subject to provision of appropriate documentation and any terms and conditions of their scholarship or sponsorship.
(28)  Candidates are entitled to up to six (6) months’ parental leave, including adoption leave for each child born or adopted during candidature, subject to provision of appropriate documentation and any terms and conditions of their scholarship or sponsorship.
(29)  Requests for parental leave may be granted in addition to the standard leave of absence provisions.
(30)  Candidates who have experienced pregnancy loss may also access special leave, and in cases where this occurs within 20 weeks of the expected due date, the candidate is entitled to Parental Leave for a period of up to three (3) months. 
(31)  It is acknowledged that members of Aboriginal and Torres Strait Islander communities have significant responsibilities for cultural and ceremonial obligations. Aboriginal and Torres Strait Islander candidates may access up to six days leave per calendar year, non-cumulative, for cultural and ceremonial obligations of Aboriginal and Torres Strait Islander people. 
(32)  Candidates may apply for all types of leave of absence, including parental leave, by submitting a Leave of Absence Form with supporting documentation to SGR. 
(33)  Candidates receiving a scholarship or sponsorship must contact their provider to discuss the potential impact of LOA on their scholarship or sponsorship.
(34)  Candidates whose research has ethics approval, or an ethics approval pending, must notify the Coordinator – Research Governance and Ethics of the relevant ethics review body if their LOA application is granted. 
(35)  If the application for LOA is less than the total amount permissible for candidature (12 months) the LOA form must be submitted for approval by the HDR DA, after consultation with the supervisory team. If approved, the application is processed by the RTS team in SGR. 
(36)  If the application for LOA is greater than the total amount permissible for candidature (12 months) or the candidate has been granted an extension beyond maximum duration, the LOA form must be submitted for endorsement by the HDR DA, after consultation with the supervisory team. If the application is endorsed, the RTS team in SGR must submit the documentation for approval by the ADVC RT&D or nominee.
(37)  SGR will notify candidates of the outcome of their LOA application.
(38)  Candidates must cease working on their research while on a leave of absence. Access to University facilities and resources will therefore be restricted during leave. 
### Study Away and Change of Location
(39)  Candidates must inform the University of their intent to spend any time away from their normal location of study for the purposes of their research, to ensure appropriate risk assessments and controls have been put in place to cover their travel and activity in accordance with the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97). Failure to do so will limit the University’s ability to support candidates’ safety and wellbeing.
(40)  Candidates changing their normal location of study for a period of three months or more must notify RMIT of their ‘change of location’ by submitting a Notification of Change of Study Location Form to SGR.
(41)  Changing location between Australia and a country outside of Australia will have implications for those candidates requiring a student visa.
  1. Where an international candidate on a student visa is planning a permanent change of location outside of Australia, SGR will notify RMIT’s International Compliance office.
  2. Any change of location may affect a candidate’s visa. Candidates are responsible for checking their visa status and conditions. 
  3. Candidates must update their RMIT record with any change to address and contact details as a result of a study away period or a change of location.


### Program Transfer
(42)  For candidates wishing to transfer between HDR programs or to RMIT from another university, the transfer may be supported, subject to entry and admission conditions being met, if:
  1. less than 3.0 EFTSL has been consumed in a PhD, or
  2. less than 1.0 EFTSL consumed in a Master by Research.


(43)  A transfer after 3.0 EFTSL (PhD) or 1.0 EFTSL (Master by Research) may take place in exceptional circumstances, subject to approval by the ADVC RT&D or nominee.
(44)  Candidates may request a transfer to another HDR program by submitting an application via the RMIT University Application Service. Candidates must discuss their proposed change of program with their supervisory team (and proposed supervisory team, if a change of supervisor is required) before submitting supporting documentation to SGR.
(45)  The transfer application must be endorsed by the HDR DA in the school offering the proposed program, after consultation with the proposed supervisory team.
(46)  If approved, candidates will receive an offer of admission to their new program from SGR. Candidates must accept their offer and enrol into the new program. 
(47)  Transfer from a Master by Research to a PhD program
  1. Candidates who wish to transfer from a Master by Research to a PhD program must demonstrate that they can expand the scope of their research to doctoral level by presenting a PhD-level confirmation of candidature in place of a Master by Research-level second milestone review. This must occur within the second milestone window. The [HDR Progress Managment and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=15) provides further information on milestone reviews. Candidates can only attempt this transfer once, and if unsuccessful must continue in their current program.


(48)  Transfer from a PhD to a Master by Research program
  1. Candidates who wish to transfer from a PhD to Master by Research program must demonstrate that they can reduce the scope of their research to Master by Research-level by presenting a Master by Research-level milestone.


### Readmission Within Maximum Duration
(49)  Candidates who wish to apply for readmission within the maximum duration of their candidature must submit an application via the RMIT University Application Service. Candidates must discuss their proposed readmission with their supervisory team before submitting their application.
(50)  The application must include:
  1. the background of the request
  2. a summary of work completed prior to the cancellation of enrolment
  3. an outline of the work remaining
  4. a timeline for the completion of the work remaining
  5. a change of supervisor form, if a change of supervisor is required.


(51)  If approved for readmission, the candidate will be issued an offer with a revised final submission date. Candidates must accept their offer and enrol into the new program.
### Extension Beyond Maximum Duration
(52)  Candidates may apply for an extension beyond the maximum duration of their candidature by submitting a Candidate Action and Support Plan (CASP). Candidates should discuss their extension and develop their CASP with their supervisory team before submitting it to SGR. For more details on CASPs see the [HDR Progress Management and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=15).
(53)  Extensions beyond maximum duration of candidature are not automatic and, if approved, are strictly capped at the approved duration of the accompanying CASP.
(54)  The extension application must be endorsed by the HDR DA, after consultation with the supervisory team. If the application is endorsed, the RTS team in SGR must submit the documentation for approval by the ADVC RT&D or nominee.
(55)  International candidates studying in Australia on a student visa will be advised by the RTS team in SGR on how to apply for a new eCoE for a visa extension if their extension beyond maximum duration is approved.
### Cancellation Due to Exceeding Maximum Duration
(56)  Candidates who do not submit by their final submission date, or their extension end-date, will be notified that they have exceeded maximum duration of candidature. This notification will inform candidates of the options available to them and advise that, if they do not take any action, the ADVC RT&D or nominee will request that the Academic Registrar cancel the candidate’s enrolment.
(57)  Candidates whose enrolment is cancelled for exceeding maximum duration are eligible to apply for readmission for the purpose of examination within three years of their cancellation. Refer to the [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18) for further information.
### Cancellation Due to Unresponsive Candidate
(58)  A candidate may be considered unresponsive and having abandoned their program of study under one or more of the following circumstances:
  1. Failure to return to their studies after a period of approved leave of absence.
  2. Failure to maintain regular communication and interaction with their supervisory team and to respond to reasonable attempts by the University to contact them. 


(59)  Senior supervisors who have had no response from a candidate after reasonable attempts will notify the HDR DA. 
(60)  Where the HDR DA is satisfied the supervisory team have not had any recent contact with the candidate, they will notify SGR.
(61)  If their absence remains unexplained, SGR will contact Student Support and request a missing student check as per the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11). If a welfare issue is discovered, SGR will work with the student welfare team to determine the appropriate steps. 
(62)  Following discussion with the HDR DA, and provided any welfare matters have been addressed, SGR will provide the candidate with options available to them and advise that if they do not respond to University correspondence within 20 working days and re-engage with their studies, the ADVC RT&D or nominee will request that the Academic Registrar cancel their enrolment. Where the candidate is an international student, SGR will notify the relevant parts of the University. 
(63)  Candidates whose enrolment is cancelled due to being unresponsive may be eligible to apply for Readmission within Candidature as prescribed in this procedure or in the [HDR Submission and Examination Procedure](https://policies.rmit.edu.au/document/view.php?id=18).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=16&version=4#document-top)
# Section 5 - Resources
(64)  Refer to the following documents:
  1. [HDR Forms](https://policies.rmit.edu.au/download.php?id=68&version=2&associated): 
    1. Change of Location form
    2. RMIT Leave of Absence form
    3. Request to Reduce Enrolment Load form


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
