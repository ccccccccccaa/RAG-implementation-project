[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=178&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=178&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Defence Export Controls Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=178)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=178&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=178&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=178&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=178&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=178&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=178&version=1)


# Defence Export Controls Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=178&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=178&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=178&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=178&version=1#section4)
  * [Requirements](https://policies.rmit.edu.au/document/view.php?id=178&version=1#major1)
  * [Assessment of Research Activities and Projects](https://policies.rmit.edu.au/document/view.php?id=178&version=1#major2)
  * [Applying for a Defence Trade Controls (DTC) Permit](https://policies.rmit.edu.au/document/view.php?id=178&version=1#major3)
  * [Variations to a Defence Trade Controls (DTC) Permit](https://policies.rmit.edu.au/document/view.php?id=178&version=1#major4)
  * [Management of Defence Trade Controls (DTC) Records](https://policies.rmit.edu.au/document/view.php?id=178&version=1#major5)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=178&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  Australia’s Defence Export Control scheme, including the [Defence Trade Controls Act 2012](https://policies.rmit.edu.au/directory/summary.php?legislation=23), has been established to ensure the export of military or dual-use goods and technologies is consistent with Australia’s national interests and international obligations.
(2)  Controlled goods and technologies include:
  1. military items designed or adapted expressly for military purposes or those that are inherently lethal, incapacitating or destructive
  2. dual-use commercial items and technologies that may be used or adapted for use in a military program or contribute to the development and production of chemical, biological or nuclear weapons systems.


(3)  RMIT recognises the importance of understanding and complying with Australia’s export control scheme and supports the accountable and responsible export of defence and dual-use goods and technologies in a manner that is compliant with relevant controls and laws, and protects Australia’s national interests.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=178&version=1#document-top)
# Section 2 - Authority
(4)  Authority for this document is established by the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=178&version=1#document-top)
# Section 3 - Scope
(5)  This procedure applies to all staff, students, visiting researchers and honorary and adjunct appointees undertaking or supporting research at all RMIT Group and external research locations, and any research RMIT is obliged to consider.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=178&version=1#document-top)
# Section 4 - Procedure
### Requirements
(6)  Accountability is a core principle of the responsible development, undertaking and reporting of research and requires researchers (staff and students) and others to comply with any relevant legislation, policies and guidelines, this includes Australia’s Defence Trade Controls.
(7)  Researchers will be responsible for maintaining an awareness and understanding of Australia’s Defence Trade Controls and assessing how these controls might apply to any research projects or activities they undertake.
(8)  RMIT will administer the University’s Defence Export Controls (DEC) Client Reference Number and provide professional development, resources, processes and infrastructure that support researchers in understanding when Defence Trade Controls apply, in the gaining and maintaining of required permits, and in conducting research in line with these controls and RMIT policy.
(9)  Researchers and any person undertaking research with or on behalf of RMIT will only undertake controlled activities (supply, publish, export or broker) with defence and strategic goods or technologies with the appropriate authorisation to do so.
(10)  In Australia, RMIT researchers will remain compliant with Australia’s Defence Trade Controls at all times, including when conducting research at other institutions.
### Assessment of Research Activities and Projects
(11)  Researchers must assess whether or not Defence Trade Controls, including those described in the [Defence Trade Controls Act 2012](https://policies.rmit.edu.au/directory/summary.php?legislation=23) or the [Customs Act 1901](https://policies.rmit.edu.au/directory/summary.php?legislation=42), apply to their research activities or projects. In conducting this assessment, researchers will make use of the online tools and resources available on the [Defence Export Controls website](https://policies.rmit.edu.au/download.php?id=251&version=1&associated), including the Activity Questionnaire and online Defence and Strategic Goods List (DSGL). Support and advice can also be sought from the Research Ethics, Integrity and Governance team (REIG).
(12)  Where this assessment indicates research activities fall within the scope of Defence Trade Controls, researchers will contact REIG to seek advice and to support their application for a permit. Where researchers are unsure as to whether Defence Trade Controls apply, support and advice will be sought from REIG.
(13)  REIG will support researchers in finalising an assessment of whether Defence Trade Controls apply to their research activities or projects, and in progressing an application for a Defence Trade Control permit (see below).
### Applying for a Defence Trade Controls (DTC) Permit
(14)  Researchers must gain and maintain appropriate permits for all controlled activities (supply, publish, export or broker) with defence and strategic goods or technologies in accordance with this procedure.
(15)  Researchers must work with REIG to complete and finalise applications for a permit and are responsible for providing information and supporting documentation which details:
  1. a description of the military or dual-use goods and/or technologies
  2. details of the proposed activities (export, supply or publish) to be undertaken the military or dual-use goods and/or technologies
  3. date/s or period/s over which these activities will occur and
  4. the end-user/s.


(16)  Only RMIT staff can be named as an applicant or contact person on a DTC permit application.
(17)  REIG will complete a governance check of the permit application before it is submitted to the DEC team in the Department of Defence, for approval.
(18)  All applications must be approved, with confirmation and a copy of the permit received from the DEC team before any controlled activities are undertaken or commence.
(19)  Researchers will advise REIG of the outcome of their application, and forward a copy of any permit obtained, for their information and records.
### Variations to a Defence Trade Controls (DTC) Permit
(20)  Only minor additions or revisions are permitted to an existing permit issued by the Department of Defence, with all requests for amendment to be submitted, reviewed and approved by the DEC team. 
(21)  Where there are any proposed minor additions or revisions to the controlled goods, technologies or activities which are the subject of a DTC permit, researchers will work with REIG to complete and finalise any request for an amendment.
(22)  REIG will complete a governance check of the request for amendment before it is submitted to the DEC team, for review and approval.
(23)  All requests for amendment must be approved, with confirmation and a copy of the notice of variation received from the DEC team, before any changes to the controlled goods, technologies or activities are made.
(24)  Researchers will advise the REIG of the outcome of their request for amendment.
(25)  Where researchers want to make a significant addition or revision (for example, addition of new destinations or multiple new end users or consignees, or significant increases in quantities, or different technology) a new application will be required.
### Management of Defence Trade Controls (DTC) Records
(26)  Researchers must create, manage and maintain all required records of their research activities with controlled goods or technologies, in line with the legislative and RMIT requirements, including:
  1. a description of the goods or technologies supplied,
  2. the dates of supply, and 
  3. where a permit covers supply over a period of time, the period or periods during which the supply of the goods or technologies occurred.


(27)  Researchers and REIG will manage and maintain required records relating to the gaining and maintaining of permits and professional development, in line with the legislative and RMIT requirements.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=178&version=1#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this document).
Defence Export Controls (DEC) |  DEC within the Australian Government Department of Defence is Australia’s military and dual-use goods and technology export regulator.  
---|---  
Defence export or trade controls |  Defence export or trade controls are a legislative framework, comprising legislation and regulations, that regulate the export of military and dual-use goods, to protect Australia’s national interests in keeping with international obligations.  
Defence Trade Controls Act |  This includes the [Defence Trade Controls Act 2012](https://policies.rmit.edu.au/directory/summary.php?legislation=23) and any amendments to this Act.  
Defence and Strategic Goods List (DSGL) |  The list that specifies the goods, software or technology that is regulated when exported, supplied, brokered or published. A permit is required when exporting, supplying, brokering or publishing DSGL items, unless there is an exemption.  
Defence Export Controls (DEC) Permit |  A permit issued by Defence Export Controls.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
