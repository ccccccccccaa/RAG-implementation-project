[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=23&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=23&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Intellectual Property Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=23)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=23&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=23&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=23&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=23&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=23&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=23&version=2)


# Intellectual Property Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=23&version=2#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=23&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=23&version=2#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=23&version=2#section4)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=23&version=2#major1)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=23&version=2#major2)
  * [Section 5 - Procedures](https://policies.rmit.edu.au/document/view.php?id=23&version=2#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=23&version=2#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  To describe the rights, roles and responsibilities of RMIT, staff, affiliates and students in relation to intellectual property (IP).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=2#document-top)
# Section 2 - Overview
(2)  [RMIT Statute No.1](https://policies.rmit.edu.au/document/view.php?id=177), Part 10 states RMIT’s position on ownership of intellectual property created by staff and students. This policy prescribes how RMIT declares and protects its rights and those of its staff, students and affiliates by detailing IP ownership and the conditions for protecting and commercialising IP.
(3)  RMIT recognises and respects the significance of Indigenous Culture and Intellectual Property (ICIP) creation, practices, innovations, and cultural expressions.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=2#document-top)
# Section 3 - Scope
(4)  The policy applies to all staff, students and affiliates of the University and its controlled entities (known as the RMIT Group).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=2#document-top)
# Section 4 - Policy
(5)  Protection and commercialisation of IP:
  1. protects the rights of RMIT and members of the RMIT Group in line with our commitment to Responsible Practice
  2. fosters an innovative culture in which the creation of IP and entrepreneurial endeavour are valued and rewarded
  3. enables use and exploitation of RMIT’s IP by industry, government and community for local, national and global benefit
  4. facilitates timely transfer of research to industry, government and community.


(6)  Excluding the copyright in scholarly works, RMIT asserts ownership of IP as follows:
  1. IP created: 
    1. by an employee of the RMIT Group in the course of their employment, or
    2. using RMIT resources, IP or funding, or 
    3. by a team including RMIT staff
  2. IP created by an affiliate of the RMIT Group where it involves the use of RMIT resources, IP or funding or is generated by a team including RMIT staff
  3. IP created by students who are also staff where the IP has been created in the course of their employment
  4. IP created by students under any research project or activity undertaken within RMIT or a third party collaborator of RMIT, except for student academic works.


(7)  In the absence of a specific agreement to the contrary, the author of scholarly works in clause 6 grants RMIT a perpetual, royalty free, non-exclusive licence to reproduce and use those scholarly works for the purposes of teaching and research.
(8)  In the absence of a specific agreement to the contrary, the author of course materials owned by RMIT has a non-exclusive, non-transferable, royalty-free licence to use such works for the purpose of their own teaching, education or research, and to release such works under an open licence (subject to clause 12 of the [Open Scholarship Policy](https://policies.rmit.edu.au/document/view.php?id=267) and clause 16 of the [Open Scholarly Works Dissemination Procedure](https://policies.rmit.edu.au/document/view.php?id=268)) but may not sub-licence or assign such works for any other purposes.
(9)  RMIT does not assert ownership over pre-existing intellectual property.
(10)  RMIT acknowledges the moral rights of the authors of IP in accordance with the [Copyright Act 1968](https://policies.rmit.edu.au/directory/summary.php?legislation=4) (Cth). 
(11)  For any work owned by RMIT in which moral rights may apply, the author of that work waives all moral rights the author may have in relation to that work, acknowledges that RMIT may amend that work without the consent of the author and consents to acts undertaken by or on behalf of RMIT which would otherwise infringe the moral rights of the author.
(12)  RMIT recognises the significance of Indigenous Cultural and Intellectual Property, and that it must be respected, protected and recognised. To that end, RMIT will ensure that:
  1. assignment of rights and interests and commercialisation practices related to IP recognise and protect the rights and interests of Indigenous Knowledge holders and custodians
  2. IP derived from or with Indigenous peoples (including Aboriginal and Torres Strait Islander individuals, communities or groups) recognises, respects and values connection to place
  3. IP commercialisation practices in Australia comply with the [AIATSIS Code of Ethics for Aboriginal and Torres Strait Islander Research](https://policies.rmit.edu.au/download.php?id=255&version=2&associated) and RMIT’s Indigenous Research Plan.


(13)  RMIT has the sole right to protect and commercialise any IP over which it asserts legal and beneficial ownership and may assign or license such IP to third parties, with the right to sub-license, unless otherwise agreed in writing.
(14)  RMIT endeavours to make decisions about the protection and commercialisation of IP in consultation with creators.
(15)  RMIT’s commercialisation of IP ensures due reward to members of the RMIT group who created the IP.
(16)  RMIT asserts legal and beneficial ownership of IP developed by students who are also staff where the IP has been created in the course of their employment, unless agreed otherwise in writing by the Deputy Vice-Chancellor Research and Innovation.
(17)  Disputes arising over IP are dealt with under the Intellectual Property Committee's Terms of Reference. 
### Responsibilities
(18)  The Deputy Vice-Chancellor Research and Innovation is responsible for the implementation of this policy.
(19)  The Intellectual Property and Commercialisation Team is responsible for the administration of the Intellectual Property Policy, for education and information relating to IP, for the commercialisation of RMIT’s IP, the management of RMIT’s IP assets, and the disbursement of net revenue.
### Review
(20)  This policy and related procedure will be reviewed every five years.
(21)  The procedure and resources associated with this policy may be reviewed at any time at the discretion of the Deputy Vice-Chancellor Research and Innovation.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=2#document-top)
# Section 5 - Procedures
(22)  [Intellectual Property Procedure](https://policies.rmit.edu.au/document/view.php?id=281).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=2#document-top)
# Section 6 - Definitions
Affiliates | Conjoint, adjunct, emeritus, honorary and visiting appointments of RMIT.  
---|---  
Background intellectual property | Any intellectual property owned by RMIT that exists at the time new intellectual property is created.  
Commercialise/ commercialisation | To exploit commercially and includes: 
  1. in relation to an IP right, the exercise of all the rights exclusively granted to the holder of such IP rights by the laws of the jurisdiction in which the IP right subsists, including where permitted the right to sub-license those rights.
  2. in relation to a product, kit, apparatus, substance, documentation or information resource (or any part of such materials), to make, distribute, market, sell, hire out, lease, supply, or otherwise dispose of it.
  3. in relation to a method or process, to use the method or process or to make, distribute, market, sell, hire out, lease, supply, or otherwise dispose of a product, kit or apparatus the use of which is proposed or intended to involve the exercise of the method or process.

  
Commercialisation revenue | The gross revenue received and retained by RMIT from the commercialisation and exploitation of speciﬁc IP owned by RMIT, after the payment of any withholding, goods and services or other taxes, bank fees, transaction fees and other charges. Commercialisation revenue does not include income received from the provision of research, consultancy or other services.   
Course materials | All materials produced in the course of, or for use in, teaching in any form and all IP in such materials, including but not limited to lectures, lecture notes and material, syllabi, study guides, assessment materials, images, multi-media presentations, web content, case studies and course software.  
Creator | Any of the following: 
  1. in the case of a patentable invention subject to the [Patents Act 1990](https://policies.rmit.edu.au/directory/summary.php?legislation=32) (Cth), the Inventor
  2. in the case of a literary or artistic work or similar subject to the [Copyright Act 1968](https://policies.rmit.edu.au/directory/summary.php?legislation=4) (Cth), the Author
  3. in the case of designs registrable under the [Designs Act 2003](https://policies.rmit.edu.au/directory/summary.php?legislation=33) (Cth), the Designer
  4. in the case of Plant Breeders Rights, under the [Plant Breeder's Rights Act 1994 (C'th)](https://policies.rmit.edu.au/directory/summary.php?legislation=34), the Principal Breeder
  5. in the case of circuit layouts, under the [Circuit Layouts Act 1989](https://policies.rmit.edu.au/directory/summary.php?legislation=30) (Cth), the Designer.

  
Indigenous Cultural and Intellectual Property | The rights that Indigenous peoples (including Aboriginal and Torres Strait Islander peoples) have, and want to have, to protect their Cultural and Intellectual Property. Sometimes the term ‘cultural heritage’ is used to mean the same thing. Refer to the [ICIP Information Sheet](https://www.artslaw.com.au/information-sheet/indigenous-cultural-intellectual-property-icip-aitb/) for a full list of the ICIP rights that must be considered in relation to this policy.  
Intellectual property (IP) | All statutory and other proprietary rights (including rights to require information be kept conﬁdential) in respect of inventions, copyright, trademarks, designs, patents, plant breeder's rights, circuit layouts, know-how, trade secrets, data, materials and all other rights as deﬁned by Article 2 of the Convention establishing the World Intellectual Property Organisation of July 1967, all rights to apply for the same and, for the avoidance of doubt, includes: 
  1. patents under the [Patents Act 1990](https://policies.rmit.edu.au/directory/summary.php?legislation=32) (Cth)
  2. copyright which subsists in original works under the [Copyright Act 1968](https://policies.rmit.edu.au/directory/summary.php?legislation=4) (Cth), including computer programs and data
  3. trade marks registered under the [Trade Marks Act 1995](https://policies.rmit.edu.au/directory/summary.php?legislation=35) (Cth)
  4. designs registered under the [Designs Act 2003](https://policies.rmit.edu.au/directory/summary.php?legislation=33) (Cth)
  5. new plant varieties under the [Plant Breeders’ Rights Act 1994](https://policies.rmit.edu.au/directory/summary.php?legislation=34) (Cth)
  6. circuit layouts (computer chips) under the [Circuit Layouts Act 1989](https://policies.rmit.edu.au/directory/summary.php?legislation=30) (Cth), and
  7. trade secrets and other conﬁdential material under Common Law.

  
Invention | Any IP that is patentable under the [Patents Act 1990](https://policies.rmit.edu.au/directory/summary.php?legislation=32) (Cth).  
Net revenue | The monetary amount retained by RMIT from the commercialisation revenue received from the commercialisation of IP after the legitimate claims of third parties are satisﬁed.  
Pre-existing intellectual property | Tangible IP that RMIT agrees is owned by a staﬀ member, a student or a third- party prior to the date of their employment or enrolment at RMIT.  
Scholarly works |  Any work or subject matter (other than course material and computer software) in any format in which copyright subsists and: (a) is created: (i) by an employee of the RMIT Group in the course of their employment, or (ii) using RMIT resources, IP or funding, or  (iii) by a team including RMIT staff, and (b) is intended for academic publication. Examples of scholarly works include journal articles, books, book chapters, and presentations for an academic or professional audience.  
Student academic works | Any work or subject matter other than works in any format in which copyright subsists, that is a student thesis or coursework.  
Specifically commissioned | Resources of the University and its controlled entities which includes without limitation facilities, funds, services, equipment, paid leave, staﬀ time and support staﬀ.  
University resources | Resources of the University and its controlled entities, which includes without limitation facilities, funds, services, equipment, paid leave, staﬀ time and support staﬀ.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
