[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=252&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=252&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course External Referencing and Benchmarking Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=252)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=252&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=252&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=252&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=252&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=252&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=252&version=1)


# Program and Course External Referencing and Benchmarking Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=252&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=252&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=252&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=252&version=1#section4)
  * [General Standards](https://policies.rmit.edu.au/document/view.php?id=252&version=1#major1)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=252&version=1#section5)
  * [Section 6 - Resources](https://policies.rmit.edu.au/document/view.php?id=252&version=1#section6)
  * [Section 7 - Definitions](https://policies.rmit.edu.au/document/view.php?id=252&version=1#section7)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure outlines RMIT’s approach to benchmarking and external referencing of programs and courses.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all accredited higher education award programs and courses offered by the RMIT Group, partners and affiliated third parties.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252&version=1#document-top)
# Section 4 - Procedure
### General Standards
(4)  RMIT supports its legislative requirements and ensures institutional quality assurance by performing external referencing and benchmarking activities as a core component of the Comprehensive Program Review cycle. The Centre for Academic Quality and Enhancement (CAQE) leads RMIT’s external referencing responsibilities and is responsible for the processes and practices supporting academic quality assurance.
(5)  External referencing is the process where a higher education provider compares an aspect of its operations with an external comparator. In the context of RMIT, external referencing is the degree to which Program Managers reflect outside their programs to inform the design, content and relevance of learning. It is undertaken as part of the Comprehensive and Annual Program Reviews. RMIT’s prescribed reference points for external referencing are set out in the [RMIT Comprehensive Program Review Terms of Reference](https://rmiteduau.sharepoint.com/sites/CAQE-Resource-Hub/SitePages/2022%20Program%20Reviews.aspx?csf=1&web=1&e=uB3lJf).
(6)  External referencing and benchmarking activities for courses are managed by course coordinators under the direction of Program Managers as part of ongoing course monitoring.
(7)  This procedure describes benchmarking activity in relation to programs and courses. Benchmarking may take place outside of program and course design and review activity to inform RMIT decisions or contextualise key data sets.
#### Comprehensive and Annual Program Reviews
(8)  The Comprehensive Program Reviews (CPR) are where external referencing and benchmarking activities are monitored and reported upon. Please refer to the [Program and Course Review Procedure](https://policies.rmit.edu.au/document/view.php?id=39).
#### Student Feedback and Success
(9)  RMIT is committed to working with students to improve the quality of learning and teaching experiences. Student staff consultative committees (SSCCs) are an RMIT requirement enabling students to provide feedback on their program to meet regulatory requirements. SSCCs empower students to provide real-time feedback, highlight best practice and have input into how their courses are taught and managed.
(10)  Guidance on the operational aspects of SSCCs can be found at the [Student Staff Consultative Committee resource page](https://rmiteduau.sharepoint.com/sites/CAQE-Resource-Hub/SitePages/SSCC%20Instructional%20Guide.aspx?csf=1&web=1&e=OJZcHb).
(11)  Program Managers and teams must demonstrate programs delivered in multiple locations and modes have mechanisms, practices, or processes in place to compare these measures across the different locations/modes. Best practice involves referencing the success of student cohorts against comparable courses of study within the program and across the discipline. This extends to the requirements of external referencing and benchmarking.
#### Internal and External Referencing and Benchmarking
(12)  External referencing with peer review, moderation and validation enables alignment with the wider academic community and other higher education providers. Comparison of key program features include assessment methods and grading with competitive programs at local and international institutions.
(13)  Broad types of benchmarking to be reported on in Program Reviews include:
  1. program or course internal benchmarking of program or course design and student performance
  2. internal process benchmarking involving comparisons of processes and practices, for example, of cycle times, efficiency
  3. external outcome benchmarking, relating to the comparison of outcomes data, especially student outcomes such as attrition, progression and completion rates
  4. internal best-practice benchmarking, where RMIT selects an equivalent comparator considered to be at the forefront in the area to be benchmarked
  5. external cohort analysis of student performance data
  6. external industry engagement and consultation aligning with best practices.


(14)  Peer review and validation includes:
  1. analysis of competing programs’ curriculum
  2. approach to delivery
  3. program learning outcomes
  4. collaboration between providers
  5. assessment methods
  6. grading guides.


(15)  External peer validation reports are to be provided as written evidence that meet the key criteria as detailed in the [External Peer Review Template](https://rmiteduau.sharepoint.com/:w:/r/sites/CAQE-Resource-Hub/_layouts/15/Doc.aspx?sourcedoc=%7B971FEA70-5274-4953-9CB0-E8CB13147BBF%7D&file=External-Peer-Review-template-final.docx&action=default&mobileredirect=true&wdLOR=c312017E4-32EE-48A7-9F26-B94244425E41&cid=d532ecc6-16bf-4a79-b452-eea676135ccf). Colleges are required to submit evidence and reflection in the Comprehensive Program Review referring to external course referencing, including a copy of the written validation report. At the completion of all Comprehensive Program Reviews the reflection and outcomes of external referencing will be included in CAQE’s subsequent report to Academic Board and its subcommittees.
(16)  Evidence from the following resources and activities can be provided with CAQE’s report, addressing the key criteria in the External Peer Review template: 
  1. the use of assessment panels made up of external academic subject matter experts on final or milestone assessments (capstone or equivalent course/s)
  2. peer review portal – external academic review of final or milestone assessments (capstone or equivalent course/s)
  3. Partner Peer options – utilising resources provided by CAQE that are available on the [CAQE Resource Hub – External Referencing and Benchmarking for Program Reviews.](https://rmiteduau.sharepoint.com/sites/CAQE-Resource-Hub/SitePages/2022-External-Referencing-and-Benchmarking.aspx?Mode=Edit) Program Managers and college quality teams have the option to use external academic peers to review and provide reports on the capstone or equivalent course/s
  4. professional accreditation reports
  5. other methods that have addressed all key criteria in the External Peer Review Template and can be evidenced.


#### Industry Advisory Committees and WIL Experiences
(17)  All RMIT programs must have an Industry Advisory Committee to meet the RMIT threshold for external referencing and to facilitate regular communication between RMIT programs and their associated industries and communities. Industry Advisory Committees enable essential external referencing and help to maintain the programs' relevance and currency.
(18)  Industry Advisory Committees advise RMIT on matters associated with the development, delivery and assessment of our programs.
(19)  Program Managers must demonstrate:
  1. how feedback gathered through Industry Advisory Committees and other industry consultation has been applied to further integrate industry content, skills, technologies, etc
  2. evidence on how programs assure the quality of Work Integrated Learning (WIL) arrangements with third parties, industry partners and the quality of supervision of student experiences
  3. how WIL experiences meet the minimum unit or course and credit point requirement as referred to in the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27)
  4. the exploration of mechanisms, practices or processes employed to gather and apply feedback from industry partners.


(20)  For further information on the formation and functionality of Industry Advisory Committees, refer to the [Industry Advisory Committee Guide for Program Reviews](https://rmiteduau.sharepoint.com/sites/CAQE-Resource-Hub/SitePages/IAC%20Instructional%20Guide.aspx?csf=1&web=1&e=sSX80y).
#### Industry Standards and Professional Accreditation
(21)  Program learning outcomes should be aligned to industry standards to evidence the quality and standing of the program. Programs that hold professional accreditation with peak industry bodies or organisations illustrate status, evidence and standing of professional accreditation. Professional accreditation that addresses all key criteria included in the External Peer Review Template can be used as evidence.
(22)  When reviewing a program or a course, coordinators can refer to industry and/or commission reports (i.e. Royal Commissions) on trends from industry and how these can be used to inform and validate course delivery. Aligning with the future ways of working with an industry program can offer an external evidence base as context for development and improvement which can positively impact student outcomes.
#### Program Enhancement Plans
(23)  Program Enhancement Plans (PEPs) are developed to apply improvements to programs following the submission of the Comprehensive Program Reviews. Annual Program Reviews include status updates which are completed by Program teams, led by Program Managers and endorsed by Deans or Heads of School and College Associate Deputy Vice-Chancellors, Learning and Teaching (or equivalent). For further information on Program Enhancement Plans, refer to the [CAQE Resource Hub](https://rmiteduau.sharepoint.com/sites/CAQE-Resource-Hub/SitePages/2022%20Program%20Reviews.aspx?csf=1&web=1&e=uB3lJf).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252&version=1#document-top)
# Section 5 - Schedules
(24)  The Program Review Schedule is reviewed and determined by College Quality teams and confirmed by Q1 of each cycle year. CAQE maintains the schedule for monitoring and reporting.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252&version=1#document-top)
# Section 6 - Resources
(25)  [Program and Course Review Procedure](https://policies.rmit.edu.au/document/view.php?id=39).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=252&version=1#document-top)
# Section 7 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Benchmarking | The process of externally comparing aspects of educational practices within the organisation and other institutions. Benchmarking reveals skills, trends, emerging influences or changes in industry and scholarship that may validate or challenge program design or delivery.  
Capstone or Equivalent | Final year course/s that encompasses overall program learning outcomes.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
