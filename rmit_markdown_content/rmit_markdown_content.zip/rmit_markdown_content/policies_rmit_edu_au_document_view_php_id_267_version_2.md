[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=267&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=267&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Open Scholarship Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=267)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=267&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=267&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=267&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=267&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=267&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=267&version=2)


# Open Scholarship Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=267&version=2#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=267&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=267&version=2#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=267&version=2#section4)
  * [Part A - Principles](https://policies.rmit.edu.au/document/view.php?id=267&version=2#part1)
  * [Part B - Responsibilities](https://policies.rmit.edu.au/document/view.php?id=267&version=2#part2)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=267&version=2#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=267&version=2#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  To set out RMIT’s commitment to the principles of open scholarship and the free and responsible flow of research, teaching and learning, transforming how our community discovers, accesses, shares, uses and creates knowledge.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=267&version=2#document-top)
# Section 2 - Overview
(2)  RMIT is committed to the responsible and widest possible dissemination of its research and educational scholarly output to foster intellectual enquiry that enriches our communities and the public through elevating an awareness of educational, scientific, social sciences, humanities and artistic knowledge. 
(3)  RMIT recognises and respects the significance of [Indigenous Cultural and Intellectual Property](https://www.artslaw.com.au/information-sheet/indigenous-cultural-intellectual-property-icip-aitb/) (ICIP) creation, practices, innovations, and cultural expressions.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=267&version=2#document-top)
# Section 3 - Scope
(4)  This policy applies to all staff, students, and affiliates, including conjoint, adjunct, emeritus, honorary and visiting appointments of the University and its controlled entities (known as the RMIT Group). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=267&version=2#document-top)
# Section 4 - Policy
## Part A - Principles
(5)  RMIT encourages University-generated scholarly outputs, ideas, and knowledge to be made open access without barriers to use and reuse. RMIT scholarly output should strive to be ‘open where possible, closed where necessary’ in consideration of contractual, confidentiality, ethical, Indigenous Knowledge Authority, and privacy restrictions and requirements.
(6)  Open scholarly practices recognise the reciprocal relationship between research and practice of teaching that enables impactful research, education, and learning. This benefits the economy, society, environment, and culture by:
  1. broadening engagement with scholarship
  2. driving greater impact of research and scholarly outputs
  3. increasing recognition of open scholarly publication for academic promotion purposes.


(7)  RMIT open scholarship practices adopt creative, innovative and responsible approaches to negotiating ownership of scholarly output wherever possible, while recognising and respecting contractual, confidentiality, ethical, Indigenous Knowledge Authority, intellectual property and privacy restrictions and requirements.
(8)  RMIT authors, where possible, align practice to the [Dissemination of Research Outputs Procedure](https://policies.rmit.edu.au/document/view.php?id=84) when entering into agreements and:
  1. retain copyright in their works, or
  2. publish under an open license (preferably within the Creative Commons licensing framework) and ensure they retain the right to use and self-archive without embargo.


#### Indigenous Cultural and Intellectual Property
(9)  RMIT recognises the significance of Indigenous Cultural and Intellectual Property, and that it must be respected, protected, and recognised. The University will ensure that:
  1. Open research and scholarly practices recognise and protect the rights and interests of Indigenous knowledge holders and custodians.
  2. Open research and scholarly practices with Aboriginal and Torres Strait Islander individuals, communities, or groups, recognise, respect and value connection to place.
  3. The open dissemination of scholarly practices aligns with the [AIATSIS Code of Ethics for Aboriginal and Torres Strait Islander Research](https://policies.rmit.edu.au/download.php?id=255&version=2&associated), [RMIT’s Indigenous Research Plan (2023-2025)](https://rmiteduau.sharepoint.com/:b:/r/sites/ResearchInnovationHub/Shared Documents/Strategy/Indigenous-Research-Plan-final.pdf?csf=1&web=1&e=gFe7Vh).


#### Intellectual Property
(10)  Protection and commercialisation of intellectual property (IP) is designed to foster an innovative culture where the creation of IP and entrepreneurial endeavour are valued and rewarded. Open scholarship enables the use and commercialisation of RMIT’s IP by industry, government, and community for local, national and global benefit.
(11)  RMIT encourages researchers and educators to disseminate scholarly output as widely as possible, subject to confidentiality, Indigenous Knowledge Authority, trade secrets, privacy and commercialisation restrictions.
(12)  Research or educational scholarly published output intended for commercialisation or containing confidential information should not be considered for open scholarly release or publication.
(13)  Ownership of intellectual property rights (including copyright) in scholarly works is governed by the [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23), and general law (including statute law and contracts).
  1. RMIT retains a perpetual, royalty free, non-exclusive licence to use scholarly works for educational and research purposes as defined within [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23), and subject to contractual obligations the creator owes to third parties (for example, a publisher of a journal article).
  2. In RMIT’s commitment to open scholarship, RMIT reserves a non-exclusive, perpetual, irrevocable, royalty-free licence to use and archive copies of scholarly works and to make them as widely available as possible, in exercise of the non-exclusive licence subject to contractual obligations the creator owes to third parties (for example, a publisher of a journal article).


(14)  In collaboration with consortia partners, the University Library seeks to improve equitable participation in the dissemination of scholarly output including but not limited to the following:
  1. enacting read and publish agreements to reduce or remove article processing charges (APCs) for University researchers
  2. negotiating to improve the value of transformative (read and publish) agreements.


#### Research
(15)  RMIT is committed to open and responsible dissemination of publicly funded research output and providing open access to the public, government, industry partners and developing countries, while respecting any restrictions on dissemination. This commitment will lead to increased research visibility and impact.
  1. RMIT supports compliance with the University’s obligations under the contracts, funding rules and open access policies of the [Australian Research Council (ARC)](https://www.arc.gov.au/about-arc/program-policies/open-access-policy), [National Health and Medical Research Council (NHMRC)](https://www.nhmrc.gov.au/about-us/resources/nhmrc-open-access-policy), national or international funding bodies.
  2. Open access publication and dissemination of research findings must align with the [Dissemination of Research Outputs Procedure](https://policies.rmit.edu.au/document/view.php?id=84) and embody the principles of honesty, rigour, transparency, fairness, recognition, and accountability of the [Australian Code for Responsible Conduct of Research, 2018](https://www.nhmrc.gov.au/about-us/publications/australian-code-responsible-conduct-research-2018), and [RMIT Values](https://www.rmit.edu.au/about/our-values). 


(16)  RMIT supports the [Policy Statement on FAIR (Findable, Accessible, Interoperable and Reusable) Access to Australia’s Research Outputs](https://www.fair-access.net.au/fair-statement) and the [CARE Principles for Indigenous Data Governance](https://static1.squarespace.com/static/5d3799de845604000199cd24/t/5d79c383e904c741c9e9cd86/1568260995760/CARE+Principles+for+Indigenous+Data+Governance_FINAL_Sept+06+2019.pdf) in the open and responsible dissemination of research data.
#### Teaching
(17)  RMIT is committed to the widest possible dissemination of educational scholarly output to promote critical and free enquiry, transforming how our communities discover, share, use and create knowledge.
(18)  RMIT supports the creation and adoption of open educational resources where they are of high quality, contextually relevant and enhance student learning in preference to the adoption of commercially published educational resources.
(19)  RMIT affirms open scholarly practices in education as a model of innovative pedagogy to enhance the quality of the student experience and reflect the principles of equity, inclusion, and social justice. 
(20)  RMIT strives to embed the principles of social justice, equity and inclusion within scholarly teaching practice and commits to the [Diversity and Inclusion Framework and Action Plans](https://www.rmit.edu.au/about/our-values/diversity-and-inclusion).
(21)  Educators are encouraged to apply a Creative Commons licence to their teaching materials and share via appropriate open platforms.
(22)  The creation, publication and underlying pedagogy of open educational resources will be compliant with the recommended standards outlined in the [TEQSA Higher Education Standards Framework (2021)](https://policies.rmit.edu.au/download.php?id=295&version=1&associated) and the [Program and Courses Policy](https://policies.rmit.edu.au/document/view.php?id=27). 
## Part B - Responsibilities
(23)  The Deputy Vice-Chancellor Education is responsible for this policy and may delegate this responsibility.
(24)  Researchers, educators and others in relevant roles are required to comply with all applicable: 
  1. Laws enacted by the Commonwealth, States or Territories in Australia and/or in other countries
  2. Institutional policies and professional or disciplinary standards and codes of practice
  3. RMIT policies, including but not limited to: 
    1. [Intellectual Freedom Policy](https://policies.rmit.edu.au/document/view.php?id=56)
    2. [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52) (staff)
    3. [Intellectual Property Policy](https://policies.rmit.edu.au/document/view.php?id=23)
    4. [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28)
    5. [Inclusion, Diversity, and Equity Policy](https://policies.rmit.edu.au/document/view.php?id=93)
    6. [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12)
    7. [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27)
    8. [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91)
    9. [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59)
    10. [Sustainability Policy](https://policies.rmit.edu.au/document/view.php?id=103)
    11. [Authorship of Research Outputs Procedure](https://policies.rmit.edu.au/document/view.php?id=83)
    12. [Research Integrity Breach Management Procedure](https://policies.rmit.edu.au/document/view.php?id=30)
    13. [Dissemination of Research Outputs Procedure](https://policies.rmit.edu.au/document/view.php?id=84)
    14. [Research Data Management Procedure](https://policies.rmit.edu.au/document/view.php?id=86)
    15. [Disclosing and Exploiting Intellectual Property Process](https://policies.rmit.edu.au/document/view.php?id=24)
    16. [Corporate Social Responsibility Framework](https://policies.rmit.edu.au/document/view.php?id=104)
    17. [RMIT’s Indigenous Research Plan (2023-2025)](https://rmiteduau.sharepoint.com/:b:/r/sites/ResearchInnovationHub/Shared Documents/Strategy/Indigenous-Research-Plan-final.pdf?csf=1&web=1&e=gFe7Vh).

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=267&version=2#document-top)
# Section 5 - Procedures and Resources
(25)  Refer to the following documents which are established in accordance with this policy:
  1. [Open Scholarly Works Dissemination Procedure](https://policies.rmit.edu.au/document/view.php?id=268)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=267&version=2#document-top)
# Section 6 - Definitions
(26)  (Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition  
---|---  
Accepted manuscript | Is a version of a research output that must have been through the peer review process, and must have been accepted for publication, and all proposed changes to it must have been made  
Indigenous Knowledge Authority | Is a traditional knowledge custodian who must be an Aboriginal or Torres Strait Islander person or persons who has a relationship with that traditional knowledge  
Indigenous Cultural and Intellectual Property (ICIP) | Indigenous Cultural and Intellectual Property refers to the rights that Aboriginal and Torres Strait Islander peoples have, and want to have, to protect their Cultural and Intellectual Property. Sometimes the words ‘Cultural Heritage’ are used to mean the same thing. Refer to the [ICIP Information Sheet](https://www.artslaw.com.au/information-sheet/indigenous-cultural-intellectual-property-icip-aitb/) for a full list of the ICIP rights that must be considered in relation to this policy.  
Indigenous traditional knowledge | Is cultural practices, resources and knowledge systems that have been developed, nurtured and refined for generations by Indigenous people, and is an expression of cultural identity which may include distinctive signs, symbols, practices, know-how and skills  
Open educational resources | Are teaching practices, techniques and tools that will foster knowledge creation and sharing in an open environment  
Open licence | Is a copyright licence that grants permission for the distribution, access, use, and reuse of a copyright work with limited or no restrictions  
Open research practices | Are research practices that will enable and promote collaboration, transparency and reproducibility throughout the entire research lifecycle  
Open scholarly practices | Are a range of educational and research practices through which knowledge and scholarly resources are openly disseminated  
Open scholarship | Is the creation and sharing of knowledge in the educational and research scholarly environment that will encompass openness  
Scholarly educational output | Is any work that is openly published, such as texts, teaching resources, quizzes, images and videos, and other learning materials that can be shared and reused  
Scholarly impact | Is the influence and effect that knowledge and scholarly resources have on the world and will include all aspects of educational and research impact  
Scholarly research output | Is a traditional or non-traditional research output and may include academic journal articles, books, conference papers, exhibitions, presentations, performances, media interviews, theses, research data  
Self-archive | Is a process where an author will deposit a free copy of a scholarly output online to provide open access to it  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
