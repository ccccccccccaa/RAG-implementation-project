[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=107&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=107&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Contract Management Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=107)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=107&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=107&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=107&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=107&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=107&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=107&version=2)


# Contract Management Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=107&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=107&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=107&version=2#section3)
  * [Application](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major1)
  * [Terminology](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major2)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=107&version=2#section4)
  * [Phase 1: Identification and Planning](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major3)
  * [Phase 2: Review and drafting](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major4)
  * [Phase 3: Approvals and confirmation](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major5)
  * [Phase 4: Signature and execution](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major6)
  * [Phase 5: Recording](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major7)
  * [Phase 6: Management](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major8)
  * [Phase 7: Variation or extension](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major9)
  * [Phase 8: Expiry or termination](https://policies.rmit.edu.au/document/view.php?id=107&version=2#major10)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure outlines the approach for staff across RMIT and its controlled entities to prepare, establish, negotiate, and manage contracts. This procedure enables RMIT to:
  1. apply a consistent approach to contracting
  2. manage the risk associated with contracts, while maximising the benefits, and
  3. ensure obligations under contracts are performed.


(2)  In this procedure, the term ‘contracting activities’ includes how contracts are negotiated, approved, delivered, and managed.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=107&version=2#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Contract Management Policy](https://policies.rmit.edu.au/document/view.php?id=69).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=107&version=2#document-top)
# Section 3 - Scope
### Application
(4)  This procedure applies across the RMIT Group, including controlled entities, unless otherwise stated. All international RMIT Group entities must also comply with any applicable country-specific requirements. 
(5)  This procedure applies to all agreements or contracts RMIT makes with an external party or person, except for: 
  1. Employment contracts, agreements or deeds within the scope of the [People team](https://www.rmit.edu.au/staff/rmit-structure/operations/people)
  2. [Work Integrated Learning](https://policies.rmit.edu.au/download.php?id=164&version=3&associated) (WIL) Agreements, which are covered by the [Program and Course Work Integrated Learning Procedure](https://policies.rmit.edu.au/document/view.php?id=119)
  3. terms and conditions between RMIT Group entities and individual students, including where RMIT enrols a student in either accredited or non-accredited courses, which are covered by academic, enrolment and student related policies (e.g. refund policies). This procedure does apply to contracts which relate to the provision of education, such as partner agreements, or third-party delivery agreements.


(6)  Contracts and contracting activities which are covered by this procedure include all other contracts that create legally binding obligations, including financial, non-financial, lease agreements, dispute settlements and agreements between RMIT Group entities. 
### Terminology
(7)  For the purpose of this procedure, the term “Contract Manager” is a generic term to describe a role which has a set of functions and responsibilities, and not a specific departmental position or job title.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=107&version=2#document-top)
# Section 4 - Procedure
(8)  Contracting activities must comply with all applicable laws and regulations and other RMIT policies and procedures to be consistent with the objects of RMIT under the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20) (Vic). 
(9)  The following phases of the contracting process must be followed and support RMIT strategy:
Phase 1: Identification and planning
Phase 2: Review and drafting
Phase 3: Approvals and confirmation
Phase 4: Signature and execution
Phase 5: Recording
Phase 6: Management
Phase 7: Variation or extension
Phase 8: Expiry or termination
### Phase 1: Identification and Planning
(10)  The identification and planning process commences when an RMIT team identifies that there is:
  1. a need to engage someone external to RMIT to supply services or products to RMIT
  2. an opportunity to supply services or products to an entity outside of RMIT
  3. a need to document or commit to an arrangement formally
  4. a third-party proposal for a contractual relationship.


(11)  A Contract Owner who is accountable for the contract must be appointed for each contract. A Contract Owner may appoint a Contract Manager to support in the management or administration of the contract. Even if a Contract Owner delegates certain tasks to the Contract Manager, the Contract Owner remains accountable for the outcomes of the contract.
(12)  The Contract Owner must comply with the [Procurement and Expenditure Policy](https://policies.rmit.edu.au/document/view.php?id=221) including the engagement of [Procurement](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/procurement) for all third-party expenditure contracts within the scope of that policy that meet or exceed Strategic Sourcing thresholds per [Procurement Schedule 1 – Purchasing Threshold (Australia and Vietnam)](https://policies.rmit.edu.au/document/view.php?id=223). 
(13)  The Contract Owner must undertake due diligence to ensure other parties to the contract are appropriate for RMIT to engage with. Due diligence helps inform planning for proposed contracts by assessing the background and suitability of other contracting parties including their organisational capabilities, financial strength, and reputational standing. The extent to which due diligence is undertaken will depend on the nature and value of the proposed contract.
(14)  Input and advice should be sought from the relevant specialist teams during the planning phase, including for due diligence. The specialist teams may be [Procurement](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/procurement), [](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/central-finance-operations)[Central Finance](https://policies.rmit.edu.au/download.php?id=490&version=1&associated), [Enterprise Risk Management](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/risk-management), [Information Technology Services](https://www.rmit.edu.au/staff/rmit-structure/operations/its),[Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services), [Research Strategy and Services](https://www.rmit.edu.au/staff/rmit-structure/research-innovation/strategy-services), [Health, Safety and Wellbeing](https://www.rmit.edu.au/staff/service-connect/safety-wellbeing/workplace-safety/process-guidance), [Sustainability](https://www.rmit.edu.au/staff/our-rmit/sustainability) and [Central Compliance](https://www.rmit.edu.au/staff/service-connect/compliance-process/compliance).
### Phase 2: Review and drafting
(15)  Contract documents can either be:
  1. provided by the other party, or
  2. provided by the RMIT [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) (RMIT Terms) to the Contract Owner or relevant appointed teams. RMIT’s standard terms include our [Purchase Order Terms and Conditions](https://www.rmit.edu.au/utilities/po-terms).


(16)  All contracts that RMIT enters into must either be on RMIT Terms or reviewed by RMIT Legal Services Group, unless otherwise advised by Legal Services Group.
(17)  Contracts must be reviewed by [Legal Services](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) if they meet any of the following criteria:
  1. Strategic Sourcing contracts as defined in the [Procurement Schedule 1 – Purchasing Threshold (Australia and Vietnam)](https://policies.rmit.edu.au/document/view.php?id=223)
  2. contracts which are on third party terms
  3. contracts which are on RMIT Terms, but where the other side seeks amendments to the terms, or
  4. where approval or signature is required by a VCE member or a person with delegation level 1 or higher in accordance with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).


(18)  Contracts that do not require review by [Legal Services](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) include:
  1. Non-Disclosure Agreements which are on RMIT Terms, with no amendments to the legal terms
  2. Memorandum of Understanding which are expressly stated to not contain legal obligations, which are non-binding, and are on RMIT Terms
  3. contracts where [Legal Services](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) has advised in writing that legal review is not required either for a specific contract, or a defined category of contracts, within specific parameters. For example, the [Research Contracts Team](https://www.rmit.edu.au/staff/rmit-structure/research-innovation/strategy-services) must follow the RCT Legal Referral Checklist when assessing whether review by the [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) is required for a research contract.


(19)  In Vietnam, the RMIT Vietnam Legal and Compliance team set the criteria for non-research related contracting activities that require advice and legal support. For research contracts, the Research Contracts Team must be engaged. 
(20)  In Europe:
  1. for research contracts, RMIT EU must contact the [Research Contracts Team](https://www.rmit.edu.au/staff/rmit-structure/research-innovation/strategy-services), who will brief the [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) if needed
  2. for all other contracts (including non-research contracts), RMIT Europe should seek local legal advice.


(21)  For contracts involving the Strategic Sourcing team in Procurement, generally the [Procurement team](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/procurement) negotiates the commercial aspects of the proposal or tender, and the [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) at RMIT Australia or Legal and Compliance team at RMIT Vietnam negotiates the contractual documents in consultation with Procurement and other internal stakeholders, including the Contract Owner.
(22)  Where RMIT is required to comply with Key Performance Indicators (KPIs) or Service Level Agreements (SLAs), the Contract Owner must ensure that their delivery under the contract is structured and resourced to meet or exceed those metrics. RMIT must not enter contracts which contain KPIs, SLAs, milestones, and deliverables which it is at risk of not meeting.
### Phase 3: Approvals and confirmation
(23)  The [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51) stipulates the roles which can authorise contracting activities. Due to the nature of a contract, including its value, risks, and subject matter, several other RMIT staff members may be required to approve a contract before it receives the final signature of approval.
(24)  Before communicating to the other party that a set of terms or conditions are acceptable to RMIT, the Contract Owner must obtain the approval in writing of relevant internal stakeholders and subject matter experts (as per the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51)). The [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) can direct the Contract Owner on the specific approvals required for a contract.
(25)  Contract Owners must ensure they have approval from the [](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/central-finance-operations)[Central Finance](https://policies.rmit.edu.au/download.php?id=490&version=1&associated) team or the relevant College or Portfolio if the contract will require additional funding or changes to a budget, managing tax compliance (local and international as relevant), foreign exchange or currency risk, payment terms, or other financial structuring issues.
(26)  Before entering into certain types of contracts, RMIT may be required by law to review and assess the contracts and notify relevant authorities of RMIT’s intent to enter that contract. Instances of this include notifications to the Department of Foreign Affairs and Trade by the RMIT [Foreign Relations Management team](https://www.rmit.edu.au/staff/service-connect/compliance-process/compliance/foreign-relations-act), and Notifications to the Tertiary Education Quality and Standards Agency by the RMIT [Education Regulation Compliance and Assurance (ERCA) Team](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/risk-audit-compliance).
### Phase 4: Signature and execution
(27)  Prior to the commencement of a contract, the Contract Owner must ensure that the Contract Signatory has approved and signed the contract in accordance with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).
(28)  The Contract Signatory must be satisfied with the advice, guidance, and approvals in relation to the contract before signing it on behalf of RMIT.
(29)  The following contracts must be signed via the Central Contracts team:
  1. contracts which are required by the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51) to be signed by a VCE member, or a person in a role with level 1 or higher delegation of authority (or their subdelegate)
  2. or as otherwise advised by [Legal Services](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services).


(30)  The Legal and Compliance team in RMIT Vietnam, and local European law firms for RMIT Europe, advise on separate processes that govern contracting in their respective jurisdictions.
### Phase 5: Recording
(31)  The final signed copies of all contracts must be uploaded in [](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Content-Manager-\(TRIM\).aspx)[TRIM](https://policies.rmit.edu.au/download.php?id=379&version=1&associated), RMIT’s Record Management System, and document repository for contracts as per [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
  1. Where a contract has been signed via the [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services), a member of the [Central Contracts](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services/central-contracts) team will upload it into [](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Content-Manager-\(TRIM\).aspx)[TRIM](https://policies.rmit.edu.au/download.php?id=379&version=1&associated).
  2. Where a contract is signed in any way other than via the [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) the Contract Owner is responsible for ensuring it is uploaded into [](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Content-Manager-\(TRIM\).aspx)[TRIM](https://policies.rmit.edu.au/download.php?id=379&version=1&associated).


(32)  For financial non-research contracts, the Contract Owner must ensure that a contract is uploaded and recorded in [Workday](https://www.rmit.edu.au/staff/service-connect/facilities-technology/it/systems/workday/guides) by completing the relevant Finance [Service Connect form](https://rmititsm.service-now.com/sp?id=sc_cat_item&sys_id=e3a0558adbf3d05093ec42a0149619c6) and accurately reflecting the key features of the contract so that:
  1. purchase order can be raised, and invoices paid against an expense contract;
  2. invoices can be raised and sent to customers for revenue contracts


(33)  For financial research contracts relating to research projects, the contract data can be uploaded to [](https://www.rmit.edu.au/staff/service-connect/facilities-technology/it/systems/workday/guides)[Workday](https://policies.rmit.edu.au/download.php?id=378&version=1&associated) by [](https://www.rmit.edu.au/staff/rmit-structure/operations/finance-governance/central-finance-operations)[Central Finance](https://policies.rmit.edu.au/download.php?id=490&version=1&associated) via the [Awards Management team](https://www.rmit.edu.au/staff/rmit-structure/research-innovation/strategy-services). 
(34)  The Contract Owner must ensure other key information is recorded and managed in systems which are relevant to their College or Portfolio (e.g. Salesforce, Research Master or [](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Content-Manager-\(TRIM\).aspx)[TRIM](https://policies.rmit.edu.au/download.php?id=379&version=1&associated)) including, but not limited to, milestone dates, name and contract details of the other party, RMIT’s key personnel, and any related contracts in line with [Data Quality Standard](https://policies.rmit.edu.au/document/view.php?id=229).
### Phase 6: Management
(35)  The Contract Owner is accountable for:
  1. monitoring and managing performance for both RMIT and the other parties to the contract
  2. ensuring RMIT and the third parties comply with the contract, including monitoring and reporting on performance metrics, meeting key milestones, and the achievement of payment, service, and delivery obligations under the contract
  3. ensuring maintenance of records about the contract delivery and performance, or any other significant events or circumstances regarding the contract, such as notifications from the other party, invoices and purchase orders created or received, and payments made or received
  4. ensuring identification, recording and management of risks identified during performance of the contract in compliance with RMIT’s [Risk Management Policy](https://policies.rmit.edu.au/document/view.php?id=60).
  5. managing the relationship with the other party, including ensuring appropriate communication mechanisms and expectations are established, and, if appropriate, an escalation process to respond to or manage issues under the contract
  6. ensuring other contract stakeholders in RMIT are informed about relevant activities or issues under the contract, including any non-compliance or breaches
  7. ensuring handover and transition of duties related to the contract in instances where the Contract Owner or Contract Manager departs RMIT.


(36)  The Contract Owner or appointed teams must engage the [Legal Services Group](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) (or, for research contracts, the [Research Contracts Team](https://www.rmit.edu.au/staff/rmit-structure/research-innovation/strategy-services)) if they require advice on: 
  1. the interpretation of the contract.
  2. actual or potential breaches of the contract
  3. changes or amendments which either RMIT or the other party want to make to the contract
  4. any disputes or disagreements with the other party which could have a material impact on the delivery or performance of the contract.


(37)  It is important that the parties do not unintentionally change the terms of a contract through their conduct or behaviour, or by letting it be delivered or performed differently to how it was agreed, if doing so has a negative or serious impact on one of the parties.
### Phase 7: Variation or extension
(38)  Changes to the terms of a contract can only come into effect through a formally documented variation or amendment. Negotiating, agreeing, and signing a variation should be done in the same way as a contract, or via an appointed team in line with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).
(39)  Where a change to a contract alters the recorded data about that contract, the Contract Owner must ensure that the change is also reflected in all relevant contract record systems (e.g. [](https://www.rmit.edu.au/staff/service-connect/facilities-technology/it/systems/workday/guides)[Workday](https://policies.rmit.edu.au/download.php?id=378&version=1&associated) and Salesforce) and [](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Content-Manager-\(TRIM\).aspx)[TRIM](https://policies.rmit.edu.au/download.php?id=379&version=1&associated) in line with [Data Quality Standard](https://policies.rmit.edu.au/document/view.php?id=229).
(40)  Before a contract is varied or extended, Contract Owners are responsible for ensuring that contract spends are kept within the set spend limits of any associated head agreement and the spend limits of the Contract Signatory per the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51).
### Phase 8: Expiry or termination
(41)  The Contract Owner is accountable for ensuring that when a contract is approaching its expiry, a decision is made about whether the contract should be allowed to expire, be amended, or extended.
(42)  If RMIT seeks to end or terminate a contract before its stated expiry date, the Contract Owner must engage [Legal Services](https://www.rmit.edu.au/staff/service-connect/compliance-process/legal-copyright-privacy/legal-services) to seek advice, and ensure that this change is reflected in all relevant contract record systems and [](https://rmiteduau.sharepoint.com/sites/Analytics%26Insights/SitePages/Content-Manager-\(TRIM\).aspx)[TRIM](https://policies.rmit.edu.au/download.php?id=379&version=1&associated).
(43)  When a contract expires or is otherwise ended, the Contract Owner must manage the operational implications and relevant risks and consequences for RMIT by ensuring that the appropriate transition or exit arrangements are planned and complied with.
(44)  For the close-out of a contract, the Contract Owner must consider:
  1. completing handover activities and managing any remediation issues
  2. managing the return of physical property or equipment, or security or access passes or tokens, closing or deactivating access accounts
  3. ensuring intellectual property rights are managed in accordance with the agreed contract terms
  4. finalising outstanding financial payment obligations, invoices or acquittals, or other management of securities such as bank guarantees and items held in escrow
  5. reporting or meeting other compliance obligations, such as updating external or internal registers or notifying regulators or other relevant authorities
  6. effecting or confirming the return or destruction of contract materials, such as confidential information with the other party
  7. any other steps necessary in relation to RMIT’s obligations or rights following the end of the contract.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
