[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=23&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=23&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Intellectual Property Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=23)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=23&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=23&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=23&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=23&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=23&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=23&version=1)


# Intellectual Property Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=23&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=23&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=23&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=23&version=1#section4)
  * [Pre-existing IP](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major1)
  * [Details of IP ownership](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major2)
  * [Assignment of IP Rights](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major3)
  * [Protection and Commercialisation of IP](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major4)
  * [Attribution](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major5)
  * [Dispute Resolution](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major6)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major7)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=23&version=1#major8)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=23&version=1#section5)
  * [Section 6 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=23&version=1#section6)
  * [Section 7 - Definitions](https://policies.rmit.edu.au/document/view.php?id=23&version=1#section7)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  To describe the rights, roles and responsibilities of the University, staff, affiliates and students in relation to intellectual property (IP).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=1#document-top)
# Section 2 - Overview
(2)  RMIT Statute No, 1 Part 10 states the University’s position on ownership of intellectual property created by staff and students. This policy prescribes how RMIT declares and protects the rights of the University and its staff, students and affiliates by detailing IP ownership, and the conditions for protecting and commercialising IP.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=1#document-top)
# Section 3 - Scope
(3)  The policy applies to all staff, students and affiliates, including conjoint, adjunct, emeritus, honorary and visiting appointments of the University and its controlled entities (known as the RMIT Group).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=1#document-top)
# Section 4 - Policy
(4)  Protection and commercialisation of IP:
  1. protects the rights of RMIT and members of the RMIT Group
  2. fosters an innovative culture which the creation of IP and entrepreneurial endeavour are valued and rewarded
  3. enables use and exploitation of RMIT’s IP by industry, government and community for local, national and global benefit
  4. facilitates timely transfer of research to industry, government and community.


(5)  RMIT asserts ownership of IP as follows:
  1. IP created by an employee of the RMIT Group in or during their employment is the property of RMIT.
  2. IP created by an affiliate of the RMIT Group is the property of RMIT where it involves the use of University resources, IP or funding or is generated by a team including RMIT staff.
  3. IP developed by students who are also staff where the IP has been developed as a direct result of their employment.
  4. Where students agree to be involved in research activities that could lead to the development of IP over which RMIT, or a third-party may claim ownership or other rights.


(6)  RMIT recognises the moral rights of the creators of IP in accordance with the [Copyright Act 1968](https://policies.rmit.edu.au/directory/summary.php?legislation=4) (Cth). These include the right of fair attribution of authorship or invention, the need for work not to be altered or used in such a way that it harms the reputation of the creator, and an opportunity for the creator to be involved in determining the final outcome of their labours.
(7)  RMIT recognises the significance of Indigenous Traditional Knowledge. The heritage of Indigenous people is a living one and includes items that may be created in the future, based on that heritage. Consistent with RMIT's recognition of the significance of Indigenous Traditional Knowledge, the University will:
  1. not commercialise IP developed using Indigenous Cultural and Traditional Knowledge without the approval and involvement of the holders of such Indigenous Cultural and Traditional Knowledge
  2. ensure the equitable sharing of benefits arising from Indigenous Traditional Knowledge
  3. acknowledge the source of the traditional knowledge from which such IP is derived.


(8)  RMIT will have the sole right to protect and commercialise any IP over which it asserts legal and beneficial ownership and may assign or license such IP to third parties, with the right to sub-license, unless otherwise agreed in writing.
(9)  RMIT will endeavour to make decisions about the protection and commercialisation of IP in consultation with creators.
(10)  Commercialisation of IP will ensure due reward to members of the RMIT group who created the IP.
### Pre-existing IP
(11)  RMIT does not assert ownership over pre-existing intellectual property subject to clause 12.
(12)  Staff and students must advise the Deputy Vice-Chancellor Research and Innovation of the existence of pre-existing IP as soon as possible following employment or enrolment. If no such advice is received by the Deputy Vice-Chancellor Research and Innovation, then any IP developed or disclosed during the period of employment or enrolment will be treated as University owned IP.
### Details of IP ownership
#### RMIT Employees
(13)  IP created by staff in or during their employment is the property of RMIT unless agreed in writing by the Vice-Chancellor, Deputy Vice-Chancellor Research and Innovation, and Deputy Vice-Chancellor Education. This includes the generation, creation or realisation of any act, work, research or idea by reason of:
  1. the use of University resources
  2. participation in any project or program supported by funding obtained or provided by the University;
  3. a course of research being undertaken at the University, either in collaboration with other Staff members or any third-party; or
  4. where the creation incorporates or uses background intellectual property.


#### Affiliates
(14)  Unless agreed in writing by the Vice-Chancellor, Deputy Vice-Chancellor Research and Innovation, and Deputy Vice-Chancellor Education, IP created by affiliates is the property of RMIT where:
  1. generation of the IP has required use of University resources
  2. generation of the IP has resulted from the use of background IP owned by RMIT
  3. the IP is a component of IP generated by a team of which this person is a member and other members are members of the RMIT group
  4. the IP has been generated as a result of any funding provided by or obtained by the RMIT
  5. requires the use of existing University IP.


#### Students
(15)  Unless agreed in writing by the Vice-Chancellor and Deputy Vice-Chancellor Research and Innovation, RMIT asserts legal and beneficial ownership of IP developed by students who are also staff where the IP has been developed as a direct result of their employment.
(16)  Where students agree to be involved in research activities that could lead to the development of IP over which RMIT, or a third-party may claim ownership or other rights:
  1. the supervisor or course coordinator will make it clear to students what the nature of the work and the conditions of their involvement are before they undertake the research activity
  2. participation in the research will not interfere with the assessment of the student's academic performance
  3. any confidentiality and/or IP assignment agreement should only be signed by students after they have been first advised to obtain independent advice
  4. the student must formally assign, in advance, all right, title and interest they may have in any IP to the University before the student will be permitted to engage in such research
  5. the student's copyright and moral rights in any thesis or publications arising from the research will be retained by the student, unless subject to a third-party agreement
  6. the student will receive consideration and other rights commensurate with those that a staff member would otherwise have under the policy, unless subject to a third-party agreement
  7. subject to the confidentiality provisions that may be contained in any third-party agreement, the student's future career choices will not be restricted by the choice to work in a confidential area of research
  8. any delays in publication of the thesis or any part thereof that arise from a confidentiality and/or assignment agreement will be limited to a maximum of two years, unless otherwise approved by the Deputy Vice-Chancellor Research and Innovation.


(17)  Where students may be involved in research carried out at institutions which are affiliated with RMIT or at other institutions independent of RMIT and where RMIT does not assert ownership of IP, agreement must be reached in writing between the student and the host institutions regarding the rights of the student to IP.
#### Course Materials and Scholarly Works
(18)  RMIT does not assert ownership of any IP in scholarly books, journal articles, or other scholarly works or subject matter generated (whether in written or any other form) by staff or students, except where the work is speciﬁcally commissioned by RMIT or produced with the assistance of University resources.
(19)  The creator grants to RMIT a perpetual, royalty free, non-exclusive licence to use such scholarly books, journal articles, course materials, or other scholarly works or subject matter generated by that creator for RMIT’s teaching and research purposes.
  1. The non-exclusive licence to use such scholarly books, journal articles, course materials, or other scholarly works or subject matter persists should the creator leave RMIT.
  2. This licence is subject to any overriding contractual obligations the creator owes to third parties (for example, a publisher of a journal article), provided the creator informs the University of such obligations.


(20)  In the absence of a specific agreement to the contrary, the creator of the course materials has a non-exclusive, non-transferable, free licence to use such works for the purpose of their own teaching, education or research at other educational institutions, but may not:
  1. sub-license or assign such materials
  2. use them to generate royalties or licence fees.


(21)  RMIT may, at its discretion, give the creator(s) of specifically commissioned course materials a non-exclusive licence to use the course materials for teaching purposes, provided that such a licence will not extend to the use of the course materials for any purpose which is in direct competition with RMIT.
(22)  Where RMIT does not wish to commercialise specifically commissioned course materials and advises the creator(s) accordingly, the creator(s) may request the assignment of the ownership rights of those course materials to the creator(s) or any one of them. RMIT will retain a non-exclusive licence for educational purposes.
#### Artistic, Musical, Dramatic or Creative Works
(23)  RMIT does not assert any right or claim to ownership of the IP in artistic, musical, dramatic or other creative works created or composed by its staff or students, except where these works have been specifically commissioned by RMIT or are created in whole or in part with the use of University resources.
(24)  Any work which may be considered to be both creative work and course materials will be treated as course materials for the purposes of this policy.
### Assignment of IP Rights
(25)  At the request of RMIT, staff and students must assign to the University all IP in a timely manner and execute all such deeds of assignment and other documentation necessary to give effect to the IP ownership, protection, use, and commercialisation provisions set out in this policy.
(26)  No staff member or student may act on behalf of RMIT, or act in their own name, to assign, license, protect or otherwise deal with IP which is the property of RMIT or over which RMIT asserts rights under this policy, unless specifically delegated to do so in writing.
(27)  Where a student owns IP and there are no other staff or student creators, a student may in their own name, assign, license, protect or otherwise deal with that IP in accordance with the Disclosing and Exploiting Intellectual Property Process.
(28)  Students are required to assign their IP rights to RMIT where:
  1. the IP consists of course materials
  2. has been assigned to RMIT under a specific agreement
  3. has been jointly developed with staff and the student is deemed to be a co-creator
  4. is the subject of an existing agreement between RMIT and a third party.


(29)  Students involved in research activities that could lead to the development of IP over which RMIT or a third-party may claim ownership or other rights must formally assign, in advance, all IP to RMIT before engaging in research, in return for the same IP benefits that a staff member would have under the policy, unless subject to a third-party agreement.
(30)  Supervisors electing to supervise a student in an area whose research activities are covered by third-party agreements must ensure a confidentiality and IP assignment agreement is completed between RMIT and the student before the work is commenced.
(31)  Some projects may not be available to students who choose not to sign a confidentiality and/or IP assignment agreement.
(32)  Despite any contrary provision in this policy, all existing legally binding contracts, deeds and agreements entered into by RMIT at the effective date of this policy, will remain in full force and effect. Their terms will prevail in the event that a conflict arises with this policy.
(33)  RMIT may assign its rights, title and interests in IP owned by it to third parties in accordance with this policy.
### Protection and Commercialisation of IP
(34)  Where a staff member, student or affiliate develops IP over which RMIT asserts ownership rights they must follow the process outlined in the Invention Disclosure Form.
(35)  RMIT will decide whether or not to proceed with the protection or commercialisation of IP owned by RMIT. The University is under no obligation to protect or commercialise any IP. The terms on which RMIT protects its IP will be at the absolute discretion of the University. The University will endeavour to make decisions regarding protection or commercialisation of such IP in consultation with the relevant creators.
(36)  Creators must use their best endeavours to assist RMIT in its commercialisation efforts.
(37)  Where there is more than one creator, the Deputy Vice-Chancellor Research and Innovation will, in the absence of agreement by the creators, determine the proportions to be paid to the individual creators. Distribution to a creator shall not be affected by the death, resignation or retirement of the staff member.
(38)  Where creators may personally hold equity in companies that have a license or assignment to RMIT-owned IP, they will be required to forego any other creator’ entitlements in relation to the same IP.
(39)  If Indigenous Traditional Knowledge is involved in any proposed commercialisation activities, the University must consult with the Pro Vice-Chancellor, Indigenous Education, Research and Engagement to ensure appropriate recognition and protection is given to Indigenous Traditional Knowledge and its owners.
(40)  Staff, students and affiliates must complete all required documentation to allow RMIT to protect, commercialise and exploit any IP.
(41)  If a creator fails to complete any documentation or any other action necessary for the commercialisation of IP owned by the University, the Vice-Chancellor has the right to execute all such documents and do all such acts as their attorney.
(42)  This power of attorney does not extend to instances where failure to complete documentation is a result of conflicts as to ownership of the IP, or where there is a dispute between the creators and RMIT. In these instances, the Section dealing with Dispute Resolution will apply.
(43)  RMIT is responsible for administering all trade marks, domain names and business names relating to University activities. All trade mark applications must be made in the University’s name.
(44)  In addition, any use of the University’s name, logo or coat of arms must be approved by the relevant delegate before any application is made.
### Attribution
(45)  The University has a Copyright Management Service that oversees the appropriate use of Copyright materials.
(46)  University-owned Copyright must be appropriately attributed in accordance with Schedule 1.
### Dispute Resolution
(47)  Disputes between staff, between students or between staff and students arising will be dealt with under the Intellectual Property Committee's Terms of Reference. The committee will recommend to the Vice-Chancellor the establishment of a sub-committee to resolve any dispute submitted to it concerning:
  1. the ownership of intellectual property
  2. the division of any income arising from the commercialisation of intellectual property.


(48)  Where the sub-committee is unable to resolve any dispute submitted to it, the staff member or student may appeal to the Vice-Chancellor.
### Responsibilities
(49)  The Deputy Vice-Chancellor Research and Innovation is responsible for the implementation of this policy.
(50)  Intellectual Property and Commercialisation Team is responsible for the administration of the IP Policy, for education and information relating to IP, for the commercialisation of the University’s IP, the management of the University’s IP assets, and the disbursement of net revenue as prescribed in [Schedule 2](https://policies.rmit.edu.au/download.php?id=66&version=2&associated).
(51)  The Chair of the Intellectual Property Committee (IPC) may issue procedures and resources under this policy, as applicable.
### Review
(52)  This policy will be reviewed every three years.
(53)  The procedures and resources associated with this policy may be reviewed at any time at the discretion of the Deputy Vice-Chancellor Research and Innovation.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=1#document-top)
# Section 5 - Schedules
(54)  [Intellectual Property Policy Schedules 1 & 2](https://policies.rmit.edu.au/download.php?id=66&version=2&associated)
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=1#document-top)
# Section 6 - Procedures and Resources
(55)  Refer to the following documents which are established in accordance with this Policy:
  1. [Distribution of Commercialisation Income Process](https://policies.rmit.edu.au/document/view.php?id=25)
  2. [Disclosing and Exploiting Intellectual Property Process](https://policies.rmit.edu.au/document/view.php?id=24)
  3. [Invention Disclosure Form](https://policies.rmit.edu.au/download.php?id=13&version=1&associated)
  4. [Royalty Distribution Form](https://policies.rmit.edu.au/download.php?id=14&version=3&associated)
  5. [Intellectual Property Policy Schedules 1 & 2](https://policies.rmit.edu.au/download.php?id=66&version=2&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=23&version=1#document-top)
# Section 7 - Definitions
Background intellectual property | Any intellectual property owned by the University that exists at the time new Intellectual Property is created.  
---|---  
Commercialise/commercialisation | To exploit commercially and includes: 
  1. in relation to an IP right; the exercise of all the rights exclusively granted to the holder of such IP rights by the laws of the jurisdiction in which the IP right subsists, including where permitted the right to sub-license those rights
  2. in relation to a product, kit, apparatus, substance, documentation or information resource (or any part of such materials): to make, distribute, market, sell, hire out, lease, supply, or otherwise dispose of it; and
  3. in relation to a method or process: to use the method or process or to make, distribute, market, sell, hire out, lease, supply, or otherwise dispose of a product, kit or apparatus the use of which is proposed or intended to involve the exercise of the method or process.

  
Commercialisation revenue | The gross revenue actually received and retained by RMIT from the Commercialisation and Exploitation of specific IP owned by RMIT, after the payment of any withholding, goods and services or other taxes, bank fees, transaction fees and other charges. Commercialisation revenue does not include income received from the provision of research, consultancy or other services.  
Contributor | A staff member, affiliate or student who is a creator or is a person that contributed to the creation, development or invention of the relevant IP, as determined in accordance with the relevant process.  
Course materials | All materials produced in the course of, or for use in, teaching in any form and all IP in such materials including but not limited to lectures, lecture notes and material, syllabi, study guides, assessment materials, images, multi-media presentations, web content, case studies and course software.  
Creator | Any of the following: 
  1. in the case of a patentable invention subject to the [Patents Act 1990](https://policies.rmit.edu.au/directory/summary.php?legislation=32) (Cth): the Inventor
  2. in the case of a literary or artistic work or similar subject to the [Copyright Act 1968](https://policies.rmit.edu.au/directory/summary.php?legislation=4) (Cth): the Author
  3. in the case of designs registrable under the [Designs Act 2003](https://policies.rmit.edu.au/directory/summary.php?legislation=33) (Cth): the Designer
  4. in the case of Plant Breeders Rights, under the [Plant Breeders’ Rights Act 1994](https://policies.rmit.edu.au/directory/summary.php?legislation=34) (Cth): the Principal Breeder
  5. in the case of circuit layouts, under the [Circuit Layouts Act 1989](https://policies.rmit.edu.au/directory/summary.php?legislation=30) (Cth), the Designer.

  
Indigenous Traditional Knowledge | Indigenous Australians' rights to their heritage, consisting of intangible and tangible aspects of the whole body of cultural practices, resources and knowledge systems developed nurtured and refined by Indigenous people and passed on by them as part of expressing their cultural identity, including distinctive signs and symbols, practices, know-how and skills.  
Intellectual property (IP) | All statutory and other proprietary rights (including rights to require information be kept confidential) in respect of inventions, copyright, trademarks, designs, patents, plant breeder's rights, circuit layouts, know-how, trade secrets, data, materials and all other rights as defined by Article 2 of the Convention establishing the World Intellectual Property Organisation of July 1967, all rights to apply for the same and, for the avoidance of doubt, includes: 
  1. patents under the [Patents Act 1990](https://policies.rmit.edu.au/directory/summary.php?legislation=32) (Cth)
  2. copyright which subsists in original works under the [Copyright Act 1968](https://policies.rmit.edu.au/directory/summary.php?legislation=4), including computer programs and data (Cth)
  3. trade marks registered under the [Trade Marks Act 1995](https://policies.rmit.edu.au/directory/summary.php?legislation=35) (Cth)
  4. designs registered under the [Designs Act 2003](https://policies.rmit.edu.au/directory/summary.php?legislation=33) (Cth)
  5. new plant varieties under the [Plant Breeders’ Rights Act 1994](https://policies.rmit.edu.au/directory/summary.php?legislation=34) (Cth)
  6. circuit layouts (computer chips) under the [Circuit Layouts Act 1989](https://policies.rmit.edu.au/directory/summary.php?legislation=30) (Cth); and
  7. trade secrets and other confidential material under Common Law.

  
Invention | Any IP that is patentable under the [Patents Act 1990](https://policies.rmit.edu.au/directory/summary.php?legislation=32) (Cth).  
Net revenue | The monetary amount retained by RMIT from the commercialisation revenue received from the commercialisation of IP after the legitimate claims of third parties are satisfied.  
Pre-existing intellectual property | Tangible IP that the University agrees is owned by a Staff member, a Student or a third-party prior to the date of their employment or enrolment at RMIT.  
Specifically commissioned | Work requested by the University by agreement, where particular consideration is given. This may include financial consideration or relief from teaching or other duties.  
University resources | Resources of the University and its controlled entities which includes without limitation facilities, funds, services, equipment, paid leave, staff time and support staff.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
