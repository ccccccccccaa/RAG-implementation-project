[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=184&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=184&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Controlled and Non-Controlled Entity Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=184)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=184&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=184&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=184&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=184&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=184&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=184&version=1)


# Controlled and Non-Controlled Entity Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=184&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=184&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=184&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=184&version=1#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major1)
  * [Approval and Review](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major2)
  * [Disposal of an Interest in an Entity ](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major3)
  * [Governing Documents of Entities ](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major4)
  * [Directors, Boards and Administration ](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major5)
  * [Policies, Governance and Reporting ](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major6)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major7)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=184&version=1#major8)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=184&version=1#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=184&version=1#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The governance framework within which the University will acquire and manage ownership or other significant interests in an Entity in keeping with its powers under section 48(1) of the [Royal Melbourne Institute of Technology Act 2010](https://policies.rmit.edu.au/directory/summary.php?legislation=20) (RMIT Act). This policy has been developed in line with the Voluntary Code of Best Practice for the Governance of Australian Public Universities (May 2018).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=184&version=1#document-top)
# Section 2 - Overview
(2)  This policy establishes the governance framework for the University’s controlled and non-controlled Entities to ensure that: 
  1. the University operates in accordance with its obligations under the RMIT Act
  2. RMIT University Council (Council) has appropriate oversight of all functions and activities conducted by Entities. 

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=184&version=1#document-top)
# Section 3 - Scope
(3)  This policy applies to all Entities within the RMIT Group.
(4)  Any investment in the ordinary course by RMIT as part of the University’s enterprise wide investment strategy overseen by Council is excluded from the requirements of this policy.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=184&version=1#document-top)
# Section 4 - Policy
### Principles
(5)  Subject to the approval process described in this policy, the University may form, manage or participate in an Entity for one or more of the following purposes: 
  1. to provide a more appropriate governance or operational framework for the management of specialised functions of the University
  2. to separate the management of non-core functions from the core functions of the University
  3. to meet country specific legislative requirements for operations outside Australia, or 
  4. to act as a holding entity or trustee for specific activities of the University, and 
  5. where one or more of the following objects are met: 
    1. making available facilities for study, research or education
    2. providing teaching, research, development, consultancy or other services for public or private entities
    3. assisting or engaging in the development or promotion of the University’s research or the application or use of the results of that research
    4. preparing, publishing, distributing or licensing the use of literary or artistic work, audio or audio-visual material or computer software
    5. exploiting commercially a facility or resource of the University, including but not limited to, study, research or knowledge developed by or belonging to the University, whether alone or with another entity
    6. seeking or encouraging gifts to the University or for the University’s purposes, or 
    7. any other object, consistent with the RMIT Act, which the Council considers appropriate in the circumstances.


### Approval and Review
(6)  Council must approve the formation or management of, or the participation in, an Entity by the University prior to the establishment or acquisition of the interest in the Entity. To avoid doubt, Council must approve any increase in the size of an interest in an Entity. 
(7)  The Vice-Chancellor (VC) may submit a proposal to Council for the formation, management or participation in an Entity in accordance with the [Controlled and Non-Controlled Entity Procedure](https://policies.rmit.edu.au/document/view.php?id=185) (the Procedure). 
### Disposal of an Interest in an Entity 
(8)  Council must approve the proposed disposal of an interest in a Controlled Entity prior to the disposal of such an interest by the University. 
(9)  The VC may submit a proposal to Council for the disposal of an interest in a Controlled Entity. Any proposal must detail: 
  1. the reasons and background for the proposed disposal, and 
  2. include provisions for the distribution of any assets in accordance with the constituent Documents of the Entity. 


### Governing Documents of Entities 
(10)  The terms, including any changes to those terms, of governing documents of Controlled Entities must: 
  1. be approved by Council 
  2. be compliant with the laws in the jurisdiction in which the Controlled Entity is registered
  3. include a description of the mechanism in which the University maintains control (as defined in section 50AA of the [Corporations Act 2001](https://policies.rmit.edu.au/directory/summary.php?legislation=25)) of the Controlled Entity, and 
  4. include a provision that expressly authorises a director of the Controlled Entity to act in the best interests of the University. 


(11)  The terms, including any changes to those terms, of governing documents of Non-Controlled Entities must be endorsed by Council. 
### Directors, Boards and Administration 
(12)  Directors of a Controlled Entity must be approved by Council prior to their appointment. 
(13)  Nominations for directorship of a Controlled Entity must be made by the VC in accordance with the Controlled and Non-Controlled Entity Procedure. 
(14)  A Board of a Controlled Entity must have at least three and no more than seven directors, with a Chair approved by the VC (subject to any requirement under local laws for Controlled Entities registered outside Australia). 
(15)  A Company Secretary will be appointed by the directors of a Controlled Entity in accordance with the Controlled and Non-Controlled Entity Procedure (subject to any requirement under local laws for Controlled Entities registered outside Australia). 
(16)  Administration of a Controlled Entity will be managed in accordance with the [Controlled and Non-Controlled Entity Procedure](https://policies.rmit.edu.au/document/view.php?id=185) and the [Controlled Entity Guidelines](https://policies.rmit.edu.au/document/view.php?id=186). 
### Policies, Governance and Reporting 
(17)  All Controlled Entities must comply with policies, procedures and guidelines of the University unless otherwise authorised in writing by the VC and Chair of the policy approval authority. 
(18)  Each Controlled Entity must report to Council prior to the commencement of each financial year, including providing Council with a draft business plan for Council approval and otherwise report to Council in accordance with the Controlled and Non-Controlled Entity Procedure. 
(19)  Each Controlled Entity must provide regular (and not less than each quarter) updates to Council against the Entity’s business plan. 
(20)  The relevant VCE member must ensure that the VC has regular and sufficient information regarding activities of each Non-Controlled Entity. 
(21)  Each Controlled Entity must be audited annually by the Victorian Auditor-General’s Office (VAGO). It it is an entity outside Australia, VAGO must nominate an auditor. 
### Responsibilities
(22)  The Executive Director, Governance, Legal and Strategic Operations is responsible for ensuring the currency of this policy.
(23)  Responsibilities for the administration of Controlled Entities is described in the [Controlled Entity Guideline](https://policies.rmit.edu.au/document/view.php?id=186).
### Review
(24)  This policy will be reviewed every five years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=184&version=1#document-top)
# Section 5 - Procedures and Resources
(25)  Refer to the following documents which are established in accordance with this policy:
  1. [Controlled and Non-Controlled Entity Procedure](https://policies.rmit.edu.au/document/view.php?id=185)
  2. [Controlled Entity Guideline](https://policies.rmit.edu.au/document/view.php?id=186)
  3. [Financial Management Policy](https://policies.rmit.edu.au/document/view.php?id=70)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=184&version=1#document-top)
# Section 6 - Definitions
Any defined terms below are specific to this policy.
Controlled Entity | means an entity that is subject to the control of RMIT in terms of section 50AA of the Corporations Act 2001. In essence, where RMIT has the capacity to determine the outcome of decisions about the second entity’s decisions and policy making.  
---|---  
Entities | includes companies, associations, trusts, partnerships, or joint ventures.  
Non-Controlled Entity | means an Entity in which RMIT has an interest but where RMIT’s interest does not satisfy the definition of control in terms of section 50AA of the Corporations Act 2001.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
