[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=209&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=209&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment - COVID-19 Vaccination Requirements Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=209)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=209&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=209&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=209&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=209&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=209&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=209&version=1)


# Enrolment - COVID-19 Vaccination Requirements Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=209&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=209&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=209&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=209&version=1#section4)
  * [Enrolment Requirements ](https://policies.rmit.edu.au/document/view.php?id=209&version=1#major1)
  * [Enrolment Management ](https://policies.rmit.edu.au/document/view.php?id=209&version=1#major2)
  * [Assessment ](https://policies.rmit.edu.au/document/view.php?id=209&version=1#major3)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=209&version=1#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure provides the COVID-19 vaccination rules and requirements for enrolment.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=209&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=209&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all students enrolled in programs and courses delivered by the RMIT Group in Australia, including English Language Intensive Courses for Overseas Students (ELICOS) training programs, Foundation Studies, and domestic RMIT partner institutions.
(4)  This procedure does not apply to students enrolled in programs and courses offered by RMIT Online or at RMIT Vietnam.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=209&version=1#document-top)
# Section 4 - Procedure
### Enrolment Requirements 
(5)  Students enrolled in a program or course are subject to RMIT statutes, regulations policies, and procedures. This includes the [Student Charter](https://policies.rmit.edu.au/download.php?id=74&version=1&associated) and the [Statement of Student Responsibilities](https://policies.rmit.edu.au/download.php?id=75&version=1&associated).
(6)  All students are to be fully vaccinated against COVID-19 with an approved vaccine, or supply evidence of a valid medical exemption, in order to physically attend RMIT premises, facilities or RMIT supported events, including those held offsite, in accordance with the [COVID-19 Vaccination Procedure](https://policies.rmit.edu.au/document/view.php?id=204). This requirement extends to attendance for classes, assessment tasks, placements or Work Integrated Learning and wellbeing activities. Class schedules (including attendance requirements) are published in course guides.
  1. To gain an exemption, the person must provide the University with one of the following: 
    1. Immunisation History Statement showing that the contraindication for COVID-19 vaccines has been accepted, or
    2. COVID-19 Digital Certificate showing that the contraindication for COVID-19 vaccines has been accepted.


(7)  Where enrolling in programs and courses that require in-person attendance, students must provide evidence of full vaccination against COVID-19, or a valid medical exemption prior to commencement of classes. Students holding a valid medical exemption will be responsible for ensuring its validity over the duration of a course or program. Students who do not provide evidence of vaccination or a valid medical exemption will be considered unvaccinated against COVID-19.
(8)  RMIT will verify vaccination certificates or exemption documentation.
### Enrolment Management 
(9)  When enrolling in programs and courses, students must review the requirements for in-person attendance. While many programs may be completed online, others may have a requirement for in-person attendance. Students should refer to program and course guides and Canvas information, and can also seek academic advice regarding course attendance requirements from their Course Coordinator/Program Manager (or equivalent).
(10)  Students who are not fully vaccinated and do not have a valid medical exemption or have not provided their vaccination status will be unable to complete their course and program learning objectives where in-person attendance is required.
(11)  Students who are not fully vaccinated and do not have a valid medical exemption or have not provided their vaccination status have the option of withdrawing from any class they enrol into before the census date where they cannot complete the requirements, in order to avoid financial liability or academic penalty. Students may also apply for a leave of absence or discontinue their program enrolment where they cannot continue. RMIT will discontinue students who do not maintain a current enrolment in line with normal enrolment requirements for their program.
(12)  Students who are unable to continue within their course or program as a consequence of their vaccination status may apply for study in other programs that are offered entirely online, or do not have in-person attendance requirements.
(13)  Higher Degree by Research (HDR) students who are not fully vaccinated and do not have a valid medical exemption or have not provided their vaccination status should discuss the possibility of changing their research focus with their supervisory team. This may impact time of completion and is not grounds for an extension of candidature. Research may be completed remotely subject to the approval of supervisors.
(14)  Scholarship payments for enrolled students (including HDR) will be terminated where a student cannot continue, withdraws, or discontinues their program enrolment.
(15)  Students who do not meet the vaccination requirements and do not withdraw from a class before census date and cannot complete assessment requirements, will remain both academically and financially liable.
(16)  Students can re-enrol in future offerings of a withdrawn course when they meet vaccination requirements, or supply evidence of a valid medical exemption, provided they have an active program.
### Assessment 
(17)  Students must be fully vaccinated against COVID-19 or supply evidence of a valid medical exemption to attend in-person assessment including examinations. The [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) will apply to reported breaches of this requirement
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=209&version=1#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Term | Definition   
---|---  
Approved vaccine | Any COVID-19 vaccination that has been provisionally registered for use in Australia by the Therapeutic Goods Administration (TGA). In the case of people who received their vaccination at an overseas location, an Approved Vaccine means any COVID-19 vaccination that has been approved by the TGA as a recognised vaccine for the purpose of determining incoming international travellers as being appropriately vaccinated.  
Fully vaccinated | Means having obtained the TGA’s recommended dosage of any approved vaccine. For example, where a two-dose schedule is recommended by the TGA, a person will be considered fully vaccinated when they have received both doses of the vaccine. This may include any requirement for booster doses.  
Valid medical exemption |  Any person attending RMIT premises or activities will be exempted from the requirement to be fully vaccinated if they have a recognised medical contraindication. To gain an exemption, the person must provide the University with one of the following:
  1. Immunisation History Statement showing that the contraindication for COVID-19 vaccines has been accepted, or
  2. COVID-19 Digital Certificate showing that the contraindication for COVID-19 vaccines has been accepted.

  
Recognised medical contraindication |  A reaction to an approved vaccine as advised by the Australian Technical Advisory Group on Immunisation (ATAGI).  
RMIT or University premises |  Any building or outdoor space owned by the University occupied by the University, and/or under the control of the University as defined by section 11 of [RMIT Statute No 1](https://policies.rmit.edu.au/document/view.php?id=177).  
University activity |  Any event or function which is organised, endorsed or arranged by RMIT, whether on RMIT premises or not, and includes but is not limited to a student attending clinical or work integrated learning placement or a staff member attending a private or third-party premises to conduct a research study.  
Student |  A student as defined by section 4 of [RMIT Statute No 1](https://policies.rmit.edu.au/document/view.php?id=177) as any person enrolled at the university  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
