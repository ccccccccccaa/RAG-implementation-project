[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=124&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=124&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Leave and Public Holidays Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=124)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=124&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=124&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=124&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=124&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=124&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=124&version=1)


# Leave and Public Holidays Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=124&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=124&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=124&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=124&version=1#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=124&version=1#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=124&version=1#major2)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=124&version=1#major3)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=124&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  To ensure the provision, application and approval of leave entitlements, and requests for staff to work on nominated public holidays comply with relevant legislation applicable to staff employed by the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=124&version=1#document-top)
# Section 2 - Overview
(2)  This policy outlines the conditions and responsibilities for leave entitlements and public holidays at RMIT to enable:
  1. staff to access their full leave entitlements.
  2. managers to know their responsibilities with respect to approving leave.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=124&version=1#document-top)
# Section 3 - Scope
(3)  This policy applies to all current employees of the RMIT Group, subject to relevant legislation and employment terms.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=124&version=1#document-top)
# Section 4 - Policy
### Principles
(4)  RMIT is committed to providing staff with a safe and healthy workplace and offers a variety of leave arrangements (paid and unpaid) that enable staff to balance work with their personal needs and other specific purposes.
(5)  RMIT will ensure:
  1. provisions for leave and public holidays comply with relevant legislation.
  2. staff required to work on nominated public holidays are appropriately consulted (and agreement sought where relevant legislation requires) and remunerated.
  3. the types and quantities of leave applicable are communicated to staff members.


(6)  RMIT may provide additional leave arrangements at its discretion.
(7)  All leave entitlements have regard to the following conditions:
  1. all staff are aware of timeframes regarding leave applications and evidentiary requirements to allow managers to plan for known absences
  2. management may periodically direct staff with excessive leave balances to take leave, subject to the provisions of any relevant country law, agreements or awards
  3. management may direct staff to utilise paid leave entitlements prior to utilising any unpaid leave
  4. management may only approve requests to cash out leave entitlements where permitted by law.
  5. leave entitlements will be paid out in accordance with relevant legislation and agreement terms to staff members at the end of their employment.


### Responsibilities
(8)  The Chief People Officer or nominated delegate (including for RMIT Group entities) is responsible for developing and recommending approval of specific leave and public holiday procedures and resources in accordance with relevant obligations that apply across the RMIT Group. 
(9)  People managers are responsible for:
  1. the review and approval of leave requests for their direct reports
  2. managing leave entitlements in the interests of the individual staff member, the relevant team, and the RMIT Group entity.


(10)  All staff are responsible for understanding and managing their leave entitlements in accordance with this policy and related documents.
### Review
(11)  This policy will be reviewed at least once every three years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=124&version=1#document-top)
# Section 5 - Procedures and Resources
(12)  Leave entitlements and conditions for specific leave types available to staff may vary according to RMIT Group entity, staff cohort, relevant legislation and employment terms. Staff should consult the resources approved under this policy and location-specific staff information on leave entitlements for more information.
(13)  Refer to the following documents which are established in accordance with this policy:
  1. [Annual Leave Guideline](https://policies.rmit.edu.au/download.php?id=385&version=2&associated)
  2. [Sporting Leave Guideline](https://policies.rmit.edu.au/download.php?id=386&version=2&associated)
  3. [Attendance at Court Leave Guideline](https://policies.rmit.edu.au/download.php?id=387&version=1&associated)
  4. [Blood Donor Leave Guideline](https://policies.rmit.edu.au/download.php?id=388&version=2&associated)
  5. [Relocation Leave Guideline](https://policies.rmit.edu.au/download.php?id=365&version=4&associated)
  6. [Community Service Leave Guideline](https://policies.rmit.edu.au/download.php?id=393&version=1&associated)
  7. [Compassionate Leave Guideline](https://policies.rmit.edu.au/download.php?id=351&version=2&associated)
  8. [Cultural Leave Guideline](https://policies.rmit.edu.au/download.php?id=389&version=2&associated)
  9. [Defence Reserve Leave Guideline](https://policies.rmit.edu.au/download.php?id=390&version=2&associated)
  10. [Domestic and Family Violence Leave Guideline](https://policies.rmit.edu.au/download.php?id=367&version=1&associated)
  11. [Long Service Leave Guideline](https://policies.rmit.edu.au/download.php?id=391&version=1&associated)
  12. [Parental Leave Guideline](https://policies.rmit.edu.au/download.php?id=309&version=12&associated)
  13. [Personal Leave Guideline](https://policies.rmit.edu.au/download.php?id=310&version=4&associated)
  14. [Political Candidate Leave Guideline](https://policies.rmit.edu.au/download.php?id=392&version=2&associated)
  15. [Vocational Education Leave Guideline](https://policies.rmit.edu.au/download.php?id=317&version=2&associated).


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
