[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=101&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=101&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Honorary and Visiting Academic Appointments Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=101)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=101&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=101&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=101&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=101&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=101&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=101&version=1)


# Honorary and Visiting Academic Appointments Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=101&version=1#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=101&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=101&version=1#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=101&version=1#section4)
  * [Employment relationship](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major1)
  * [Requirements of Appointment](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major2)
  * [Reimbursement of Travel and Living Expenses](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major3)
  * [Specific Employment Assignment for Honorary or Visiting Academics](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major4)
  * [Visa Requirements for International Visiting Academics](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major5)
  * [Eligibility for Appointment](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major6)
  * [Use of Title](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major7)
  * [Contribution and Duties](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major8)
  * [Obligations](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major9)
  * [Access to University Facilities](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major10)
  * [Induction](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major11)
  * [Insurance](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major12)
  * [Intellectual Property](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major13)
  * [Conflict of Interest](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major14)
  * [Termination of Appointment](https://policies.rmit.edu.au/document/view.php?id=101&version=1#major15)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=101&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  The purpose of this policy is to define the requirements, eligibility, conditions, and other arrangements associated with the honorary and visiting academic appointments established under the Titles Regulations.
(2)  Under the Titles Regulations, the University may confer honorary and visiting academic titles on individuals who have a significant association with the University, subject to the relevant policies and procedures.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=1#document-top)
# Section 2 - Overview
(3)  The objectives of this policy are to enable RMIT University to:
  1. ensure application of appointments is fair and consistent throughout the University
  2. provide a targeted response to the strategic directions of the University
  3. broaden the research and teaching base of the University
  4. maximise the academic and professional talent in the broader community to advance the University’s research, teaching and learning experience
  5. build and establish its international, interstate and intra-state networks in teaching and research and scholarships
  6. to engage industry practitioners that support practical education and training that is aligned to modern professional and industry needs and connects students and other staff to international industry and professional experience

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=1#document-top)
# Section 3 - Scope
(4)  This policy applies to individuals who may be considered for appointment to an honorary or visiting academic position at RMIT established under the Titles Regulations.
(5)  This policy does not cover:
  1. Current employees on a fixed term or continuing contract, with the exception of the Vice-Chancellor’s Innovation Professor title, which may be conferred on an individual whether or not they are an employee at the time of conferral. Academic staff visiting from other national or international institutions who receive payment for their service and will be sponsored on a Business Sponsored (457) visa;
  2. Academics associating with RMIT under Scholars at Risk policy
  3. Recipients of other Honorary Awards conferred by RMIT Council including Honorary Degrees or University Medals
  4. RMIT Foundation Fellowships

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=1#document-top)
# Section 4 - Policy
### Employment relationship
(6)  Appointment to an honorary or visiting position does not in itself constitute an employer/employee or independent contractor relationship between the individual and the University.
### Requirements of Appointment
(7)  The table below provides a summary of the types of the appointment, purpose, eligibility, term of appointment and authority for approval.
University title |  Purpose |  Eligibility |  Authority |  Term of appointment |  Paid  
---|---|---|---|---|---  
Emeritus Professor |  May be conferred on a retired Professor of the University in recognition of significant distinguished service to the University. |  Professors with significant distinguished service to the University. The person is retiring from academic activity at RMIT. |  Nominated by: Head of School/Dean or Director of Centre/Institute Endorsed by: Three full Professors of the University. Approved by: Relevant Deputy Vice-Chancellor |  Ongoing |  Normally without payment *  
Honorary University Fellow |  May be conferred on a retired academic or teaching (HE or TAFE) staff member in recognition of significant outstanding service to the University. |  Academic or teaching staff with a significant outstanding record of service to the University. The person is not a full RMIT professor. The person is retiring from academic or teaching activity at RMIT. |  Nominated by: Head of School/ or Director of Centre/Institute. Endorsed by: Professor of the University. Approved by: Relevant Deputy Vice-Chancellor |  Ongoing |  Normally without payment *  
Honorary Professor Honorary Associate Professor/ Honorary Principal Research Fellow |  May be provided to experienced and research active Professor, Associate Professor or Honorary Principal Research Fellow who could continue their work to the benefit of their discipline and to RMIT. |  The person must have held a similar rank at RMIT or another recognised University or is deemed to be of equivalent standing. The person would continue academic research activity post leaving RMIT. |  Nominated by: Head of School/Dean or Director of Centre/Institute Endorsed by: Professor of the University. Approved by: Relevant Deputy Vice-Chancellor |  Initially a period not exceeding three (3) years May be renewed for a further period not exceeding three (3) years |  Normally without payment *  
Visiting Professor Visiting Associate Professor/ Visiting Principal Research Fellow Visiting Research Fellow |  May be provided to visiting academic staff employed at other universities or institutions who are appointed to the University for a specified term for teaching, research or other purposes. |  The person must hold a similar rank at another recognised university or institution or be deemed to be of equivalent standing. The person is research active. International visiting academics must satisfy Immigration requirements |  Nominated by: Head of School/ Dean or Director of Centre/Institute Approved by: Deputy Vice-Chancellor via Contracts Management Team |  An appointment not exceeding 12 months in duration, for any one visit |  Normally without payment. Consult Central Recruitment Unit to discuss immigration requirements and visa costs  
Adjunct Professor Adjunct Associate Professor/ Adjunct Principal Research Fellow |  May be provided to academic staff employed in other institutions whose appointment will assist in developing and strengthening engagement with industry and the professions; and enhancing the levels of experience and expertise within the University. |  The person must hold a similar rank or be of equivalent standing in an industry. |  Nominated by: Head of School/Dean or Director of Centre/Institute Endorsed by: Professor of the University. Approved by: Relevant Deputy Vice-Chancellor |  Initially a period not exceeding three (3) years May be renewed for a further period not exceeding three (3) years |  Normally without payment *  
Associate/ Clinical Associate |  May be provided to suitably qualified and experienced persons who would contribute to the teaching, research or advancement of the University in an honorary capacity. Clinical Associates must be qualified in a recognised clinical area. |  Person must hold a similar rank or be of equivalent standing in an industry, and demonstrate professional achievement in relevant area. |  Nominated by: Head of School/Dean or Director of Centre/Institute Endorsed by: Professor of the University. Approved by: Relevant Deputy Vice-Chancellor |  Initially a period not exceeding three (3) years May be renewed for a further period not exceeding three (3) years |  Normally without payment *  
Senior Industry Fellow |  May be provided to suitably qualified and experienced persons who would contribute to the teaching, research or advancement of the University. The person may use their expertise to teach and be involved in course design. |  Person must have a significant record of service with a relevant industry and demonstrate professional achievement in relevant area. |  Nominated by: Head of School/Dean or Director of Centre/Institute Approved by: Deputy Vice-Chancellor |  Casual basis |  Negotiated Casual rates  
Vice-Chancellor’s Innovation Professor |  May be granted to a person whose work is of esteemed benefit to their discipline or field and to the University. |  Person must have a significant record of relevant service to the University. |  Proposed by: A member of the Vice-Chancellor's Executive Endorsed by: An independent nomination review committee Approved by: Vice-Chancellor |  Initially a period not exceeding three (3) years May be renewed for further periods |  Normally without payment *  
### Reimbursement of Travel and Living Expenses
(8)  An appointee may receive reimbursement for reasonable travel and living expenses while performing relevant activities for the University by prior agreement with the relevant manager. Reimbursement arrangements must be stipulated in the proposal recommending appointment and if required be consistent with any immigration requirements.
### Specific Employment Assignment for Honorary or Visiting Academics
(9)  Conferral of an honorary appointment does not preclude an individual being appointed to a paid position within the University.
(10)  International visiting academics on visiting visas may not undertake any form of paid work, without prior application and approval to vary their visa. The central Contracts Management team may provide additional information on visas.
### Visa Requirements for International Visiting Academics
(11)  RMIT is required to support the sponsorship of the visa for international visiting academics that do not have Australian residence rights. This visa will be required to be obtained before they enter Australia.
(12)  The central Contracts Management team will provide up to date information on visas, and any costs RMIT may be expected to pay.
(13)  It is a requirement of visa holders, to demonstrate to the Department of Immigration at the point of visa application that they have purchased comprehensive health insurance prior to their visa application being submitted.
### Eligibility for Appointment
(14)  An appointee must meet eligibility requirements, as outlined in the table above and detailed in procedure, before being considered for an academic honorary or visiting appointment and title.
### Use of Title
(15)  The level of academic title is dependent on the nature of the contribution to the University and the criteria applicable to the level of appointment of academic staff by the University.
(16)  A visiting academic title will normally be awarded for the period of the association or visit. An appointee will use the relevant honorary or visiting prefix before the appropriate academic title in any correspondence or documents during the term of the appointment (e.g: Visiting Associate Professor of RMIT University).
(17)  The use of any title covered by this policy is not to be used for private gain or for private purposes not associated with or for the benefit of the University.
### Contribution and Duties
(18)  An appointee may make contributions across Colleges or Portfolios. More than one honorary or visiting position may be attached to a School, College or Portfolio.
(19)  The precise nature of the duties of each appointment will be the subject of negotiation between the individual and the relevant manager, who will be responsible for managing the performance of duties of appointees.
(20)  These duties should be clearly outlined in the proposal recommending appointment, and would normally involve contribution to one or more of the following academic areas:
  1. learning and teaching;
  2. research and scholarship;
  3. leadership.


(21)  An appointee will not be a member of any University body nor eligible for election to University bodies, unless the membership of the body includes co-opted members.
(22)  Subject to normal approval processes an appointee to an Emeritus Professor, Honorary and Adjunct professorial position may be eligible to serve as a joint supervisor of research postgraduate students (including Honorary Associate Professors and Adjunct Associate Professors). An appointee to an associate or clinical associate position may also be eligible to serve as a supervisor of postgraduate research students, subject to normal approval processes.
(23)  For all purposes of courtesy and on ceremonial occasions Emeritus Professors, Honorary Professors, Honorary Associate Professors / Principal Research Fellows, Visiting Professors, Visiting Associate Professors / Principal Research Fellows, Adjunct Professor and Adjunct Associate Professors / Principal Research Fellows shall be regarded as a professor of the University but shall not be a member of any University body nor eligible for election to University bodies, unless the membership of the body includes co-opted members.
### Obligations
(24)  An appointee is bound to abide by University statutes, legislation, codes, policies and procedures whilst undertaking activities relating to their appointment.
(25)  Any breach or suspected breach of policy or any conduct which, in the opinion of the University, is likely to bring the University or any of its related entities into disrepute may result in withdrawal of the title and/or relationship.
### Access to University Facilities
(26)  It is the responsibility of the relevant manager to provide appropriate physical accommodation, equipment and resources.
(27)  An appointee is eligible to access full academic staff privileges at RMIT University Libraries.
### Induction
(28)  It is the responsibility of the relevant manager to ensure all appointees have completed the RMIT University induction modules.
### Insurance
(29)  As this type of appointment does not constitute an employment arrangement, appointees are not covered by the University's workers' compensation insurance (except for Senior Industry Fellows employed on a casual basis).
(30)  An appointee is covered by RMIT’s personal accident, public liability and professional indemnity insurance policies whilst engaged in RMIT approved activities. Any accident or incident involving an appointee should be reported to the relevant manager and Financial Services.
### Intellectual Property
(31)  Any intellectual property rights in materials created by the appointee whilst working on any University project during the term of appointment will be owned by the University or in accordance with the University’s agreement with an external funding body.
### Conflict of Interest
(32)  An appointee must disclose any actual or potential conflict of interest to the University, which may arise at any point during the appointment period.
### Termination of Appointment
(33)  An appointee may have their appointment terminated by the Vice-Chancellor, or the Deputy Vice-Chancellor as appropriate, if it is considered that continuation is not in the best interests of the University.
(34)  Termination of appointment prior to their formal end date will be assessed on a case by case basis and will be in accordance with the conditions outlined in the letter of appointment.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=101&version=1#document-top)
# Section 5 - Procedures and Resources
(35)  Refer to the following documents which are established in accordance with this policy:
  1. [Honorary and Visiting Academic Appointments Procedure](https://policies.rmit.edu.au/download.php?id=87&version=1&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
