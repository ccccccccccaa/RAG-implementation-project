[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=179&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=179&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Integrity Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=179)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=179&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=179&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=179&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=179&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=179&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=179&version=1)


# Academic Integrity Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=179&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=179&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=179&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=179&version=1#section4)
  * [Assessment of Breaches](https://policies.rmit.edu.au/document/view.php?id=179&version=1#major1)
  * [Managing Academic Integrity Breaches](https://policies.rmit.edu.au/document/view.php?id=179&version=1#major2)
  * [Student Advocacy and Support ](https://policies.rmit.edu.au/document/view.php?id=179&version=1#major3)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=179&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets out the requirements for identifying, managing and responding to breaches of academic integrity.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=179&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Academic Integrity Policy](https://policies.rmit.edu.au/document/view.php?id=168).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=179&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all staff and students of the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=179&version=1#document-top)
# Section 4 - Procedure
### Assessment of Breaches
(4)  Staff apply their professional and/or academic judgment in identifying potential breaches of academic integrity and making an initial assessment of the level of violation.
(5)  First-time, low-level breaches of academic integrity characterised by inexperience, lack of student knowledge, or poor writing skills may be managed as an educational opportunity initially by a course coordinator.
(6)  Repeat or higher order breaches that may be intentional, deliberately planned, organised or systematic, are reported to a Senior Officer to manage as a potential instance of academic misconduct under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35). In managing academic integrity breaches that may constitute academic misconduct under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35), Senior Officers refer to the [Academic Misconduct Senior Officer Response Guidelines](https://policies.rmit.edu.au/download.php?id=332&version=2&associated) for guidance.
### Managing Academic Integrity Breaches
(7)  The following processes will be used to address actions or behaviours that constitute a breach of academic integrity set out within clause (15) of the [Academic Integrity Policy](https://policies.rmit.edu.au/document/view.php?id=168).
(8)  The following processes may be used to address other actions or behaviours constituting a breach of academic integrity, seeking to apply a consistent approach for similar kinds of breach.
#### Failure to Appropriately Acknowledge Sources and Plagiarism
(9)  A student’s failure to appropriately and accurately acknowledge their sources may indicate a lack of understanding of correct referencing practices or may be an instance of plagiarism amounting to academic misconduct. The following considerations are taken into account in determining the appropriate course of action to take:
  1. the level of knowledge and experience the student has by reference to their university journey
  2. the extent of academic integrity training, including referencing practices relevant to the course
  3. the student’s intention
  4. any prior instances of academic integrity breaches and the educative response taken, and
  5. any other relevant circumstances giving rise to the failure.


(10)  Where a Course Coordinator (or equivalent) finds that a lack of understanding is the basis for the student’s failure to appropriately and accurately acknowledge their sources, they must treat the instance as an assessment matter and:
  1. explain the breach of academic integrity
  2. require the student to repeat the assessment task and/or deduct marks from the assessment (up to a maximum of 20% of the mark for the assessment task)
  3. direct the student to engage in educational support services
  4. provide a written warning to the student advising that another breach of academic integrity will be handled as an allegation of academic misconduct and may result in more severe penalties, and
  5. advise the relevant school/industry cluster academic services team (or equivalent) to record the warning.


(11)  Where a Course Coordinator (or equivalent) suspects that a more serious breach of academic integrity has occurred, or if the student commits a subsequent breach, they will refer the matter to a Senior Officer for determination under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) as a potential instance of academic misconduct.
#### Contract Cheating or Ghost Writing
(12)  Contract cheating or ghostwriting occurs when a student submits an assessment task that has been completed for them by a third party and represents it as though it was the student’s own by:
  1. obtaining the assessment task from a commercial service, including internet sites, whether pre-written or specially prepared for the student concerned
  2. submitting an assessment task produced by a third party, including a friend, family member, fellow student or a staff member of the University, or
  3. submitting an assessment task generated or altered by software tools or an unauthorised or unacknowledged algorithm.


(13)  Contract cheating or ghostwriting may be detected in assessment tasks by identifying anomalies or inconsistencies in:
  1. the level of engagement with a course and the quality of assessment tasks
  2. assessment content, language level, coherence, punctuation, grammar, or vocabulary between assessment tasks
  3. reference or lack of reference to course materials or requirements, or assessment criteria
  4. file naming conventions and metadata
  5. formatting within a document and changes in layout between assessment tasks, or
  6. the use of referencing software or automatic formatting between assessment tasks.


(14)  In determining whether a student has engaged in contract cheating, a staff member may:
  1. meet with the student and request the student to provide: 
    1. evidence of the research and writing processes (for example, drafts) before final submission, and/or
    2. an oral defence of the work to demonstrate authorship
  2. seek advice from a Senior Officer or Student Conduct.


(15)  Where a Course Coordinator (or equivalent) suspects that a student may have submitted an assessment task that has been completed by a third party, they will refer the matter to a Senior Officer for determination under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) as a potential instance of academic misconduct. 
#### Collusion or Unauthorised Collaboration
(16)  Collusion is unauthorised collaboration with another person or group on an assessment that is presented as the student’s or group’s own work, or as the work of other students. Collusion occurs when a student or group, without authorisation:
  1. works with one or more people to prepare and produce an assessment
  2. allows others to copy their work or shares course material
  3. allows another person to prepare or edit an assessment
  4. produces or substantially edits an assessment for another student, or
  5. offers to produce academic work for other students.


(17)  Collusion occurs whether or not the persons or assessment concerned are connected with RMIT.
(18)  Where a Course Coordinator (or equivalent) suspects that collusion or unauthorised collaboration has occurred they will refer the matter to a Senior Officer for determination under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) as a potential instance of academic misconduct.
#### Falsification and Fabrication of Information
(19)  Falsification and fabrication occurs when a student presents untrue information or omits to disclose information relating to an assessment task, including by:
  1. providing incorrect or misleading statements about research, results, or history
  2. inventing or distorting data (including statistical data) used in an assessment, or
  3. inventing or distorting arguments, whether represented as direct quotations or not, ascribed to other individuals.


(20)  Information provided by students that may be falsified or fabricated may relate to:
  1. Work Integrated Learning placement and assessment requirements, placement attendance, participation, training, projects, assessments, or reports
  2. attendance and or participation in other learning activities
  3. falsified documents and reports
  4. inclusion of citations to non-existent or incorrect sources
  5. falsified or manipulated text matching software reports, or
  6. word count declarations.


(21)  When a Course Coordinator (or equivalent) suspects that information provided by a student in relation to an assessment task has been falsified or fabricated they will refer the matter to a Senior Officer for determination under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) as a potential instance of academic misconduct.
#### Attempting to Gain Unfair Advantage in a Supervised Assessment
(22)  Students breach academic integrity when they use any method to attempt to gain an unfair advantage in an invigilated or supervised assessment or test, including but not limited to:
  1. communicating, or attempting to communicate, with a fellow student or individual who is neither an invigilator nor a member of University staff
  2. copying, or attempting to copy from a fellow student
  3. being in possession of any unauthorised material or device which contains or conveys, or is capable of conveying information concerning the subject matter under examination, including any unauthorised printed or written material, or electronic calculating or information storage device; or mobile phones or other communication device
  4. recording, transmitting or disseminating questions and/or answers to themselves or another person
  5. impersonating another student, or
  6. failing to comply with an instruction by an officer appointed to supervise the assessment task.


(23)  When a student is found to have attempted to gain unfair advantage in an invigilated or supervised assessment, the matter will be referred to a Senior Officer for determination under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) as a potential instance of academic misconduct.
### Student Advocacy and Support 
(24)  Students will be advised of support services available to them as part of any academic integrity breach report, investigation or outcome, for example:
  1. study support
  2. counselling
  3. Equitable Learning Services
  4. principal student organisation advocacy and support services.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=179&version=1#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Course coordinator | For the purposes of this policy, course coordinator refers to the academic or teaching staff member who is responsible for the management, conduct, teaching and assessment of a course. Specific titles may vary across the RMIT Group.  
---|---  
principal student organisation | The main body representing students at the relevant RMIT campus.  
Senior Officer | Means a staff member appointed to the role of Senior Officer in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
