[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=116&version=3#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=116&version=3#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Procedure - Discontinuation of Student Program 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=116)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=116&version=3)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=116&version=3)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=116&version=3)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=116&version=3)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=116&version=3)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=116&version=3)


# Enrolment Procedure - Discontinuation of Student Program
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=116&version=3#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=116&version=3#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=116&version=3#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=116&version=3#section4)
  * [Program Discontinuation](https://policies.rmit.edu.au/document/view.php?id=116&version=3#major1)
  * [Cancellation of Enrolment by RMIT](https://policies.rmit.edu.au/document/view.php?id=116&version=3#major2)
  * [Cancellation of Enrolment for Unpaid Fees](https://policies.rmit.edu.au/document/view.php?id=116&version=3#major3)
  * [Cancellation of Enrolment for International Students](https://policies.rmit.edu.au/document/view.php?id=116&version=3#major4)
  * [Appeals](https://policies.rmit.edu.au/document/view.php?id=116&version=3#major5)
  * [Reporting](https://policies.rmit.edu.au/document/view.php?id=116&version=3#major6)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=116&version=3#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure provides the rules for enrolment variation for all RMIT students including cancellation, discontinuation and reinstatement of enrolment.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=116&version=3#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=116&version=3#document-top)
# Section 3 - Scope
(3)  This procedure applies to students enrolled in programs and courses offered and delivered by the RMIT Group including RMIT University, RMIT Vietnam, RMIT Training, RMIT Online and international partners (collectively referred to as RMIT institutions).
(4)  This procedure does not apply to:
  1. students enrolled in English Language Intensive Courses for Overseas Students (ELICOS) provided by RMIT Training
  2. English language courses provided by RMIT Vietnam
  3. short courses provided by RMIT Training and RMIT Online.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=116&version=3#document-top)
# Section 4 - Procedure
### Program Discontinuation
(5)  Cancellation, discontinuation, reinstatement and provider transfer are considered enrolment variations.
(6)  A student who wishes to vary their program enrolment must do so in accordance with the processes prescribed by the Academic Registrar.
(7)  The Academic Registrar may vary a student’s enrolment on administrative grounds or as an outcome of a decision made under RMIT’s policies and procedures.
### Cancellation of Enrolment by RMIT
(8)  The Academic Registrar may cancel a student’s program enrolment in the following circumstances:
  1. A student who has failed to: 
    1. provide accurate and/or complete information in their application for admission to their program
    2. meet requirements for enrolment by the relevant deadline and therefore their place in a program or candidature has lapsed
    3. pay the prescribed fees by the payment deadline
    4. comply with enrolment-related visa conditions, as applicable
    5. meet legislative requirements to retain their enrolment.
  2. A student who is an apprentice or a trainee and: 
    1. has changed training provider, or
    2. whose training agreement has been cancelled.
  3. A vocational education student who has not attended any scheduled classes.
  4. A vocational education student accessing a VET Student Loan who fails to submit their VET Student Loan progression forms, or submits a progression form with an outcome response that does not match their enrolment record for the relevant period. 
    1. A student will be provided at least 28 day’s notice that failure to submit their VET Student Loan progression forms will lead to their program cancellation, and should they be identified for program cancellation, they can either: 
      1. immediately submit their outstanding VET Student Loan progression form
      2. contact RMIT Connect to seek a review of their VET Student Loan fee deferrals and progression forms where they believe there is an error
      3. opt to pay tuition fees for the courses in full to RMIT and request cancellation of their VET Student Loan.
  5. A higher degree by research student: 
    1. who has committed a breach of academic integrity in the research proposal submitted as part of their application for admission
    2. whose research candidature has been terminated for failing to make satisfactory academic progress.
  6. A student whose enrolment is sponsored by their employer and the employer has advised that the student ceases to be an employee.
  7. A student who has not complied with terms stipulated in a third-party agreement.
  8. The student’s enrolment is contrary to Australian or relevant country law.
  9. A student who has: 
    1. been expelled from the University
    2. failed to meet the requirements of the [Higher Education Support Act 2003](https://policies.rmit.edu.au/directory/summary.php?legislation=21) or the [VET Student Loans Act 2016](https://policies.rmit.edu.au/directory/summary.php?legislation=36)
    3. been excluded for failing to make satisfactory academic progress
    4. been deemed a serious concern or risk in relation to the RMIT community.


### Cancellation of Enrolment for Unpaid Fees
(9)  The University may cancel the enrolment of students who fail to pay outstanding tuition fees as prescribed in the [Approved Schedule of Fees and Charges](https://policies.rmit.edu.au/download.php?id=128&version=1&associated).
(10)  Until they have paid their debt in full, students who have unpaid fees totalling no more than $500.00 (or as specified in the relevant fees and charges schedule)
  1. may be prevented from: 
    1. adding courses to their program enrolment, or
    2. re-enrolling
  2. and will be prevented from: 
    1. obtaining a transcript or other documentation of their achievement
    2. being conferred an award, and
    3. graduating.


(11)  Where a student has unpaid fees totalling more than $500.00, RMIT will provide at least 20 working days (or 28 calendar days) notice that they are liable to have their enrolment cancelled. During this period a student may:
  1. pay the outstanding fees during this period, or
  2. contact [Student Connect](https://policies.rmit.edu.au/download.php?id=130&version=2&associated) to seek a review of their fees where they believe there is an error.


(12)  The notice period may be reduced for a student who:
  1. is enrolled in an online accelerated mode program
  2. is enrolled at RMIT Vietnam.


(13)  Where a student’s program enrolment is cancelled because of unpaid tuition fees, their current and future enrolment in all incomplete courses, in all programs, will be withdrawn.
  1. Students will remain liable for other outstanding charges, such as materials fees.
  2. Financial liability will be retained where a class is graded. 
  3. Students whose account is in credit after all debt to RMIT is settled may apply for a refund.


(14)  Students whose program enrolment has been cancelled because of unpaid tuition fees, and who have paid any other outstanding charges, may apply for re-instatement, re-admission or for admission to any other program at RMIT on the same basis as other applicants for admission.
  1. RMIT Vietnam may allow reinstatement into courses where evidence of payment is provided, and other published criteria are met.


#### Reinstatement of Program Enrolment Following Cancellation
(15)  To be considered for reinstatement, a student must pay all overdue fees within 10 working days of the cancellation date and apply to the relevant school/industry cluster/college.
  1. RMIT Vietnam may allow reinstatement into a program according to published processes and timelines.


(16)  The following students will have five (5) working days from date of cancellation to make payment due to shorter reporting timeframes:
  1. international students under the age of 18
  2. students enrolled in an online accelerated or online postgraduate program.


(17)  A student’s enrolment may be reinstated once only in a program following cancellation for unpaid tuition fees.
(18)  Students will not be reinstated where it is determined that to do so would be in breach of legislation.
  1. Reinstatement of international students studying on a student visa requires confirmation that they are not in breach of the conditions of their student visa.
  2. When requesting reinstatement, students studying on a student visa must provide an explanation as to why they did not make payment on time.


(19)  Any loss of access to RMIT systems and student services that are a result of enrolment being cancelled will not be considered grounds for special consideration, should the student be reinstated in line with this procedure.
### Cancellation of Enrolment for International Students
(20)  International students studying in Australia on a student visa whose enrolment is cancelled (either by the student or the institution) will have their electronic Confirmation of Enrolment (CoE) for any current and future programs cancelled.
(21)  International students who have not yet commenced study or who have not completed the first six calendar months of their program may cancel their CoE in the following circumstances:
  1. the request for student visa was refused or would not be available in time to enrol
  2. a close family member has passed away
  3. RMIT is unable to offer the program
  4. a scholarship has not been granted to the student
  5. illness or injury will prevent the student from study for an ongoing period
  6. the student has genuinely attempted but failed to meet the English or other requirements for admission into the program
  7. other special or exceptional circumstances, including political, civil or natural events
  8. the student is no longer on a student visa (e.g. has been granted Permanent Residence status) before the census date.


(22)  Fee credits and refund requests will be determined in accordance with the [Approved Schedule of Fees and Charges](https://policies.rmit.edu.au/download.php?id=128&version=1&associated).
(23)  International students studying on a student visa in Australia who have not yet completed six (6) months of study in the principal program in which they are enrolled, require notice of release from RMIT before they can be enrolled at another registered provider.
  1. Students who apply for transfer and seek a letter of release must remain enrolled and attend classes until their application has been approved.
  2. If a student cancels their enrolment before receiving permission to transfer to another provider, RMIT will report the student to the Australian government as a program cancellation.


### Appeals
(24)  A student may appeal a decision by the RMIT institution not to release them to transfer to another institution, if they can provide evidence that:
  1. significant relevant circumstances have not been considered in the decision
  2. there was an error in process or breach of policy that had a significant impact on the decision
  3. there is new, relevant information that was not available at the time the student made the application, which would have had a significant impact on the decision.


(25)  The student must submit their appeal in writing to the Associate Director, Enrolment and Student Records within 20 working days of the date the decision was provided to them.
(26)  Students who wish to seek review of the outcome of the appeal by an external agency must do so within 10 working days of the date their appeal outcome was emailed to them.
(27)  Each institution will publish information to support the appeal process and if an appeal is dismissed, the student’s right to apply for review of the decision by:
  1. in the case of RMIT Training students, the [Overseas Students Ombudsman](https://policies.rmit.edu.au/download.php?id=131&version=2&associated)
  2. in the case of RMIT University students, the [Victorian Ombudsman](https://policies.rmit.edu.au/download.php?id=120&version=1&associated)


### Reporting
(28)  Where a domestic student enrolled in a vocational education program is aged under 17 at the time of program cancellation, RMIT University is required to report to the Victorian government.
(29)  Additional reporting obligations are in place for students studying in Australia on a student visa who are under 18 years of age. Students must submit written instructions for any enrolment variation to the International Compliance Advisor in Risk, Audit and Compliance.
(30)  The University is required to report the cancellation of enrolment of International students studying in Australia on a student visa to the Australian government.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=116&version=3#document-top)
# Section 5 - Resources
(31)  Refer to the following documents which are established in accordance with this procedure:
  1. [Enrolment processes for staff](https://policies.rmit.edu.au/download.php?id=132&version=2&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
