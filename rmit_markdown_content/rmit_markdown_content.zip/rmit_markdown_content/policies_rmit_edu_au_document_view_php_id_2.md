[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Academic Promotion Procedure - Level B 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=2)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=2)


# Academic Promotion Procedure - Level B
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=2#section4)
  * [Schedule](https://policies.rmit.edu.au/document/view.php?id=2#major1)
  * [Eligibility](https://policies.rmit.edu.au/document/view.php?id=2#major2)
  * [Doctoral Qualification Equivalence](https://policies.rmit.edu.au/document/view.php?id=2#major3)
  * [Outcome of Promotion Application](https://policies.rmit.edu.au/document/view.php?id=2#major4)
  * [Appeals](https://policies.rmit.edu.au/document/view.php?id=2#major5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure details all management aspects and general conditions to be followed for the promotion of academic staff employed by RMIT University in Melbourne and Vietnam to level B.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Academic Promotion Policy](https://policies.rmit.edu.au/document/view.php?id=1).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all RMIT academic staff currently appointed at Level A who meet the prescribed eligibility requirements for promotion.
#### Exclusions
(4)  Vocational Education teachers and Professional staff cannot be promoted to an academic position through this process.
(5)  Academic staff at Levels C, D and E eligible for promotion should refer to the Academic Promotion for Levels C, D and E procedure.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=2#document-top)
# Section 4 - Procedure
### Schedule
(6)  Academic staff who are currently appointed as an Associate Lecturer or Research Officer (Level A) can apply for promotion at any time outside of the annual promotion round.
### Eligibility
(7)  Staff are eligible to apply for promotion to level B where they:
  1. are a continuing or fixed term academic staff member
  2. have 12 months’ continuous service at RMIT (excluding casual service and leave without pay)
  3. have completed probation at RMIT
  4. have completed a doctoral qualification or obtained equivalent accreditation and standing, thereby meeting University skill base and formal qualification requirements
  5. meet the University-wide skill base and formal qualifications requirements (or equivalent accreditation and standing) specified for level B
  6. meet the University Academic Expectations framework or its subsequent replacement
  7. have evidence of satisfactory professional development.


(8)  In exceptional cases, the minimum period of service may be reduced from 12 months to 6 months to permit an early application for academic promotion provided that the academic staff member has passed probation. The decision to reduce the minimum period of service will be determined on a case-by-case basis by the Dean or equivalent.
(9)  Eligible academics may activate Achievement Relative to Opportunity for promotion purposes.
(10)  Except with the approval of the relevant DVC or equivalent (or nominee), academic staff are excluded from applying for promotion in the year immediately following an unsuccessful application. 
(11)  Promotion determinations are made to the level immediately above the applicant’s substantive classification, unless the Vice-Chancellor determines, following a request from the Dean or equivalent and supported by the DVC, that there are exceptional circumstances and that it is in the best interests of RMIT for promotion to a higher level to be considered.
### Doctoral Qualification Equivalence
(12)  Applicants seeking to establish equivalence to a doctoral qualification need to submit to their Dean or equivalent an application of no more than two pages making a case that substantiates their case for equivalent accreditation and standing.
(13)  Examples of evidence may include (but are not limited to) the following:
  1. professional qualifications and contribution to profession
  2. teaching experience, including implementation of the Learning and Teaching Strategy
  3. experience in research, including collaborative work with other RMIT staff in research programs
  4. experience outside tertiary education in industry, business or government employment
  5. creative achievement
  6. professional contributions
  7. leadership in local, state or national advisory bodies or community organisations
  8. technical achievement
  9. publication, presentations or work in progress that indicate a contribution to the area of expertise. 


### Outcome of Promotion Application
(14)  The Dean or equivalent must make a recommendation on whether to endorse the application no later than 10 working days after receipt.
(15)  The final promotion decision is made by the relevant Deputy Vice-Chancellor or their nominated delegate.
(16)  Should an applicant to be approved for promotion, the relevant Deputy Vice-Chancellor or their nominated delegated will notify the applicant of the outcome of their promotion application.
(17)  Promotions will take effect from the date of the final promotion decision by the relevant Deputy Vice-Chancellor or their nominated delegate.
(18)  The Dean or equivalent is responsible for supporting the applicant to manage the implications of the promotion outcome, both in workload planning and career development.
### Appeals
(19)  An unsuccessful applicant may appeal the decision in accordance with the [Academic Promotion Procedure - Appeals](https://policies.rmit.edu.au/document/view.php?id=5) no later than 15 working days following receipt of the outcome of the promotion application.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
