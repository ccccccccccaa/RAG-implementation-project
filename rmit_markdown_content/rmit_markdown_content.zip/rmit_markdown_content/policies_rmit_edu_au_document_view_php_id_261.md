[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=261#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=261#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Domestic and Family Violence Procedure - Schedule 1 - Explanations and Examples 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=261)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=261)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=261)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=261)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=261)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=261)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=261)


# Domestic and Family Violence Procedure - Schedule 1 - Explanations and Examples
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=261#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=261#section2)
  * [Section 3 - Explanations and Examples](https://policies.rmit.edu.au/document/view.php?id=261#section3)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This Schedule supports the understanding and operationalisation of the [Domestic and Family Violence Procedure - Australia](https://policies.rmit.edu.au/document/view.php?id=259). It provides the definitions that apply to the [Domestic and Family Violence Procedure - Australia](https://policies.rmit.edu.au/document/view.php?id=259).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=261#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Domestic and Family Violence Procedure - Australia](https://policies.rmit.edu.au/document/view.php?id=259). 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=261#document-top)
# Section 3 - Explanations and Examples
(3)  RMIT recognises that: 
  1. While anyone can be a victim survivor or perpetrator of domestic and family violence, domestic and family violence is predominantly committed by men against women, children and other vulnerable persons
  2. Children who are exposed to the effects of domestic and family violence are particularly vulnerable, and exposure to domestic and family violence may have a serious impact on children's current and future physical, psychological and emotional wellbeing
  3. Domestic and family violence affects the entire community and occurs in all areas of society, regardless of location, socioeconomic and health status, age, culture, gender, sexual identity, ability, ethnicity or religion.
  4. Domestic and family violence may involve overt or subtle exploitation of power imbalances and may consist of isolated incidents or patterns of abuse over time.
  5. Behaviour may constitute family violence even if the behaviour would not constitute a criminal offence.


(4)  RMIT applies the definitions of domestic and family violence from the Family Violence Protection Act 2008. This includes behaviour by a person towards a current or past family member of that person if that behaviour:
  1. is physically or sexually abusive, or
  2. is emotionally or psychologically abusive (refer to clause 7 for description), or
  3. is economically abusive (refer to clause 8 for description), or
  4. is threatening, or
  5. is coercive or
  6. in any other way controls or dominates the family member and causes that family member to feel fear for the safety or wellbeing of that family member or another person.


(5)  Examples of behaviours described in clause 4 include:
  1. using coercion, threats, physical abuse or emotional or psychological abuse to cause or attempt to cause a person to enter into a marriage
  2. using coercion, threats, physical abuse or emotional or psychological abuse to demand or receive dowry, either before or after a marriage
  3. assaulting or causing personal injury to a family member or threatening to do so
  4. sexually assaulting a family member or engaging in another form of sexually coercive behaviour or threatening to engage in such behaviour
  5. choking, strangling or suffocating (within the meaning of section 34AB(1) of the Crimes Act 1958) a family member or threatening to do so
  6. intentionally damaging a family member's property, or threatening to do so
  7. unlawfully depriving a family member of the family member's liberty, or threatening to do so
  8. causing or threatening to cause the death of, or injury to, an animal, whether or not the animal belongs to the family member to whom the behaviour is directed so as to control, dominate or coerce the family member
  9. controlling or monitoring mobility including not enabling a family member to attend classes/group assessments
  10. socially isolating a family member from allowing them to engage in university activities including group assessments or networking events
  11. damaging and destroying their personal property (for example, smashing or stealing their laptops, other study equipment and/or their modes of transport)
  12. Secretly or overtly monitoring emails, text messages, phone calls and other private password protected technology.


(6)  Domestic and family violence, as defined by the Family Violence Protection Act 2008, also includes behaviour by a person that causes a child to hear or witness or otherwise be exposed to the effects of behaviour referred to in clauses 4 and 5. Examples include:
  1. overhearing threats of physical abuse by one family member towards another family member
  2. seeing or hearing an assault of a family member by another family member
  3. comforting or providing assistance to a family member who has been physically abused by another family member
  4. cleaning up a site after a family member has intentionally damaged another family member's property
  5. being present when police officers attend an incident involving physical abuse of a family member by another family member.


(7)  Emotional or psychological abuse means behaviour by a person towards another person that torments, intimidates, harasses or is offensive to the other person.
(8)  Economic abuse is behaviour by a person (the first person) that is coercive, deceptive or unreasonably controls another person (the second person), without the second person's consent:
  1. in a way that denies the second person the economic or financial autonomy the second person would have had but for that behaviour; or
  2. by withholding or threatening to withhold the financial support necessary for meeting the reasonable living expenses of the second person or the second person's child, if the second person is entirely or predominantly dependent on the first person for financial support to meet those living expenses.


(9)  Domestic and family violence may occur between intimate partners or ex partners, including those in same sex relationships, between siblings, by adolescent or adult children and their parents, or between extended family members.
(10)  Family members includes where a person reasonably regards the other person as being like a family member, having regard to the circumstances of the relationship such as:
  1. the nature of the social and emotional ties between the relevant person and the other person
  2. whether the relevant person and the other person live together or relate together in a home environment
  3. the reputation of the relationship as being like family in the relevant person's and the other person's community
  4. the cultural recognition of the relationship as being like family in the relevant person's or other person's community
  5. the duration of the relationship between the relevant person and the other person and the frequency of contact
  6. any financial dependence or interdependence between the relevant person or other person
  7. any other form of dependence or interdependence between the relevant person and the other person
  8. the provision of any responsibility or care, whether paid or unpaid, between the relevant person and the other person
  9. the provision of sustenance or support between the relevant person and the other person.


(11)  RMIT acknowledges the systemic discrimination faced by individuals due to aspects of their identity, including sexual orientation, gender and gender identity, race, economic status, immigration status, national origin, and ability, and recognises that these forms of discrimination intersect and present unique challenges for those affected by domestic and family violence. 
  1. RMIT recognises the cultural determinants of health, wellbeing, and safety for Aboriginal and Torres Strait Islander women and children and values the protective power of cultural connection.
  2. RMIT supports the need for cultural strengthening and self-determination as essential foundations to prevent and respond to domestic and family violence against Aboriginal and Torres Strait Islander communities.
  3. RMIT recognises the value, rights, and contributions of women with disabilities and is committed to fostering an inclusive society by challenging stereotypes, promoting respect, and supporting a victim-centred approach to domestic and family violence.
  4. RMIT acknowledges that the domestic and family violence experienced by LGBTIQA+ people is driven by rigid and hierarchical ideas about sex, gender, and sexuality and is further influenced by intersecting forms of inequality, including racism, classism, ableism, and ageism.
  5. RMIT recognises the strength, resilience, and rights of older women and is committed to addressing the intersecting impacts of ageism and gender inequality by promoting safety, dignity, and equality while challenging all forms of domestic and family violence.
  6. RMIT recognises the strength and resilience of culturally and racially marginalised women and is committed to addressing the intersecting impacts of gender inequality, racism, and structural discrimination to promote safety, dignity, and equality for all.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
