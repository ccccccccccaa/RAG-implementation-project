[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=108&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=108&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Travel Procedure - Student 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=108)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=108&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=108&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=108&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=108&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=108&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=108&version=1)


# Travel Procedure - Student
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=108&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=108&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=108&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=108&version=1#section4)
  * [Traveller Safety](https://policies.rmit.edu.au/document/view.php?id=108&version=1#major1)
  * [International Traveller Safety](https://policies.rmit.edu.au/document/view.php?id=108&version=1#major2)
  * [Arranging Travel (Domestic or International)](https://policies.rmit.edu.au/document/view.php?id=108&version=1#major3)
  * [Travel Insurance](https://policies.rmit.edu.au/document/view.php?id=108&version=1#major4)
  * [Student Safety (including students travelling internationally under a DFAT program) ](https://policies.rmit.edu.au/document/view.php?id=108&version=1#major5)
  * [Student Conduct](https://policies.rmit.edu.au/document/view.php?id=108&version=1#major6)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=108&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure sets out the requirements for students undertaking RMIT enrolment-related travel. It aims to minimise travel risk and promote student compliance.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Travel Policy](https://policies.rmit.edu.au/document/view.php?id=80).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all RMIT student travellers (including HDR candidates) across the RMIT Group. This procedure applies to all enrolment-related travel undertaken by students, including domestic and international travel by air, and ground transportation, and covers:
  1. University organised travel
  2. student mobility programs including exchange or study abroad placements, and global work placements/internships
  3. interstate or international Work Integrated Learning (WIL) placements 
  4. third party organised travel.


(4)  It does not apply to students who are also staff members and are travelling in their capacity as a staff member.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=1#document-top)
# Section 4 - Procedure
### Traveller Safety
(5)  Students undertaking enrolment-related travel must comply with:
  1. RMIT policies, procedures and processes
  2. host institution or organisation policies and procedures (where applicable)
  3. any direction given by the Chief Operating Officer in the interest of safety
  4. any other directions given by RMIT on conduct and requirements for that travel
  5. any special conditions imposed by a scholarship or other funding body
  6. the [Civil Aviation Safety Authority advice for air travellers](https://policies.rmit.edu.au/download.php?id=113&version=4&associated)
  7. local laws of the state, country or countries in which they are travelling
  8. host country/countries border entry requirements to ensure students have obtained the correct endorsement to enter, leave, or stay for a specified period of time.


### International Traveller Safety
(6)  Students undertaking enrolment-related international travel must register and provide all relevant travel documentation prior to travelling in:
  1. [MOBI Global Experiences](https://policies.rmit.edu.au/download.php?id=114&version=1&associated)
  2. [International SOS](https://policies.rmit.edu.au/download.php?id=117&version=2&associated), including itinerary details and any changes to travel, via the process established by Industry and Global Experiences.


(7)  RMIT strongly recommends that RMIT students undertaking enrolment-related international travel complete: 
  1. the micro credential module ‘[Preparing for Learning Abroad](https://policies.rmit.edu.au/download.php?id=116&version=1&associated)’ or a comprehensive pre-departure briefing 
  2. if an Australian citizen, register for updates with [Smartraveller](https://policies.rmit.edu.au/download.php?id=115&version=1&associated) at the Australian Government website, and in the case of a crisis, register with the service so the Government can assist you in case of an emergency
  3. if a non-Australian citizen, register with a similar Government service from your home country.


(8)  All student exchange partners are to be risk assessed by Industry and Global Experiences prior to final approval of the agreement. This will ensure appropriate and relevant guidance is provided for potential high-risk travel. 
(9)  RMIT reserves the right to withdraw a student’s program or representation based on Government and/or International SOS travel advice. RMIT will not be liable for any expense incurred due to the cancellation of travel and claims should be made through the student’s insurance. 
(10)  Based on Smart Traveller and International SOS travel and health advice for the student’s host country or countries, RMIT can request a student return home should their safety be at risk. RMIT will not be liable for any expense incurred due to the request to return and claims should be made through the student's insurance.
### Arranging Travel (Domestic or International)
(11)  Where group travel is a requirement of a student’s program, RMIT can arrange the travel booking, but the student is responsible for ensuring they have:
  1. sufficient funds
  2. necessary visas (if required)
  3. additional travel insurance (if necessary)
  4. immunisations (if required)
  5. fulfilled other requirements relevant to the travel arrangement.


(12)  In all other circumstances, the student is responsible for
  1. booking their own travel
  2. ensuring they have visas (if required)
  3. purchasing additional travel insurance (if necessary) in addition to the base level of insurance that the University will provide
  4. obtaining immunisations (if required)
  5. researching additional requirements if their program is in a sanctioned country.


(13)  For students under the age of 18 years, valid consent from the guardian/caregiver must in place when arranging travel. 
(14)  RMIT strongly recommends that students do not book flights on the excluded airlines list.
### Travel Insurance
(15)  All RMIT University students undertaking enrolment-related travel receive complimentary travel insurance.
  1. This excludes any individual travel from a RMIT global campus or partner once they reach Australia or domestic travel that is less that 50km from the students point of origin.
  2. This insurance can cover cancellations, delays, lost luggage, theft, hire car excess cover, and some other non-medical expenses. 
  3. Medical insurance is covered for international travel emergencies only. 


### Student Safety (including students travelling internationally under a DFAT program) 
(16)  RMIT adopts a zero-tolerance approach to the sexual exploitation, abuse and harassment (SEAH) of individuals and is committed to providing a safe and respectful learning environment. In response to this commitment: 
  1. where group travel is a requirement of a student’s program, it is the responsibility of the program coordinator to complete a risk assessment for the proposed program
  2. pre-departure briefings and conditions of participation must be made available to students prior to travelling.


(17)  International travel plans for all RMIT students who are funding recipients or awardees of a Department of Foreign Affairs and Trade (DFAT) program, including, but not limited to Australian volunteers program, Australia Awards, New Colombo Plan, other DFAT-funded scholarship programs or grants, and students who are undertaking travel as part of a DFAT agreement must:
  1. have their program risk assessed by the relevant RMIT business unit administering the DFAT program with the support of Industry and Global Experiences as appropriate, prior to the program being approved
  2. have the appropriate approvals prior to travel plans being made
  3. attend a pre-departure briefing or sign conditions of participation.


(18)  A student or staff member who has concerns or suspicions that SEAH has occurred while on DFAT-related travel must report their concerns to RMIT Safer Community or the Whistleblower hotline within 48 hours of becoming aware of the incident. 
### Student Conduct
(19)  Students are bound by the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and [Student Charter](https://policies.rmit.edu.au/download.php?id=74&version=1&associated) while undertaking RMIT enrolment-related travel.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=1#document-top)
# Section 5 - Resources
(20)  Refer to the following documents which are established in accordance with this procedure:
  1. PSEAH Risk Assessment Guidance
  2. Student Travel Risk Escalation Matrix
  3. [Travel Instruction - Leading Student Travel](https://policies.rmit.edu.au/document/view.php?id=302).


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
