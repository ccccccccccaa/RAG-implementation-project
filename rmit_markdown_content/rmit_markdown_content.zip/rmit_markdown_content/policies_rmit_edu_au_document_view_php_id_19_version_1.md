[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=19&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=19&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Masters by Research Grading Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=19)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=19&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=19&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=19&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=19&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=19&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=19&version=1)


# Masters by Research Grading Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=19&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=19&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=19&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=19&version=1#section4)
  * [Grading Sought from Masters by Research Examiners](https://policies.rmit.edu.au/document/view.php?id=19&version=1#major1)
  * [Determining and Awarding the Final Grade](https://policies.rmit.edu.au/document/view.php?id=19&version=1#major2)
  * [Grading Standards](https://policies.rmit.edu.au/document/view.php?id=19&version=1#major3)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=19&version=1#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure sets the rules for providing a graded outcome to candidates who successfully complete a masters by research degree at RMIT.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=19&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=19&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all RMIT masters by research candidates regardless of location.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=19&version=1#document-top)
# Section 4 - Procedure
### Grading Sought from Masters by Research Examiners
(4)  In addition to providing an examination recommendation of R1 to R5, examiners of masters by research submissions are asked to recommend a numerical grade. The grades available to examiners are as follows:
  1. High Distinction (80-100%)
  2. Distinction (70-79%)
  3. Credit (60-69%)
  4. Pass (50-59%)
  5. Fail (<50%)


### Determining and Awarding the Final Grade
(5)  Grades for masters by research examinations are only provided for final outcomes; the classification of a C4 Revise and Resubmit is regarded as an interim examination outcome and candidates receiving this classification are not provided with a grade.
(6)  All masters by research grades must be approved by the Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) before they are finalised.
(7)  Final grades with a decimal point between 0.1 - 0.4 will be rounded down, e.g. 81.3 =81%. Grades with a decimal point between 0.5 - 0.9 will be rounded up, e.g. 81.8 = 82%.
(8)  Candidates receive the final grade as approved by the ADVC RT&D. They do not receive individual grades from each examiner.
(9)  Candidates are informed of their grade when they receive their final examination classification.
(10)  Examinations with similar examiner recommendations (R1-R5)
  1. If the examiners’ recommended grades are within 15 percentage points of each other, the SGR Examinations team will derive a grade from the mean of the two recommended grades to recommend to the ADVC RT&D.
  2. If the examiners’ grades differ by more than 15 percentage points, the ADVC RT&D may refer to the College GRC representative to appoint a moderator. The moderator is an internal appointment, and therefore not considered to be wholly independent. For this reason, their grade cannot supersede the examiners’ grades but rather, must consolidate their grades.
  3. The moderator must be an RMIT academic staff member who has not been involved in the candidature or the research. The preferable appointment is an HDR DA in the same college.
  4. The moderator is given the following documents: Moderator’s Grade Form – Masters by Research; the candidate’s submission; the examiners’ written reports and recommendations; RMIT Guidelines for Examiners of a Masters by Research.
  5. A moderator is given two weeks in which to complete their moderation, which must include recommending a grade that: 
    1. agrees with one of the examiners’ grades, in which case this shall become the candidate’s final grade after approval; or
    2. is within the limits set by the examiners’ grades. In this case the SGR Examinations team will derive a grade from the mean of the grades recommended by both examiners and the moderator.
  6. The moderator is required to attach a one-page written rationale for the grade when they submit the completed Moderator’s Grade Form – Masters by Research to the School of Graduate Research.
  7. Examinations with significantly different examiner recommendations (R1 to R5) 
    1. If examiners’ recommendations (R1 to R5) are significantly different the examination outcome may be referred to a College Higher Degrees by Research Examinations Advisory Committee (CHEAC) in accordance with section 9 of the HDR Submission and Examination Procedure.
    2. A CHEAC may recommend a C4 classification or refer the research to an adjudicator in accordance with Schedule 2 of the HDR Submission and Examination Procedure.
    3. If an adjudicator is engaged, and they recommend the submission be classified as R1, R2 or R3, they must provide an additional grade between 50% and the grade nominated by the examiner who recommended the R1, R2 or R3 outcome.
    4. The adjudicator is an independent assessor appointed to reconcile diverging examination recommendations and grades. For this reason, their recommended grade will become the final grade once approved by the ADVC RT&D.


### Grading Standards
Grade range | Level | Standard  
---|---|---  
80-100% | HD: High Distinction | Work of exceptional quality showing clear understanding of subject matter and appreciation of issues; well formulated; arguments sustained; figures and diagrams where relevant; appropriate literature referenced; strong evidence of creative ability and originality; high level of intellectual work. Excellent analysis, comprehensive research, sophisticated theoretical or methodological understanding, impeccable presentation. The candidate demonstrates outstanding potential for doctoral level study and warrants strong scholarship support.  
70-79% | DI: Distinction | Work of high quality showing strong grasp of subject matter and appreciation of dominant issues though not necessarily of the finer points; arguments clearly developed; relevant literature referenced; evidence of creative ability and solid intellectual work. Very good work that is very well researched, shows critical analytical skills, is well argued, with scholarly presentation and documentation. The candidate is capable of doctoral level study.  
60-69% | CR: Credit | Work of solid quality showing competent understanding of subject matter and appreciation of main issues though possibly with some lapses and inadequacies and with clearly identifiable deficiencies in logic, presentation or originality. Some evidence of critical analysis and creative ability; well researched, prepared and presented. The candidate may be capable of doctoral level study under close supervision.  
50-59% | PA: Pass | Completion of key tasks at an adequate level of performance with demonstrated understanding of key ideas and some analytical skills. Satisfactory presentation, research and documentation. Adequate report, reasonable quality but showing a minimal understanding of the research area with deficiencies in content or experimental rigour; little evidence of creative ability or original thought. The candidate is unlikely to be capable of doctoral level study.  
0-49% | NN: Fail | The research does not meet the criteria for the degree as specified by the University and a significant amount of additional research work and/or major substantive revision will not raise it to an acceptable standard.  
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=19&version=1#document-top)
# Section 5 - Resources
(11)  Refer to the following documents which are established in accordance with this procedure:
  1. [HDR Forms](https://policies.rmit.edu.au/download.php?id=68&version=2&associated)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
