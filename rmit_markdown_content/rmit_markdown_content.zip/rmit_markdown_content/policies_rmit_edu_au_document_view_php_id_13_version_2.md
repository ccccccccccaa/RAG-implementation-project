[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=13&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=13&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Action and Support Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=13)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=13&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=13&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=13&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=13&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=13&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=13&version=2)


# HDR Action and Support Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=13&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=13&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=13&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=13&version=2#section4)
  * [Candidates Who Need Action and Support for Their Academic Progress](https://policies.rmit.edu.au/document/view.php?id=13&version=2#major1)
  * [Action and Support Management](https://policies.rmit.edu.au/document/view.php?id=13&version=2#major2)
  * [CASP Criteria](https://policies.rmit.edu.au/document/view.php?id=13&version=2#major3)
  * [Next Steps After a Period of Action and Support](https://policies.rmit.edu.au/document/view.php?id=13&version=2#major4)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=13&version=2#section5)


This is not a current document. It has been repealed and is no longer in force.
# Section 1 - Context
(1)  This procedure sets out the rules and processes for addressing unsatisfactory academic progress by higher degrees by research (HDR) candidates.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=2#document-top)
# Section 3 - Scope
(3)  The procedure applies to all staff responsible for HDR management and supervision and all HDR candidates of the University and its controlled entities (known as the RMIT Group).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=2#document-top)
# Section 4 - Procedure
### Candidates Who Need Action and Support for Their Academic Progress
(4)  Completing an HDR program requires the acquisition and development of advanced knowledge, skills and techniques, alongside precise project management to generate complex outputs within a tight time-frame. While HDR candidates are expected to take the initiative in managing their workload, there will be times when they require additional direction and guidance to support a return to satisfactory progress. The University is committed to ensuring that any action and support required is provided effectively and in a timely manner. This is done through the development and implementation of an [HDR Candidate Action and Support Plan (CASP)](https://policies.rmit.edu.au/download.php?id=229&version=1&associated).
(5)  In extraordinary circumstances, a specialised CASP can be developed to record the impact on a candidate’s academic progress.
  1. Processes and timelines will vary from the standard CASP process listed in this procedure.


(6)  A candidate may request action and support from their senior supervisor and/or HDR Delegated Authority (HDR DA) where they themselves identify a need. This is done by requesting a meeting with their supervisory team and/or HDR DA to discuss their progress. 
(7)  The HDR DA will nominate the candidate for action and support if:
  1. a candidate fails to attend two or more regular supervision meetings without providing evidence of exceptional/compassionate circumstances
  2. there are circumstances beyond the candidate’s control which are impeding their academic progress
  3. there is documented evidence of failure by the candidate to: 
    1. consistently produce work requested for review by their supervisor to the required standard;
    2. complete one or more coursework courses; or
    3. otherwise follow their agreed research plan
  4. the candidate has missed a milestone due date
  5. the candidate has been unable to achieve the requirements of their milestone within four weeks of the due date
  6. the candidate applies for an extension beyond maximum duration of candidature.


(8)  The Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) or delegate will instruct action and support for candidates where the need is identified.
### Action and Support Management
(9)  Nominations or requests for candidate action and support must be made in writing to the HDR DA.
(10)  The HDR DA takes the decision on whether action and support is required unless instructed by the ADVC RT&D.
(11)  Once a requirement for action and support is established, the HDR DA provides written notice within 10 working days to the candidate, supervisors, and the School of Graduate Research (SGR) of a scheduled action and support meeting.
(12)  The meeting’s purpose is to discuss reasons action and support are needed, and to develop a CASP which will outline the action for the candidate and their supervisors, as well as any additional support to be provided, in order to return the candidate to satisfactory progress. 
(13)  Attendees will comprise the HDR DA, who will chair the meeting, the primary senior supervisor and the candidate. The presence of any associate or joint senior supervisor/s is at the Chair’s discretion.
(14)  The candidate may take a support person to the meeting.
(15)  Action and support meetings should be face-to-face, either in person or via video conferencing. 
(16)  The candidate will be provided with a copy of the CASP and is still expected to work with their supervisors to implement the plan by the proposed end date, if the candidate does not:
  1. attend an action and support meeting;
  2. contribute to the development of a CASP; or
  3. sign the CASP within 10 working days of its development.


(17)  A CASP represents the formal record of the meeting and of the University’s commitment to the provision of action and support.
(18)  The HDR DA is responsible for reviewing and endorsing the CASP and may require amendments where appropriate. 
(19)  SGR may provide further advice and guidance regarding the development, implementation and review of a CASP if required.
(20)  The HDR DA must submit the CASP to SGR within 15 working days of its formalisation.
(21)  CASPs may be monitored and reviewed by SGR, and the ADVC RT&D (or delegate) may:
  1. instruct amendments to be made to the CASP
  2. instruct any remedial action or additional support deemed necessary to uphold academic standards, support HDR progress, and to ensure compliance with University policy.


(22)  At the end of the nominated CASP period, the HDR DA must review the candidate’s progress against the CASP (in accordance with Next Steps After a Period of Action and Support).
### CASP Criteria
(23)  The duration of a CASP is determined by the HDR DA up to a maximum duration of three months or part-time equivalent. In cases where the candidate has not returned to satisfactory progress by the end of the first CASP, a second, consecutive CASP may be developed of up to the same maximum duration if deemed appropriate by the HDR DA. 
(24)  No more than two consecutive CASPs may be agreed for the same candidate unless approved by the ADVC RT&D or delegate.
(25)  A full set of documentation from the action and support meeting must be developed to ensure the action and commitments agreed by School, supervisors, and candidate are recorded. The CASP documentation must include:
  1. a summary of the candidate’s perspective on barriers to progress
  2. recommendations by the senior supervisor and/or HDR DA for additional support for the candidate which may include, but is not limited to: 
    1. school-based support, such as increased supervisory meetings, regular meetings with the HDR DA and/or supporting an increase in hours per week spent on research
    2. variations to candidature, such as reducing study load, applying for leave of absence (LOA), reviewing the supervisory arrangements and/or applying for an extension beyond maximum (refer to the [HDR Candidature Duration and Enrolment Variation Procedure](https://policies.rmit.edu.au/document/view.php?id=16))
    3. referrals to other RMIT services, such as wellbeing services and/or academic support services
  3. an action plan developed and endorsed by the candidate, their supervisor/s, and the HDR DA which must consist of tasks for the candidate, and the supervisory team where appropriate, that: 
    1. are clear, detailed and specific – the candidate, supervisory team and HDR DA should have the same understanding of each task after reading the action plan
    2. have set deadlines that are achievable within the time frame of the CASP (in the event of any unexpected absence, the action plan should be reviewed and updated to reflect any delays, as appropriate)
    3. include reasonable time for any specific training or access to/provision of facilities required
    4. set tasks and deadlines for the supervisory team, such as providing feedback within set period of time to support the candidate’s return to progress.


### Next Steps After a Period of Action and Support
(26)  At the end of a period of action and support, the HDR DA will determine whether the conditions of the CASP have been met. If the candidate:
  1. is deemed to be making satisfactory progress, the period of action and support will end
  2. continues to require additional support, a new CASP may be developed (in accordance with Action and Support Management)
  3. fails to make satisfactory progress or refuses to engage with the CASP, the HDR DA will either require a second, consecutive CASP or refer the matter to the College representative (College Graduate Research Committee representative or nominee) for review within ten (10) working days of the CASP’s expiry date.


See the [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174) for further information. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=13&version=2#document-top)
# Section 5 - Resources
(27)  Refer to the following documents which are established in accordance with this procedure:
  1. [HDR Unsatisfactory Progress Process](https://policies.rmit.edu.au/document/view.php?id=174)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
