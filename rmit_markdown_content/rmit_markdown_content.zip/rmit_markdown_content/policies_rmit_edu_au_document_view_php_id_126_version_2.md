[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=126&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=126&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Credit Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=126)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=126&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=126&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=126&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=126&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=126&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=126&version=2)


# Credit Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=126&version=2#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=126&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=126&version=2#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=126&version=2#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=126&version=2#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=126&version=2#major2)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=126&version=2#major3)
  * [Review](https://policies.rmit.edu.au/document/view.php?id=126&version=2#major4)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=126&version=2#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=126&version=2#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This policy establishes the principles for assessing and granting credit for prior study or learning.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=126&version=2#document-top)
# Section 2 - Overview
(2)  RMIT award programs are educationally coherent and cumulatively sequenced courses that contribute to the acquisition of knowledge, skills and other learning outcomes, including the development of RMIT graduate attributes. The granting of credit must be consistent with these principles. 
(3)  This policy: 
  1. provides principles for awarding credit for prior study or learning outside of RMIT while maintaining academic standards for RMIT programs, and 
  2. sets clear responsibilities and accountabilities for credit decisions. 

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=126&version=2#document-top)
# Section 3 - Scope
(4)  This policy applies to: 
  1. all programs and courses offered by RMIT University, RMIT Online and RMIT Vietnam 
  2. individuals applying to study at RMIT who consider they have had prior learning experiences that would potentially attract credit or advanced standing in an RMIT program or course. 


(5)  This policy does not apply to Foundation Studies programs or RMIT UP, English language programs.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=126&version=2#document-top)
# Section 4 - Policy
### Principles
(6)  RMIT will recognise and grant credit for courses, and advanced standing in programs, where specified conditions are met. 
(7)  Prospective and current students will be provided with clear and accessible information regarding available credit. 
(8)  Processes to inform credit eligibility, application and assessment at RMIT will be current and transparent across colleges and entities. 
(9)  Criteria for granting credit will be applied consistently and equitably to all applications. 
(10)  Decisions regarding applications for credit will be consistent with Australian Qualifications Framework (AQF) and currency of learning principles. 
(11)  Credit decisions will consider a student’s best interests, facilitating movement between institutions and programs without disadvantage to progress. 
(12)  Credit will be not be granted where to do so will: 
  1. undermine the integrity of the award and requirements of the relevant discipline, or
  2. contravene any conditions for the professional accreditation of the award. 


(13)  Appropriate review and appeal provisions will be available with respect to credit decisions.
### Responsibilities
(14)  The Academic Registrar is responsible for credit procedures and resources for coursework programs and courses at RMIT. 
(15)  The Associate Deputy Vice-Chancellor Research Training and Development is responsible for credit procedures and resources for applicants to higher degree by research programs. 
(16)  The Deputy Vice-Chancellor College of Vocational Education or delegate is responsible for the credit resources specific to vocational education compliance. 
(17)  Responsibilities for other related decision-making points are as stated in this policy, associated procedures and resources.
### Compliance
(18)  All staff responsible for administering credit activities must follow this policy, associated procedures and resources. 
(19)  Significant breaches of this policy by a student or staff member that impair or undermine academic integrity will be managed via the: 
  1. [Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=52), or 
  2. [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)


### Review
(20)  This policy will be reviewed at least once every five years in accordance with the [Policy Governance Policy](https://policies.rmit.edu.au/document/view.php?id=57).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=126&version=2#document-top)
# Section 5 - Procedures and Resources
(21)  Refer to the following documents which are established in accordance with this policy:
  1. [Articulation Agreements Guideline](https://policies.rmit.edu.au/document/view.php?id=129)
  2. [Credit Procedure](https://policies.rmit.edu.au/document/view.php?id=37)
  3. [Credit Procedure - Masters Advanced Standing](https://policies.rmit.edu.au/document/view.php?id=127)
  4. [Currency of Learning Guideline](https://policies.rmit.edu.au/document/view.php?id=130)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=126&version=2#document-top)
# Section 6 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Advanced standing |  Credit for prior learning which contributes towards the volume of learning required to complete a program at RMIT whereby the student enters the program at a later semester or year of the program. Advanced standing may be granted as specified or unspecified credit.   
---|---  
Advanced standing precedent |  An approved advanced standing decision that is available for reuse in subsequent, comparable advanced standing applications.   
Credit |  A reduction in the number of courses a student is required to complete for a program, in recognition of their previous learning.   
Credit pathway |  A pathway by which a student receives a standard grant of credit towards a program.   
Credit precedent |  An assessment of an application which is used as a precedent for subsequent decisions on whether to grant credit to subsequent applicants with the same qualifications   
Credit transfer |  The process by which students receive credit for courses on the basis of previous formal study with equivalent content and learning outcomes.;   
Formal learning |  Study comprising credit-bearing courses, subjects or units offered by an accredited tertiary education institution.   
Informal learning |  Learning gained other than through study with an education provider; may include work or life experience.   
Masters Advanced Standing |  Advanced standing may be available in masters by coursework programs. It is credit for basic acquired knowledge in the relevant discipline, which reduces the volume of learning required to complete a program at RMIT. It is granted on the basis of qualifications at AQF 7 or above, where applicants have a degree specialisation or major in the same discipline as the masters program in which the applicant has been offered a place.   
Micro-credential |  An award that warrants achievement of clearly articulated learning outcomes that is not sufficient, in itself, to lead to the award of an Australian Higher Education Qualification or international qualification with equivalent learning outcomes   
Non-formal learning |  Learning gained through study with an education provider that is not an accredited tertiary institution, or which is not credit bearing: for example, short courses, professional development workshops.   
Pathway |  A program of study at RMIT or another institution, from which a student may enter an RMIT program, with or without a standard grant of credit.   
Precedent  |  A reference point for future credit decisions agreed by the University in consultation with relevant schools based on evidence that students are not disadvantaged in achieving course learning outcomes.   
Recognition of current competency |  A process of assessing that an individual who has previously achieved competency in a unit of competency or module, has maintained that competency.   
Recognition of prior learning |  (Higher Education) a process of assessing an individual's relevant prior informal and non-formal learning to determine whether they have met the learning outcomes of courses and can receive credit for them.  (Vocational Education) a process of assessing evidence that an individual has achieved units of competency through prior formal, informal and/or non-formal learning and can receive credit for them.   
Specified credit |  Credit granted towards a specific RMIT course or courses.   
Unspecified credit |  Credit that is not granted towards a specific course or courses, but in the form of credit points to fulfil elective course requirements.   
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
