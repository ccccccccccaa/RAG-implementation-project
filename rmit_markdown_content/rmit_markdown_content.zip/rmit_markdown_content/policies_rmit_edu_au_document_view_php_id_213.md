[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=213#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=213#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Child Safe Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=213)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=213)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=213)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=213)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=213)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=213)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=213)


# Child Safe Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=213#section1)
  * [Section 2 - Overview](https://policies.rmit.edu.au/document/view.php?id=213#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=213#section3)
  * [Section 4 - Policy](https://policies.rmit.edu.au/document/view.php?id=213#section4)
  * [Principles](https://policies.rmit.edu.au/document/view.php?id=213#major1)
  * [Responsibilities](https://policies.rmit.edu.au/document/view.php?id=213#major2)
  * [Responding and Reporting](https://policies.rmit.edu.au/document/view.php?id=213#major3)
  * [Compliance](https://policies.rmit.edu.au/document/view.php?id=213#major4)
  * [Section 5 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=213#section5)
  * [Section 6 - Definitions](https://policies.rmit.edu.au/document/view.php?id=213#section6)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  The purpose of this policy is to: 
  1. outline RMIT’s commitment to child safety and wellbeing
  2. guide the development and maintenance of best practice child safety systems and processes across RMIT campuses and online environments.

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=213#document-top)
# Section 2 - Overview
(2)  RMIT University allows the enrolment of domestic and international students from 16 years old, provides childcare services to children from three months to five years of age, hosts visiting children and conducts research with children/young people. RMIT recognises its responsibility and is committed to child safety, protecting children/young people from harm or maltreatment, being a child safe organisation, and promoting the safety, participation and empowerment of children and younger people with a disability; from culturally and/or linguistically diverse backgrounds; and Aboriginal children and/or communities.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=213#document-top)
# Section 3 - Scope
(3)  This policy applies to all staff and associates of the RMIT Group, including:
  1. RMIT University Council members, employees, researchers, students, representatives and volunteers
  2. contractors, tenants, licensees or lessees, and service providers where there is a connection with RMIT or when attending RMIT premises
  3. customers and visitors when engaged in activities with or for RMIT, or when attending RMIT premises
  4. partner organisations or people acting for or on behalf of RMIT in relation to our students and staff (including clubs and societies, and student representative organisations).
  5. Exclusion: This policy does not apply to external organisations.


(4)  For the purposes of this policy a child/young person is any person under the age of 18. Younger person, young person and children are other terms used to refer to anyone under the age of 18.
(5)  This policy should be read in conjunction with the [Child Safe Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249) and [Child Safe Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=214), or for Vietnam staff, the [Child Safe Reporting Procedure Vietnam](https://policies.rmit.edu.au/document/view.php?id=217). Other relevant policies and procedures are linked throughout this policy.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=213#document-top)
# Section 4 - Policy
### Principles
(6)  RMIT recognises its responsibility and is committed to child safety, protecting children/young people from harm and being a child safe organisation. RMIT is committed to ensuring that child safety and wellbeing is embedded in organisational leadership, governance and culture and welcomes children/young people as part of our community and commits to their participation and empowerment.
(7)  RMIT does not tolerate any form of child abuse, maltreatment or neglect. We recognise that all children/young people have a right to be kept safe from harm.
(8)  RMIT commits to equipping the University community with the skills and knowledge to provide young people with safe learning environments, both physical and online, to understand the responsibilities and boundaries of their roles and respond to any child safety concerns. This includes our students’ obligations when on placement if they interact with children/young people.
(9)  RMIT commits to engaging with and openly communicating with families and communities in relation to organisational approaches, and wherever possible, involving families in the promotion child safety and wellbeing.
(10)  All reports will be treated seriously, whether they are made by an adult or a child.
(11)  RMIT approaches complaints handling and reporting responsibilities through a child-focused lens, prioritising the rights of children/young people. The following principles govern this approach:
  1. A child making a disclosure is always to be believed.
  2. The best interests of children are paramount.
  3. Complaints handling and reporting systems are accessible and recognise the diverse needs of children and their families.
  4. Complaints are dealt with thoroughly and promptly.
  5. Complaints relating to children/young people will be managed within the limits of confidentiality, with information shared on a strict needs-to-know basis.


(12)  RMIT is committed to taking proactive preventative measures in the recruitment, screening, and training of staff to enhance child safety, to include RMIT’s Statement of Commitment to Child Safety in position descriptions, advertisements, and contracts.
(13)  Child abuse, child harm, risk of harm and/or neglect may occur in the context of RMIT activity or occur external to RMIT, for example, at home or in a recreational environment. RMIT expects all RMIT staff to be alert to child abuse, risk of harm and neglect in all contexts and report concerns in accordance with this document and the relevant procedures.
(14)  RMIT is committed to the universal requirement for valid Working with Children Checks (Victorian staff) and Police Checks for all RMIT staff. Staff are responsible for ensuring a valid Working With Children Check is maintained at all times. Managers are responsible for ensuring a valid Working with Children Check is maintained for their direct reports.
(15)  RMIT will respect and protect the cultural safety of children/young people who are Aboriginal or Torres Strait Islander and will provide a safe environment for children and younger people with a disability; from culturally and/or linguistically diverse backgrounds; those who are unable to live at home; and lesbian, gay, bisexual, transgender and intersex children and young people. 
(16)  RMIT is committed to protecting the privacy of children/young people in accordance with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59).
(17)  RMIT will empower children/young people, employees, volunteers and third parties to speak up and escalate any matters where they feel concerned about the safety of a child/young person in in-person and online environments.
(18)  RMIT is committed to the ethical and responsible conduct of human research involving children/young people, which may also be subject to the requirements of the [DFAT Child Protection Policy](https://www.dfat.gov.au/about-us/publications/pages/child-protection-policy) and [Child Safe Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249).
(19)  In accordance with the [Education Services for Overseas Students Act 2000](https://policies.rmit.edu.au/directory/summary.php?legislation=1), RMIT will ensure appropriate support and general welfare arrangements are made to protect the personal safety and social wellbeing of enrolled international students intending to apply for a subclass 500 student under the age of 18.
(20)  RMIT is committed to providing a best practice response if a risk, concern, or report arises regarding the safety or wellbeing of a child/young person. All allegations and safety concerns about children will be taken seriously and with sensitivity in line with our Child Safe Reporting procedures.
(21)  RMIT is committed to reviewing any systemic issues which may be contributing to or hindering RMIT from being safe for children/young people.
(22)  RMIT will monitor and review risks that may occur in physical and online environments regularly, including after incidents, near misses or complaints.
### Responsibilities
(23)  All members of the RMIT community are responsible for prioritising the assessment and mitigation of risks to child safety in their day-to-day roles and in the planning and delivery of special events and activities.
(24)  The Safer Community team are responsible for maintaining a central registry of instances of reportable conduct matters across all RMIT University campuses and wholly owned subsidiaries (RMIT Online, RMIT University Pathways ([RMIT UP](https://policies.rmit.edu.au/document/view.php?id=57)), as the responsible team for assessing and acting on these matters.
(25)  The Child Safety Working Group is responsible for regularly reviewing risks and improving child safety practices and preparing reports on the findings of relevant reviews to staff and volunteers, community and families, and children and young people. The Vice-Chancellor is the nominated head of organisation and is primarily responsible for RMIT’s compliance with the [Reportable Conduct Scheme](https://ccyp.vic.gov.au/reportable-conduct-scheme/).
(26)  All RMIT staff must immediately report any concerns or reports of child abuse or maltreatment or non-compliance with this policy in accordance with our procedures. Failure to comply with this obligation may constitute a criminal offence and result in serious penalties.
  1. [Child Safe Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=214)
  2. [Child Safe Reporting Procedure - Vietnam](https://policies.rmit.edu.au/document/view.php?id=217).


### Responding and Reporting
(27)  RMIT fosters an organisational culture, supported by clear policy, procedure and training, where all members of our community are confident and knowledgeable to provide an appropriate first response and to raise child safety concerns.
(28)  The types of complaints or concerning behaviours that require reporting to the Safer Community team may include:
  1. A child/young person stating that they or someone they know has been abused.
  2. Suspicions or beliefs that a child has suffered or is at risk of harm or maltreatment from an adult or a peer (includes unwanted or harmful sexualised behaviour between children).
  3. Inappropriate relationships developing between children and adults in the RMIT community.
  4. A staff, student or associate’s own feeling of discomfort about a relationship between a child and an adult in the RMIT community.
  5. Any other suspected or actual breach of this [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213), [Child Safe Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249), legislation or related policy, procedure or practice related to the safety and wellbeing of children/young people.


(29)  Where historical abuse allegations are made which pertain to RMIT, the organisation will co-operate fully with police or other statutory body investigations. RMIT will also review its current policies and procedures in light of the findings of historical abuse investigations, to determine if there is learning that may strengthen protective approaches.
### Compliance
(30)  This policy supports RMIT’s compliance obligations regarding:
  1. [National Principles for Child Safe Organisations](https://childsafe.humanrights.gov.au/national-principles)
  2. [Victorian Child Safe Standards (2022)](https://ccyp.vic.gov.au/child-safe-standards/)
  3. [Victorian Charter of Human Rights and Responsibilities](https://www.humanrights.vic.gov.au/for-individuals/human-rights/#:~:text=What%20is%20the%20Charter%20of,and%20the%20people%20it%20serves.)
  4. [Reportable Conduct Scheme](https://ccyp.vic.gov.au/reportable-conduct-scheme/)
  5. [Children, Youth and Families Act 2005](https://www.legislation.vic.gov.au/in-force/acts/children-youth-and-families-act-2005/)
  6. [Commission for Children and Young People Act 2012](https://www.legislation.vic.gov.au/in-force/acts/commission-children-and-young-people-act-2012/)
  7. [Child Wellbeing and Safety Act 2005 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/child-wellbeing-and-safety-act-2005/)
  8. [Working with Children Act 2005 (Vic)](https://www.legislation.vic.gov.au/as-made/acts/working-children-act-2005)
  9. [Crimes Act 1958 (Vic)](https://www.legislation.vic.gov.au/in-force/acts/crimes-act-1958/)
  10. [Department of Foreign Affairs and Trade Child Protection Policy](https://www.dfat.gov.au/sites/default/files/child-protection-policy.pdf)
  11. [Education Services for Overseas Students Act 2000](https://policies.rmit.edu.au/directory/summary.php?legislation=1) (Cth)
  12. [Foundation Program Standards 2021](https://www.legislation.gov.au/F2021L01264/asmade/text)
  13. [ELICOS Standards 2018](https://www.legislation.gov.au/Details/F2017L01349)
  14. [National Code 2018](https://www.teqsa.gov.au/national-code-practice)
  15. [United Nations Convention on the Rights of the Child](https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-rights-child)
  16. [Preventing Sexual Exploitation, Abuse and Harassment Policy (2019)](https://www.dfat.gov.au/international-relations/themes/preventing-sexual-exploitation-abuse-and-harassment)
  17. [Law on Children (Law No. No. 102/2016/QH13) (Vietnam)](https://www.economica.vn/Content/files/LAW%20%26%20REG/102_2016_QH13%20Law%20on%20Children.pdf)


(31)  Non-compliance with the legislation will result in an internal or external investigation and may affect an individual’s employment or association with RMIT University and its controlled entities.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=213#document-top)
# Section 5 - Procedures and Resources
(32)  The following documents are established in accordance with this policy:
  1. [Child Safe Reporting Procedure](https://policies.rmit.edu.au/document/view.php?id=214)
  2. [Child Safe Reporting Procedure - Vietnam](https://policies.rmit.edu.au/document/view.php?id=217)
  3. [Child Safe Code of Conduct](https://policies.rmit.edu.au/document/view.php?id=249)
  4. [Child Safe Reporting Instruction](https://policies.rmit.edu.au/download.php?id=354&version=2&associated)
  5. [Child Safe Image Instruction](https://policies.rmit.edu.au/document/view.php?id=235)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=213#document-top)
# Section 6 - Definitions
Adult | A person 18 years of age and older  
---|---  
Child | A child/young person under the age of 18 years  
Child abuse |  An act or acts which endangers a child’s health, wellbeing and/or development. It can be a single event or a series of events. It includes: - cumulative harm - emotional or physical abuse - exposure to family violence - neglect - grooming - sexual abuse and sexual exploitation (sexual harm) - multi-dimensional harm  
Historical abuse | Historical sexual abuse is a term used to describe child and/or adult sexual abuse that has happened in the past. This could mean months, years or decades ago.  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
