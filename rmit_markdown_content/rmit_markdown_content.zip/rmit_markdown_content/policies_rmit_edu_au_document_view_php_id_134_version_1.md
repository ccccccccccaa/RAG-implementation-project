[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=134&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=134&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Equity and Other Admission Schemes Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=134)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=134&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=134&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=134&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=134&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=134&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=134&version=1)


# Equity and Other Admission Schemes Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=134&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=134&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=134&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=134&version=1#section4)
  * [Recognised Under-Represented Groups ](https://policies.rmit.edu.au/document/view.php?id=134&version=1#major1)
  * [Eligibility Criteria for Equity Admission Schemes ](https://policies.rmit.edu.au/document/view.php?id=134&version=1#major2)
  * [RMIT Equity Admissions Schemes](https://policies.rmit.edu.au/document/view.php?id=134&version=1#major3)
  * [Subject Adjustments ](https://policies.rmit.edu.au/document/view.php?id=134&version=1#major4)
  * [Elite Athlete Adjustment ](https://policies.rmit.edu.au/document/view.php?id=134&version=1#major5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  RMIT is committed to supporting student diversity and ensuring people from all backgrounds have the opportunity to access RMIT programs 
(2)  This procedure details the ways in which RMIT will support groups considered to be under-represented in tertiary education, by the application of adjustment factors to entry scores.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=134&version=1#document-top)
# Section 2 - Authority
(3)  Authority for this document is established by the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=134&version=1#document-top)
# Section 3 - Scope
(4)  This procedure applies to all applications for admission to RMIT programs and courses that meet the prescribed eligibility criteria.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=134&version=1#document-top)
# Section 4 - Procedure
### Recognised Under-Represented Groups 
(5)  RMIT maintains equitable and other admissions schemes to support student diversity and promote:
  1. access to RMIT programs, and
  2. participation of students from recognised under-represented and other groups who have experienced educational disadvantage.


(6)  The following student cohorts are considered by RMIT to be under-represented in tertiary education and eligible for equity admission consideration: 
  1. students from rural and isolated areas 
  2. students from low socioeconomic status (SES) backgrounds 
  3. students with disabilities 
  4. Aboriginal and Torres Strait Islander students 
  5. women in specific disciplines 
  6. mature-age students
  7. students from a School Network Access Program (SNAP) partnership school
  8. students from non–English speaking backgrounds 
  9. students who have experienced educational disadvantage. 


(7)  Applicants may be awarded a maximum of 28 aggregate points by equity and other adjustments.
### Eligibility Criteria for Equity Admission Schemes 
(8)  Equity consideration is only available for admission to programs at certificate IV level and above. 
(9)  Applicants must meet citizenship and residency requirements and must follow the specified application process within the specified time-frames. 
(10)  Applicants must meet the entry requirements for their intended program. 
(11)  Domestic and other eligible cohorts applying to eligible RMIT award programs may be considered under one or more admission scheme category.
### RMIT Equity Admissions Schemes
(12)  RMIT equity admission schemes for domestic and other eligible cohorts are aligned across application processes through the approaches/mechanisms detailed in this section.
#### Adjustment Factors for Under-Represented Groups 
(13)  The University allocates adjustment to eligible students from under-represented and equity groups that reflect the University’s equity priorities through: 
  1. the VTAC Equity Schemes and Scholarships
  2. the RMIT Access scheme, and 
  3. Regional Adjustments. 


(14)  Adjustment factors are applied by selection officers to an applicant’s selection rank where they meet eligibility criteria.
(15)  Programs that select using a selection task will apply the adjustment factor to the scored outcome of the task according to the program selection methodology. 
#### Regional Adjustments 
(16)  Regional adjustment factors are automatically applied to the selection rank of applicants whose highest qualification is Year 12 and who reside in areas classified as low SES. 
  1. The low SES adjustment is not restricted to applicants who have made an individual Equity Schemes and Scholarships or RMIT Access application for the consideration of disadvantage but applies to anyone from the designated areas in the entire applicant pool for a program.


#### Adjustment for Applicants from a School Network Access Program (SNAP) 
(17)  SNAP consideration is available through the VTAC Equity Schemes and Scholarships application process and is aimed at improving access to higher education for students from select Victorian secondary schools with whom the University has a SNAP partnership. 
  1. For programs that use ATAR for selection SNAP consideration is provided via re-ranking within the VTAC system. 
  2. Programs that select using a selection task will apply the adjustment factor to the scored outcome of the task according to the program selection methodology. 


### Subject Adjustments 
(18)  Eligible Year 12 applicants may be automatically awarded subject adjustments to their selection rank if they are applying for an undergraduate course and have gained the required minimum study score in an eligible VCE subject. 
### Elite Athlete Adjustment 
(19)  Elite and emerging athletes who apply for the Elite Athlete Scheme may be eligible for an adjustment to their selection rank. 
  1. Applicants must be assessed and verified as an Elite or Emerging Athlete based on evidence provided with their application for admission.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
