[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=11&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=11&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Policy 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=11)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=11&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=11&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=11&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=11&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=11&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=11&version=1)


# Enrolment Policy
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=11&version=1#section1)
  * [Section 2 - Scope](https://policies.rmit.edu.au/document/view.php?id=11&version=1#section2)
  * [Section 3 - Policy](https://policies.rmit.edu.au/document/view.php?id=11&version=1#section3)
  * [Part A - Enrolment](https://policies.rmit.edu.au/document/view.php?id=11&version=1#part1)
  * [Requirements for Enrolment](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major1)
  * [Entitlements of Enrolment](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major2)
  * [Concurrent and Cross-institutional Enrolments](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major3)
  * [Mobility Enrolments](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major4)
  * [Variations to Enrolment](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major5)
  * [Attendance Requirements](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major6)
  * [Leave of Absence](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major7)
  * [Missing Student](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major8)
  * [Death of a Student](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major9)
  * [Cancellation of Enrolment by a Student](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major10)
  * [Cancellation of Enrolment by the Institution](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major11)
  * [Transfer of International Students to Another Provider](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major12)
  * [Effect of Exclusion, Suspension or Expulsion](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major13)
  * [Part B - Refund of Fees](https://policies.rmit.edu.au/document/view.php?id=11&version=1#part2)
  * [Refund of Fees and Remission of Debt](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major14)
  * [Where Students Withdraw by the Student’s Class Enrolment Census Date](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major15)
  * [Appeals Against Fee Refund Decisions for Timely Withdrawals](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major16)
  * [Late Refund or Remission Under Special Circumstances](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major17)
  * [Review of Decisions of Late Refund or Remission in Special Circumstances](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major18)
  * [Late Leave of Absence in Exceptional Circumstances](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major19)
  * [Part C - Processes](https://policies.rmit.edu.au/document/view.php?id=11&version=1#part3)
  * [Enrolment Processes and Guidance Materials](https://policies.rmit.edu.au/document/view.php?id=11&version=1#major20)
  * [Section 4 - Procedures and Resources](https://policies.rmit.edu.au/document/view.php?id=11&version=1#section4)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=11&version=1#section5)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This policy establishes the rules for enrolment of students at RMIT Group institutions.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=1#document-top)
# Section 2 - Scope
(2)  All programs and courses offered by RMIT University and English Language Intensive Courses for Overseas Students (ELICOS) training programs provided by RMIT Training.
(3)  Non-award courses offered by RMIT University, to which students are admitted via RMIT Training are within the scope of this policy.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=1#document-top)
# Section 3 - Policy
## Part A - Enrolment
### Requirements for Enrolment
(4)  A person is eligible to enrol if they have satisfied the requirements of enrolment as stated in the enrolment process of the relevant institution.
### Entitlements of Enrolment
(5)  A person enrolled in a program or course is:
  1. subject to the statutes, regulations and policies of the relevant RMIT institution, and
  2. entitled to: 
    1. academic and student support services offered by the institution;
    2. attend or participate in teaching sessions and other scheduled activities (except in short courses and some English skills acquisition courses where there is no summative assessment);
    3. assessment of their learning and performance;
    4. in the case of higher degree by research programs, research training and supervision; and
    5. receive results (except in short courses and some English skills acquisition courses where there is no summative assessment).


(6)  A person who is not enrolled by the enrolment or re-enrolment deadline published by the RMIT institution for the relevant teaching period is not considered to be a student and does not have the responsibilities or entitlements described in clause 5(b).
(7)  Students in the following situations remain a student enrolled at their RMIT institution, and are entitled to academic and student support services of the institution, although not enrolled in RMIT courses:
  1. a student granted leave of absence from their program;
  2. a student enrolled at an external institution as part of an approved study abroad arrangement or exchange program.


(8)  The RMIT institution may extend students’ enrolment entitlements to permit them to complete assessment tasks.
(9)  Where a student is determined by the RMIT institution to have completed the requirements of their program, their enrolment in that program will expire on the day before the start-date of the next relevant compulsory teaching period, or on their graduation with the qualification, whichever is the earlier.
### Concurrent and Cross-institutional Enrolments
(10)  With permission, a student may be enrolled concurrently in more than one program of the RMIT institution, subject to the requirements in the enrolment process for that institution.
(11)  A student enrolled in an RMIT program may apply to study some courses at an external institution, subject to:
  1. the requirements to be eligible for credit for these courses stated in the [Admission and Credit Policy](https://policies.rmit.edu.au/document/view.php?id=6), and
  2. the requirements of the enrolment process for the RMIT institution.


(12)  A student enrolled in a program at an external institution may apply to study single courses on a non-award basis at an RMIT institution, subject to the requirements in the enrolment process for the RMIT institution.
### Mobility Enrolments
(13)  For the requirements in relation to cross-institutional, exchange and study abroad enrolments, and enrolments to enable students to study at RMIT programs in more than one country, see the enrolment process for the relevant RMIT institution.
### Variations to Enrolment
(14)  A student may add and withdraw from courses up to the deadline published by the institution for variations to enrolment in the relevant teaching period, provided these changes comply with:
  1. the program structure;
  2. published course requisites;
  3. any enrolment instructions issued to the student by the institution; and
  4. any other requirements for variation of enrolment stated in the enrolment process for the relevant institution.


(15)  A student will incur academic and/or financial penalties if they withdraw from courses after the deadline published by the institution for variations to enrolment in the relevant teaching period, subject to the rules in this policy regarding refund of fees and remission of debt.
(16)  An RMIT institution may:
  1. instruct a student to amend their enrolment to comply with the requirements of a policy or process of the institution; and
  2. where a student does not comply with such an instruction, amend the student’s enrolment directly.


### Attendance Requirements
(17)  Attendance requirements apply to some types of students: see the enrolment process for the relevant RMIT institution.
(18)  Under circumstances described in the enrolment process for the RMIT institution, an officer of the institution may report a student in an international English language course, Foundation Studies or Victorian Certificate of Education program to the federal Department of Immigration (“the Department”) for a breach of attendance requirements of their Australian student visa. The officers who do this are:
  1. for RMIT Training 
    1. RMIT English Worldwide, the RMIT Training Student Services Compliance Administrator or RMIT Training Student Services Compliance Officer
    2. Foundation Studies, the International Compliance Coordinator in Compliance, Regulation and Reporting (CRR)
  2. for RMIT University, the International Compliance Coordinator in Compliance, Regulation and Reporting (CRR).


(19)  The student has a right to appeal this decision to the relevant director where the student:
  1. provides evidence that the University has made an error in process that has been a significant factor in the decision, and/or
  2. provides evidence that significant circumstances have not been taken into account, and/or
  3. provides new, relevant evidence that was not available at the time the non-attendance was identified, that would have been a significant factor in the decision.


(20)  The relevant director is:
  1. for RMIT Training, 
    1. RMIT English Worldwide, the Director, Pathways, RMIT Training
    2. Foundation Studies, the Director, Compliance, Regulation and Reporting, RMIT University
  2. for RMIT University, the Director, Compliance, Regulation and Reporting, RMIT University.


(21)  The student must submit the appeal in writing to the relevant director within 20 working days of the date of the letter advising them of the intention to report them to the Department.
(22)  See the enrolment process for the relevant institution for detailed requirements in relation to this type of appeal and, if an appeal is dismissed, in relation to the student’s right to apply for review of the decision by:
  1. in the case of RMIT Training students, the Overseas Student Ombudsman;
  2. in the case of RMIT University students, Ombudsman Victoria.


### Leave of Absence
(23)  Leave of absence is available to students enrolled in some types of program. See the enrolment process for the relevant institution for requirements in relation to leave of absence.
(24)  A student who is suspended, expelled or excluded, or whose enrolment is cancelled, is not eligible for leave of absence. At the conclusion of any appeal process, a decision to suspend, expel or exclude a student overrides any approved leave of absence.
### Missing Student
(25)  Missing students must be reported using the enrolment process for the relevant RMIT institution.
### Death of a Student
(26)  The actions required upon the death of a student are set out in the enrolment process for the relevant RMIT institution.
### Cancellation of Enrolment by a Student
(27)  A student who wishes to cancel their enrolment must do so by dropping the relevant courses in the online enrolment system or by writing to the institution by the deadline for the relevant teaching period: see the enrolment process for the relevant institution.
(28)  Any student who transfers from an RMIT institution to another registered provider must cancel their enrolment at RMIT.
(29)  A student who withdraws from or cancels all their course enrolments in a program ceases to be enrolled in the program. The student must apply for readmission should they wish to resume studying in the program: see the [Admission and Credit Policy](https://policies.rmit.edu.au/document/view.php?id=6) for requirements in relation to readmission.
### Cancellation of Enrolment by the Institution
(30)  Where a student has not paid all course fees by the deadline for payment, their enrolment may be cancelled by the institution.
(31)  The institution may cancel a student’s enrolment under the circumstances and subject to the requirements described in the enrolment process for the relevant institution.
### Transfer of International Students to Another Provider
(32)  International students studying on a student visa in Australia who have not yet completed six months of study in the program in which they are enrolled, require a letter of release from the RMIT institution, before they can be enrolled at another institution. Details are set out in the enrolment process for the RMIT institution.
(33)  A student may appeal a decision by the RMIT institution not to release them to transfer to another institution, if they can provide evidence that:
  1. significant relevant circumstances have not been taken into account in the decision, and/or
  2. there was an error in process or breach of policy that had a significant impact on the decision, and/or
  3. there is new, relevant information that was not available at the time the student made the application, which would have had a significant impact on the decision.


(34)  The student must submit their appeal in writing to the relevant director within 20 working days of the date the decision was emailed to them. The relevant director is:
  1. for RMIT Training 
    1. RMIT English Worldwide, the Director, Pathways, RMIT Training
    2. Foundation Studies, the Executive Director, International
  2. for RMIT University, the Executive Director, International.


(35)  Students who wish to seek review of the outcome of the appeal by an external agency must do so within 10 working days of the date their appeal outcome was emailed to them.
(36)  See the enrolment process for the relevant institution for detailed requirements in relation to this type of appeal and, if an appeal is dismissed, in relation to the student’s right to apply for review of the decision by:
  1. in the case of RMIT Training students, the Overseas Student Ombudsman;
  2. in the case of RMIT University students, Ombudsman Victoria.


### Effect of Exclusion, Suspension or Expulsion
(37)  A person who has been expelled from an RMIT institution is:
  1. not permitted to enrol in any program or course at any RMIT institution (including programs or courses offered by an RMIT institution via another provider such as Open Universities Australia); and
  2. not entitled to use the services offered by any RMIT institution to enrolled students.


(38)  A person who has been suspended from an RMIT institution is, for the period of the suspension:
  1. not permitted to enrol in any program or course at any RMIT institution (including programs or courses offered by an RMIT institution via another provider such as Open Universities Australia); and
  2. not entitled to use the services offered by any RMIT institution to enrolled students.


(39)  At the conclusion of a specified period of suspension from the RMIT institution, a student:
  1. has the right to resume their studies in the same program they were studying when suspended, subject to the availability of the program or an equivalent replacement program, and
  2. is required to meet any conditions for resumption of their studies that have been set by the institution.


(40)  A person who has been excluded from an RMIT program:
  1. is not permitted to enrol in any courses for the program during the period of their exclusion, but
  2. may apply for admission to other programs of the institution, or another RMIT institution.


(41)  At the conclusion of a period of exclusion for unsatisfactory academic progress, a student may apply for readmission to the program from which they were excluded: see the [Admission and Credit Policy](https://policies.rmit.edu.au/document/view.php?id=6) and processes.
(42)  A student is entitled to maintain their enrolment during an internal appeal against, or a recognised external review of, a decision to exclude them for unsatisfactory academic progress: see the [Assessment and Assessment Flexibility Policy](https://policies.rmit.edu.au/document/view.php?id=7) and [Assessment Processes](https://policies.rmit.edu.au/document/view.php?id=38).
## Part B - Refund of Fees
### Refund of Fees and Remission of Debt
(43)  The clauses below apply to programs delivered by RMIT institutions alone, not to programs delivered in partnership with other education providers. For students enrolled with a partner institution, the policy and processes of the partner institution on refund of fees and remission of debt apply.
### Where Students Withdraw by the Student’s Class Enrolment Census Date
(44)  A student who withdraws from courses or cancels their enrolment in a program:
  1. can apply for a refund of course fees they have paid themselves; and
  2. will not incur a debt for tuition fee loans from the Australian government,


(45)  An individual or organisation that has paid a student’s fees on their behalf can also apply for a refund of the fees under the above circumstances.
(46)  The RMIT institution may withhold an administrative fee from the refund to:
  1. international students studying in Australia on a student visa; or
  2. students studying at a campus outside Australia;
  3. an individual or organisation that has paid the fees on behalf of such students.


(47)  RMIT Training may withhold an administrative fee from the refund to domestic students studying ELICOS courses in Australia.
### Appeals Against Fee Refund Decisions for Timely Withdrawals
(48)  A commencing international student studying in Australia on a student visa, or a domestic student studying an ELICOS course offered by RMIT Training in Australia, may appeal a decision not to refund their fees or the refund amount, for courses undertaken in the first six months of their RMIT study.
(49)  The student must submit the appeal in writing, within 20 working days of the date the email notifying them of the decision was sent to them, to the relevant director, who is:
  1. for RMIT Training, the Director, RMIT English Worldwide Melbourne;
  2. for RMIT University, the Executive Director, International.


(50)  Appeals can be considered if the student:
  1. provides evidence that the institution has made an error in process that has been a significant factor in the decision; and/or
  2. provides evidence that significant circumstances have not been taken into account; and/or
  3. provides new, relevant evidence that was not available at the time of the decision, which would have been a significant factor in the decision.


(51)  Details of the refund application process, any administrative fees, and the appeal process are set out in the enrolment process for the relevant RMIT institution.
### Late Refund or Remission Under Special Circumstances
(52)  An RMIT Training ELICOS student who withdraws from a course or fails a course, or cancels their program enrolment, after the census date, or others who have paid the fees for their enrolment, may apply for a refund of tuition fees for courses where circumstances outside the student’s control made it impracticable for them to complete the courses.
(53)  An RMIT University student who withdraws from a course or fails a course, or cancels their program enrolment, after the census date, or others who have paid the fees for their enrolment, may apply to the institution for a refund of tuition fees, or (where relevant) remission of their Australian government tuition fee loan debt, for courses where the following conditions apply:
  1. circumstances outside the student’s control made it impracticable for them to complete the course; and
  2. these circumstances did not make their full impact on the student until on or after the census date in the course; and
  3. the student had not had assessment results such that they would certainly have failed the course at the time the circumstances made their full impact; and
  4. the student applies in accordance with the requirements of the enrolment processes of the relevant RMIT institution.


(54)  A student, or an individual or organisation who paid tuition fees on behalf of the student, may apply to the following officers for refund of fees or remission of debt under the above circumstances:
  1. for remission of Australian government tuition fee loan debt, to the Manager, Assessment Support, RMIT University;
  2. for refund of fees for study at RMIT University, to the Academic Registrar (or nominee);
  3. for refund of fees for study at RMIT Training, to the Director, RMIT English Worldwide Melbourne;


(55)  Applications may be considered if they are submitted within one calendar year of:
  1. the date the student’s withdrawal from the course was actioned by the institution, or
  2. where the student did not withdraw from the course, the end-date of the relevant teaching period.


(56)  In exceptional circumstances, a later application can be considered, if the student provides evidence that it was not possible for them to apply sooner.
### Review of Decisions of Late Refund or Remission in Special Circumstances
(57)  Where a student is dissatisfied with a decision not to grant refund of fees under the circumstances described above, they can apply for a review of the decision from the following:
  1. for RMIT Training, the Chief Executive Officer, RMIT Training;
  2. for RMIT University, the RMIT Ombuds;


(58)  Where a student is dissatisfied with a decision not to grant them remission of government tuition fee loan debt under the circumstances described above, they can apply for a review of the decision by the Academic Registrar and, if still dissatisfied, can apply for external review by the Administrative Appeals Tribunal.
### Late Leave of Absence in Exceptional Circumstances
(59)  Where a student of RMIT University or RMIT Vietnam is unable to complete their courses in a teaching period because of circumstances beyond their control, but does not meet the criteria for late refund of fees or remission of debt under special circumstances above, the Academic Registrar or Registrar of the institution may in exceptional circumstances authorise a leave of absence backdated to before the course census date. Such decisions of the Academic Registrar or Registrar are final.
## Part C - Processes
### Enrolment Processes and Guidance Materials
(60)  The Academic Registrar maintains processes and guidance materials for enrolment in RMIT University programs and courses.
(61)  The Chief Executive Officer, RMIT Training maintains processes and guidance materials for enrolment in RMIT Training programs and courses.
(62)  The Executive Director, Vocational Education maintains processes specific to vocational education compliance.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=1#document-top)
# Section 4 - Procedures and Resources
(63)  Refer to the following documents which are established in accordance with this Policy:
  1. [Enrolment Processes](https://policies.rmit.edu.au/document/view.php?id=45)
  2. [Enrolment Processes - Refund of Fees](https://policies.rmit.edu.au/document/view.php?id=46)
  3. VE Essentials

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=11&version=1#document-top)
# Section 5 - Definitions
Census date | The date after which students can no longer withdraw from a class and have their fees refunded (unless there are exceptional circumstances).  
---|---  
Course requisite | A course that a student must have completed or be enrolled in as a precondition of their enrolment in another course.  
Cross-institutional enrolment | Where a student enrols at an institution other than their home institution, in courses that count towards their home program.  
Domestic student | A student studying in Australia who is a citizen or permanent resident of Australia, or who holds an Australian temporary protection visa, or who is a New Zealand citizen.  
Enrolment | The process by which a person registers as a student of the institution and the resulting state of being enrolled.  
Exchange | A cross-institutional enrolment at an institution in another country, under a formal agreement between the two institutions.  
Exclusion | Where a student’s enrolment in a program is cancelled for a specified period, but the student is not barred from applying for admission to other programs or enrolling in single courses.  
Expulsion | Where a student’s enrolment is cancelled and they are not permitted to enrol in any program or course of any RMIT Group institution (including courses/programs that an RMIT Group institution offers via another provider) for an indefinite period.  
Leave of absence | Where a student is granted approved leave from studying in a program for a specific period.  
Non-award enrolment | Where a student is enrolled in a single course or courses without having been admitted to a program that leads to an award.  
RMIT Institution | An institution in the RMIT Group, being either RMIT Melbourne, RMIT Vietnam, RMIT Europe or RMIT Training.  
Student | Someone who is enrolled to undertake a program or course of the institution.  
Study abroad | A cross-institutional enrolment at an institution in another country, where there is no formal exchange agreement between the two institutions.  
Suspension | Where a student is barred for a specified period from attending any teaching or assessment session, or being present on any campus, or using any computing or network facilities, of any RMIT Group institution (including courses/programs that an RMIT Group institution offers via another provider) for a specific period.  
Teaching period | A semester, trimester or other period of time within which classes are scheduled; at RMIT Training, the term “study period” means teaching period  
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
