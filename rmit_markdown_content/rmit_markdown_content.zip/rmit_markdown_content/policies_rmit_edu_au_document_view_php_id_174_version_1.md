[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=174&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=174&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Unsatisfactory Progress Process 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=174)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=174&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=174&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=174&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=174&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=174&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=174&version=1)


# HDR Unsatisfactory Progress Process
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=174&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=174&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=174&version=1#section3)
  * [Section 4 - Process](https://policies.rmit.edu.au/document/view.php?id=174&version=1#section4)
  * [College review of CASP](https://policies.rmit.edu.au/document/view.php?id=174&version=1#major1)
  * [College Review of Candidate Progress](https://policies.rmit.edu.au/document/view.php?id=174&version=1#major2)
  * [Candidature Termination](https://policies.rmit.edu.au/document/view.php?id=174&version=1#major3)
  * [Appeals Against Termination](https://policies.rmit.edu.au/document/view.php?id=174&version=1#major4)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Purpose
(1)  This document sets out the process for addressing unsatisfactory academic progress by HDR candidates following the implementation of a Candidate Action Support Plan (CASP) as outlined in the [HDR Action and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=13).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=174&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [HDR Action and Support Procedure](https://policies.rmit.edu.au/document/view.php?id=13).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=174&version=1#document-top)
# Section 3 - Scope
(3)  The process applies to all staff responsible for HDR management and supervision and all HDR candidates of the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=174&version=1#document-top)
# Section 4 - Process
### College review of CASP
(4)  Following a candidate’s continued unsatisfactory academic progress after the implementation of a CASP, the HDR Delegated Authority (HDR DA) will refer the matter to the College representative or nominee.
(5)  Within 10 working days of referral, the College Graduate Research Committee (CGRC) representative or nominee will determine whether the conditions of the CASP have not been met due to:
  1. any failure by the University as represented by the supervisory team, HDR DA, School administration or University services, which has materially affected the candidate’s ability to maintain good progress; or
  2. the candidate’s inability or refusal to complete the actions detailed for them in the CASP; or
  3. a combination of the above. 


(6)  This is done through reference to:
  1. all documentation relating to the candidate’s candidature, progress, supervisory meetings, and the support provided to the candidate, supplied by the School
  2. any relevant evidence supplied by the School of Graduate Research (SGR).


(7)  If required, the College may also:
  1. interview the HDR DA and/or supervisory team
  2. conduct a confidential interview with the candidate.


(8)  The College representative will submit a report of the audit to SGR and a recommendation as to whether the candidate should:
  1. be permitted a further period of action and support
  2. attend a Research Candidate Progress Committee (RCPC).


(9)  Where a deficit in support provided by the University is identified, the audit report should also include a remediation plan.
(10)  The Associate Deputy Vice-Chancellor Research Training and Development (ADVC RT&D) or delegate will consider the recommendations from the College CASP audit for approval, and determine subsequent action as needed.
(11)  SGR will monitor implementation of any remediation plan developed following College review.
### College Review of Candidate Progress
(12)  Where the College CASP audit finds that responsibility for not meeting the conditions of the CASP lies with the candidate, the College will convene an RCPC to determine whether the candidature is viable.
  1. The RCPC Secretary must notify the candidate via email and invite them to attend, at least 15 working days prior to the meeting (unless otherwise agreed with the candidate). The RCPC Secretary will be an administrator nominated by the College. 
  2. Candidates must be enrolled and are afforded all the entitlements of enrolment during the College Review of Candidate Progress.


(13)  The RCPC is convened by the College and will comprise the following members:
  1. Committee Chair (CGRC member or nominee)
  2. School HDR DA
  3. An independent senior academic from another school in the same College, who is registered as a Category 1 supervisor.


(14)  RCPC meetings must be face-to-face in person or via video conferencing.
(15)  The candidate’s supervisory team is invited to provide evidence at the RCPC. At least one of the candidate’s supervisors must attend in this capacity. 
(16)  The candidate’s supervisors may not be members of the RCPC and must not be present during Committee deliberations.
(17)  All documentation relating to the College audit must also be provided to the RCPC.
(18)  Candidates may take one support person to the RCPC.
(19)  Candidates will be offered an opportunity to make a written submission to the committee.
  1. If they accept, their submission should provide evidence on all relevant issues and special circumstances affecting academic performance.
  2. They must also provide grounds to RMIT that clearly define how they will improve their progress so that it can be assessed as ‘satisfactory’.
  3. Wherever possible, this written submission must be supported by relevant independent documentation.


(20)  Any written submission is to be provided by the candidate to the Secretary of the RCPC at least five (5) working days prior to the meeting. Late submissions will be accepted at the discretion of the Committee Chair.
(21)  In the case of a candidate who does not attend the RCPC, or lodge a written submission, the meeting will be held and the committee will make a recommendation based on the evidence available.
(22)  After consideration of all available evidence by the Committee, the Chair of the RCPC can recommend to the ADVC RT&D that:
  1. there is a valid case for the candidate to be allowed to continue in their program, because there is insufficient evidence of unsatisfactory progress; in this case the candidate is renominated for action and support, or
  2. the candidature is terminated due to unsatisfactory academic progress.


(23)  The recommendation must be documented on the [Research Candidate Progress Committee (RCPC) Outcome Form](https://policies.rmit.edu.au/download.php?id=228&version=1&associated).
(24)  The RCPC Outcome Form and meeting minutes are provided to the candidate, RCPC members, any supervisors who attended the meeting, and SGR by the RCPC Secretary within 5 working days of the RCPC meeting. SGR is also sent a complete set of supporting documentation at this time.
(25)  The notification of the final RCPC outcome from the ADVC RT&D or delegate will be provided to the candidate via email within 10 working days of SGR receiving the recommendation from the RCPC.
### Candidature Termination
(26)  Where an RCPC recommends that the candidature is terminated, and if the ADVC RT&D or delegate approves the recommendation, all documentation is forwarded to the Academic Registrar's Group (ARG) for a review of compliance with RMIT policies. The candidate will receive a notification of the outcome via email within 10 working days of ARG receiving the progress documentation from SGR.
  1. If, after ARG review, a termination of candidature decision is found to be non-compliant, SGR will inform the candidate, School and College that the candidate will require a further period of action and support. A new CASP must then be developed by the School.
  2. If the termination documentation is compliant, ARG will commence the process of cancellation of enrolment.
  3. The notification of the intention to cancel enrolment will be provided to the candidate by ARG.


### Appeals Against Termination
(27)  A candidate may appeal against a decision to terminate their candidature which has been based on their having unsatisfactory academic progress to the University Appeals Committee (UAC) via the Academic Registrar. The appeal process detailed in the [Assessment, Academic Progress and Appeals Regulations](https://policies.rmit.edu.au/document/view.php?id=190) should be followed.
(28)  A candidate may lodge an appeal on the following grounds:
  1. there is evidence of a breach of University legislation, policy or process in the handling of the additional support process which has had a meaningful impact on the determination to terminate the candidature, and/or
  2. there is significant new, relevant evidence that was not available at the time of the Research Candidate Progress Committee meeting.


(29)  Candidates must lodge their appeal application no later than 20 working days from the date the notification of intention to cancel their enrolment is sent to them by the university. This date will be specified in the notification of the intention to cancel enrolment.
(30)  A candidate is entitled to maintain their enrolment during an internal appeal against a decision to terminate their HDR candidature due to unsatisfactory academic progress. The process to initiate enrolment cancellation by the Academic Registrar's Group will not be undertaken until the candidate is notified of the outcome of the UAC hearing. Candidates will continue to consume candidature during this time.
(31)  Where an international candidate studying in Australia has their candidature terminated for unsatisfactory academic progress, the Academic Registrar will cancel the candidate’s confirmation of enrolment in accordance with the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
(32)  If candidature is terminated, any further enrolment in a higher degree by research program at RMIT can only be achieved by the person re-applying for admission, in accordance with the [Admission Policy](https://policies.rmit.edu.au/document/view.php?id=6).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
