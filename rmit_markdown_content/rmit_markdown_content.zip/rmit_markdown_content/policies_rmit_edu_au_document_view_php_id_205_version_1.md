[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=205&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=205&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Program and Course Approval Procedure - Higher Degree by Research 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=205)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=205&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=205&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=205&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=205&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=205&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=205&version=1)


# Program and Course Approval Procedure - Higher Degree by Research
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=205&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=205&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=205&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=205&version=1#section4)
  * [Program and Course Lifecycle – Higher Degree by Research Programs](https://policies.rmit.edu.au/document/view.php?id=205&version=1#major1)
  * [Higher Education Program and Course Approval Criteria that apply to Research Programs](https://policies.rmit.edu.au/document/view.php?id=205&version=1#minor1)
  * [New Research Programs, Program Offerings and Amendments to Existing Programs](https://policies.rmit.edu.au/document/view.php?id=205&version=1#minor2)
  * [New Research Courses and Amendments to Existing Courses ](https://policies.rmit.edu.au/document/view.php?id=205&version=1#minor3)
  * [Discontinuation of Research Programs](https://policies.rmit.edu.au/document/view.php?id=205&version=1#minor4)
  * [Research Programs Offered with a Partner Institution Outside Australia ](https://policies.rmit.edu.au/document/view.php?id=205&version=1#minor5)
  * [Section 5 - Schedules ](https://policies.rmit.edu.au/document/view.php?id=205&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets the requirements for higher degrees by research program and course approval, delivery, management and discontinuation.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=205&version=1#document-top)
# Section 2 - Authority
(2)  The authority for this document is established by the [Program and Course Policy](https://policies.rmit.edu.au/document/view.php?id=27).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=205&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to all higher degree by research programs and courses offered by the RMIT Group, partners and affiliated third parties. 
(4)  This procedure does not address approvals for higher education coursework, non-award courses or vocational education and training (please see the [Program and Course Approval Procedure - Higher Education Coursework, Short Courses and Micro-Credentials](https://policies.rmit.edu.au/document/view.php?id=297) and the [Program and Course Approval Procedure – Vocational Education and Training](https://policies.rmit.edu.au/document/view.php?id=207)). 
(5)  This procedure does not address the delivery and management of higher degrees by research, including information about admissions, candidature, examinations and related matters, which are covered by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) suite.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=205&version=1#document-top)
# Section 4 - Procedure
(6)  Award programs comply with the volume of learning in the relevant [Australian Qualifications Framework (AQF)](https://policies.rmit.edu.au/download.php?id=18&version=2&associated) specification. 
(7)  A new program or program offering or amended program offering can only be advertised or commence delivery once approval has been provided by the RMIT delegated authorities defined in the [Program and Course Schedule – Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=10&associated). 
(8)  A new program or program offering: 
  1. requiring Australian Commonwealth financial support under the [Higher Education Support Act 2003](https://policies.rmit.edu.au/directory/summary.php?legislation=21) can only commence delivery once it has been registered with the Commonwealth Government 
  2. intended to be available to international students in Australia can only commence advertising or delivery once it has been issued a CRICOS code 
  3. required to be registered with any other national regulator of tertiary education programs can only commence delivery once it has been registered. 


(9)  An RMIT program must be delivered in English before it is offered in another language so that learning and assessment materials can be aligned with internal and external compliance standards before they are translated. 
  1. RMIT programs that are delivered and assessed in a language other than English must be approved by Academic Board. 


### Program and Course Lifecycle – Higher Degree by Research Programs
(10)  RMIT higher degree by research programs require: 
  1. the completion of an original research project undertaken by a single higher degree candidate under the academic supervision of at least two duly appointed supervisors 
  2. the development of researcher capabilities by each candidate through formative experience 
  3. completion of coursework courses no more than 33% proportional to the overall program. 


(11)  All higher degree by research programs follow a similar format and are subject to the same award criteria regardless of the field of research or the academic organisational unit which owns the program. 
(12)  Coursework offered through research programs may or may not be program-specific and may be offered in a variety of program contexts depending on the research methods and capabilities a candidate requires to complete their research. 
(13)  New programs and significant changes to program format or content must be in accordance with the University-wide approach to research training delivery. 
  1. Before commencing any development requiring program or course approval, colleges and schools must liaise with the School of Graduate Research to ensure that the proposal is aligned with RMIT’s approach. 
  2. Program proposals must also align with the college or campus governance processes before any part of a Higher Education Program Approval Template (HEPAT) is submitted. 


(14)  Program and course proposals are categorised as: 
  1. new award 
  2. new offering of an existing award 
  3. change of title 
  4. amendment to an existing program
  5. business case - new program or offering 
  6. discontinuation 
  7. discontinuation – student transition or teach out plan. 


#### Higher Education Program and Course Approval Criteria that apply to Research Programs
(15)  The following criteria for all higher education program and course approvals also apply to approvals related to research programs: 
  1. Program development processes within the college or campus must include appropriate consultation, benchmarking and endorsement by the nominated research committee. 
  2. School of Graduate Research and Academic Registrar's Group Academic Governance staff may provide advice and guidance on program developments and the appropriate processes to follow. 
  3. All program and course developments, documentation for endorsement, approval and/or configuration must be submitted to the Graduate Research Committee and the Research Committee (where required) with the support of the College Research Committee. 
    1. Refer to the [Program and Course Schedule – Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=10&associated) for further information. 


#### New Research Programs, Program Offerings and Amendments to Existing Programs
(16)  The circumstances under which higher degree by research programs may require development are rare and are likely to be driven by one or more of the following: 
  1. organisational restructure 
  2. change in enterprise-wide approach to program and/or curriculum management and/or resourcing 
  3. change in regulatory landscape 
  4. outcome of program quality review. 


(17)  The creation and approval of a new research program plan is a requirement for:
  1. a new offering of an existing program at a different RMIT campus (e.g. Vietnam) or partner location, except for programs delivered with partners approved via the Collaborative Research Training Agreement approval process within the framework of existing programs offered by RMIT in Australia 
  2. a change of program title 
  3. changes to the requirements for completion of the degree (e.g. the number of core, option and/or elective courses a student must complete has changed). 


(18)  Other changes to the program structure or program guide text fields are approved as a program amendment. 
#### New Research Courses and Amendments to Existing Courses 
(19)  New research courses and amendments to existing courses may need to include consideration of the impact of these changes to the program structure and learning outcomes. 
#### Discontinuation of Research Programs
(20)  Proposals to discontinue a research program are endorsed by the Graduate Research Committee and approved by the College Deputy Vice-Chancellor. 
(21)  If the proposal involves a transition plan, the plan must be endorsed by the College Deputy Vice-Chancellor, and the Graduate Research Committee, and approved by the Research Committee. 
#### Research Programs Offered with a Partner Institution Outside Australia 
(22)  Research programs offered with a partner institution outside Australia are managed within an existing program through the Collaborative Research Training Agreement process and approval path. 
(23)  Collaborative Research Training Agreements include: 
  1. joint delivery of research training 
  2. joint award through a cotutelle agreement 
  3. a double-badged award through a double-badged PhD agreement. 


(24)  All existing RMIT Australia higher degree by research programs may be offered through such partnerships. 
(25)  Candidates enrolled through these agreements are enrolled in existing RMIT programs. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=205&version=1#document-top)
# Section 5 - Schedules 
(26)  [Program and Course Schedule - Approval and Discontinuation](https://policies.rmit.edu.au/download.php?id=404&version=10&associated).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
