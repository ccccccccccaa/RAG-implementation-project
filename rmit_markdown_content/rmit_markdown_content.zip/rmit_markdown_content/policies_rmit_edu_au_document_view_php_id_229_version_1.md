[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=229&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=229&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Data Quality Standard 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=229)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=229&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=229&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=229&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=229&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=229&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=229&version=1)


# Data Quality Standard
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=229&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=229&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=229&version=1#section3)
  * [Section 4 - Standard](https://policies.rmit.edu.au/document/view.php?id=229&version=1#section4)
  * [Overview](https://policies.rmit.edu.au/document/view.php?id=229&version=1#major1)
  * [Requirements](https://policies.rmit.edu.au/document/view.php?id=229&version=1#major2)
  * [Data Quality Dimensions and Measures](https://policies.rmit.edu.au/document/view.php?id=229&version=1#major3)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This standard defines the requirements for the quality of data and information of the RMIT Group.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=229&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=229&version=1#document-top)
# Section 3 - Scope
(3)  This standard applies to all staff with responsibility for creating, managing and using data at RMIT, including temporary employees, contractors, visitors and third parties globally who manage RMIT Group data and information, with the exception of research data as defined by the [Research Policy](https://policies.rmit.edu.au/document/view.php?id=28).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=229&version=1#document-top)
# Section 4 - Standard
### Overview
(4)  High-quality data supports University strategy and enables quality insights and decision-making, driven by data that is trusted.
(5)  This standard provides the requirements for data quality as well as data quality dimensions and measures to support establishing and maintaining high-quality data at RMIT.
(6)  This standard should be used in conjunction with the Data Quality Guideline and supporting tools, which provide staff with further guidance on assessing and improving data quality and implementing this standard in practice.
### Requirements
(7)  Data created, managed and used at RMIT must be of high quality. Data will be considered high quality when it is fit for its intended purpose and meets the requirements of all stakeholders. 
(8)  Data must meet stakeholder requirements for validity, completeness, accuracy, consistency, timeliness and uniqueness, in accordance with the data quality dimensions in this standard.
(9)  The level of data quality should be defined, assessed and measured so that it can be improved.
(10)  Data that does not meet the expected level of quality must be improved at the source, ie., at the point of data entry, creation or collection. Data that cannot be improved at the source must be corrected prior to use, for purposes such as reporting and analytics.
(11)  RMIT is required to ensure that the information it collects, uses, and discloses is accurate, complete, and up-to-date in accordance with relevant Victorian and Australian Privacy laws, specifically the [Victorian Information Privacy Principles – IPP3](https://ovic.vic.gov.au/privacy/resources-for-organisations/information-privacy-principles-full-text/) and the [Australian Privacy Principle – APP10](https://www.oaic.gov.au/privacy/australian-privacy-principles/read-the-australian-privacy-principles) regarding data quality.
### Data Quality Dimensions and Measures
(12)  The following data quality dimensions are most relevant to the RMIT Group, and should be used when defining, assessing, measuring and reporting on data quality. These may have equal or varying weights depending on the context of use.
(13)  Completeness 
  1. Data must contain values for all expected attributes and instances identified as mandatory.
  2. Completeness can be measured by comparing the number of records where data is populated to the total number of records.*


(14)  Validity
  1. Data must contain values that conform to the defined data type, format and precision as required by domain specific business rules.
  2. Validity can be measured by number of records where the validity rules are met and comparing this to the total number of records.


(15)  Accuracy
  1. Data must correctly represent the true value of the real-world concept or event being described.*
  2. Accuracy can be measured by the number of erroneous records and comparing this to the total number of records.*


(16)  Consistency
  1. Data must be absent of difference, when comparing two or more representations of a thing against a definition.*
  2. Consistency can be measured by the number of matched values across records and comparing this to the total number of records.


(17)  Timeliness
  1. Data must represent reality from the required point in time.*
  2. Timeliness can be measured by looking at the time between when data was created and when it is made available for use and by looking at whether the most up-to-date version of the information is available.


(18)  Uniqueness
  1. No record exists more than once within a data set or between multiple data sets.
  2. Uniqueness can be measured by the number of unique records identified and comparing that to the total number of records.


The [Data Quality Guidelines](https://policies.rmit.edu.au/document/view.php?id=230) provide further guidance on how to define an acceptable level of data quality and implement practices to measure, monitor and improve.
* Adapted from DAMA-DMBOK : data management body of knowledge Earley, S., Henderson, D. & Data Management Association, 2017. DAMA-DMBOK : data management body of knowledge / DAMA International ; senior editor, Deborah Henderson ; editor, Susan Earley ; production editor, Laura Sebastian-Coleman ; bibliography researcher, Elena Sykora ; collaboration tool manager, Eva Smith. 2nd ed., Bradley Beach, New Jersey: Technics Publications.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
