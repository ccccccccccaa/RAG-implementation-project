[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=167#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=167#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Enrolment Instruction - Officers of the Student Union 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=167)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=167)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=167)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=167)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=167)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=167)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=167)


# Enrolment Instruction - Officers of the Student Union
Hide Navigation
  * [Section 1 - Purpose](https://policies.rmit.edu.au/document/view.php?id=167#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=167#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=167#section3)
  * [Section 4 - Instruction](https://policies.rmit.edu.au/document/view.php?id=167#section4)
  * [Office Bearers Program](https://policies.rmit.edu.au/document/view.php?id=167#major1)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Purpose
(1)  This instruction details enrolment options and requirements for RMIT Student Union elected officers during their tenure. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=167#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Enrolment Policy](https://policies.rmit.edu.au/document/view.php?id=11).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=167#document-top)
# Section 3 - Scope
(3)  The Office Bearers program is available to elected office bearers of the RMIT Student Union only; no other students are entitled to enrol in this program.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=167#document-top)
# Section 4 - Instruction
### Office Bearers Program
(4)  Elected Officers of the RMIT Student Union (RUSU) must be enrolled to satisfy RUSU constitutional requirements. 
(5)  Elected Officers who wish to take a leave of absence from their primary program during their term as Elected Officer must enrol in the non-award program “Student Union Council – Office Bearers” to satisfy these requirements. 
(6)  Elected Officers of RUSU are not required to enrol in this program, but may choose to: 
  1. enrol in this program only (subject to an approved leave of absence from their primary program); or 
  2. enrol in this program in addition to enrolment in their award program.


(7)  This is a non-award program and does not require attendance or assessment. 
  1. Courses do not bear credit points or contribute to a reportable study load. 
  2. There are no tuition/course fees payable for this program. 
  3. No results will be issued. 
  4. Enrolment in the program will appear on a student’s transcript. 


#### Enrolment Duration
(8)  An elected officer of RUSU may be enrolled in the non-award program for a maximum of one calendar year. 
(9)  The President of RUSU may enrol in the program for a second year if holding another RUSU officer position. 
#### Student Obligations
(10)  A student who is an elected officer of RUSU may apply for leave of absence from their award program, however must enrol in the non-award program to satisfy constitutional requirements. 
(11)  Officers who are studying on an international student visa must remain enrolled in a full-time award program to meet their visa requirements, and accordingly can only be enrolled in the Office Bearers program in addition to their award program enrolment. 
(12)  While enrolled in the Office Bearers program, a student must: 
  1. continue to remain active as an officer of RUSU 
  2. satisfy all requirements to remain in their primary (award) program. 
  3. Cancellation from all other RMIT programs will result in the student being ineligible for the Office Bearers program enrolment.


#### Enrolment Requirements 
(13)  The elected officer must advise Enrolment and Student Records no later than the last day to add classes in the relevant semester, that they wish to be enrolled in the Office Bearers program. Eligibility for the program will be checked against the published results of the most recent election. 
(14)  An eligible student will be enrolled in semesters 1 and 2, or only semester 2 where the advice is received after the semester 1 census date. 
(15)  Where a student resigns from their position as an officer of RUSU before the end of their term of office, the Chair of the RUSU Council must advise the Associate Director of Enrolment and Student Records within seven (7) days of the resignation. 
(16)  Where a student has resigned their office without cancelling their Office Bearers program enrolment, Enrolment and Student Records will cancel the enrolment accordingly. 
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
