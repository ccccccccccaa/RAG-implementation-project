[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=137&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=137&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Revenue and Expenses Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=137)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=137&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=137&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=137&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=137&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=137&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=137&version=1)


# Revenue and Expenses Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=137&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=137&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=137&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=137&version=1#section4)
  * [Authorisation of Revenue](https://policies.rmit.edu.au/document/view.php?id=137&version=1#major1)
  * [Recognition and Measurement](https://policies.rmit.edu.au/document/view.php?id=137&version=1#major2)
  * [Application and Approval of Debtors](https://policies.rmit.edu.au/document/view.php?id=137&version=1#major3)
  * [Review of Debtors and Setting Credit Limit ](https://policies.rmit.edu.au/document/view.php?id=137&version=1#major4)
  * [Invoicing Customers ](https://policies.rmit.edu.au/document/view.php?id=137&version=1#major5)
  * [Trading Terms](https://policies.rmit.edu.au/document/view.php?id=137&version=1#major6)
  * [Expenses](https://policies.rmit.edu.au/document/view.php?id=137&version=1#major7)
  * [Section 5 - Definitions](https://policies.rmit.edu.au/document/view.php?id=137&version=1#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides rules to assess revenue and expenses recognition, as required by the relevant Accounting Standards and [Financial Management Act 1994](https://policies.rmit.edu.au/directory/summary.php?legislation=7) and supports the University’s [Financial Management Policy](https://policies.rmit.edu.au/document/view.php?id=70).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=137&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Financial Management Policy](https://policies.rmit.edu.au/document/view.php?id=70).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=137&version=1#document-top)
# Section 3 - Scope
(3)  This procedure applies to Finance staff and includes rules for general expenses that apply to all staff of the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=137&version=1#document-top)
# Section 4 - Procedure
### Authorisation of Revenue
(4)  Revenue is only recognised if: 
  1. authorised via an approved contract including government funding contracts; or 
  2. received as a donation. 


(5)  Contracts must only be signed on behalf of RMIT University by persons who are fully aware of the University’s obligation attached to the revenue received and in accordance with the [Delegations of Authority Policy](https://policies.rmit.edu.au/document/view.php?id=51). 
(6)  All contracts should be assessed by the Finance prior to finalisation to ensure there is clarity pertaining to the performance obligations and timing thereof.
### Recognition and Measurement
(7)  Revenue is recognised when (or as) a company transfers control of goods or services to a customer at the amount to which RMIT expects to be entitled or when cash is received. 
(8)  Depending on whether certain criteria are met, revenue is recognised either over time, in a manner that best reflects the company’s performance, or at a point in time, when control of the goods or services is transferred to the customer. 
(9)  The key criteria to be assessed are: 
  1. whether the contract is enforceable; and 
  2. whether the performance obligations are sufficiently specific. 


(10)  A five-step model is applied to determine when to recognise revenue, and at what amount. The model considers the following criteria: 
  1. identify the contract 
  2. identify the performance obligations 
  3. determine the transaction price 
  4. allocate the transaction price 
  5. recognise revenue. 


(11)  Where the underlying agreement relating to funding is primarily to further the University’s objectives and does not require the University to transfer any goods or services to a customer, income is recognised in the period when the cash is received. 
(12)  Where revenue is recognised over time it may be accounted for based on the input or output method of measurement. The nature of the performance obligations shall inform whether input or output method is used for revenue recognition.
### Application and Approval of Debtors
(13)  A [New Customer Request form](https://policies.rmit.edu.au/download.php?id=187&version=1&associated) must be completed by the relevant entity, school or department for all new non-research trade debtors. Such a request should be made, and a response received, before any goods or services have been provided to the customer. 
(14)  Accounts Receivable is responsible for notifying the applicant of any issues with the credit history of the proposed customer. The individual department is responsible for approving/rejecting the risk of dealing with any customers with poor credit history. 
(15)  If the application is approved subsequent to credit checks, the account will be created and the school/department will be advised of the customer number within two working days. 
(16)  Where a decision is made to deal with a customer that represents high risk to the University, the Deputy CFO Central Finance Operations or delegate must contra-sign the [New Customer Request form](https://policies.rmit.edu.au/download.php?id=187&version=1&associated). Risk will be borne by the applicant’s cost area. 
(17)  If it is recommended that a credit check be carried out by a University-appointed credit reporting agency, the cost will be charged to Central Finance Operations. 
(18)  Where a new trade debtor’s account is required based on the signed contract, the [New Customer Request form](https://policies.rmit.edu.au/download.php?id=187&version=1&associated) should be completed and submitted to Accounts Receivable. No further approval to create a customer is required.
### Review of Debtors and Setting Credit Limit 
(19)  A review of credit limits will be performed regularly by Central Finance Operations. The scope of review, undertaken at the time of application, is dependent upon the size of the credit limit required and the associated credit risk. 
(20)  Recommended checks based on the total contract value: 
  1. less than $25,000 – no credit check is required 
  2. from $25,001 to $50,000 – payment history analysis is required 
  3. from $50,001 to $250,000 – payment history and ASIC check is required 
  4. over $250,001 – full credit check report is required. 


(21)  Government agencies and departments are not subject to credit limits. 
### Invoicing Customers 
(22)  A [General Invoice Request Application form](https://policies.rmit.edu.au/download.php?id=188&version=1&associated) must be completed by the relevant entity, school or department. 
  1. An invoice must quote the customer’s purchase order or details of the contract to which the invoice relates. 
  2. If no purchase order or contract exists, the invoice request must be submitted with supporting documents and authorised in accordance with Delegations of Authority. 
  3. An invoice must provide the full name of the customer contact or be addressed to the customer’s accounts payable department. 


(23)  Where a customer requires a credit note: 
  1. a [Credit Memo Request Application form](https://policies.rmit.edu.au/download.php?id=189&version=1&associated) must be completed by the relevant entity, school or department 
  2. the credit note must refer to the original invoice and have reasons for credit amendments clearly stated. 


(24)  If a claim is made disputing part of the amount outstanding, the undisputed amount must be paid as per the credit terms. 
### Trading Terms
(25)  The trading terms for trade debtors are set up as per the relevant contract terms. A general trading term of 30 days from the date of the invoice is acceptable by the University. 
(26)  Accounts Receivable may propose restricted trading terms if a debtor does not comply with the University’s trading terms. 
(27)  Any customer whose account remains outstanding at 60 days from invoice date may be placed on ‘stop credit’ unless the customer disputes the account. 
(28)  A debtor who is on ‘stop credit’ with any University controlled entity may also be placed on ‘stop credit’ with all University controlled entities until overdue balances have been paid in full. 
(29)  The details of all inter-company charges are subject to compliance with separate service level agreements (SLAs), royalty agreements and international tax legislation. All queries related to inter-company charges must be directed to Central Finance Operations. 
### Expenses
(30)  Expenditure that has been paid and relates to a future financial period should be deferred and recognised in the future period/s to which the service relates (prepayments). Supporting documentation in the form of invoices and any other relevant documentation that assists for audit substantiation is required. 
(31)  Expenditure incurred but not yet recorded in the General Ledger must be accrued. Supporting documentation in the form of invoices and any other relevant documentation that assists for audit substantiation is required. Consideration should be given to the materiality of the accrual. 
(32)  A provision is recognised when future expenditure will be incurred to settle a present obligation, resulting from past events, and the amount can be reliably estimated at a balance date. 
  1. Provisions are measured at the present value of management’s best estimate of the future expenditure. 
  2. The Deputy CFO, Financial Control is responsible for reviewing provisions to ensure they are relevant and reflect the best estimates. 


(33)  Only authorised expenses as per grant agreements and contracts should be allocated to research projects. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=137&version=1#document-top)
# Section 5 - Definitions
(Note: Commonly defined terms are in the RMIT Policy Glossary. Any defined terms below are specific to this policy).
Expense | Expenses can be classified as operating expenses (OPEX) or capital expenditure (CAPEX).  
---|---  
Present value | Present value reflects current market assessment of the time, value of money and the risks specific to the liability.   
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
