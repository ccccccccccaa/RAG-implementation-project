[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=14&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=14&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > HDR Supervision Arrangements Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=14)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=14&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=14&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=14&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=14&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=14&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=14&version=2)


# HDR Supervision Arrangements Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=14&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=14&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=14&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=14&version=2#section4)
  * [Allocation of Supervisors](https://policies.rmit.edu.au/document/view.php?id=14&version=2#major1)
  * [Supervisor Registration](https://policies.rmit.edu.au/document/view.php?id=14&version=2#major2)
  * [Supervisory Teams](https://policies.rmit.edu.au/document/view.php?id=14&version=2#major3)
  * [Replacement/Change of Supervisor](https://policies.rmit.edu.au/document/view.php?id=14&version=2#major4)
  * [Review of HDR Supervision Performance](https://policies.rmit.edu.au/document/view.php?id=14&version=2#major5)
  * [Professional Development of Supervisors](https://policies.rmit.edu.au/document/view.php?id=14&version=2#major6)
  * [Reviews of Eligibility](https://policies.rmit.edu.au/document/view.php?id=14&version=2#major7)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=14&version=2#section5)
  * [Section 6 - Resources](https://policies.rmit.edu.au/document/view.php?id=14&version=2#section6)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  This procedure defines the processes for registering, appointing and replacing Higher Degree by Research (HDR) supervisors and supporting supervisor performance and professional development. The [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12) and the Supervision Code of Practice describe the responsibilities of HDR Supervisors.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=14&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Higher Degrees by Research Policy](https://policies.rmit.edu.au/document/view.php?id=12).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=14&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all staff responsible for the management and supervision of HDR candidates and all HDR candidates in the RMIT Group. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=14&version=2#document-top)
# Section 4 - Procedure
### Allocation of Supervisors
(4)  The Dean/Head of School is accountable for the allocation of supervisors to HDR candidates and the oversight of supervisor performance. 
(5)  The Dean/Head of School may choose to delegate aspects of their authority to the school HDR Delegated Authority (HDR DA).
(6)  The University will provide each candidate with a team of suitably qualified and registered supervisors with relevant expertise to support and guide them throughout the duration of their candidature. 
(7)  It is expected that supervisory teams will reflect the range of discipline expertise required for the project and will include a mix of early career and experienced researchers. Consideration should also be given to equity, diversity and inclusion, such as gender identity and cultural background. Indigenous candidates should have at least one Indigenous supervisor. 
(8)  A minimum of two (2) supervisors, at least one of whom is a senior supervisor, are allocated to each candidate on the basis that the supervisors:
  1. have relevant experience in the candidate’s research topic and sufficient supervisory capacity in their workload to provide high-quality support, 
  2. are willing to supervise the candidate,
  3. if senior supervisors, intend to supervise the candidate for the full period of candidature, and 
  4. have no potential, perceived or actual conflict of interest, in accordance with the RMIT [Conflict of Interest Policy](https://policies.rmit.edu.au/document/view.php?id=91), [Conflict of Interest Declaration and Management Procedure](https://policies.rmit.edu.au/document/view.php?id=90) and the [Australian Council of Graduate Research guidelines on conflict of interest](https://policies.rmit.edu.au/download.php?id=285&version=6&associated). For clarity, conflicts of interest to be avoided include line management of one supervisor by another, relationships of a close, personal nature (e.g. family or intimate relationship) and financial investment or commercial relationships. 


(9)  Allocation of a candidate’s supervisory team must be finalised before an offer of admission can be made. 
(10)  Where a candidate’s research project is pursued in the context of a formal agreement with a partner organisation, every effort shall be made to appoint an external supervisor associated with the partner organisation.
### Supervisor Registration
(11)  All supervisors must be accredited and listed on the RMIT supervisor register as either an internal or external supervisor before they can be allocated to candidates.
(12)  Supervisors apply to be registered via the online Supervisor Registration Form.
(13)  Recommendations for entry on the register for academic staff are made by the Dean/Head of School (or Deputy Vice-Chancellor for the registration of Deans/Heads of School). Non-affiliated academics and professional staff nominations should include endorsement from their line manager. All non-affiliated academics and professional staff will be aligned to an academic school.
(14)  The Supervisor Register is owned and maintained by the School of Graduate Research (SGR).
(15)  The Dean/Head of School may set up supervisor limits for their school, but these must not exceed the maximum supervisory load listed in [Schedule 1 – Supervisor Registration Requirements](https://policies.rmit.edu.au/download.php?id=290&version=1&associated). 
(16)  Application of a waiver to any of the criteria detailed in [Schedule 1](https://policies.rmit.edu.au/download.php?id=290&version=1&associated) must be recommended by the Dean/Head of School (or HDR DA) based on evidence of research and supervisory performance and/or capability, and approved by the ADVC RT&D or nominee.
### Supervisory Teams
(17)  The minimum requirements for a supervisory team are a senior supervisor and an associate supervisor per candidate. Teams may also be comprised of:
  1. two joint senior supervisors,
  2. one senior and several associate supervisors, or
  3. two joint senior supervisors and one or more associates.


(18)  The senior supervisor in the supervisory team provides the overall academic leadership to the candidate on their research project. 
(19)  Any major decisions concerning the academic direction of the candidates’ research require the agreement of both joint senior supervisors, where applicable.
(20)  One senior supervisor per team, who is affiliated to the candidate’s enrolling school, must take responsibility for candidature administration and compliance. 
(21)  Associate supervisors’ roles in the supervision of a candidate may vary, depending on the candidate’s supervisory requirements.
(22)  The combined supervisor contribution load per candidate must total 100%.
  1. The senior supervisor must have a minimum load of 40%, and a higher load than any associate supervisors.
  2. If there are two joint senior supervisors, they must have the same load (e.g., 50% each, or 40% each with an associate supervisor contributing 20%).
  3. The minimum associate supervisor contribution load is 10%.


(23)  The relative loads of each supervisor contribution allocated to an HDR candidate are recorded in the candidate record. 
(24)  HDR completions are a performance indicator used in the assessment of supervisor research performance and supervisor registration. At the point of thesis or dissertation submission, all members of a supervisory team receive recognition for any HDR completions to which they have contributed, regardless of load or role.
### Replacement/Change of Supervisor
(25)  Candidates may apply for a change to supervisory arrangements at any time, including during a Candidate Action and Support Plan (CASP). In doing so, they must seek the assistance of the HDR DA in identifying a suitable replacement supervisor(s). Where a candidate changes supervisory arrangements while on a CASP, the CASP remains in place. 
(26)  Applications for a change to supervisory arrangements may not be approved. 
(27)  HDR DAs may initiate a change to supervisory arrangements at any time. It is the HDR DA's responsibility to endorse and allocate a replacement supervisor in these circumstances. 
(28)  The ADVC RT&D or nominee may instruct a change of supervisor in cases where poor performance or concerns regarding staff conduct are identified.
(29)  To aid the allocation of replacement supervisors, supervisors should notify the HDR DA in advance if they are planning extended leave or a change to their employment arrangements that will affect their ability to supervise candidates.
(30)  If a supervisor is not able to supervise a candidate for a period exceeding six weeks and no alternative arrangements have been made, the HDR DA must put in place alternative supervisory arrangements for approval by the ADVC RT&D or nominee, in consultation with the candidate. Alternative arrangements may include:
  1. the appointment of a short-term replacement supervisor to cover any absence
  2. the re-weighting of roles within the supervisory team
  3. the designation of supervisor administrative responsibilities to another supervisory team member. 


(31)  Changes to supervisory teams and supervision weighting are notified via a Change of Supervisor Form, completed by the HDR DA. 
### Review of HDR Supervision Performance
(32)  Deans/Heads of School must ensure that line managers of HDR supervisors include supervision in performance and career planning, and review HDR supervision performance as part of annual work plan discussions. 
(33)  Supervisor performance will be considered during annual program reviews.
(34)  Deans/Heads of School or nominees, and the ADVC RT&D or nominee where appropriate, will review performance and compliance of individual supervisors when potential unsatisfactory performance is identified. Poor performance identified by a school should be reported to the ADVC RT&D or nominee.
(35)  One or more indicators may lead to a review of a supervision performance and poor performance will be addressed according to the intervention strategies detailed in [Schedule 2 – Potential Consequences of Unsatisfactory Supervision Performance](https://policies.rmit.edu.au/download.php?id=291&version=1&associated).
### Professional Development of Supervisors
(36)  All internal supervisors will be required to meet annual professional development requirements. Professional development requirements are detailed in Schedule 3 – Supervisor Professional Development. 
(37)  Failure to meet these requirements will be considered in the review of eligibility to supervise new candidates.
### Reviews of Eligibility
(38)  SGR reviews the eligibility of a supervisor whenever a new supervision is proposed.
(39)  SGR annually reviews compliance with registration requirements for all supervisors and ensures Deans/Heads of School or nominees are notified. 
(40)  Supervisors who are no longer eligible but who have a current load will enter a grace period of registration to enable them to fulfil their current obligations, subject to the satisfactory progress of current candidates. During this period they will be encouraged to meet ongoing eligibility requirements. Supervisors in a grace period will be ‘unavailable’ for new candidates.
(41)  Non-eligible supervisors without current candidates will be deregistered and will not allocated further candidates until they either:
  1. fulfil the eligibility requirements, or
  2. receive a waiver in accordance with this procedure.


(42)  SGR will return a supervisor to ‘active’ status, on receipt of evidence to support their eligibility. 
(43)  External supervisors with no current load will be deregistered.
(44)  Deregistration will occur:
  1. Where a supervisor has been inactive, with no candidates, for one year. SGR will deregister the supervisor and notify the Dean/Head of School or nominee.
  2. If a supervisor who has been an RMIT staff member leaves the University and no application to move to external registration is made.
  3. In certain circumstances where unsatisfactory supervision performance is established (refer to [Schedule 2](https://policies.rmit.edu.au/download.php?id=291&version=1&associated)) in which case, either the Dean/Head of School or ADVC RT&D or nominee may instruct deregistration. 


(45)  To reregister following deregistration, regardless of registration level, the prospective supervisor will need to apply for new registration subject to approval by the Dean/Head of School and the ADVC RT&D or nominee. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=14&version=2#document-top)
# Section 5 - Schedules
(46)  This procedure includes the following schedules:
  1. [Schedule 1 – Supervisor Registration Requirements](https://policies.rmit.edu.au/download.php?id=290&version=1&associated)
  2. [Schedule 2 – Potential Consequences of Unsatisfactory Supervision Performance](https://policies.rmit.edu.au/download.php?id=291&version=1&associated)
  3. [Schedule 3 – Supervisor Professional Development](https://policies.rmit.edu.au/download.php?id=336&version=1&associated)

[Top of Page](https://policies.rmit.edu.au/document/view.php?id=14&version=2#document-top)
# Section 6 - Resources
(47)  Refer to the following documents:
  1. Supervision Code of Practice
  2. [HDR Forms](https://policies.rmit.edu.au/download.php?id=68&version=2&associated)
    1. Change of Supervisor form
  3. Supervisor Registration Form 
    1. [Internal Supervisors](https://policies.rmit.edu.au/download.php?id=286&version=3&associated)
    2. [External Supervisors](https://policies.rmit.edu.au/download.php?id=287&version=2&associated)
  4. [Supervisor Intranet](https://rmiteduau.sharepoint.com/sites/Supervisorintranet)


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
