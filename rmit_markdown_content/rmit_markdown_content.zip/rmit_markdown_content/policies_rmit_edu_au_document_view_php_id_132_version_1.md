[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=132&version=1#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=132&version=1#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Credit Card Management Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=132)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=132&version=1)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=132&version=1)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=132&version=1)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=132&version=1)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=132&version=1)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=132&version=1)


# Credit Card Management Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=132&version=1#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=132&version=1#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=132&version=1#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=132&version=1#section4)
  * [Eligibility](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major1)
  * [Cardholder Responsibilities ](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major2)
  * [Change of Credit Limit ](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major3)
  * [Lost/Stolen cards ](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major4)
  * [Cancelling Cards ](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major5)
  * [Disputed Transactions](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major6)
  * [Authorising Officer](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major7)
  * [Transactions](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major8)
  * [Credit Card Acquittal ](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major9)
  * [Compliance Monitoring and Review ](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major10)
  * [Records Management ](https://policies.rmit.edu.au/document/view.php?id=132&version=1#major11)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides rules for the use of corporate credit cards and purchasing cards (PCards).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=132&version=1#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the Financial Management Policy.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=132&version=1#document-top)
# Section 3 - Scope
(3)  All card holders and their managers must comply with this procedure.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=132&version=1#document-top)
# Section 4 - Procedure
### Eligibility
(4)  The use of corporate credit cards and PCards is restricted to RMIT business purposes only. 
(5)  The maximum credit limit on the PCard is $25,000 per month, or higher if approved by the Chief Financial Officer (CFO) or Deputy CFO Central Finance Operations. 
(6)  The maximum credit limit on the corporate credit card is $10,000 per month or higher if approved by the CFO or Deputy CFO Central Finance Operations. 
(7)  A full time continuing or fixed-term employee may apply for a corporate card, subject to: 
  1. approval from their immediate manager, if the manager holds the appropriate level of financial delegation; or 
  2. a relevant financial delegate within the area. 


### Cardholder Responsibilities 
(8)  RMIT corporate cardholders have a responsibility to: 
  1. ensure the credit card is used in accordance with university policies and procedures, including the Business Expenses Policy 
  2. keep the credit card in a secure place 
  3. ensure that cost-effective purchases are made 
  4. acquit transactions for authorisation and ensure that a tax invoice is attached to each transaction 
  5. notify Central Finance Operations if going on extended leave (more than one month) and require the credit card for RMIT purposes during this period of absence; if no notification is received, the credit card will be set to zero limit to mitigate any potential fraudulent risk 
  6. appoint a delegate for coding and submitting transactions, where the cardholder will be absent during a statement acquittal period 
  7. notify CBA Card Services and Financial Control if the card is lost or stolen. 


(9)  The card must be returned immediately if: 
  1. requested by the cost centre manager 
  2. requested by Central Finance Operations 
  3. the cardholder leaves the University 
  4. the card is no longer required. 


### Change of Credit Limit 
(10)  Cardholders must complete a Cardholder Maintenance form for any change to credit limit adjustments including conversion to a PCard. 
(11)  The Head of School or the Service Area Manager is responsible for determining which staff will be PCard holders. 
### Lost/Stolen cards 
(12)  If a corporate credit card is either lost or stolen, the cardholder must immediately notify the Commonwealth Bank Card Services Centre and Financial Control. 
(13)  When CBA is advised of a lost or stolen card, a report number is allocated, which will be proof of the date and time of the report. The cardholder must record this number. CBA will place a stop on the card account and arrange for a replacement account to be established and a card to be forwarded. 
### Cancelling Cards 
(14)  Prior to cancellation, all transactions must be acquitted in the expense management system. Details of any other transactions that have not yet appeared in the system should be provided to a delegate. 
(15)  The card must be destroyed by cutting the card in two and a cancellation request must be submitted to Financial Control. 
(16)  Periodical direct debit transactions from corporate credit cards should only be set up in exceptional circumstances. The card holder is responsible for cancelling any purchases that are automatically direct debited from the credit card on a periodic basis (e.g. subscriptions or memberships for a department and not for individual use). 
(17)  If the cardholder is leaving RMIT, they must acquit all expenditure on their PCard and/or credit card prior to leaving. 
  1. The authorising officer must confirm that all expenses up until the last date of employment have been acquitted. 
  2. It is the responsibility of the authorising officer to confirm the final acquittal. 


### Disputed Transactions
(18)  Where a transaction appears on the corporate card statement that the cardholder has no record of, or believes that the expense has been charged twice, the merchant must be contacted for clarification and rectification of the charge as appropriate. 
(19)  If the dispute is still not resolved, a CBA Customer Investigation Request must be completed. 
(20)  Any fraudulent transactions must be disputed immediately 
(21)  Cardholders are responsible for ensuring that disputed transactions are submitted and processed within 30 days of the statement date in accordance with the bank’s guidelines. 
### Authorising Officer
(22)  The Authorising Officer is an immediate manager or a person in the portfolio/department with the relevant financial authority. 
(23)  The Authorising Officer has a responsibility to: 
  1. approve the issue of cards to staff under their supervision and determine appropriate monthly credit limits 
  2. ensure that applications for new cards or the reinstatement of existing cards are appropriately authorised 
  3. seek authorisation from CFO or Deputy CFO for corporate credit card limits over $10,000 per month and PCards over $25,000 per month 
  4. review and authorise credit card statements no later than 14 calendar days after the statement date 
  5. ensure entries in the expense management system are correct and complete and follow up with staff who fail to submit transactions within the monthly acquittal period 
  6. ensure expenditure complies with University policy and take corrective action as necessary 
  7. provide guidance and support to cardholders to ensure they have the ability and skills required to acquit transactions accurately and in a timely manner. 


### Transactions
(24)  A tax invoice must be obtained for all purchases. 
  1. If a tax invoice is not available for purchases greater than $82.50 (GST inclusive), a statutory declaration is required. 
  2. A credit card receipt is not a tax invoice. 


(25)  If a card holder or Authorising Officer has any doubt as to the correctness of corporate credit card use, they must contact Financial Control before the transaction is processed. 
(26)  The following is a list of transactions where the corporate credit should not be used, unless a prior relevant approval was obtained as listed in the processes below: 
  1. asset purchases; all assets should be purchased accordingly to PPE processes 
  2. airfare purchases; airfares should be booked according to the Travel processes using approved vendors 
  3. electronic equipment and software unless prior approval of CFO or Deputy CFO is obtained 
  4. fuel, unless the card holder can prove that fuel card was stolen or hasn’t arrived on time 
  5. toll charges, unless a departmental vehicle was used for an approved business purpose; the vehicle registration number must be quoted on supporting documentation 
  6. cash withdrawals, unless a credit card with cash withdrawals was approved by CFO or Deputy CFO in exceptional circumstances only 
  7. payments to other RMIT entities (these are processed as internal transfer of funds) 
  8. payments to Campus Store (e.g. for merchandise) 
  9. payments to consultants; there are particular approvals and reporting requirements for consultants and all payments must be processed through the relevant procurement system 
  10. gifts to staff members, except where prior approval from the Head of School/ Service Area Director (or equivalent) is obtained and the purchase is compliant with the Business Expenses Policy 
  11. personal expenses (where personal expenses form part of the same account as legitimate RMIT expenses the corporate credit card must only to be used for the RMIT portion of the account) 
  12. purchases over $5000
  13. where the supplier is registered in Workday
  14. more than one payment to the same supplier and the supplier is not registered in Workday.


### Credit Card Acquittal 
(27)  Cardholders or their authorised delegates must ensure credit card acquittal is completed within prescribed timeframes and in accordance with documented processes. 
  1. All transactions much be authorised 14 days after statement end date. Late acquittals are not acceptable. 
  2. Where a statement remains un-acquitted after 60 days, the card account will be suspended. 
  3. If the statement remains un-acquitted after 75 days, the card account will be cancelled. 


(28)  Details of statement dates and general ledger export dates will be made available on the [Finances](https://policies.rmit.edu.au/download.php?id=178&version=1&associated) website and will be updated on an annual basis. 
### Compliance Monitoring and Review 
(29)  The Deputy CFO Central Finance Operations is responsible for the implementation and maintenance of this procedure, and escalating trends of non-compliance within the University. 
(30)  The Deputy CFO Central Finance Operations has the authority to cancel credit cards if the cardholder has not followed any aspect of this or another related/relevant policy. 
(31)  The cardholder’s manager is responsible for monitoring compliance with this procedure and escalating non-compliance to the head of the department/school/college. 
### Records Management 
(32)  Records related to credit card and PCard transactions must be maintained in accordance with the [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and [Information Governance Policy](https://policies.rmit.edu.au/document/view.php?id=53).
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
