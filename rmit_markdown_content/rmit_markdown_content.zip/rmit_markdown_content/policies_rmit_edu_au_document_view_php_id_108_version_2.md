[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=108&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=108&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Travel Procedure - Students 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=108)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=108&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=108&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=108&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=108&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=108&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=108&version=2)


# Travel Procedure - Students
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=108&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=108&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=108&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=108&version=2#section4)
  * [Traveller Safety](https://policies.rmit.edu.au/document/view.php?id=108&version=2#major1)
  * [Arranging Travel (Domestic or International)](https://policies.rmit.edu.au/document/view.php?id=108&version=2#major2)
  * [Travel Insurance](https://policies.rmit.edu.au/document/view.php?id=108&version=2#major3)
  * [Student Conduct](https://policies.rmit.edu.au/document/view.php?id=108&version=2#major4)
  * [Section 5 - Resources](https://policies.rmit.edu.au/document/view.php?id=108&version=2#section5)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure sets out the requirements for students undertaking RMIT enrolment-related travel. It aims to minimise travel risk and promote student compliance.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Travel Policy](https://policies.rmit.edu.au/document/view.php?id=80).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all RMIT students (including HDR candidates) across the RMIT Group undertaking enrolment-related travel, including domestic and international travel by air and ground transportation.
(4)  The procedure covers:
  1. University organised travel
  2. student mobility programs, including exchange or study abroad placements, and global work placements and internships
  3. interstate or international [Work Integrated Learning](https://policies.rmit.edu.au/download.php?id=164&version=3&associated) (WIL) placements
  4. third-party organised travel.


(5)  It does not apply to students who are also staff members and are travelling in their capacity as a staff member
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=2#document-top)
# Section 4 - Procedure
### Traveller Safety
(6)  Students undertaking enrolment-related travel must comply with:
  1. RMIT policies, procedures and processes
  2. host institution or organisation policies and procedures (where applicable)
  3. any direction given by the Chief Operating Officer in the interest of safety
  4. any other directions given by RMIT on conduct and requirements for that travel
  5. any special conditions imposed by a scholarship or other funding body
  6. the [Civil Aviation Safety Authority advice for air travellers](https://policies.rmit.edu.au/download.php?id=113&version=4&associated)
  7. local laws of the state, country or countries in which they are travelling
  8. host country border entry requirements to ensure students have obtained the correct endorsement to enter, leave, or stay for a specified period of time.


(7)  Prior to travelling, students undertaking enrolment-related international travel must:
  1. register and provide all relevant travel documentation in [RMIT Global Learning portal](https://policies.rmit.edu.au/download.php?id=368&version=1&associated) and in [International SOS](https://policies.rmit.edu.au/download.php?id=117&version=2&associated), including itinerary details and any changes to travel
  2. complete the micro-credential module ‘[](https://policies.rmit.edu.au/download.php?id=116&version=1&associated)[Preparing for Learning Abroad](https://policies.rmit.edu.au/download.php?id=116&version=1&associated)’
  3. attend a comprehensive pre-departure briefing provided or arranged by the program coordinator
  4. if an Australian citizen, register for updates with [Smartraveller](https://policies.rmit.edu.au/download.php?id=115&version=1&associated) at the Australian Government website, and in the case of a crisis, register with the service so the Government can assist
  5. if a non-Australian citizen, register with a similar Government service from their home country.


(8)  Where group travel is a requirement of a student’s program, it is the responsibility of the program coordinator, prior to the travel, to:
  1. complete a risk assessment for the proposed international study program with assistance from the Global Learning team
  2. provide students with a pre-departure briefing or arrange for an appropriate briefing by relevant RMIT staff
  3. provide students with conditions of participation.


(9)  All student exchange partners and third-party providers related to student mobility are risk assessed by the Global Learning team prior to final approval of any agreement related to travel. This ensures appropriate and relevant guidance is provided for potential high-risk travel.
(10)  RMIT reserves the right to withdraw a student’s program or representation based on Government or International SOS travel advice. RMIT will not be liable for any expense incurred due to the cancellation of travel, and claims should be made through the student’s insurance.
(11)  RMIT students who are funding recipients or awardees of a Department of Foreign Affairs and Trade (DFAT) program, including, but not limited to Australian Volunteers, Australia Awards, New Colombo Plan, other DFAT-funded scholarship programs or grants, and students who are undertaking travel as part of a DFAT agreement must:
  1. have their program risk assessed by the RMIT business unit administering the DFAT program with the support of the Global Learning team
  2. receive the appropriate approvals prior to travel plans being made
  3. attend a pre-departure briefing
  4. sign conditions of participation
  5. attend a DFAT briefing if they are a New Colombo Plan scholarship recipient.


(12)  A student or staff member who has concerns or suspicions that a member of the RMIT Group has engaged in sexual exploitation, abuse or harassment while on travel must report their concerns to RMIT Safer Community or the Whistleblower hotline, [](https://policies.rmit.edu.au/download.php?id=30&version=1&associated)[Stopline](https://policies.rmit.edu.au/download.php?id=30&version=1&associated), within 48 hours of becoming aware of the incident.
### Arranging Travel (Domestic or International)
(13)  Where group travel is a requirement of a student’s program, RMIT may arrange the travel booking and in other circumstances the student will be responsible for booking their own travel program.
(14)  Whether or not RMIT is arranging the travel booking, the student is responsible for ensuring they have:
  1. sufficient funds
  2. necessary visas
  3. additional travel insurance if necessary (refer to the section below for RMIT insurance coverage)
  4. necessary immunisations
  5. COVID vaccinations if required
  6. fulfilled other requirements relevant to the travel arrangement
  7. researched additional requirements if their program is in a sanctioned country. More information on sanctions can be found on the website for the Australian governments sanctions regulator, the [](https://policies.rmit.edu.au/download.php?id=370&version=1&associated)[Australian Sanctions Office](https://policies.rmit.edu.au/download.php?id=370&version=1&associated).


(15)  For students under the age of 18 years, valid consent from their guardian or caregiver must be in place when arranging travel.
(16)  Students arranging their own travel must not book flights on the [EU Air Safety List](https://policies.rmit.edu.au/download.php?id=373&version=1&associated).
### Travel Insurance
(17)  All students undertaking enrolment-related travel receive complimentary travel insurance.
  1. This excludes any individual travel from an RMIT global campus or partner once they reach Australia or domestic travel that is less than 50km from the students point of origin.
  2. This insurance covers cancellations, delays, lost luggage, theft, hire car excess cover, and some other nonmedical expenses.
  3. Medical insurance is covered for international travel emergencies only.


### Student Conduct
(18)  Students are bound by the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) and [Student Charter](https://policies.rmit.edu.au/download.php?id=74&version=1&associated) while undertaking enrolment-related travel.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=108&version=2#document-top)
# Section 5 - Resources
(19)  Refer to the following documents:
  1. [DFAT Risk Guidance Note on Preventing Sexual Exploitation, Abuse or Harassment](https://policies.rmit.edu.au/download.php?id=372&version=1&associated)
  2. [Student Travel Risk Escalation Matrix](https://rmiteduau.sharepoint.com/:w:/s/GRP-Short-termProgramsTeamTEST/ERSM7wzU5x5EtJnwGIdpTmABOt29rnBNgeExoskp-bwPjg?e=akhIT7&wdLOR=cAE6A3C16-1588-4F13-962E-273885DF88F8), which lists approvers of overseas activities for students travelling in countries identified as high risk.


Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
