[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=127&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=127&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Credit Procedure - Masters Advanced Standing 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=127)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=127&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=127&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=127&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=127&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=127&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=127&version=2)


# Credit Procedure - Masters Advanced Standing
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=127&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=127&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=127&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=127&version=2#section4)
  * [Masters Advanced Standing](https://policies.rmit.edu.au/document/view.php?id=127&version=2#major1)
  * [Program Guide](https://policies.rmit.edu.au/document/view.php?id=127&version=2#major2)
  * [Combinations of Advanced Standing and Credit Transfer](https://policies.rmit.edu.au/document/view.php?id=127&version=2#major3)
  * [Section 5 - Schedules](https://policies.rmit.edu.au/document/view.php?id=127&version=2#section5)
  * [Schedule 1 – Masters Advanced Standing Credit Point Values](https://policies.rmit.edu.au/document/view.php?id=127&version=2#major4)


This is the current version of this document. You can provide feedback on this policy document by navigating to the Feedback tab.
# Section 1 - Context
(1)  This procedure provides the rules for the granting of advanced standing towards masters by coursework.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=127&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Credit Policy](https://policies.rmit.edu.au/document/view.php?id=126).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=127&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to students wishing to apply for, and staff assessing applications for, advanced standing towards masters by coursework.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=127&version=2#document-top)
# Section 4 - Procedure
### Masters Advanced Standing
(4)  Advanced standing may be granted for masters by coursework programs via credit processes and may reduce the overall program duration. 
(5)  Advanced standing may be assessed at admission or after enrolment but cannot be granted after a student has attempted the courses. 
(6)  Advanced standing may be available for masters by coursework based on:
  1. qualifications at AQF 7 or above in the same discipline or degree specialisation; or
  2. qualifications at AQF 7 or above in a different discipline or degree specialisation where a minimum of 2 years relevant industry experience is also held.


(7)  The granting of advanced standing is subject to satisfaction of the following recency requirements and exceptions:
  1. Qualifications described at cl 6(a) 
    1. An applicant must have completed the qualification within a 10 year period immediately preceding commencement of the masters program for which the credit is sought;
    2. Where an applicant’s qualification was completed outside of the 10 year period, and there is evidence of ongoing professional work and/or professional development in the discipline of the masters program for which the credit is sought, the recency requirement will be satisfied.
  2. Qualifications and experience described at cl 6(b) 
    1. The recency requirement will be satisfied where an applicant’s relevant industry experience is considered to be equivalent to ongoing professional work and/or professional development in the discipline of the masters program for which the credit is sought.
  3. The Programs Committee may approve exceptions to recency requirements within cl 7(a) and (b) for specific programs (program level) by either removing them or instating a shorter period of recency. Exceptions must be stated in the articulation and pathways section of the program guide. 


(8)  The previous award an application is based on does not have to be conferred to be considered for advanced standing but the student must provide satisfactory evidence that they completed the program requirements. 
(9)  Advanced standing may be available for qualifications completed outside Australia if they are assessed as equivalent to AQF level 7 or above. 
(10)  Students may be granted advanced standing in a program for only one previous qualification. 
(11)  Students may not receive both advanced standing and credit transfer using one previous qualification. 
(12)  Advanced standing is not transferrable to a graduate diploma or graduate certificate even if it is an exit award from the masters program. 
  1. Where an applicant only wishes to take out the graduate certificate or graduate diploma they should gain entry to the appropriate level of study and apply for credit to the maximum allowable limit. 


(13)  The recommended advanced standing amounts are presented in Schedule 1 – Masters Advanced Standing Credit Point Values. 
### Program Guide
(14)  The program guide informs applicants and students of masters by coursework about any advanced standing that may be available in a program and includes the: 
  1. credit point amount of advanced standing 
  2. disciplines of previous study that advanced standing may be available for, and 
  3. volume of study that will remain after advanced standing has been applied. 


(15)  If a professionally accredited masters requires a minimum program duration, advanced standing must not reduce the duration below that minimum. These limits will be stated in program guides and marketing summary pages. 
(16)  Applications for advanced standing may not be granted if the program guide does not specify the possibility for advanced standing.
  1. If an individual’s application for advanced standing is granted, the program guide must be updated and applications from other students in the same intake must be considered. 


### Combinations of Advanced Standing and Credit Transfer
(17)  If an applicant presents two qualifications that may be the basis for advanced standing, the selection officer should apply whatever combination of advanced standing and/or credit transfer that will give the applicant the greatest reduction in their volume of learning. 
For example, where an applicant presents a same-discipline AQF level 7 bachelor degree, and a same-discipline AQF level 8 graduate diploma, the selection officer should consider whether the applicant will benefit most from granting 48 credit points of advanced standing for the bachelor degree, plus credit transfer from the graduate diploma; or from 96 credit points of advanced standing for the graduate diploma.
(18)  Eligible applications for advanced standing are assessed as part of the admissions process. Applicants are required to apply for credit transfer separately if they are eligible for credit transfer in addition to advanced standing. 
(19)  Masters advanced standing reduces the total volume of learning in a student’s program. The remaining volume of learning becomes the basis for maximum amounts of credit in accordance with Schedule 1. 
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=127&version=2#document-top)
# Section 5 - Schedules
### Schedule 1 – Masters Advanced Standing Credit Point Values
(20)  Recommended advanced standing amounts refers to the number of credit points an applicant may receive based on their completed qualification when entering the masters program. 
(21)  Maximum credit points after advanced standing refers to the number of credit points an applicant is eligible to receive after receiving the advanced standing. 
#### 192 Credit Point 2-Year Masters Programs 
Qualification  |  AQF level  |  Recommended advanced standing amounts  |  Maximum credit points after advanced standing   
---|---|---|---  
Bachelor degree  |  AQF level 7  |  48 credit points  |  72 credit points   
Bachelor degree (Hons)  |  AQF level 8  |  96 credit points  |  48 credit points   
Graduate certificate  |  AQF level 8  |  48 credit points  |  72 credit points   
Graduate diploma  |  AQF level 8  |  96 credit points  |  48 credit points   
Master degree  |  AQF level 9  |  96 credit points  |  48 credit points   
PhD  |  AQF level 10  |  96 credit points  |  48 credit points   
#### 144 Credit Point 1.5-year Masters Programs 
Qualification  |  AQF level  |  Recommended advanced standing amounts  |  Maximum credit amounts after advanced standing   
---|---|---|---  
Bachelor degree  |  AQF level 7  |  0 credit points  |  72 credit points   
Bachelor degree (Hons)  |  AQF level 8  |  48 credit points  |  48 credit points   
Graduate certificate  |  AQF level 8  |  0 credit points  |  72 credit points   
Graduate diploma  |  AQF level 8  |  48 credit points  |  48 credit points   
Master degree  |  AQF level 9  |  48 credit points  |  48 credit points   
PhD  |  AQF level 10  |  48 credit points  |  48 credit points   
#### Masters Programs Less Than 1.5 Years and 144 Credit Points
Qualification  |  AQF level  |  Exemption amounts  |  Maximum credit after advanced standing   
---|---|---|---  
Bachelor degree  |  AQF level 7  |  0 credit points  |  Normal 50% credit limit applies  
Bachelor degree (Hons)  |  AQF level 8   
Graduate certificate  |  AQF level 8   
Graduate diploma  |  AQF level 8   
Master degree  |  AQF level 9   
PhD  |  AQF level 10   
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
