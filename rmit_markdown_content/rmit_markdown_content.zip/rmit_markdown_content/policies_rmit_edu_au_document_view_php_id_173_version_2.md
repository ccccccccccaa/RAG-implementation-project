[Jump to Navigation](https://policies.rmit.edu.au/document/view.php?id=173&version=2#jump-navigation) [Jump to Content](https://policies.rmit.edu.au/document/view.php?id=173&version=2#jump-content)
[](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


Menu
  * [Home](https://policies.rmit.edu.au/)
  * [Home](https://policies.rmit.edu.au/home.php)
  * [Browse A-Z](https://policies.rmit.edu.au/browse.php)
  * [Search](https://policies.rmit.edu.au/search.php)
  * [Bulletin Board](https://policies.rmit.edu.au/bulletin.php)
  * [Discussion Board](https://policies.rmit.edu.au/discussion-board.php)
  * [Glossary](https://policies.rmit.edu.au/glossary.php)
  * [FAQs](https://policies.rmit.edu.au/faq.php)


[Admin Login](https://policies.rmit.edu.au/admin) [Policy Register](https://policies.rmit.edu.au/) > [Document](https://policies.rmit.edu.au/document.php) > Student Safety Measures Procedure 
View Document
  * [Current Version](https://policies.rmit.edu.au/document/view.php?id=173)
  * [Status and Details](https://policies.rmit.edu.au/document/status-and-details.php?id=173&version=2)
  * [Associated Information](https://policies.rmit.edu.au/document/associated-information.php?id=173&version=2)
  * [Historic Versions](https://policies.rmit.edu.au/document/view-historic.php?id=173&version=2)
  * [Future Versions](https://policies.rmit.edu.au/document/view-future.php?id=173&version=2)
  * [Print](https://policies.rmit.edu.au/document/print.php?id=173&version=2)
  * [Feedback](https://policies.rmit.edu.au/document/feedback.php?id=173&version=2)


# Student Safety Measures Procedure
Hide Navigation
  * [Section 1 - Context](https://policies.rmit.edu.au/document/view.php?id=173&version=2#section1)
  * [Section 2 - Authority](https://policies.rmit.edu.au/document/view.php?id=173&version=2#section2)
  * [Section 3 - Scope](https://policies.rmit.edu.au/document/view.php?id=173&version=2#section3)
  * [Section 4 - Procedure](https://policies.rmit.edu.au/document/view.php?id=173&version=2#section4)


This is not a current document. To view the current version, click the link in the document's navigation bar.
# Section 1 - Context
(1)  The purpose of this procedure is to identify and support students whose behaviour may pose a risk to the health and safety of themselves and/or other students or staff. It provides a framework for the effective, safe, consistent, and timely identification and management of fitness for study concerns and protects the student, staff, other students, placement providers and the University.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=173&version=2#document-top)
# Section 2 - Authority
(2)  Authority for this document is established by the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97).
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=173&version=2#document-top)
# Section 3 - Scope
(3)  This procedure applies to all students within the RMIT Group, including:
  1. students on approved leave of absence and students who have allowed their enrolment to lapse
  2. students studying through Open Universities Australia (OUA) or other third-party providers of RMIT courses and programs
  3. students studying RMIT programs at global partner institutions
  4. higher degree by research (HDR) students, including those who have submitted work for examination
  5. graduands or past students, and
  6. students in single courses.


(4)  This policy applies to students who are also staff of RMIT.
(5)  Where a person who is the subject of a safety review is a student as well as an RMIT staff member, their fitness for work may also be considered under the relevant staff procedure.
[Top of Page](https://policies.rmit.edu.au/document/view.php?id=173&version=2#document-top)
# Section 4 - Procedure
#### Identifying behaviours representing grounds for concern
(6)  RMIT is required to take reasonably practical steps to reduce or eliminate risk where it is notified that a student or a student’s circumstances gives rise to a likelihood of physical or psychological harm to themselves or to another student, staff or community member.
  1. Examples of behaviours or circumstances that might require RMIT to take action to reduce or eliminate risk include: 
    1. reported behaviour or circumstances involving risk of harm that is likely to recur, or where multiple reports involving risk of harm have been received about the same student
    2. behaviour or circumstances that may give rise to a risk to the student’s own health or safety
    3. behaviour or circumstances that may give rise to a risk to other students or staff
    4. behaviour or circumstances that may give rise to harm to or damage of property, assets or infrastructure.


#### Reporting and Initial Action
(7)  Where there is an emergency or an immediate risk of harm, staff should seek urgent assistance via:
  1. emergency services and RMIT Security, for RMIT Australia. RMIT Security will assist in coordinating personal safety of staff and students, responding to property damage or theft, or referral to a Critical Incident Management Team.
  2. the relevant local authority, for offshore campuses and partners.


(8)  RMIT staff, students, supervisors or other members of the University community who consider that a student’s behaviour or circumstances represents grounds for concern about risk to their or others’ safety must make a report to
  1. the Health, Safety and Wellbeing team via PRIME as a confidential incident, and/or
  2. directly to Safer Community.


(9)  The responding person will triage the response to the relevant team/s to:
  1. notify the Director, Health Safety and Wellbeing and the relevant Senior Officer
  2. coordinate timely and adequate support to the student and any other students or staff impacted
  3. conduct a risk assessment to determine the level or type of investigation or action required which may include: 
    1. a HSW investigation
    2. a SASH investigation
    3. a referral to Student Conduct
  4. initiate the case management process if required
  5. determine whether it is safe for the student to retain access to campus or safely engage with RMIT activities, while investigations or other risk management steps are being undertaken
  6. determine whether a Critical Incident Management Team notification need to be made.


#### Student Safety Case Management
(10)  The objective of case management is to support the student in their pathway back to health in order to continue their study in a manner that is safe for them and those who interact with them.
(11)  Cases managed under this procedure will be coordinated by a suitably qualified staff member, nominated by the Director, Health Safety and Wellbeing, who will lead a team that may include representatives from:
  1. Safer Community
  2. a student wellbeing specialist from the Students group
  3. the Academic Registrar's Group
  4. a staff wellbeing specialist from the Health, Safety and Wellbeing team
  5. the People Business Partner for the relevant School or entity where staff are impacted
  6. a senior officer from the relevant School or entity.


(12)  Depending on the circumstances of the student, the team may also include:
  1. School of Graduate Research (for HDR students)
  2. Child Safety advisor where the matter involves a person who is under 18 years of age
  3. Ngarara Willim Centre (for Aboriginal and Torres Strait Islander students)
  4. any other team which may be appropriate for the purposes of scoping and managing the relevant risks.


(13)  Once a case manager has been appointed to the case the case manager must:
  1. at the earliest appropriate opportunity discuss or communicate the concern with the relevant student. The student may wish to have a support person or responsible adult attend with them
  2. consider the student’s perception of their behaviour or circumstances, and the response of the student to any steps taken by the University to manage the situation
  3. identify existing support and adjustments that may be provided to the student in order to address the relevant risks
  4. Identify any ongoing support or adjustments required for staff or other students
  5. Notify the key stakeholders as required, which may include: 
    1. [Equitable Learning Services](https://policies.rmit.edu.au/download.php?id=52&version=1&associated)
    2. Director Research Training Services, School of Graduate Research
    3. Associate Director Integrity and Assessment Support, Academic Registrar's Group
    4. Security
    5. People Business Partner.


#### High-Risk Behaviours
(14)  A high-risk behaviour or circumstance is one where, without significant change or other controls, there is a risk of physical or psychological injury to either the student of concern or those that work or study in the same environment.
(15)  The case manager may recommend certain precautionary measures in response to a report of harm, to protect the wellbeing and safety of all students, staff and third parties, and where there may be an ongoing risk to the broader RMIT community. The case manager will consult with the relevant areas of RMIT in implementing appropriate precautionary measures, including Safer Community, Health, Safety and Wellbeing, Risk, [Compliance](https://policies.rmit.edu.au/download.php?id=147&version=1&associated), the Academic Registrar's Group, Legal Services, Policy and Workplace Relations.
(16)  Precautionary measures that can be implemented by the Safer Community team may include but are not limited to:
  1. changes to class timetables
  2. temporary remote learning arrangements
  3. temporary restriction of access to campus
  4. academic adjustments
  5. no contact directives
  6. a recommendation regarding an executive suspension, in accordance with the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35).


(17)  Any direction under this provision should be limited initially to seven days but may be extended for a further seven days if additional time is required for an investigation or other risk mitigation activities to be completed.
#### Reports or notifications to the Police
(18)  If a person who has experienced harm wants to make a report to the Police, Safer Community can support a person to make a police report but cannot make a police report on that person’s behalf.
(19)  However, in certain circumstances, RMIT may have a duty to notify the Police, in its own name. This includes where the incident involves a risk to students, or staff; or where the person who is the subject of the disclosure or report to presents a risk to themself.
  1. RMIT may have this obligation to notify the Police even if the discloser or person making a report to RMIT does not want to make their own report to the Police.
  2. a notification to the Police by RMIT in its own name must be approved by the Chief Operating Officer (if the respondent is a staff member) and Academic Registrar (if the respondent is a student) taking into account: 
    1. evidence of an unacceptable risk to RMIT’s community, or the public
    2. multiple disclosures, reports, or complaints about the same person
    3. advice from the Critical Incident Management Team, and other relevant groups including Policy and Workplace Relations, Risk, [Compliance](https://policies.rmit.edu.au/download.php?id=147&version=1&associated) and the Academic Registrar's Group
    4. advice from Safer Community
    5. the wishes of the person who has experienced the harm or who made the disclosure or report initially.


(20)  Safer Community will advise the person who has disclosed or reported the harm about RMIT’s decision to notify the Police and (to the extent possible) will keep the person informed of any actions that result from that notification.
#### Health, Safety and Wellbeing Investigation and Outcomes
(21)  Where a health, safety and wellbeing investigation is undertaken to better understand the relevant risks and causes and the inform appropriate actions, an ICAM (Incident Cause Analysis Method) investigation may be used to identify causative factors, or failures within organisations, systems or communications and to provide recommendations directed at preventing recurrence.
(22)  The investigation should cover the specific student behaviours or circumstances, the risk and the impact or potential impact on the physical or psychological safety of other students or staff.
(23)  Recommendations from investigations could include both an organisational response and actions required of individuals, including the student of concern. Recommendations could include but are not limited to:
  1. requiring an external threat assessment to inform risk management actions for cases involving complex mental illness and behaviours which pose risk to psychological or physical safety of the student themselves or others
  2. requiring that the student provide medical evidence from a suitably qualified specialist to determine their fitness to study or participate other activities, including placements or attendance at campus. Where the student is not already under the care of an appropriate medical specialist, RMIT may direct the student to attend an Independent Medical Examination (IME)
  3. commencing action a referral under the [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35) for potential misconduct
  4. making a recommendation to the Academic Registrar that an executive suspension be initiated in accordance with the [Student Conduct Regulations](https://policies.rmit.edu.au/document/view.php?id=180) and [Student Conduct Policy](https://policies.rmit.edu.au/document/view.php?id=35)
  5. taking steps to prepare and make a report to Police
  6. making a recommendation to the Academic Registrar that adjustments are required to a student’s enrolment including applying a leave of absence.


(24)  Once the recommendations have been assessed and actions agreed by the Director, Health Safety and Wellbeing:
  1. the student must receive a written copy of the decision in plain, accessible language, including a detailed description of why the university has reached that decision, the information it considered in making the decision and any avenues for review or appeal.
  2. the case manager will work with the student to develop an action and support plan that will detail the steps required of both the student and RMIT to return to study (if required).


#### Records, Privacy and Confidentiality
(25)  All persons involved in Student Safety Measure matters initiated under the [Health, Safety and Wellbeing Policy](https://policies.rmit.edu.au/document/view.php?id=97) and corresponding procedures must maintain confidentiality in order to ensure the integrity of the proceedings and outcomes, and the privacy of all persons involved. This requirement does not limit the exercise of student academic freedoms associated with university operations upon the formal conclusion of safety review proceedings.
(26)  Advocates and support persons are bound by the same confidentiality requirements as all other persons involved in student or staff conduct proceedings.
(27)  Where personal medical information of the student is presented it must be managed in accordance with the Health Records Act 2001 (Vic). Access to this information will be limited to those people who require it to make a decision about the case.
(28)  RMIT recognises the importance of maintaining confidentiality to ensure safety and will seek to balance this with procedural fairness. This may mean that the identities of persons who are witnesses are not disclosed to a respondent student where it might give rise to a risk to safety or wellbeing. Different approaches to confidentiality may also apply where a matter involves persons who are under 18 years of age, in accordance with the [Child Safe Policy](https://policies.rmit.edu.au/document/view.php?id=213).
(29)  Records and information regarding student safety matters will be managed in accordance with RMIT’s [Privacy Policy](https://policies.rmit.edu.au/document/view.php?id=59) and the information management policies and procedures.
Copyright © 2025 RMIT University |
[Terms ](https://www.rmit.edu.au/utilities/terms) |
[Privacy ](https://www.rmit.edu.au/utilities/privacy) |
[Accessibility ](https://www.rmit.edu.au/utilities/accessibility) |
[Complaints ](https://www.rmit.edu.au/utilities/complaints) |
ABN 49 781 030 034 |
CRICOS provider number: 00122A |
TEQSA provider number: PRV12145 |
RTO Code: 3046 |
[Open Universities Australia ](https://www.open.edu.au/online-courses/rmit-university)
[](https://www.facebook.com/RMITuniversity/)
[ ](https://twitter.com/rmit)
[ ](https://www.instagram.com/rmituniversity/)
[ ](https://www.linkedin.com/school/rmit-university/)
[ ](https://www.youtube.com/user/rmitmedia)
[ ](https://www.weibo.com/rmituni)
